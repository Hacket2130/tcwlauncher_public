import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path

os.environ["TCW_DATABASE_PATH"] = str(Path(tempfile.gettempdir()) / "tcw-profile-test.sqlite3")
os.environ["TCW_PLAYER_DATA_ROOT"] = str(Path(tempfile.gettempdir()) / "tcw-profile-test-players")
os.environ["TCW_EVENTS_PATH"] = str(Path(tempfile.gettempdir()) / "tcw-profile-test-events.json")
os.environ["TCW_AVATAR_ROOT"] = str(Path(tempfile.gettempdir()) / "tcw-profile-test-avatars")
os.environ["TCW_MARKETPLACE_PATH"] = str(Path(tempfile.gettempdir()) / "tcw-profile-test-marketplace.json")

import server  # noqa: E402


class ProgressionTests(unittest.TestCase):
    def setUp(self):
        if server.DATABASE_PATH.exists():
            server.DATABASE_PATH.unlink()
        if server.PLAYER_DATA_ROOT.exists():
            shutil.rmtree(server.PLAYER_DATA_ROOT)
        if server.EVENTS_PATH.exists():
            server.EVENTS_PATH.unlink()
        if server.MARKETPLACE_PATH.exists():
            server.MARKETPLACE_PATH.unlink()
        if server.AVATAR_ROOT.exists():
            shutil.rmtree(server.AVATAR_ROOT)
        server.initialize_database()

    def test_level_curve(self):
        self.assertEqual(server.level_for_xp(0), 1)
        self.assertEqual(server.level_for_xp(499), 1)
        self.assertEqual(server.level_for_xp(500), 2)
        self.assertEqual(server.level_for_xp(2000), 3)

    def test_profile_and_achievements(self):
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                ("76561198000000000", 'CT-2130 "Hacket"'),
            )
            db.execute(
                "INSERT INTO stats (steam_id, kills, credits, xp, missions) VALUES (?, 10, 1000, 8000, 10)",
                ("76561198000000000",),
            )
            unlocked = server.unlock_achievements(db, "76561198000000000")
            profile = server.profile_for(db, "76561198000000000")
        self.assertIn("first_blood", unlocked)
        self.assertIn("seasoned_10", unlocked)
        self.assertEqual(profile["display_name"], 'CT-2130 "Hacket"')
        self.assertGreaterEqual(profile["level"], 5)
        self.assertEqual(profile["avatar_id"], server.DEFAULT_AVATAR_ID)
        self.assertEqual(profile["inventory"], [])

    def test_avatar_catalog_and_profile_selection(self):
        steam_id = "76561198000000005"
        server.AVATAR_ROOT.mkdir(parents=True, exist_ok=True)
        (server.AVATAR_ROOT / "104th-wolfpack.png").write_bytes(b"png")
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, avatar_id, verified_at, created_at, updated_at) VALUES (?, ?, ?, 1, 1, 1)",
                (steam_id, "CT Wolfpack", "104th-wolfpack"),
            )
            db.execute("INSERT INTO stats (steam_id) VALUES (?)", (steam_id,))
            profile = server.profile_for(db, steam_id)
        catalog_ids = [avatar["id"] for avatar in server.avatar_catalog()]

        self.assertIn(server.DEFAULT_AVATAR_ID, catalog_ids)
        self.assertIn("104th-wolfpack", catalog_ids)
        self.assertEqual(profile["avatar_id"], "104th-wolfpack")
        self.assertTrue(profile["avatar_url"].endswith("/104th-wolfpack.png"))

    def test_contextual_geonosis_awards_and_snapshot(self):
        steam_id = "76561198000000000"
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                (steam_id, "CT Geonosis"),
            )
            db.execute("INSERT INTO stats (steam_id) VALUES (?)", (steam_id,))
            values = {stat: 0 for stat in server.EVENT_STAT_LIMITS}
            values.update({"missions": 1, "kills": 2, "enemy_kills": 2, "friendly_kills": 3, "deaths": 20})
            event = {
                "event_id": "geo-1",
                "steam_id": steam_id,
                "map": "Geonosis",
                "event_type": "mission_end",
                "mission_stats": {"deaths": 20, "enemy_kills": 2, "friendly_kills": 3},
            }
            contextual, progress = server.achievement_context_for_event(
                event,
                values,
                server.GEONOSIS_LAUNCH_WEEK_START + 60,
            )
            db.execute(
                """
                UPDATE stats
                   SET kills = ?, deaths = ?, missions = ?, droid_kills = ?,
                       friendly_kills = ?, geonosis_missions = ?,
                       friendly_fire_missions = ?, high_death_missions = ?
                 WHERE steam_id = ?
                """,
                (
                    values["kills"], values["deaths"], values["missions"], values["enemy_kills"],
                    values["friendly_kills"], progress["geonosis_missions"],
                    progress["friendly_fire_missions"], progress["high_death_missions"], steam_id,
                ),
            )
            unlocked = server.unlock_achievements(db, steam_id, contextual)
            repeated = server.unlock_achievements(db, steam_id, contextual)
            server.safe_write_player_profile_snapshot(db, steam_id)

        self.assertIn("geonosis_not_shiny_for_long", unlocked)
        self.assertIn("droid_bait", unlocked)
        self.assertIn("same_team", unlocked)
        self.assertIn("welcome_to_the_front", unlocked)
        self.assertEqual(repeated, [])
        snapshot = server.PLAYER_DATA_ROOT / steam_id / "achievements.json"
        self.assertTrue(snapshot.exists())
        snapshot_payload = json.loads(snapshot.read_text(encoding="utf-8"))
        self.assertEqual(snapshot_payload["steam_id"], steam_id)
        self.assertEqual(len([item for item in snapshot_payload["achievements"] if item["id"] == "droid_bait"]), 1)
        self.assertTrue((server.PLAYER_DATA_ROOT / steam_id / "inventory.json").exists())

    def test_marketplace_purchase_is_backend_authoritative(self):
        steam_id = "76561198000000002"
        server.MARKETPLACE_PATH.write_text(
            json.dumps(
                {
                    "items": [
                        {
                            "id": "orange-pauldrons",
                            "category": "custom_armour",
                            "name": "Orange Pauldrons",
                            "description": "Approved armour cosmetic.",
                            "cost": 250,
                            "class_name": "TCW_Armor_OrangePauldron",
                        }
                    ]
                }
            ),
            encoding="utf-8",
        )
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                (steam_id, "CT Store"),
            )
            db.execute("INSERT INTO stats (steam_id, credits) VALUES (?, 300)", (steam_id,))
            status, result = server.purchase_marketplace_item(db, steam_id, "orange-pauldrons")
            repeated_status, repeated = server.purchase_marketplace_item(db, steam_id, "orange-pauldrons")
            profile = server.profile_for(db, steam_id)

        self.assertEqual(status, server.HTTPStatus.OK)
        self.assertEqual(result["purchase"]["class_name"], "TCW_Armor_OrangePauldron")
        self.assertEqual(profile["credits"], 50)
        self.assertEqual(profile["inventory"][0]["item_id"], "orange-pauldrons")
        self.assertEqual(repeated_status, server.HTTPStatus.CONFLICT)
        self.assertEqual(repeated["error"], "already_owned")

    def test_kamino_and_master_scrapper_awards_are_one_time(self):
        steam_id = "76561198000000001"
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                (steam_id, "CT Kamino"),
            )
            db.execute("INSERT INTO stats (steam_id, droid_kills, kamino_visits) VALUES (?, 1000, 1)", (steam_id,))
            unlocked = server.unlock_achievements(db, steam_id)
            repeated = server.unlock_achievements(db, steam_id)

        self.assertIn("kamino_shiny", unlocked)
        self.assertIn("master_scrapper", unlocked)
        self.assertEqual(repeated, [])

    def test_public_profiles_bio_and_recent_squadmates(self):
        first = "76561198000000010"
        second = "76561198000000011"
        hidden = "76561198000000012"
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, unit, rank, bio, profile_public, verified_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, 1, 1, 10)",
                (first, "CT First", "104th", "Trooper", "Frontline lore"),
            )
            db.execute(
                "INSERT INTO users (steam_id, display_name, unit, rank, bio, profile_public, verified_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, 1, 1, 20)",
                (second, "CT Second", "501st", "Sergeant", "Squadmate lore"),
            )
            db.execute(
                "INSERT INTO users (steam_id, display_name, unit, rank, bio, profile_public, verified_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 0, 1, 1, 30)",
                (hidden, "CT Hidden", "104th", "Trooper", "Hidden lore"),
            )
            for steam_id in [first, second, hidden]:
                db.execute("INSERT INTO stats (steam_id, xp, missions) VALUES (?, 500, 1)", (steam_id,))
            db.execute(
                "INSERT INTO server_events (event_id, official_server, steam_id, payload_json, received_at) VALUES (?, ?, ?, '{}', ?)",
                ("recent-a", "geonosis", first, 1000),
            )
            db.execute(
                "INSERT INTO server_events (event_id, official_server, steam_id, payload_json, received_at) VALUES (?, ?, ?, '{}', ?)",
                ("recent-b", "geonosis", second, 1100),
            )
            db.execute(
                "INSERT INTO server_events (event_id, official_server, steam_id, payload_json, received_at) VALUES (?, ?, ?, '{}', ?)",
                ("recent-hidden", "geonosis", hidden, 1100),
            )

            public_profiles = server.list_public_profiles(db, "", "active")
            unit_profiles = server.list_public_profiles(db, "104th", "legion")
            recent = server.recently_played_with(db, first)

        self.assertEqual([profile["steam_id"] for profile in public_profiles], [second, first])
        self.assertEqual([profile["steam_id"] for profile in unit_profiles], [first])
        self.assertEqual([profile["steam_id"] for profile in recent], [second])
        self.assertEqual(server.clean_profile_bio("x" * 700), "x" * server.MAX_PROFILE_BIO_CHARS)

    def test_release_manifest_sha256_cleanup(self):
        digest = "a" * 64
        manifest = server.clean_release_manifest(
            {
                "sha256": digest.lower(),
                "downloads": {
                    "windows": {
                        "url": "https://tcwa3.co.uk/downloads/TCW-Launcher-Windows.zip",
                        "installer_url": "https://tcwa3.co.uk/downloads/TCW-Launcher-Windows.zip",
                        "sha256": "not-a-real-digest",
                    }
                },
            }
        )
        self.assertEqual(manifest["sha256"], digest.upper())
        self.assertEqual(manifest["downloads"]["windows"]["sha256"], "")

    def test_news_payload_cleanup(self):
        payload = server.clean_news_payload(
            {
                "items": [
                    {
                        "title": "Long title " * 20,
                        "body": "Mission update",
                        "date": "2026-06-19",
                        "priority": "3",
                    },
                    {"title": "Higher Priority", "body": "First in launcher", "priority": 10},
                ]
            }
        )
        self.assertEqual(payload["items"][0]["title"], "Higher Priority")
        self.assertLessEqual(len(payload["items"][1]["title"]), 80)

    def test_news_payload_requires_items(self):
        with self.assertRaises(ValueError):
            server.clean_news_payload({"items": []})

    def test_event_payload_cleanup_and_active_manifest(self):
        payload = server.save_events_payload(
            {
                "events": [
                    {
                        "title": "+20% XP Weekend",
                        "description": "Bonus XP for launch weekend.",
                        "active": True,
                        "priority": 10,
                        "accent_color": "#d9b36c",
                        "background_color": "#070b12",
                        "effect": "pulse",
                        "xp_bonus_percent": 20,
                    },
                    {
                        "title": "Inactive old event",
                        "active": False,
                        "xp_bonus_percent": 500,
                    },
                ]
            }
        )
        manifest = server.load_event_manifest()
        bonus, event_ids = server.active_event_xp_bonus(server.now())

        self.assertEqual(payload["events"][0]["id"], "20-xp-weekend")
        self.assertEqual(len(manifest["events"]), 1)
        self.assertEqual(manifest["modifiers"]["xp_bonus_percent"], 20)
        self.assertEqual(bonus, 20)
        self.assertEqual(event_ids, ["20-xp-weekend"])
        self.assertEqual(server.apply_xp_bonus(100, bonus), 120)

    def test_event_dates_filter_future_and_ended_banners(self):
        current_time = 1_800_000_000
        server.save_events_payload(
            {
                "events": [
                    {"title": "Live", "start_at": "2026-01-01T00:00:00Z", "end_at": "2030-01-01T00:00:00Z"},
                    {"title": "Future", "start_at": "2035-01-01T00:00:00Z"},
                    {"title": "Ended", "end_at": "2020-01-01T00:00:00Z"},
                ]
            }
        )
        active = server.load_event_banners(timestamp=current_time)

        self.assertEqual([event["title"] for event in active], ["Live"])

    def test_audio_manifest_scans_named_categories(self):
        with tempfile.TemporaryDirectory() as temp_root:
            original_root = server.AUDIO_ROOT
            original_base = server.AUDIO_BASE_URL
            try:
                server.AUDIO_ROOT = Path(temp_root)
                server.AUDIO_BASE_URL = "https://tcwa3.co.uk/audio"
                music_dir = server.AUDIO_ROOT / "menu_music"
                sounds_dir = server.AUDIO_ROOT / "menu_sounds"
                radio_dir = server.AUDIO_ROOT / "holonet_radio"
                music_dir.mkdir(parents=True)
                sounds_dir.mkdir(parents=True)
                radio_dir.mkdir(parents=True)
                (music_dir / "republic march.mp3").write_bytes(b"mp3")
                (sounds_dir / "button click.mp3").write_bytes(b"mp3")
                (radio_dir / "holonet bulletin.mp3").write_bytes(b"mp3")
                (radio_dir / "ignore.txt").write_text("not audio", encoding="utf-8")

                manifest = server.load_audio_manifest()
            finally:
                server.AUDIO_ROOT = original_root
                server.AUDIO_BASE_URL = original_base

        self.assertEqual(manifest["categories"]["menu_music"]["tracks"][0]["title"], "Republic March")
        self.assertEqual(manifest["categories"]["menu_sounds"]["tracks"][0]["category"], "menu_sounds")
        self.assertEqual(len(manifest["categories"]["holonet_radio"]["tracks"]), 1)
        self.assertTrue(manifest["categories"]["holonet_radio"]["tracks"][0]["url"].endswith("holonet_radio/holonet%20bulletin.mp3"))

    def test_theme_manifest_loads_custom_theme_assets(self):
        with tempfile.TemporaryDirectory() as temp_root:
            original_root = server.THEME_ROOT
            original_base = server.THEME_BASE_URL
            try:
                server.THEME_ROOT = Path(temp_root)
                server.THEME_BASE_URL = "https://tcwa3.co.uk/themes"
                theme_dir = server.THEME_ROOT / "104th"
                (theme_dir / "backgrounds").mkdir(parents=True)
                (theme_dir / "logo.png").write_bytes(b"png")
                (theme_dir / "backgrounds" / "wolfpack.png").write_bytes(b"png")
                (theme_dir / "theme.json").write_text(
                    json.dumps(
                        {
                            "id": "104th",
                            "name": "104th Wolfpack",
                            "description": "Wolfpack legion theme.",
                            "accent_color": "#9aa4ad",
                            "logo": "logo.png",
                            "backgrounds": ["backgrounds/wolfpack.png", "../secret.png"],
                        }
                    ),
                    encoding="utf-8",
                )

                manifest = server.load_theme_manifest()
            finally:
                server.THEME_ROOT = original_root
                server.THEME_BASE_URL = original_base

        custom = [theme for theme in manifest["themes"] if theme["id"] == "104th"][0]
        self.assertEqual(custom["name"], "104th Wolfpack")
        self.assertEqual(len(custom["backgrounds"]), 1)
        self.assertTrue(custom["logo_url"].endswith("/104th/logo.png"))

    def test_community_manager_audio_upload_and_delete(self):
        with tempfile.TemporaryDirectory() as temp_root, tempfile.TemporaryDirectory() as temp_bin:
            original_root = server.AUDIO_ROOT
            original_base = server.AUDIO_BASE_URL
            original_bin = server.ASSET_BIN_ROOT
            try:
                server.AUDIO_ROOT = Path(temp_root)
                server.AUDIO_BASE_URL = "https://tcwa3.co.uk/audio"
                server.ASSET_BIN_ROOT = Path(temp_bin)
                track = server.save_audio_upload("holonet_radio", "briefing report.mp3", b"mp3")
                inventory = server.load_community_asset_inventory()
                binned = server.delete_audio_asset("holonet_radio", "briefing report.mp3")
                bin_inventory = server.load_community_asset_inventory()["bin"]
                binned_file_exists = binned is not None and (Path(temp_bin) / binned["bin_path"]).exists()
            finally:
                server.AUDIO_ROOT = original_root
                server.AUDIO_BASE_URL = original_base
                server.ASSET_BIN_ROOT = original_bin

        self.assertEqual(track["title"], "Briefing Report")
        self.assertEqual(track["category"], "holonet_radio")
        self.assertEqual(len(inventory["audio"]["holonet_radio"]["tracks"]), 1)
        self.assertFalse((Path(temp_root) / "holonet_radio" / "briefing report.mp3").exists())
        self.assertIsNotNone(binned)
        self.assertEqual(binned["kind"], "audio")
        self.assertTrue(binned_file_exists)
        self.assertIn("backend_asset_archive/community_assets/audio/holonet_radio", binned["github_archive_path"])
        self.assertEqual(len(bin_inventory["items"]), 1)

    def test_community_manager_theme_upload_and_delete(self):
        with tempfile.TemporaryDirectory() as temp_root, tempfile.TemporaryDirectory() as temp_bin:
            original_root = server.THEME_ROOT
            original_base = server.THEME_BASE_URL
            original_bin = server.ASSET_BIN_ROOT
            try:
                server.THEME_ROOT = Path(temp_root)
                server.THEME_BASE_URL = "https://tcwa3.co.uk/themes"
                server.ASSET_BIN_ROOT = Path(temp_bin)
                theme = server.save_theme_upload("104th", "104th Wolfpack", "background", "wolfpack.png", b"png")
                inventory = server.load_community_asset_inventory()
                binned = server.delete_theme_asset("104th", "backgrounds/wolfpack.png")
                manifest = json.loads((server.THEME_ROOT / "104th" / "theme.json").read_text(encoding="utf-8"))
                binned_file_exists = binned is not None and (Path(temp_bin) / binned["bin_path"]).exists()
            finally:
                server.THEME_ROOT = original_root
                server.THEME_BASE_URL = original_base
                server.ASSET_BIN_ROOT = original_bin

        self.assertEqual(theme["id"], "104th")
        self.assertEqual(theme["name"], "104th Wolfpack")
        self.assertEqual(len(theme["backgrounds"]), 1)
        self.assertEqual(len(inventory["themes"][0]["background_assets"]), 1)
        self.assertEqual(manifest["backgrounds"], [])
        self.assertIsNotNone(binned)
        self.assertEqual(binned["kind"], "images")
        self.assertTrue(binned_file_exists)
        self.assertIn("backend_asset_archive/community_assets/images/104th", binned["github_archive_path"])

    def test_community_manager_theme_metadata_save(self):
        with tempfile.TemporaryDirectory() as temp_root:
            original_root = server.THEME_ROOT
            original_base = server.THEME_BASE_URL
            try:
                server.THEME_ROOT = Path(temp_root)
                server.THEME_BASE_URL = "https://tcwa3.co.uk/themes"
                theme = server.save_theme_metadata(
                    {
                        "theme_id": "104th",
                        "theme_name": "104th Wolfpack",
                        "description": "Wolfpack legion theme.",
                        "accent_color": "#9aa4ad",
                        "panel_color": "#05090f",
                        "text_color": "#f8fafc",
                    }
                )
                saved = json.loads((server.THEME_ROOT / "104th" / "theme.json").read_text(encoding="utf-8"))
            finally:
                server.THEME_ROOT = original_root
                server.THEME_BASE_URL = original_base

        self.assertEqual(theme["id"], "104th")
        self.assertEqual(theme["name"], "104th Wolfpack")
        self.assertEqual(theme["accent_color"], "#9AA4AD")
        self.assertEqual(theme["panel_color"], "#05090F")
        self.assertEqual(theme["text_color"], "#F8FAFC")
        self.assertEqual(saved["description"], "Wolfpack legion theme.")

    def test_community_manager_rejects_unsafe_asset_paths(self):
        with tempfile.TemporaryDirectory() as temp_root:
            with self.assertRaises(ValueError):
                server.resolve_public_child(Path(temp_root), "../secret.png")
            with self.assertRaises(ValueError):
                server.safe_asset_filename("payload.exe", server.AUDIO_EXTENSIONS)

    def test_youtube_feed_parser(self):
        feed = b"""<?xml version="1.0" encoding="UTF-8"?>
        <feed xmlns="http://www.w3.org/2005/Atom"
              xmlns:yt="http://www.youtube.com/xml/schemas/2015"
              xmlns:media="http://search.yahoo.com/mrss/">
          <entry>
            <yt:videoId>Ct7sYna3wU0</yt:videoId>
            <title>The Clone Wars | Arma-3 - The First Battle of Geonosis Trailer</title>
            <published>2026-06-14T13:00:13+00:00</published>
            <link rel="alternate" href="https://www.youtube.com/watch?v=Ct7sYna3wU0" />
            <media:group>
              <media:thumbnail url="https://i.ytimg.com/vi/Ct7sYna3wU0/hqdefault.jpg" />
            </media:group>
          </entry>
        </feed>"""
        video = server.parse_youtube_feed(feed)
        self.assertTrue(video["available"])
        self.assertEqual(video["video_id"], "Ct7sYna3wU0")
        self.assertIn("mute=1", video["embed_url"])
        self.assertEqual(video["thumbnail_url"], "https://i.ytimg.com/vi/Ct7sYna3wU0/hqdefault.jpg")


if __name__ == "__main__":
    unittest.main()
