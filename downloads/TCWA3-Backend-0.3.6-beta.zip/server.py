#!/usr/bin/env python3
"""TCW Launcher profile and progression API.

Dependency-free by design. HTTPS should be terminated by a reverse proxy.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import html
import json
import math
import os
import re
import secrets
import shutil
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


def parse_env_utc_timestamp(name: str, default_value: str) -> int:
    value = os.getenv(name, default_value).strip() or default_value
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        parsed = datetime.fromisoformat(default_value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return int(parsed.astimezone(timezone.utc).timestamp())


DATABASE_PATH = Path(os.getenv("TCW_DATABASE_PATH", "/srv/tcw-launcher/data/tcw.sqlite3"))
PLAYER_DATA_ROOT = Path(os.getenv("TCW_PLAYER_DATA_ROOT", "/srv/tcw-launcher/data/players"))
PUBLIC_BASE_URL = os.getenv("TCW_PUBLIC_BASE_URL", "").rstrip("/")
WEB_BASE_URL = os.getenv("TCW_WEB_BASE_URL", "https://tcwa3.co.uk").rstrip("/")
BIND_HOST = os.getenv("TCW_BIND_HOST", "127.0.0.1")
PORT = int(os.getenv("TCW_PORT", "8080"))
SQUAD_XML_URL = os.getenv(
    "TCW_SQUAD_XML_URL",
    "https://arma-stats.root-storm.com/public/squads/tcwa3/squad.xml",
)
ROSTER_SYNC_SECONDS = int(os.getenv("TCW_ROSTER_SYNC_SECONDS", "900"))
NEWS_PATH = Path(os.getenv("TCW_NEWS_PATH", "/srv/tcw-launcher/data/news.json"))
EVENTS_PATH = Path(os.getenv("TCW_EVENTS_PATH", "/srv/tcw-launcher/data/events.json"))
MARKETPLACE_PATH = Path(os.getenv("TCW_MARKETPLACE_PATH", "/srv/tcw-launcher/data/marketplace.json"))
AUDIO_ROOT = Path(os.getenv("TCW_AUDIO_ROOT", "/srv/tcw-launcher/public/audio"))
AUDIO_BASE_URL = os.getenv("TCW_AUDIO_BASE_URL", "https://tcwa3.co.uk/audio").rstrip("/")
THEME_ROOT = Path(os.getenv("TCW_THEME_ROOT", "/srv/tcw-launcher/public/themes"))
THEME_BASE_URL = os.getenv("TCW_THEME_BASE_URL", "https://tcwa3.co.uk/themes").rstrip("/")
AVATAR_ROOT = Path(os.getenv("TCW_AVATAR_ROOT", "/srv/tcw-launcher/public/avatars"))
AVATAR_BASE_URL = os.getenv("TCW_AVATAR_BASE_URL", "https://tcwa3.co.uk/avatars").rstrip("/")
ASSET_BIN_ROOT = Path(os.getenv("TCW_ASSET_BIN_ROOT", "/srv/tcw-launcher/data/asset_bin"))
ASSET_BIN_RETENTION_SECONDS = int(os.getenv("TCW_ASSET_BIN_RETENTION_SECONDS", str(7 * 86400)))
RELEASE_PATH = Path(os.getenv("TCW_RELEASE_PATH", "/srv/tcw-launcher/release.json"))
SESSION_DAYS = int(os.getenv("TCW_SESSION_DAYS", "365"))
DEFAULT_CORS_ORIGINS = "https://tcwa3.co.uk,https://www.tcwa3.co.uk"
ALLOWED_CORS_ORIGINS = {
    origin.strip().rstrip("/")
    for origin in os.getenv("TCW_CORS_ORIGINS", DEFAULT_CORS_ORIGINS).split(",")
    if origin.strip()
}
NEWS_ADMIN_TOKEN = os.getenv("TCW_NEWS_ADMIN_TOKEN", "")
COMMUNITY_MANAGER_TOKEN = os.getenv("TCW_COMMUNITY_MANAGER_TOKEN", "")
COMMUNITY_MANAGER_MAX_FILE_BYTES = int(os.getenv("TCW_COMMUNITY_MANAGER_MAX_FILE_BYTES", str(50 * 1024 * 1024)))
YOUTUBE_HANDLE = os.getenv("TCW_YOUTUBE_HANDLE", "TheCloneWarsArma-3").strip().lstrip("@")
YOUTUBE_CHANNEL_ID = os.getenv("TCW_YOUTUBE_CHANNEL_ID", "").strip()
YOUTUBE_CACHE_SECONDS = int(os.getenv("TCW_YOUTUBE_CACHE_SECONDS", "900"))
STEAM_WEB_API_KEY = os.getenv("STEAM_WEB_API_KEY", "").strip()
STEAM_NAME_CACHE_SECONDS = int(os.getenv("TCW_STEAM_NAME_CACHE_SECONDS", "86400"))
GEONOSIS_LAUNCH_WEEK_START = parse_env_utc_timestamp("TCW_GEONOSIS_LAUNCH_WEEK_START", "2026-06-22T00:00:00Z")
GEONOSIS_LAUNCH_WEEK_END = parse_env_utc_timestamp("TCW_GEONOSIS_LAUNCH_WEEK_END", "2026-06-29T00:00:00Z")
DEVICE_CODE_TTL = 600
MAX_BODY_BYTES = 1024 * 1024
STEAM_OPENID = "https://steamcommunity.com/openid/login"
STEAM_ID_PATTERN = re.compile(r"^7656119\d{10}$")
PROFILE_NAME_PATTERN = re.compile(r"[^\w\-\[\]()\"' .#]", re.UNICODE)

STAT_LIMITS = {
    "kills": 5_000,
    "deaths": 5_000,
    "credits": 1_000_000,
    "xp": 1_000_000,
    "missions": 100,
    "playtime_seconds": 172_800,
}

EVENT_STAT_LIMITS = {
    **STAT_LIMITS,
    "droid_kills": 5_000,
    "enemy_kills": 5_000,
    "friendly_kills": 5_000,
}

PROGRESSION_STAT_COLUMNS = {
    "droid_kills": "INTEGER NOT NULL DEFAULT 0",
    "friendly_kills": "INTEGER NOT NULL DEFAULT 0",
    "kamino_visits": "INTEGER NOT NULL DEFAULT 0",
    "geonosis_missions": "INTEGER NOT NULL DEFAULT 0",
    "friendly_fire_missions": "INTEGER NOT NULL DEFAULT 0",
    "high_death_missions": "INTEGER NOT NULL DEFAULT 0",
    "perfect_missions": "INTEGER NOT NULL DEFAULT 0",
}

ACHIEVEMENT_COLUMNS = {
    "acknowledged_at": "INTEGER",
}

ACHIEVEMENTS = {
    "first_blood": {"name": "First Blood", "description": "Record your first confirmed kill."},
    "trooper_10": {"name": "Battle Ready", "description": "Record 10 confirmed kills."},
    "veteran_100": {"name": "Veteran of the Republic", "description": "Record 100 confirmed kills."},
    "first_deployment": {"name": "First Deployment", "description": "Complete your first official deployment."},
    "seasoned_10": {"name": "Seasoned Trooper", "description": "Complete 10 official deployments."},
    "credit_1000": {"name": "Quartermaster's Friend", "description": "Earn 1,000 credits."},
    "level_5": {"name": "Rising Through the Ranks", "description": "Reach level 5."},
    "geonosis_not_shiny_for_long": {
        "name": "Not shiny for long - the battle of geonosis",
        "description": "Complete a Geonosis mission during the first launch week.",
    },
    "kamino_shiny": {"name": "Shiny", "description": "Play on any Kamino hub world."},
    "droid_bait": {"name": "Droid bait", "description": "Die 20 times in the same mission."},
    "master_scrapper": {"name": "Master scrapper", "description": "Destroy 1,000 droids."},
    "same_team": {
        "name": "We're on the same team!",
        "description": "Finish a mission with more friendly kills than enemy kills.",
    },
    "welcome_to_the_front": {"name": "Welcome to the front", "description": "Complete your first TCWA3 mission."},
    "roger_roger": {"name": "Roger roger remover", "description": "Destroy 100 droids."},
    "hold_the_line": {"name": "Hold the line", "description": "Complete 5 official missions."},
    "survivor": {"name": "Still standing", "description": "Complete a mission without dying."},
    "veteran_of_geonosis": {"name": "Veteran of Geonosis", "description": "Complete 5 Geonosis missions."},
    "payday": {"name": "Republic payday", "description": "Earn 10,000 credits."},
}

DEFAULT_DISPLAY_NAME = "Clone trooper"
GENERIC_DISPLAY_NAMES = {"Unknown", "Unknown Steam", "Unknown Trooper", DEFAULT_DISPLAY_NAME}
MAX_PROFILE_BIO_CHARS = 600
DEFAULT_AVATAR_ID = "tcw-standard"
DEFAULT_AVATAR_NAME = "TCW Standard"
DEFAULT_AVATAR_URL = f"{WEB_BASE_URL}/assets/default-profile-avatar.png"
AVATAR_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}

USER_PROFILE_COLUMNS = {
    "bio": "TEXT NOT NULL DEFAULT ''",
    "profile_public": "INTEGER NOT NULL DEFAULT 1",
    "avatar_id": f"TEXT NOT NULL DEFAULT '{DEFAULT_AVATAR_ID}'",
}

DEFAULT_NEWS = [
    {
        "title": "Profiles Online",
        "body": "TCW launcher profiles are now connected to api.tcwa3.co.uk.",
        "date": "2026-06-18",
        "priority": 10,
    },
    {
        "title": "Galaxy Map",
        "body": "The campaign galaxy map is available from the launcher.",
        "date": "2026-06-18",
        "priority": 8,
    },
    {
        "title": "Stats Tracking",
        "body": "Official server stat tracking is being prepared for Root Storm integration.",
        "date": "2026-06-18",
        "priority": 5,
    },
]

DEFAULT_EVENTS: list[dict[str, Any]] = []
EVENT_EFFECTS = {"none", "glow", "pulse", "scanline", "urgent"}

MARKETPLACE_CATEGORIES = [
    {
        "id": "customisations",
        "name": "Customisations",
        "description": "Visual and identity extras for player expression.",
    },
    {
        "id": "custom_armour",
        "name": "Custom Armour",
        "description": "Approved armour options that can be granted through the kit system.",
    },
    {
        "id": "unique_items",
        "name": "Unique Items",
        "description": "Rare or event-specific rewards controlled by TCW staff.",
    },
    {
        "id": "rp_items",
        "name": "RP Items",
        "description": "Roleplay utility items for official TCW scenarios.",
    },
]

DEFAULT_MARKETPLACE = {
    "categories": MARKETPLACE_CATEGORIES,
    "items": [],
}

AUDIO_CATEGORIES = {
    "menu_music": {
        "label": "Menu Music",
        "directory": "menu_music",
        "description": "Background tracks for the launcher main menu.",
    },
    "menu_sounds": {
        "label": "Menu Sounds",
        "directory": "menu_sounds",
        "description": "Short UI button sounds played by the launcher.",
    },
    "holonet_radio": {
        "label": "Holonet Radio",
        "directory": "holonet_radio",
        "description": "Longer MP3 tracks players can cycle through in the Holonet radio box.",
    },
}
AUDIO_EXTENSIONS = {".mp3"}
THEME_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}
THEME_ASSET_TYPES = {"background", "logo"}

DEFAULT_THEMES = [
    {
        "id": "tcw_standard",
        "name": "TCW Standard",
        "description": "The current TCWA3 launcher look.",
        "built_in": True,
    },
    {
        "id": "dark",
        "name": "Dark",
        "description": "A simple dark presentation theme.",
        "built_in": True,
    },
    {
        "id": "light",
        "name": "Light",
        "description": "A simple light presentation theme.",
        "built_in": True,
    },
]

DEFAULT_RELEASE = {
    "version": "0.3.6-beta",
    "channel": "beta",
    "title": "TCW Launcher 0.3.6 Beta",
    "summary": "Launcher profile layout polish, empty-store lockout, server-browser overlay cleanup, rank/unit display, community systems, profile sign-in, events, audio, server status, and launcher fixes online.",
    "mandatory": False,
    "download_url": "",
    "installer_url": "",
    "sha256": "",
    "notes": [
        "Keeps launcher profile cards visible and moves the compact card higher above the server heading.",
        "Scales the expanded military record panel inside the launcher window and allows the detailed profile content to scroll cleanly.",
        "Greys out the launcher store entry until approved marketplace items are live.",
        "Keeps main launcher panels out of the server browser and restores them when players return to the menu.",
        "Backend-powered server status, community news, events, audio, and Steam-linked profiles remain online.",
    ],
    "published_at": "2026-06-21",
    "downloads": {
        "windows": {
            "url": "",
            "installer_url": "",
            "sha256": "",
        },
        "linux": {
            "url": "",
            "sha256": "",
        },
    },
}

YOUTUBE_CACHE_LOCK = threading.Lock()
YOUTUBE_CACHE_EXPIRES = 0.0
YOUTUBE_LATEST_CACHE: dict[str, Any] = {}
YOUTUBE_DISCOVERED_CHANNEL_ID = ""
STEAM_NAME_CACHE_LOCK = threading.Lock()
STEAM_NAME_CACHE: dict[str, tuple[float, str]] = {}


def now() -> int:
    return int(time.time())


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def level_for_xp(xp: int) -> int:
    return 1 + math.isqrt(max(0, xp) // 500)


def next_level_xp(level: int) -> int:
    return 500 * max(1, level) ** 2


def clean_profile_name(value: Any) -> str:
    name = PROFILE_NAME_PATTERN.sub("", str(value or "")).strip()
    return name[:64] or DEFAULT_DISPLAY_NAME


def is_generic_display_name(value: Any) -> bool:
    return str(value or "").strip() in GENERIC_DISPLAY_NAMES


def public_display_name(value: Any) -> str:
    name = str(value or "").strip()
    if not name or is_generic_display_name(name):
        return DEFAULT_DISPLAY_NAME
    return name


def clean_profile_bio(value: Any) -> str:
    """Keep player-written lore readable and harmless for public profile views."""
    bio = str(value or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    bio = re.sub(r"\n{3,}", "\n\n", bio)
    return bio[:MAX_PROFILE_BIO_CHARS]


def bounded_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def event_container_values(event: dict[str, Any], keys: tuple[str, ...]) -> list[str]:
    values: list[str] = []
    for key in keys:
        value = event.get(key)
        if isinstance(value, dict):
            for nested_key in ("name", "map", "world", "terrain", "mission", "mission_name", "server_name"):
                nested_value = value.get(nested_key)
                if nested_value:
                    values.append(str(nested_value))
        elif value:
            values.append(str(value))
    return values


def event_location_text(event: dict[str, Any]) -> str:
    fields = ("map", "world", "terrain", "mission", "mission_name", "server_name", "location", "context")
    return " ".join(event_container_values(event, fields)).lower()


def event_has_location(event: dict[str, Any], location_name: str) -> bool:
    return location_name.lower() in event_location_text(event)


def clean_campaign_text(value: Any, fallback: str, limit: int = 96) -> str:
    text = PROFILE_NAME_PATTERN.sub("", str(value or "")).strip()
    text = re.sub(r"\s+", " ", text)
    return (text or fallback)[:limit]


def event_named_value(event: dict[str, Any], keys: tuple[str, ...]) -> str:
    for key in keys:
        value = event.get(key)
        if isinstance(value, dict):
            for nested_key in ("display_name", "title", "name", "mission_name", "map", "world", "terrain"):
                nested_value = value.get(nested_key)
                if nested_value:
                    return str(nested_value)
        elif value:
            return str(value)
    return ""


def campaign_for_event(event: dict[str, Any]) -> dict[str, str]:
    """Map official server event context into the player-facing campaign log."""
    if event_has_location(event, "geonosis"):
        return {"id": "battle_of_geonosis", "name": "The Battle of Geonosis", "planet": "Geonosis"}
    if event_has_location(event, "kamino"):
        return {"id": "kamino_training", "name": "Kamino Training Rotation", "planet": "Kamino"}
    location = clean_campaign_text(
        event_named_value(event, ("planet", "location", "map", "world", "terrain", "server_name")),
        "Unknown Front",
        48,
    )
    campaign_id = re.sub(r"[^a-z0-9]+", "_", location.lower()).strip("_") or "tcwa3_campaign"
    campaign_name = "TCWA3 Campaign" if location == "Unknown Front" else f"{location} Campaign"
    return {"id": campaign_id[:64], "name": campaign_name[:96], "planet": location}


def mission_name_for_event(event: dict[str, Any], campaign: dict[str, str]) -> str:
    mission_name = event_named_value(
        event,
        (
            "deployment_name",
            "operation_name",
            "mission_name",
            "scenario_name",
            "mission",
            "operation",
            "briefing_name",
        ),
    )
    fallback = f"Official {campaign['planet']} deployment" if campaign.get("planet") else "Official deployment"
    return clean_campaign_text(mission_name, fallback, 112)


def event_boolean(event: dict[str, Any], keys: tuple[str, ...]) -> bool:
    for key in keys:
        value = event.get(key)
        if isinstance(value, bool):
            return value
        if isinstance(value, str) and value.strip().lower() in {"1", "true", "yes", "complete", "completed"}:
            return True
    return False


def event_mission_completed(event: dict[str, Any], values: dict[str, int]) -> bool:
    event_type = str(event.get("event_type") or event.get("type") or event.get("kind") or "").strip().lower()
    completion_types = {"mission_complete", "mission_completed", "mission_end", "deployment_complete", "deployment_completed"}
    return values.get("missions", 0) > 0 or event_type in completion_types or event_boolean(
        event,
        ("mission_completed", "mission_complete", "deployment_complete", "completed"),
    )


def mission_stat_value(event: dict[str, Any], values: dict[str, int], keys: tuple[str, ...]) -> int:
    containers = [event.get("mission_stats"), event.get("round_stats"), event.get("stats"), event.get("mission")]
    for container in containers:
        if not isinstance(container, dict):
            continue
        for key in keys:
            if key in container:
                return bounded_int(container.get(key))
    for key in keys:
        if key in event:
            return bounded_int(event.get(key))
        if key in values:
            return values[key]
    return 0


def achievement_context_for_event(event: dict[str, Any], values: dict[str, int], timestamp: int) -> tuple[list[str], dict[str, int]]:
    """Return one-mission awards and stat increments from a signed server event."""
    mission_completed = event_mission_completed(event, values)
    mission_deaths = mission_stat_value(event, values, ("mission_deaths", "deaths"))
    enemy_kills = mission_stat_value(event, values, ("enemy_kills", "droid_kills", "kills"))
    friendly_kills = mission_stat_value(event, values, ("friendly_kills", "team_kills"))
    has_mission_stat_context = mission_completed or isinstance(event.get("mission_stats"), dict) or isinstance(event.get("round_stats"), dict)

    contextual: list[str] = []
    progress = {
        "kamino_visits": 0,
        "geonosis_missions": 0,
        "friendly_fire_missions": 0,
        "high_death_missions": 0,
        "perfect_missions": 0,
    }
    if event_has_location(event, "kamino"):
        contextual.append("kamino_shiny")
        progress["kamino_visits"] = 1
    if mission_completed and event_has_location(event, "geonosis"):
        progress["geonosis_missions"] = 1
        if GEONOSIS_LAUNCH_WEEK_START <= timestamp < GEONOSIS_LAUNCH_WEEK_END:
            contextual.append("geonosis_not_shiny_for_long")
    if has_mission_stat_context and mission_deaths >= 20:
        contextual.append("droid_bait")
        progress["high_death_missions"] = 1
    if mission_completed and friendly_kills > enemy_kills:
        contextual.append("same_team")
        progress["friendly_fire_missions"] = 1
    if mission_completed and mission_deaths == 0:
        contextual.append("survivor")
        progress["perfect_missions"] = 1
    return contextual, progress


def request_url(url: str, timeout: int = 10, user_agent: str = "TCWLauncher/1.0") -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": user_agent})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def fetch_steam_display_name(steam_id: str) -> str:
    if not STEAM_ID_PATTERN.fullmatch(steam_id):
        return ""
    timestamp = time.time()
    with STEAM_NAME_CACHE_LOCK:
        cached = STEAM_NAME_CACHE.get(steam_id)
        if cached and timestamp < cached[0]:
            return cached[1]

    name = fetch_steam_webapi_name(steam_id) or fetch_steam_xml_name(steam_id)
    cleaned = clean_profile_name(name) if name else ""
    if is_generic_display_name(cleaned):
        cleaned = ""

    with STEAM_NAME_CACHE_LOCK:
        STEAM_NAME_CACHE[steam_id] = (timestamp + STEAM_NAME_CACHE_SECONDS, cleaned)
    return cleaned


def fetch_steam_webapi_name(steam_id: str) -> str:
    if not STEAM_WEB_API_KEY:
        return ""
    query = urllib.parse.urlencode({"key": STEAM_WEB_API_KEY, "steamids": steam_id})
    url = f"https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?{query}"
    try:
        payload = json.loads(request_url(url, timeout=8).decode("utf-8", "replace"))
    except (OSError, urllib.error.URLError, json.JSONDecodeError, TimeoutError):
        return ""
    players = payload.get("response", {}).get("players", []) if isinstance(payload, dict) else []
    if not players or not isinstance(players[0], dict):
        return ""
    return str(players[0].get("personaname", "")).strip()


def fetch_steam_xml_name(steam_id: str) -> str:
    # Steam's profile XML endpoint does not need a secret and gives us a useful
    # public-name fallback when the official Web API key is not configured.
    url = f"https://steamcommunity.com/profiles/{urllib.parse.quote(steam_id)}/?xml=1"
    try:
        root = ET.fromstring(request_url(url, timeout=8, user_agent="TCW-Profile-API/1.0"))
    except (OSError, urllib.error.URLError, ET.ParseError, TimeoutError):
        return ""
    return str(root.findtext("steamID", "") or "").strip()


def youtube_channel_url() -> str:
    return f"https://www.youtube.com/@{YOUTUBE_HANDLE}" if YOUTUBE_HANDLE else ""


def youtube_embed_url(video_id: str) -> str:
    query = urllib.parse.urlencode(
        {
            "autoplay": "1",
            "mute": "1",
            "controls": "1",
            "playsinline": "1",
            "rel": "0",
            "modestbranding": "1",
        }
    )
    return f"https://www.youtube-nocookie.com/embed/{urllib.parse.quote(video_id)}?{query}"


def unavailable_youtube_video(message: str = "Latest video unavailable") -> dict[str, Any]:
    return {
        "available": False,
        "title": message,
        "video_id": "",
        "published_at": "",
        "url": youtube_channel_url(),
        "embed_url": "",
        "thumbnail_url": "",
        "channel_url": youtube_channel_url(),
        "updated_at": now(),
    }


def discover_youtube_channel_id() -> str:
    global YOUTUBE_DISCOVERED_CHANNEL_ID
    if YOUTUBE_CHANNEL_ID:
        return YOUTUBE_CHANNEL_ID
    if YOUTUBE_DISCOVERED_CHANNEL_ID:
        return YOUTUBE_DISCOVERED_CHANNEL_ID
    if not YOUTUBE_HANDLE:
        return ""

    url = f"https://www.youtube.com/@{urllib.parse.quote(YOUTUBE_HANDLE, safe='-_')}"
    try:
        page = request_url(url, timeout=10, user_agent="Mozilla/5.0 TCW-Profile-API/1.0").decode("utf-8", "replace")
    except (OSError, urllib.error.URLError, TimeoutError):
        return ""
    for pattern in [r'"channelId":"(UC[^"]+)"', r'"externalId":"(UC[^"]+)"', r"channel/(UC[0-9A-Za-z_-]+)"]:
        match = re.search(pattern, page)
        if match:
            YOUTUBE_DISCOVERED_CHANNEL_ID = match.group(1)
            return YOUTUBE_DISCOVERED_CHANNEL_ID
    return ""


def parse_youtube_feed(feed_xml: bytes) -> dict[str, Any]:
    namespaces = {
        "atom": "http://www.w3.org/2005/Atom",
        "yt": "http://www.youtube.com/xml/schemas/2015",
        "media": "http://search.yahoo.com/mrss/",
    }
    root = ET.fromstring(feed_xml)
    entry = root.find("atom:entry", namespaces)
    if entry is None:
        return unavailable_youtube_video("No YouTube videos found")

    video_id = str(entry.findtext("yt:videoId", "", namespaces)).strip()
    if not video_id:
        return unavailable_youtube_video("No YouTube video ID found")
    title = html.unescape(str(entry.findtext("atom:title", "Latest TCWA3 video", namespaces)).strip())[:160]
    published = str(entry.findtext("atom:published", "", namespaces)).strip()[:40]
    video_url = f"https://www.youtube.com/watch?v={video_id}"
    link = entry.find("atom:link[@rel='alternate']", namespaces)
    if link is not None:
        video_url = str(link.attrib.get("href", video_url)).strip()[:500] or video_url

    thumbnail_url = ""
    media_group = entry.find("media:group", namespaces)
    if media_group is not None:
        thumbnail = media_group.find("media:thumbnail", namespaces)
        if thumbnail is not None:
            thumbnail_url = str(thumbnail.attrib.get("url", "")).strip()[:500]

    return {
        "available": True,
        "title": title or "Latest TCWA3 video",
        "video_id": video_id,
        "published_at": published,
        "url": video_url,
        "embed_url": youtube_embed_url(video_id),
        "thumbnail_url": thumbnail_url,
        "channel_url": youtube_channel_url(),
        "updated_at": now(),
    }


def latest_youtube_video(force: bool = False) -> dict[str, Any]:
    global YOUTUBE_CACHE_EXPIRES, YOUTUBE_LATEST_CACHE
    timestamp = time.time()
    with YOUTUBE_CACHE_LOCK:
        if not force and YOUTUBE_LATEST_CACHE and timestamp < YOUTUBE_CACHE_EXPIRES:
            return dict(YOUTUBE_LATEST_CACHE)

    video = unavailable_youtube_video()
    channel_id = discover_youtube_channel_id()
    if channel_id:
        feed_url = "https://www.youtube.com/feeds/videos.xml?" + urllib.parse.urlencode({"channel_id": channel_id})
        try:
            video = parse_youtube_feed(request_url(feed_url, timeout=10, user_agent="TCW-Profile-API/1.0"))
        except (OSError, urllib.error.URLError, ET.ParseError, TimeoutError):
            with YOUTUBE_CACHE_LOCK:
                if YOUTUBE_LATEST_CACHE:
                    return dict(YOUTUBE_LATEST_CACHE)
            video = unavailable_youtube_video()

    with YOUTUBE_CACHE_LOCK:
        YOUTUBE_LATEST_CACHE = video
        cache_seconds = YOUTUBE_CACHE_SECONDS if video.get("available") else min(300, YOUTUBE_CACHE_SECONDS)
        YOUTUBE_CACHE_EXPIRES = timestamp + cache_seconds
    return dict(video)


def clean_news_item(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    title = str(value.get("title", "Update")).strip()[:80] or "Update"
    body = str(value.get("body", "")).strip()[:500]
    date = str(value.get("date", "")).strip()[:32]
    link = str(value.get("link", "")).strip()[:300]
    try:
        priority = int(value.get("priority", 0))
    except (TypeError, ValueError):
        priority = 0
    return {"title": title, "body": body, "date": date, "link": link, "priority": priority}


def load_news() -> list[dict[str, Any]]:
    if not NEWS_PATH.exists():
        return DEFAULT_NEWS
    try:
        parsed = json.loads(NEWS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return DEFAULT_NEWS
    raw_items = parsed.get("items", parsed) if isinstance(parsed, dict) else parsed
    if not isinstance(raw_items, list):
        return DEFAULT_NEWS
    items = [item for item in (clean_news_item(raw) for raw in raw_items) if item is not None]
    items.sort(key=lambda item: int(item.get("priority", 0)), reverse=True)
    return items[:20] or DEFAULT_NEWS


def clean_news_payload(value: Any) -> dict[str, list[dict[str, Any]]]:
    raw_items = value.get("items", value) if isinstance(value, dict) else value
    if not isinstance(raw_items, list):
        raise ValueError("News payload must include an items list")
    items = [item for item in (clean_news_item(raw) for raw in raw_items) if item is not None]
    if not items:
        raise ValueError("At least one valid news item is required")
    items.sort(key=lambda item: int(item.get("priority", 0)), reverse=True)
    return {"items": items[:20]}


def save_news_payload(value: Any) -> dict[str, list[dict[str, Any]]]:
    payload = clean_news_payload(value)
    NEWS_PATH.parent.mkdir(parents=True, exist_ok=True)
    NEWS_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return payload


def clean_hex_color(value: Any, fallback: str) -> str:
    color = str(value or "").strip()
    if re.fullmatch(r"#[0-9A-Fa-f]{6}", color):
        return color.upper()
    return fallback


def clean_iso_text(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return ""
    return text[:40]


def timestamp_from_iso_text(value: Any) -> int | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return int(parsed.astimezone(timezone.utc).timestamp())


def clean_event_id(value: Any, fallback_title: str) -> str:
    raw = str(value or fallback_title or "event").strip().lower()
    event_id = re.sub(r"[^a-z0-9]+", "-", raw).strip("-")[:72]
    return event_id or f"event-{now()}"


def clean_event_banner(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    title = str(value.get("title", "Community Event")).strip()[:96] or "Community Event"
    description = str(value.get("description", "")).strip()[:700]
    xp_bonus_percent = bounded_int(value.get("xp_bonus_percent"), 0)
    xp_bonus_percent = max(0, min(500, xp_bonus_percent))
    priority = bounded_int(value.get("priority"), 0)
    effect = str(value.get("effect", "glow")).strip().lower()
    if effect not in EVENT_EFFECTS:
        effect = "glow"
    start_at = clean_iso_text(value.get("start_at") or value.get("starts_at"))
    end_at = clean_iso_text(value.get("end_at") or value.get("ends_at"))
    return {
        "id": clean_event_id(value.get("id"), title),
        "title": title,
        "description": description,
        "active": bool(value.get("active", True)),
        "start_at": start_at,
        "end_at": end_at,
        "priority": max(-1000, min(1000, priority)),
        "accent_color": clean_hex_color(value.get("accent_color"), "#D9B36C"),
        "background_color": clean_hex_color(value.get("background_color"), "#070B12"),
        "effect": effect,
        "xp_bonus_percent": xp_bonus_percent,
    }


def clean_events_payload(value: Any) -> dict[str, list[dict[str, Any]]]:
    raw_events = value.get("events", value) if isinstance(value, dict) else value
    if not isinstance(raw_events, list):
        raise ValueError("Events payload must include an events list")
    events = [event for event in (clean_event_banner(raw) for raw in raw_events) if event is not None]
    seen: set[str] = set()
    unique_events: list[dict[str, Any]] = []
    for event in events[:30]:
        base_id = event["id"]
        event_id = base_id
        suffix = 2
        while event_id in seen:
            event_id = f"{base_id}-{suffix}"[:80]
            suffix += 1
        event["id"] = event_id
        seen.add(event_id)
        unique_events.append(event)
    unique_events.sort(key=lambda item: int(item.get("priority", 0)), reverse=True)
    return {"events": unique_events}


def save_events_payload(value: Any) -> dict[str, list[dict[str, Any]]]:
    payload = clean_events_payload(value)
    EVENTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    EVENTS_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return payload


def load_event_banners(include_inactive: bool = False, timestamp: int | None = None) -> list[dict[str, Any]]:
    if not EVENTS_PATH.exists():
        events = list(DEFAULT_EVENTS)
    else:
        try:
            parsed = json.loads(EVENTS_PATH.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            parsed = {"events": DEFAULT_EVENTS}
        try:
            events = clean_events_payload(parsed)["events"]
        except ValueError:
            events = list(DEFAULT_EVENTS)
    if include_inactive:
        return events
    check_time = timestamp if timestamp is not None else now()
    active_events: list[dict[str, Any]] = []
    for event in events:
        if not bool(event.get("active", True)):
            continue
        start_ts = timestamp_from_iso_text(event.get("start_at"))
        end_ts = timestamp_from_iso_text(event.get("end_at"))
        if start_ts is not None and check_time < start_ts:
            continue
        if end_ts is not None and check_time >= end_ts:
            continue
        active_events.append(event)
    return active_events


def load_event_manifest(timestamp: int | None = None) -> dict[str, Any]:
    active_events = load_event_banners(include_inactive=False, timestamp=timestamp)
    xp_bonus_percent = min(500, sum(bounded_int(event.get("xp_bonus_percent")) for event in active_events))
    return {
        "updated_at": now(),
        "events": active_events,
        "modifiers": {
            "xp_bonus_percent": xp_bonus_percent,
            "xp_multiplier": round(1.0 + (xp_bonus_percent / 100.0), 3),
        },
    }


def active_event_xp_bonus(timestamp: int) -> tuple[int, list[str]]:
    active_events = load_event_banners(include_inactive=False, timestamp=timestamp)
    bonus = min(500, sum(bounded_int(event.get("xp_bonus_percent")) for event in active_events))
    event_ids = [str(event.get("id", "")) for event in active_events if bounded_int(event.get("xp_bonus_percent")) > 0]
    return bonus, event_ids


def apply_xp_bonus(xp: int, bonus_percent: int) -> int:
    if xp <= 0 or bonus_percent <= 0:
        return xp
    return int(round(xp * (100 + bonus_percent) / 100.0))


def clean_marketplace_category(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    category_id = re.sub(r"[^a-z0-9_]+", "_", str(value.get("id", "")).strip().lower()).strip("_")[:48]
    if not category_id:
        return None
    return {
        "id": category_id,
        "name": str(value.get("name", category_id.replace("_", " ").title())).strip()[:80],
        "description": str(value.get("description", "")).strip()[:240],
    }


def marketplace_category_ids(categories: list[dict[str, Any]]) -> set[str]:
    return {str(category.get("id", "")) for category in categories if category.get("id")}


def clean_marketplace_item(value: Any, category_ids: set[str]) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    item_id = re.sub(r"[^a-z0-9_\-]+", "-", str(value.get("id", "")).strip().lower()).strip("-")[:80]
    category = re.sub(r"[^a-z0-9_]+", "_", str(value.get("category", "")).strip().lower()).strip("_")[:48]
    if not item_id or category not in category_ids:
        return None
    try:
        cost = int(value.get("cost", 0))
    except (TypeError, ValueError):
        cost = 0
    return {
        "id": item_id,
        "category": category,
        "name": str(value.get("name", item_id.replace("-", " ").replace("_", " ").title())).strip()[:96],
        "description": str(value.get("description", "")).strip()[:700],
        "cost": max(0, min(1_000_000, cost)),
        "class_name": str(value.get("class_name", "")).strip()[:160],
        "image_url": str(value.get("image_url", "")).strip()[:300],
        "enabled": bool(value.get("enabled", True)),
        "visible": bool(value.get("visible", True)),
        "one_time": bool(value.get("one_time", True)),
        "tags": [str(tag).strip()[:32] for tag in value.get("tags", [])[:8] if str(tag).strip()]
        if isinstance(value.get("tags", []), list)
        else [],
    }


def clean_marketplace_payload(value: Any) -> dict[str, Any]:
    raw = value if isinstance(value, dict) else {}
    categories = [
        category
        for category in (clean_marketplace_category(item) for item in raw.get("categories", MARKETPLACE_CATEGORIES))
        if category is not None
    ]
    if not categories:
        categories = [dict(category) for category in MARKETPLACE_CATEGORIES]
    category_ids = marketplace_category_ids(categories)
    items = [
        item
        for item in (clean_marketplace_item(raw_item, category_ids) for raw_item in raw.get("items", []))
        if item is not None and bool(item.get("visible", True))
    ]
    items.sort(key=lambda item: (str(item.get("category", "")), int(item.get("cost", 0)), str(item.get("name", ""))))
    return {"categories": categories, "items": items}


def load_marketplace_catalog() -> dict[str, Any]:
    if not MARKETPLACE_PATH.exists():
        return clean_marketplace_payload(DEFAULT_MARKETPLACE)
    try:
        parsed = json.loads(MARKETPLACE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return clean_marketplace_payload(DEFAULT_MARKETPLACE)
    return clean_marketplace_payload(parsed)


def marketplace_item_by_id(item_id: str) -> dict[str, Any] | None:
    cleaned = re.sub(r"[^a-z0-9_\-]+", "-", str(item_id).strip().lower()).strip("-")[:80]
    for item in load_marketplace_catalog()["items"]:
        if item["id"] == cleaned:
            return item
    return None


def public_file_url(root: Path, path: Path, base_url: str) -> str:
    try:
        relative_path = path.relative_to(root).as_posix()
    except ValueError:
        return ""
    return base_url + "/" + urllib.parse.quote(relative_path, safe="/-_.~")


def display_title_from_filename(path: Path) -> str:
    title = re.sub(r"[_\-]+", " ", path.stem).strip()
    return re.sub(r"\s+", " ", title).title()[:90] or path.stem[:90]


def clean_avatar_id(value: Any) -> str:
    cleaned = re.sub(r"[^a-z0-9_\-/]+", "-", str(value or "").strip().lower()).strip("-/")
    return cleaned[:80] or DEFAULT_AVATAR_ID


def avatar_entry(path: Path) -> dict[str, Any] | None:
    if path.suffix.lower() not in AVATAR_EXTENSIONS:
        return None
    try:
        stat = path.stat()
        relative_path = path.relative_to(AVATAR_ROOT)
    except (OSError, ValueError):
        return None
    avatar_id = clean_avatar_id(relative_path.with_suffix("").as_posix())
    url = public_file_url(AVATAR_ROOT, path, AVATAR_BASE_URL)
    if not url:
        return None
    return {
        "id": avatar_id,
        "name": display_title_from_filename(path),
        "url": url,
        "filename": path.name[:180],
        "size_bytes": stat.st_size,
        "updated_at": int(stat.st_mtime),
    }


def avatar_catalog() -> list[dict[str, Any]]:
    catalog: list[dict[str, Any]] = [
        {
            "id": DEFAULT_AVATAR_ID,
            "name": DEFAULT_AVATAR_NAME,
            "url": DEFAULT_AVATAR_URL,
            "filename": "",
            "size_bytes": 0,
            "updated_at": 0,
        }
    ]
    seen = {DEFAULT_AVATAR_ID}
    if AVATAR_ROOT.exists() and AVATAR_ROOT.is_dir():
        for path in sorted(AVATAR_ROOT.rglob("*"), key=lambda item: item.as_posix().lower()):
            if not path.is_file():
                continue
            entry = avatar_entry(path)
            if entry is not None and entry["id"] not in seen:
                seen.add(entry["id"])
                catalog.append(entry)
    return catalog


def avatar_by_id(avatar_id: Any) -> dict[str, Any]:
    cleaned = clean_avatar_id(avatar_id)
    for entry in avatar_catalog():
        if entry["id"] == cleaned:
            return entry
    return avatar_catalog()[0]


def avatar_id_is_available(avatar_id: Any) -> bool:
    cleaned = clean_avatar_id(avatar_id)
    return any(entry["id"] == cleaned for entry in avatar_catalog())


def audio_track_entry(category: str, path: Path) -> dict[str, Any] | None:
    if path.suffix.lower() not in AUDIO_EXTENSIONS:
        return None
    try:
        stat = path.stat()
    except OSError:
        return None
    url = public_file_url(AUDIO_ROOT, path, AUDIO_BASE_URL)
    if not url:
        return None
    return {
        "id": re.sub(r"[^a-z0-9]+", "-", path.stem.lower()).strip("-")[:80] or path.stem[:80],
        "category": category,
        "title": display_title_from_filename(path),
        "filename": path.name[:180],
        "url": url,
        "size_bytes": stat.st_size,
        "updated_at": int(stat.st_mtime),
    }


def load_audio_manifest() -> dict[str, Any]:
    categories: dict[str, dict[str, Any]] = {}
    for category, metadata in AUDIO_CATEGORIES.items():
        directory = AUDIO_ROOT / str(metadata["directory"])
        tracks: list[dict[str, Any]] = []
        if directory.exists() and directory.is_dir():
            for path in sorted(directory.iterdir(), key=lambda item: item.name.lower()):
                if path.is_file():
                    track = audio_track_entry(category, path)
                    if track is not None:
                        tracks.append(track)
        categories[category] = {
            "label": metadata["label"],
            "description": metadata["description"],
            "tracks": tracks,
        }
    return {"updated_at": now(), "categories": categories}


def clean_theme_id(value: Any) -> str:
    return re.sub(r"[^a-z0-9_-]+", "-", str(value or "").lower()).strip("-")[:64]


def clean_theme_manifest(value: Any, theme_dir: Path) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    theme_id = clean_theme_id(value.get("id", theme_dir.name))
    if not theme_id:
        return None
    background_files = value.get("backgrounds", [])
    if not isinstance(background_files, list):
        background_files = []
    backgrounds: list[str] = []
    for background in background_files[:24]:
        relative = Path(str(background).replace("\\", "/"))
        if relative.is_absolute() or ".." in relative.parts:
            continue
        candidate = theme_dir / relative
        if candidate.exists() and candidate.is_file():
            backgrounds.append(public_file_url(THEME_ROOT, candidate, THEME_BASE_URL))
    logo_url = ""
    logo_value = str(value.get("logo", "")).replace("\\", "/")
    if logo_value:
        relative_logo = Path(logo_value)
        if not relative_logo.is_absolute() and ".." not in relative_logo.parts:
            candidate_logo = theme_dir / relative_logo
            if candidate_logo.exists() and candidate_logo.is_file():
                logo_url = public_file_url(THEME_ROOT, candidate_logo, THEME_BASE_URL)
    return {
        "id": theme_id,
        "name": str(value.get("name", theme_id.replace("_", " ").title())).strip()[:80],
        "description": str(value.get("description", "")).strip()[:240],
        "accent_color": clean_hex_color(value.get("accent_color"), ""),
        "panel_color": clean_hex_color(value.get("panel_color"), ""),
        "text_color": clean_hex_color(value.get("text_color"), ""),
        "logo_url": logo_url,
        "backgrounds": backgrounds,
        "built_in": False,
    }


def load_theme_manifest() -> dict[str, Any]:
    themes = [dict(theme) for theme in DEFAULT_THEMES]
    if THEME_ROOT.exists() and THEME_ROOT.is_dir():
        for theme_dir in sorted(THEME_ROOT.iterdir(), key=lambda item: item.name.lower()):
            if not theme_dir.is_dir():
                continue
            manifest_path = theme_dir / "theme.json"
            if not manifest_path.exists():
                continue
            try:
                parsed = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            theme = clean_theme_manifest(parsed, theme_dir)
            if theme is not None:
                themes.append(theme)
    return {"updated_at": now(), "themes": themes}


def safe_asset_filename(value: Any, allowed_extensions: set[str]) -> str:
    raw_name = str(value or "").replace("\\", "/").rsplit("/", 1)[-1].strip()
    if not raw_name:
        raise ValueError("File name is required")
    path = Path(raw_name)
    extension = path.suffix.lower()
    if extension not in allowed_extensions:
        allowed = ", ".join(sorted(allowed_extensions))
        raise ValueError(f"Unsupported file type. Allowed: {allowed}")
    stem = re.sub(r"[^A-Za-z0-9._ -]+", "-", path.stem).strip(" .-_")
    stem = re.sub(r"\s+", " ", stem)[:80]
    if not stem:
        stem = "asset"
    return stem + extension


def safe_theme_directory_id(value: Any) -> str:
    theme_id = clean_theme_id(value)
    if not theme_id:
        raise ValueError("Theme id is required")
    return theme_id


def decode_asset_upload(value: Any) -> bytes:
    data_text = str(value or "").strip()
    if "," in data_text and data_text.lower().startswith("data:"):
        data_text = data_text.split(",", 1)[1]
    if not data_text:
        raise ValueError("File data is required")
    try:
        data = base64.b64decode(data_text, validate=True)
    except (ValueError, TypeError) as exc:
        raise ValueError("File data must be base64 encoded") from exc
    if not data:
        raise ValueError("Uploaded file is empty")
    if len(data) > COMMUNITY_MANAGER_MAX_FILE_BYTES:
        raise ValueError("Uploaded file is too large")
    return data


def relative_public_path(root: Path, path: Path) -> str:
    return path.relative_to(root).as_posix()


def resolve_public_child(root: Path, relative_path: Any) -> Path:
    relative = Path(str(relative_path or "").replace("\\", "/"))
    if relative.is_absolute() or ".." in relative.parts or not relative.parts:
        raise ValueError("Invalid asset path")
    candidate = (root / relative).resolve()
    root_resolved = root.resolve()
    try:
        candidate.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError("Invalid asset path") from exc
    return candidate


def asset_bin_manifest_path() -> Path:
    return ASSET_BIN_ROOT / "manifest.json"


def load_asset_bin_manifest() -> list[dict[str, Any]]:
    manifest_path = asset_bin_manifest_path()
    if not manifest_path.exists():
        return []
    try:
        parsed = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    items = parsed.get("items", []) if isinstance(parsed, dict) else []
    if not isinstance(items, list):
        return []
    cleaned: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        bin_path = str(item.get("bin_path", "")).replace("\\", "/")
        if not bin_path:
            continue
        try:
            resolve_public_child(ASSET_BIN_ROOT, bin_path)
        except ValueError:
            continue
        cleaned.append(item)
    return cleaned


def save_asset_bin_manifest(items: list[dict[str, Any]]) -> None:
    ASSET_BIN_ROOT.mkdir(parents=True, exist_ok=True)
    payload = {"updated_at": now(), "items": items}
    asset_bin_manifest_path().write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def unique_private_bin_path(relative_path: Path) -> Path:
    candidate = ASSET_BIN_ROOT / relative_path
    if not candidate.exists():
        return candidate
    stem = candidate.stem
    suffix = candidate.suffix
    parent = candidate.parent
    for index in range(1, 1000):
        numbered = parent / f"{stem}-{index}{suffix}"
        if not numbered.exists():
            return numbered
    raise ValueError("Could not create a unique bin file path")


def move_asset_to_private_bin(kind: str, group: str, source_path: Path, original_path: str) -> dict[str, Any] | None:
    if not source_path.exists() or not source_path.is_file():
        return None
    timestamp = now()
    deletion_day = time.strftime("%Y-%m-%d", time.gmtime(timestamp))
    safe_group = clean_theme_id(group) or "misc"
    original_relative = Path(str(original_path).replace("\\", "/"))
    safe_parts = [re.sub(r"[^A-Za-z0-9._ -]+", "-", part).strip(" .-_") or "asset" for part in original_relative.parts]
    target_relative = Path(kind) / safe_group / deletion_day / Path(*safe_parts)
    target_path = unique_private_bin_path(target_relative)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(source_path), str(target_path))
    try:
        size_bytes = target_path.stat().st_size
    except OSError:
        size_bytes = 0
    bin_path = relative_public_path(ASSET_BIN_ROOT, target_path)
    entry = {
        "id": secrets.token_urlsafe(10),
        "kind": kind,
        "group": safe_group,
        "filename": target_path.name,
        "original_path": str(original_path).replace("\\", "/"),
        "bin_path": bin_path,
        "github_archive_path": f"backend_asset_archive/community_assets/{bin_path}",
        "size_bytes": size_bytes,
        "deleted_at": timestamp,
        "expires_at": timestamp + ASSET_BIN_RETENTION_SECONDS,
    }
    items = load_asset_bin_manifest()
    items.append(entry)
    save_asset_bin_manifest(items)
    return entry


def load_asset_bin_inventory() -> dict[str, Any]:
    items: list[dict[str, Any]] = []
    for item in load_asset_bin_manifest():
        try:
            path = resolve_public_child(ASSET_BIN_ROOT, item.get("bin_path"))
        except ValueError:
            continue
        if not path.exists() or not path.is_file():
            continue
        copy = dict(item)
        copy["days_until_cleanup"] = max(0, math.ceil((int(copy.get("expires_at", 0)) - now()) / 86400))
        items.append(copy)
    return {
        "retention_seconds": ASSET_BIN_RETENTION_SECONDS,
        "items": sorted(items, key=lambda value: int(value.get("deleted_at", 0)), reverse=True),
    }


def load_theme_json(theme_dir: Path, theme_id: str, name: str = "") -> dict[str, Any]:
    manifest_path = theme_dir / "theme.json"
    parsed: dict[str, Any] = {}
    if manifest_path.exists():
        try:
            loaded = json.loads(manifest_path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                parsed = loaded
        except (OSError, json.JSONDecodeError):
            parsed = {}
    parsed["id"] = theme_id
    parsed["name"] = str(name or parsed.get("name") or theme_id.replace("-", " ").replace("_", " ").title()).strip()[:80]
    parsed["description"] = str(parsed.get("description", "")).strip()[:240]
    parsed["accent_color"] = clean_hex_color(parsed.get("accent_color"), "")
    parsed["panel_color"] = clean_hex_color(parsed.get("panel_color"), "")
    parsed["text_color"] = clean_hex_color(parsed.get("text_color"), "")
    backgrounds = parsed.get("backgrounds", [])
    parsed["backgrounds"] = backgrounds if isinstance(backgrounds, list) else []
    return parsed


def write_theme_json(theme_dir: Path, manifest: dict[str, Any]) -> None:
    theme_dir.mkdir(parents=True, exist_ok=True)
    (theme_dir / "theme.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def save_audio_upload(category: Any, filename: Any, data: bytes) -> dict[str, Any]:
    category_key = str(category or "")
    metadata = AUDIO_CATEGORIES.get(category_key)
    if not metadata:
        raise ValueError("Unknown audio category")
    safe_name = safe_asset_filename(filename, AUDIO_EXTENSIONS)
    target_dir = AUDIO_ROOT / str(metadata["directory"])
    target_dir.mkdir(parents=True, exist_ok=True)
    target_path = target_dir / safe_name
    target_path.write_bytes(data)
    track = audio_track_entry(category_key, target_path)
    if track is None:
        raise ValueError("Could not save audio file")
    return track


def save_theme_upload(theme_id_value: Any, theme_name: Any, asset_type_value: Any, filename: Any, data: bytes) -> dict[str, Any]:
    theme_id = safe_theme_directory_id(theme_id_value)
    asset_type = str(asset_type_value or "").strip().lower()
    if asset_type not in THEME_ASSET_TYPES:
        raise ValueError("Theme asset type must be background or logo")
    safe_name = safe_asset_filename(filename, THEME_IMAGE_EXTENSIONS)
    theme_dir = THEME_ROOT / theme_id
    relative_path = Path("backgrounds") / safe_name if asset_type == "background" else Path(safe_name)
    target_path = theme_dir / relative_path
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_bytes(data)

    manifest = load_theme_json(theme_dir, theme_id, str(theme_name or ""))
    relative_text = relative_path.as_posix()
    if asset_type == "logo":
        manifest["logo"] = relative_text
    else:
        backgrounds = [str(item) for item in manifest.get("backgrounds", []) if str(item).strip()]
        if relative_text not in backgrounds:
            backgrounds.append(relative_text)
        manifest["backgrounds"] = backgrounds[:24]
    write_theme_json(theme_dir, manifest)
    theme = clean_theme_manifest(manifest, theme_dir)
    if theme is None:
        raise ValueError("Could not save theme asset")
    return theme


def save_theme_metadata(payload: dict[str, Any]) -> dict[str, Any]:
    theme_id = safe_theme_directory_id(payload.get("theme_id") or payload.get("id"))
    theme_dir = THEME_ROOT / theme_id
    manifest = load_theme_json(theme_dir, theme_id, str(payload.get("theme_name") or payload.get("name") or ""))
    if "name" in payload or "theme_name" in payload:
        manifest["name"] = str(payload.get("theme_name") or payload.get("name") or manifest["name"]).strip()[:80]
    if "description" in payload:
        manifest["description"] = str(payload.get("description") or "").strip()[:240]
    for key in ("accent_color", "panel_color", "text_color"):
        if key in payload:
            manifest[key] = clean_hex_color(payload.get(key), "")
    write_theme_json(theme_dir, manifest)
    theme = clean_theme_manifest(manifest, theme_dir)
    if theme is None:
        raise ValueError("Could not save theme metadata")
    return theme


def delete_audio_asset(category: Any, filename: Any) -> dict[str, Any] | None:
    category_key = str(category or "")
    metadata = AUDIO_CATEGORIES.get(category_key)
    if not metadata:
        raise ValueError("Unknown audio category")
    safe_name = safe_asset_filename(filename, AUDIO_EXTENSIONS)
    path = AUDIO_ROOT / str(metadata["directory"]) / safe_name
    return move_asset_to_private_bin("audio", category_key, path, safe_name)


def delete_theme_asset(theme_id_value: Any, relative_path_value: Any) -> dict[str, Any] | None:
    theme_id = safe_theme_directory_id(theme_id_value)
    theme_dir = THEME_ROOT / theme_id
    target_path = resolve_public_child(theme_dir, relative_path_value)
    relative_text = relative_public_path(theme_dir, target_path)
    binned = move_asset_to_private_bin("images", theme_id, target_path, relative_text)
    manifest = load_theme_json(theme_dir, theme_id)
    if str(manifest.get("logo", "")) == relative_text:
        manifest["logo"] = ""
    manifest["backgrounds"] = [
        str(item) for item in manifest.get("backgrounds", [])
        if str(item).replace("\\", "/") != relative_text
    ]
    write_theme_json(theme_dir, manifest)
    return binned


def load_community_asset_inventory() -> dict[str, Any]:
    themes: list[dict[str, Any]] = []
    if THEME_ROOT.exists() and THEME_ROOT.is_dir():
        for theme_dir in sorted(THEME_ROOT.iterdir(), key=lambda item: item.name.lower()):
            if not theme_dir.is_dir():
                continue
            manifest_path = theme_dir / "theme.json"
            if not manifest_path.exists():
                continue
            try:
                parsed = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            theme = clean_theme_manifest(parsed, theme_dir)
            if theme is None:
                continue
            logo_path = str(parsed.get("logo", "")).replace("\\", "/")
            backgrounds = parsed.get("backgrounds", [])
            theme["logo"] = {
                "path": logo_path,
                "url": theme.get("logo_url", ""),
                "filename": Path(logo_path).name if logo_path else "",
            } if logo_path else None
            theme["background_assets"] = []
            if isinstance(backgrounds, list):
                for background in backgrounds:
                    relative = str(background).replace("\\", "/")
                    try:
                        candidate = resolve_public_child(theme_dir, relative)
                    except ValueError:
                        continue
                    if candidate.exists() and candidate.is_file():
                        theme["background_assets"].append(
                            {
                                "path": relative,
                                "filename": candidate.name,
                                "url": public_file_url(THEME_ROOT, candidate, THEME_BASE_URL),
                            }
                        )
            themes.append(theme)
    return {
        "updated_at": now(),
        "audio": load_audio_manifest()["categories"],
        "themes": themes,
        "events": load_event_banners(include_inactive=True),
        "bin": load_asset_bin_inventory(),
        "built_in_themes": DEFAULT_THEMES,
        "limits": {
            "max_file_bytes": COMMUNITY_MANAGER_MAX_FILE_BYTES,
            "audio_extensions": sorted(AUDIO_EXTENSIONS),
            "theme_image_extensions": sorted(THEME_IMAGE_EXTENSIONS),
        },
    }


def version_parts(value: Any) -> list[int]:
    return [int(part) for part in re.findall(r"\d+", str(value or ""))]


def is_newer_version(latest: Any, current: Any) -> bool:
    latest_parts = version_parts(latest)
    current_parts = version_parts(current)
    length = max(len(latest_parts), len(current_parts))
    latest_parts.extend([0] * (length - len(latest_parts)))
    current_parts.extend([0] * (length - len(current_parts)))
    return latest_parts > current_parts


def clean_sha256(value: Any) -> str:
    digest = str(value or "").strip()
    if not digest:
        return ""
    if re.fullmatch(r"[A-Fa-f0-9]{64}", digest):
        return digest.upper()
    return ""


def clean_release_manifest(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return dict(DEFAULT_RELEASE)
    manifest = dict(DEFAULT_RELEASE)
    manifest.update(
        {
            "version": str(value.get("version", manifest["version"])).strip()[:40] or manifest["version"],
            "channel": str(value.get("channel", manifest["channel"])).strip()[:24] or manifest["channel"],
            "title": str(value.get("title", manifest["title"])).strip()[:80] or manifest["title"],
            "summary": str(value.get("summary", manifest["summary"])).strip()[:500],
            "mandatory": bool(value.get("mandatory", manifest["mandatory"])),
            "download_url": str(value.get("download_url", manifest["download_url"])).strip()[:500],
            "installer_url": str(value.get("installer_url", manifest["installer_url"])).strip()[:500],
            "sha256": clean_sha256(value.get("sha256", manifest["sha256"])),
            "published_at": str(value.get("published_at", manifest["published_at"])).strip()[:40],
        }
    )
    notes = value.get("notes", manifest["notes"])
    if isinstance(notes, list):
        manifest["notes"] = [str(note).strip()[:240] for note in notes[:12] if str(note).strip()]
    downloads = value.get("downloads", manifest["downloads"])
    if isinstance(downloads, dict):
        cleaned_downloads: dict[str, dict[str, str]] = {}
        for platform, data in downloads.items():
            if not isinstance(data, dict):
                continue
            cleaned_downloads[str(platform).lower()[:32]] = {
                "url": str(data.get("url", "")).strip()[:500],
                "installer_url": str(data.get("installer_url", "")).strip()[:500],
                "sha256": clean_sha256(data.get("sha256", "")),
            }
        manifest["downloads"] = cleaned_downloads
    return manifest


def load_release_manifest(current_version: str = "") -> dict[str, Any]:
    if not RELEASE_PATH.exists():
        manifest = dict(DEFAULT_RELEASE)
    else:
        try:
            parsed = json.loads(RELEASE_PATH.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            parsed = DEFAULT_RELEASE
        manifest = clean_release_manifest(parsed)
    manifest["update_available"] = is_newer_version(manifest.get("version", ""), current_version)
    manifest["checked_at"] = now()
    return manifest


def normalize_server_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


BATTLEMETRICS_CACHE_SECONDS = 60
BATTLEMETRICS_CACHE_LOCK = threading.Lock()
BATTLEMETRICS_CACHE_EXPIRES = 0.0
BATTLEMETRICS_BY_NAME: dict[str, dict[str, Any]] = {}
BATTLEMETRICS_BY_ADDRESS: dict[tuple[str, int], dict[str, Any]] = {}


def battlemetrics_request(search: str, timeout: int = 8) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode(
        {
            "filter[game]": "arma3",
            "filter[search]": search,
            "page[size]": "100",
        }
    )
    request = urllib.request.Request(
        f"https://api.battlemetrics.com/servers?{query}",
        headers={"User-Agent": "TCWLauncher/1.0"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))
    data = payload.get("data", []) if isinstance(payload, dict) else []
    return data if isinstance(data, list) else []


def refresh_battlemetrics_cache(force: bool = False) -> None:
    global BATTLEMETRICS_CACHE_EXPIRES, BATTLEMETRICS_BY_NAME, BATTLEMETRICS_BY_ADDRESS

    # BattleMetrics is a third-party dependency, so cache successful lookups and
    # briefly suppress retries after failures. This keeps the launcher responsive
    # and avoids hammering BattleMetrics when many users open the server browser.
    timestamp = time.time()
    with BATTLEMETRICS_CACHE_LOCK:
        if not force and timestamp < BATTLEMETRICS_CACHE_EXPIRES and BATTLEMETRICS_BY_NAME:
            return

        by_name: dict[str, dict[str, Any]] = {}
        by_address: dict[tuple[str, int], dict[str, Any]] = {}
        try:
            data = battlemetrics_request("TCW", timeout=10)
        except (OSError, urllib.error.URLError, json.JSONDecodeError, TimeoutError):
            BATTLEMETRICS_CACHE_EXPIRES = timestamp + 15
            return

        for item in data:
            if not isinstance(item, dict):
                continue
            attributes = item.get("attributes", {})
            if not isinstance(attributes, dict):
                continue
            name_key = normalize_server_name(str(attributes.get("name", "")))
            ip = str(attributes.get("ip", ""))
            port = int(attributes.get("port", 0) or 0)
            if name_key:
                by_name[name_key] = attributes
            if ip and port:
                by_address[(ip, port)] = attributes

        BATTLEMETRICS_BY_NAME = by_name
        BATTLEMETRICS_BY_ADDRESS = by_address
        BATTLEMETRICS_CACHE_EXPIRES = timestamp + BATTLEMETRICS_CACHE_SECONDS


def cached_battlemetrics_match(ip: str, port: int, normalized_name: str) -> dict[str, Any] | None:
    refresh_battlemetrics_cache()
    with BATTLEMETRICS_CACHE_LOCK:
        exact_address = BATTLEMETRICS_BY_ADDRESS.get((ip, port))
        if exact_address:
            return exact_address
        if normalized_name:
            exact_name = BATTLEMETRICS_BY_NAME.get(normalized_name)
            if exact_name:
                return exact_name
            # TCW server display names and game ports can drift slightly between
            # hosts/providers. Fuzzy name and near-port matching gives the UI a
            # useful status instead of showing "unknown" for a renamed server.
            for found_name, attributes in BATTLEMETRICS_BY_NAME.items():
                if normalized_name == found_name or normalized_name in found_name or found_name in normalized_name:
                    found_port = int(attributes.get("port", 0) or 0)
                    if found_port == port or abs(found_port - port) <= 10:
                        return attributes
        for (found_ip, found_port), attributes in BATTLEMETRICS_BY_ADDRESS.items():
            if found_ip == ip and abs(found_port - port) <= 10:
                return attributes
    return None


def battlemetrics_status(ip: str, port: int, name: str = "") -> dict[str, Any]:
    ip = ip.strip()
    if not ip or port <= 0 or port > 65535:
        return {"status": "unknown", "players": 0, "max_players": 0, "mission": "Unavailable"}

    name = name.strip()
    normalized_name = normalize_server_name(name)
    cached = cached_battlemetrics_match(ip, port, normalized_name)
    if cached:
        return format_battlemetrics_status(cached)

    searches = [f"{ip}:{port}"]
    if name:
        searches.append(name)
    searches.append(ip)
    fallback: dict[str, Any] = {}

    for search in searches:
        try:
            data = battlemetrics_request(search)
        except (OSError, urllib.error.URLError, json.JSONDecodeError, TimeoutError):
            continue

        for item in data:
            if not isinstance(item, dict):
                continue
            attributes = item.get("attributes", {})
            if not isinstance(attributes, dict):
                continue
            found_ip = str(attributes.get("ip", ""))
            found_port = int(attributes.get("port", 0) or 0)
            found_name = str(attributes.get("name", ""))
            normalized_found_name = normalize_server_name(found_name)
            if found_port == port:
                if found_ip == ip:
                    return format_battlemetrics_status(attributes)
                if normalized_name and (
                    normalized_name == normalized_found_name
                    or normalized_name in normalized_found_name
                    or normalized_found_name in normalized_name
                ):
                    return format_battlemetrics_status(attributes)
            if found_ip == ip and not fallback and abs(found_port - port) <= 10:
                fallback = attributes
            if normalized_name and not fallback and (
                normalized_name == normalized_found_name
                or normalized_name in normalized_found_name
                or normalized_found_name in normalized_name
            ):
                fallback = attributes

        if fallback:
            return format_battlemetrics_status(fallback)

    return {"status": "unknown", "players": 0, "max_players": 0, "mission": "Unavailable"}


def format_battlemetrics_status(attributes: dict[str, Any]) -> dict[str, Any]:
    details = attributes.get("details", {})
    if not isinstance(details, dict):
        details = {}
    mission = "Unavailable"
    for key in ["map", "mapName", "world", "worldName", "terrain", "mission", "missionName", "scenario"]:
        value = str(details.get(key, attributes.get(key, ""))).strip()
        if value and value.lower() not in ["unknown", "n/a", "none"]:
            mission = value.replace("_", " ")
            break

    return {
        "status": str(attributes.get("status", "unknown")).lower(),
        "players": int(attributes.get("players", 0) or 0),
        "max_players": int(attributes.get("maxPlayers", 0) or 0),
        "mission": mission,
    }


def load_server_keys() -> dict[str, str]:
    raw = os.getenv("TCW_SERVER_KEYS_JSON", "{}")
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    if not isinstance(parsed, dict):
        return {}
    return {str(key): str(value) for key, value in parsed.items() if str(value)}


SERVER_KEYS = load_server_keys()


@contextmanager
def connect_db():
    connection = sqlite3.connect(DATABASE_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA journal_mode = WAL")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def ensure_table_columns(db: sqlite3.Connection, table: str, columns: dict[str, str]) -> None:
    existing = {row["name"] for row in db.execute(f"PRAGMA table_info({table})").fetchall()}
    for column, definition in columns.items():
        if column not in existing:
            db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def write_json_file(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_name(f"{path.name}.tmp")
    temporary_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary_path.replace(path)


def write_player_profile_snapshot(db: sqlite3.Connection, steam_id: str) -> None:
    """Write readable per-player JSON mirrors for team inspection and future tools."""
    if not STEAM_ID_PATTERN.fullmatch(steam_id):
        return
    profile = profile_for(db, steam_id)
    if profile is None:
        return
    player_dir = PLAYER_DATA_ROOT / steam_id
    stats = {
        "steam_id": steam_id,
        "display_name": profile["display_name"],
        "level": profile["level"],
        "xp": profile["xp"],
        "credits": profile["credits"],
        "kills": profile["kills"],
        "deaths": profile["deaths"],
        "missions": profile["missions"],
        "playtime_seconds": profile["playtime_seconds"],
        "droid_kills": profile["droid_kills"],
        "friendly_kills": profile["friendly_kills"],
        "kamino_visits": profile["kamino_visits"],
        "geonosis_missions": profile["geonosis_missions"],
        "friendly_fire_missions": profile["friendly_fire_missions"],
        "high_death_missions": profile["high_death_missions"],
        "perfect_missions": profile["perfect_missions"],
        "avatar_id": profile["avatar_id"],
        "avatar_url": profile["avatar_url"],
        "updated_at": profile["updated_at"],
    }
    write_json_file(player_dir / "profile.json", profile)
    write_json_file(player_dir / "stats.json", stats)
    write_json_file(
        player_dir / "achievements.json",
        {
            "steam_id": steam_id,
            "display_name": profile["display_name"],
            "achievements": profile["achievements"],
            "updated_at": profile["updated_at"],
        },
    )
    write_json_file(
        player_dir / "inventory.json",
        {
            "steam_id": steam_id,
            "display_name": profile["display_name"],
            "items": profile.get("inventory", []),
            "updated_at": profile["updated_at"],
        },
    )
    write_json_file(
        player_dir / "campaigns.json",
        {
            "steam_id": steam_id,
            "display_name": profile["display_name"],
            "campaigns": profile.get("campaigns", []),
            "updated_at": profile["updated_at"],
        },
    )


def safe_write_player_profile_snapshot(db: sqlite3.Connection, steam_id: str) -> None:
    try:
        write_player_profile_snapshot(db, steam_id)
    except OSError as exc:
        print(f"Player profile snapshot failed for {steam_id}: {exc}")


def initialize_database() -> None:
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    PLAYER_DATA_ROOT.mkdir(parents=True, exist_ok=True)
    with connect_db() as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                steam_id TEXT PRIMARY KEY,
                display_name TEXT NOT NULL DEFAULT 'Clone trooper',
                arma_profile_name TEXT,
                roster_name TEXT,
                unit TEXT,
                rank TEXT,
                rostered INTEGER NOT NULL DEFAULT 0,
                bio TEXT NOT NULL DEFAULT '',
                profile_public INTEGER NOT NULL DEFAULT 1,
                avatar_id TEXT NOT NULL DEFAULT 'tcw-standard',
                verified_at INTEGER,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS stats (
                steam_id TEXT PRIMARY KEY REFERENCES users(steam_id) ON DELETE CASCADE,
                kills INTEGER NOT NULL DEFAULT 0,
                deaths INTEGER NOT NULL DEFAULT 0,
                credits INTEGER NOT NULL DEFAULT 0,
                xp INTEGER NOT NULL DEFAULT 0,
                missions INTEGER NOT NULL DEFAULT 0,
                playtime_seconds INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS achievements (
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                achievement_id TEXT NOT NULL,
                unlocked_at INTEGER NOT NULL,
                PRIMARY KEY (steam_id, achievement_id)
            );

            CREATE TABLE IF NOT EXISTS device_codes (
                device_hash TEXT PRIMARY KEY,
                user_code TEXT NOT NULL UNIQUE,
                steam_id TEXT REFERENCES users(steam_id),
                status TEXT NOT NULL DEFAULT 'pending',
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                consumed_at INTEGER
            );

            CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY,
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                last_used_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS server_events (
                event_id TEXT PRIMARY KEY,
                official_server TEXT NOT NULL,
                steam_id TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                received_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS roster_members (
                external_id TEXT PRIMARY KEY,
                steam_id TEXT,
                discord_id TEXT,
                display_name TEXT NOT NULL,
                unit TEXT,
                rank TEXT,
                synced_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS marketplace_purchases (
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                item_id TEXT NOT NULL,
                category TEXT NOT NULL,
                class_name TEXT NOT NULL DEFAULT '',
                cost INTEGER NOT NULL,
                purchased_at INTEGER NOT NULL,
                PRIMARY KEY (steam_id, item_id)
            );

            CREATE TABLE IF NOT EXISTS campaign_deployments (
                deployment_id TEXT PRIMARY KEY,
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                campaign_id TEXT NOT NULL,
                campaign_name TEXT NOT NULL,
                mission_name TEXT NOT NULL,
                planet TEXT NOT NULL DEFAULT '',
                official_server TEXT NOT NULL DEFAULT '',
                completed_at INTEGER NOT NULL,
                awards_json TEXT NOT NULL DEFAULT '[]'
            );

            CREATE INDEX IF NOT EXISTS idx_sessions_steam_id ON sessions(steam_id);
            CREATE INDEX IF NOT EXISTS idx_device_codes_expiry ON device_codes(expires_at);
            CREATE INDEX IF NOT EXISTS idx_campaign_deployments_steam_id ON campaign_deployments(steam_id, completed_at DESC);
            """
        )
        ensure_table_columns(db, "users", USER_PROFILE_COLUMNS)
        ensure_table_columns(db, "stats", PROGRESSION_STAT_COLUMNS)
        ensure_table_columns(db, "achievements", ACHIEVEMENT_COLUMNS)


def sync_roster() -> dict[str, int]:
    if not SQUAD_XML_URL:
        return {"members": 0, "steam_linked": 0, "discord_only": 0}
    request = urllib.request.Request(SQUAD_XML_URL, headers={"User-Agent": "TCW-Profile-API/1.0"})
    with urllib.request.urlopen(request, timeout=15) as response:
        root = ET.fromstring(response.read())
    timestamp = now()
    members = 0
    steam_linked = 0
    discord_only = 0
    with connect_db() as db:
        db.execute("DELETE FROM roster_members")
        db.execute("UPDATE users SET rostered = 0")
        for member in root.findall("member"):
            external_id = str(member.attrib.get("id", "")).strip()
            roster_name = clean_profile_name(member.attrib.get("nick", ""))
            remark = str(member.findtext("remark", ""))
            remark_parts = [part.strip() for part in remark.split(",")]
            unit = remark_parts[0][:32] if remark_parts else ""
            rank = remark_parts[1][:32] if len(remark_parts) > 1 and remark_parts[1] != "N/A" else ""
            steam_id = external_id if STEAM_ID_PATTERN.fullmatch(external_id) else None
            discord_id = external_id[8:] if external_id.startswith("discord:") else None
            db.execute(
                """
                INSERT INTO roster_members
                    (external_id, steam_id, discord_id, display_name, unit, rank, synced_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (external_id, steam_id, discord_id, roster_name, unit, rank, timestamp),
            )
            members += 1
            if steam_id:
                steam_linked += 1
                db.execute(
                    """
                    INSERT INTO users
                        (steam_id, display_name, roster_name, unit, rank, rostered, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, 1, ?, ?)
                    ON CONFLICT(steam_id) DO UPDATE SET
                        roster_name = excluded.roster_name,
                        unit = excluded.unit,
                        rank = excluded.rank,
                        rostered = 1,
                        display_name = CASE
                            WHEN users.arma_profile_name IS NULL OR users.arma_profile_name = ''
                            THEN excluded.roster_name ELSE users.display_name END,
                        updated_at = excluded.updated_at
                    """,
                    (steam_id, roster_name, roster_name, unit, rank, timestamp, timestamp),
                )
                db.execute("INSERT OR IGNORE INTO stats (steam_id) VALUES (?)", (steam_id,))
            elif discord_id:
                discord_only += 1
    return {"members": members, "steam_linked": steam_linked, "discord_only": discord_only}


def roster_sync_loop() -> None:
    while True:
        try:
            result = sync_roster()
            print(f"Roster synced: {result}")
        except Exception as exc:
            print(f"Roster sync failed: {exc}")
        time.sleep(max(60, ROSTER_SYNC_SECONDS))


def profile_for(db: sqlite3.Connection, steam_id: str) -> dict[str, Any] | None:
    row = db.execute(
        """
        SELECT u.steam_id,
               COALESCE(NULLIF(u.arma_profile_name, ''), NULLIF(u.roster_name, ''), u.display_name) AS display_name,
               u.unit, u.rank, u.rostered, u.bio, u.profile_public, u.avatar_id, u.verified_at, u.updated_at,
               s.kills, s.deaths, s.credits, s.xp, s.missions, s.playtime_seconds,
               s.droid_kills, s.friendly_kills, s.kamino_visits, s.geonosis_missions,
               s.friendly_fire_missions, s.high_death_missions, s.perfect_missions
        FROM users u JOIN stats s ON s.steam_id = u.steam_id
        WHERE u.steam_id = ?
        """,
        (steam_id,),
    ).fetchone()
    if row is None:
        return None
    avatar = avatar_by_id(row["avatar_id"])
    level = level_for_xp(row["xp"])
    unlocked_rows = db.execute(
        "SELECT achievement_id, unlocked_at, acknowledged_at FROM achievements WHERE steam_id = ? ORDER BY unlocked_at DESC",
        (steam_id,),
    ).fetchall()
    unlocked = []
    unacknowledged = []
    for achievement in unlocked_rows:
        payload = achievement_payload(
            achievement["achievement_id"],
            achievement["unlocked_at"],
            achievement["acknowledged_at"],
        )
        unlocked.append(payload)
        if achievement["acknowledged_at"] is None:
            unacknowledged.append(payload)
    profile = {
        "steam_id": row["steam_id"],
        "display_name": public_display_name(row["display_name"]),
        "unit": row["unit"] or "",
        "rank": row["rank"] or "",
        "rostered": bool(row["rostered"]),
        "bio": row["bio"] or "",
        "profile_public": bool(row["profile_public"]),
        "avatar_id": avatar["id"],
        "avatar_name": avatar["name"],
        "avatar_url": avatar["url"],
        "verified": row["verified_at"] is not None,
        "level": level,
        "xp": row["xp"],
        "current_level_xp": 500 * (level - 1) ** 2,
        "next_level_xp": next_level_xp(level),
        "credits": row["credits"],
        "kills": row["kills"],
        "deaths": row["deaths"],
        "missions": row["missions"],
        "playtime_seconds": row["playtime_seconds"],
        "droid_kills": row["droid_kills"],
        "friendly_kills": row["friendly_kills"],
        "kamino_visits": row["kamino_visits"],
        "geonosis_missions": row["geonosis_missions"],
        "friendly_fire_missions": row["friendly_fire_missions"],
        "high_death_missions": row["high_death_missions"],
        "perfect_missions": row["perfect_missions"],
        "achievements": unlocked,
        "unacknowledged_achievements": unacknowledged,
        "campaigns": campaign_log_for(db, steam_id),
        "updated_at": row["updated_at"],
    }
    profile["inventory"] = marketplace_inventory_for(db, steam_id)
    return profile


def achievement_payload(achievement_id: str, unlocked_at: int, acknowledged_at: int | None = None) -> dict[str, Any]:
    definition = ACHIEVEMENTS.get(achievement_id, {})
    payload = {
        "id": achievement_id,
        "name": definition.get("name", achievement_id),
        "description": definition.get("description", ""),
        "unlocked_at": unlocked_at,
    }
    if acknowledged_at is not None:
        payload["acknowledged_at"] = acknowledged_at
    return payload


def campaign_log_for(db: sqlite3.Connection, steam_id: str) -> list[dict[str, Any]]:
    rows = db.execute(
        """
        SELECT deployment_id, campaign_id, campaign_name, mission_name, planet,
               official_server, completed_at, awards_json
        FROM campaign_deployments
        WHERE steam_id = ?
        ORDER BY completed_at DESC, deployment_id DESC
        LIMIT 80
        """,
        (steam_id,),
    ).fetchall()
    campaigns_by_id: dict[str, dict[str, Any]] = {}
    ordered_ids: list[str] = []
    for row in rows:
        campaign_id = row["campaign_id"]
        if campaign_id not in campaigns_by_id:
            campaigns_by_id[campaign_id] = {
                "id": campaign_id,
                "name": row["campaign_name"],
                "planet": row["planet"],
                "deployment_count": 0,
                "last_completed_at": row["completed_at"],
                "deployments": [],
            }
            ordered_ids.append(campaign_id)
        try:
            awards = json.loads(row["awards_json"] or "[]")
        except json.JSONDecodeError:
            awards = []
        campaigns_by_id[campaign_id]["deployment_count"] += 1
        campaigns_by_id[campaign_id]["deployments"].append(
            {
                "id": row["deployment_id"],
                "mission_name": row["mission_name"],
                "planet": row["planet"],
                "official_server": row["official_server"],
                "completed_at": row["completed_at"],
                "awards": awards if isinstance(awards, list) else [],
            }
        )
    return [campaigns_by_id[campaign_id] for campaign_id in ordered_ids]


def record_campaign_deployment(
    db: sqlite3.Connection,
    steam_id: str,
    deployment_id: str,
    official_server: str,
    event: dict[str, Any],
    achievement_ids: list[str],
    completed_at: int,
) -> None:
    campaign = campaign_for_event(event)
    awards = [achievement_payload(achievement_id, completed_at) for achievement_id in achievement_ids]
    db.execute(
        """
        INSERT OR IGNORE INTO campaign_deployments
            (deployment_id, steam_id, campaign_id, campaign_name, mission_name,
             planet, official_server, completed_at, awards_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            deployment_id,
            steam_id,
            campaign["id"],
            campaign["name"],
            mission_name_for_event(event, campaign),
            campaign["planet"],
            official_server,
            completed_at,
            json.dumps(awards, ensure_ascii=False),
        ),
    )


def marketplace_inventory_for(db: sqlite3.Connection, steam_id: str) -> list[dict[str, Any]]:
    rows = db.execute(
        """
        SELECT item_id, category, class_name, cost, purchased_at
        FROM marketplace_purchases
        WHERE steam_id = ?
        ORDER BY purchased_at DESC, item_id ASC
        """,
        (steam_id,),
    ).fetchall()
    return [
        {
            "item_id": row["item_id"],
            "category": row["category"],
            "class_name": row["class_name"],
            "cost": row["cost"],
            "purchased_at": row["purchased_at"],
        }
        for row in rows
    ]


def marketplace_catalog_for_player(db: sqlite3.Connection | None = None, steam_id: str | None = None) -> dict[str, Any]:
    catalog = load_marketplace_catalog()
    payload = {
        "categories": catalog["categories"],
        "items": catalog["items"],
        "updated_at": now(),
    }
    if db is not None and steam_id:
        owned_rows = db.execute(
            "SELECT item_id FROM marketplace_purchases WHERE steam_id = ?",
            (steam_id,),
        ).fetchall()
        owned_ids = {row["item_id"] for row in owned_rows}
        for item in payload["items"]:
            item["owned"] = item["id"] in owned_ids
        profile = profile_for(db, steam_id)
        payload["credits"] = int(profile["credits"]) if profile else 0
        payload["owned_item_ids"] = sorted(owned_ids)
    return payload


def purchase_marketplace_item(db: sqlite3.Connection, steam_id: str, item_id: str) -> tuple[HTTPStatus, dict[str, Any]]:
    item = marketplace_item_by_id(item_id)
    if item is None:
        return HTTPStatus.NOT_FOUND, {"error": "item_not_found", "message": "That marketplace item is not available."}
    if not bool(item.get("enabled", True)):
        return HTTPStatus.CONFLICT, {"error": "item_disabled", "message": "That marketplace item is not currently purchasable."}
    existing = db.execute(
        "SELECT item_id FROM marketplace_purchases WHERE steam_id = ? AND item_id = ?",
        (steam_id, item["id"]),
    ).fetchone()
    if existing is not None and bool(item.get("one_time", True)):
        return HTTPStatus.CONFLICT, {"error": "already_owned", "message": "You already own this item."}
    stats = db.execute("SELECT credits FROM stats WHERE steam_id = ?", (steam_id,)).fetchone()
    if stats is None:
        return HTTPStatus.NOT_FOUND, {"error": "profile_not_found", "message": "Profile stats were not found."}
    cost = int(item.get("cost", 0))
    if int(stats["credits"]) < cost:
        return HTTPStatus.CONFLICT, {"error": "not_enough_credits", "message": "You do not have enough credits for this item."}
    timestamp = now()
    db.execute(
        "UPDATE stats SET credits = credits - ? WHERE steam_id = ?",
        (cost, steam_id),
    )
    db.execute(
        """
        INSERT OR REPLACE INTO marketplace_purchases
            (steam_id, item_id, category, class_name, cost, purchased_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (steam_id, item["id"], item["category"], item.get("class_name", ""), cost, timestamp),
    )
    profile = profile_for(db, steam_id)
    safe_write_player_profile_snapshot(db, steam_id)
    return HTTPStatus.OK, {
        "status": "purchased",
        "purchase": {
            "item_id": item["id"],
            "category": item["category"],
            "class_name": item.get("class_name", ""),
            "cost": cost,
            "purchased_at": timestamp,
        },
        "profile": profile,
        "marketplace": marketplace_catalog_for_player(db, steam_id),
    }


def public_profile_card(profile: dict[str, Any], extra: dict[str, Any] | None = None) -> dict[str, Any]:
    campaigns = profile.get("campaigns", [])
    latest_campaign = campaigns[0] if campaigns else {}
    card = {
        "steam_id": profile["steam_id"],
        "display_name": profile["display_name"],
        "unit": profile["unit"],
        "rank": profile["rank"],
        "rostered": profile["rostered"],
        "verified": profile["verified"],
        "bio": profile["bio"],
        "avatar_id": profile["avatar_id"],
        "avatar_name": profile["avatar_name"],
        "avatar_url": profile["avatar_url"],
        "level": profile["level"],
        "credits": profile["credits"],
        "kills": profile["kills"],
        "droid_kills": profile["droid_kills"],
        "deaths": profile["deaths"],
        "missions": profile["missions"],
        "playtime_seconds": profile["playtime_seconds"],
        "geonosis_missions": profile["geonosis_missions"],
        "achievement_count": len(profile["achievements"]),
        "recent_achievements": profile["achievements"][:3],
        "campaign_count": len(campaigns),
        "latest_campaign": latest_campaign.get("name", "") if isinstance(latest_campaign, dict) else "",
        "updated_at": profile["updated_at"],
    }
    if extra:
        card.update(extra)
    return card


def list_public_profiles(db: sqlite3.Connection, unit_filter: str = "", sort_mode: str = "active") -> list[dict[str, Any]]:
    query = """
        SELECT u.steam_id
        FROM users u
        JOIN stats s ON s.steam_id = u.steam_id
        WHERE u.profile_public = 1
          AND u.verified_at IS NOT NULL
    """
    params: list[Any] = []
    if unit_filter:
        query += " AND LOWER(COALESCE(u.unit, '')) = LOWER(?)"
        params.append(unit_filter)
    if sort_mode == "legion":
        query += " ORDER BY LOWER(COALESCE(u.unit, 'zzzz')), LOWER(COALESCE(u.rank, 'zzzz')), LOWER(u.display_name)"
    elif sort_mode == "level":
        query += " ORDER BY s.xp DESC, s.missions DESC, u.updated_at DESC"
    else:
        query += " ORDER BY u.updated_at DESC, s.missions DESC"
    query += " LIMIT 100"
    profiles: list[dict[str, Any]] = []
    for row in db.execute(query, params).fetchall():
        profile = profile_for(db, row["steam_id"])
        if profile and profile["profile_public"]:
            profiles.append(public_profile_card(profile))
    return profiles


def public_profile_units(db: sqlite3.Connection) -> list[str]:
    rows = db.execute(
        """
        SELECT DISTINCT unit
        FROM users
        WHERE profile_public = 1
          AND verified_at IS NOT NULL
          AND unit IS NOT NULL
          AND unit != ''
        ORDER BY LOWER(unit)
        """
    ).fetchall()
    return [row["unit"] for row in rows]


def recently_played_with(db: sqlite3.Connection, steam_id: str) -> list[dict[str, Any]]:
    rows = db.execute(
        """
        WITH my_events AS (
            SELECT official_server, received_at
            FROM server_events
            WHERE steam_id = ?
            ORDER BY received_at DESC
            LIMIT 30
        )
        SELECT se.steam_id, MAX(se.received_at) AS last_played_at, MAX(se.official_server) AS server
        FROM server_events se
        JOIN my_events me ON me.official_server = se.official_server
                           AND ABS(se.received_at - me.received_at) <= 7200
        JOIN users u ON u.steam_id = se.steam_id
        WHERE se.steam_id != ?
          AND u.profile_public = 1
          AND u.verified_at IS NOT NULL
        GROUP BY se.steam_id
        ORDER BY last_played_at DESC
        LIMIT 24
        """,
        (steam_id, steam_id),
    ).fetchall()
    profiles: list[dict[str, Any]] = []
    for row in rows:
        profile = profile_for(db, row["steam_id"])
        if profile and profile["profile_public"]:
            profiles.append(public_profile_card(profile, {"last_played_at": row["last_played_at"], "server": row["server"]}))
    return profiles


def unlock_achievements(db: sqlite3.Connection, steam_id: str, contextual_ids: list[str] | None = None) -> list[str]:
    stats = db.execute("SELECT * FROM stats WHERE steam_id = ?", (steam_id,)).fetchone()
    if stats is None:
        return []
    level = level_for_xp(stats["xp"])
    eligible: list[str] = []

    def add(achievement_id: str) -> None:
        if achievement_id in ACHIEVEMENTS and achievement_id not in eligible:
            eligible.append(achievement_id)

    for achievement_id in contextual_ids or []:
        add(achievement_id)
    if stats["kills"] >= 1:
        add("first_blood")
    if stats["kills"] >= 10:
        add("trooper_10")
    if stats["kills"] >= 100:
        add("veteran_100")
    if stats["droid_kills"] >= 100:
        add("roger_roger")
    if stats["droid_kills"] >= 1000:
        add("master_scrapper")
    if stats["missions"] >= 1:
        add("first_deployment")
        add("welcome_to_the_front")
    if stats["missions"] >= 5:
        add("hold_the_line")
    if stats["missions"] >= 10:
        add("seasoned_10")
    if stats["credits"] >= 1000:
        add("credit_1000")
    if stats["credits"] >= 10000:
        add("payday")
    if stats["kamino_visits"] >= 1:
        add("kamino_shiny")
    if stats["geonosis_missions"] >= 5:
        add("veteran_of_geonosis")
    if stats["friendly_fire_missions"] >= 1:
        add("same_team")
    if stats["high_death_missions"] >= 1:
        add("droid_bait")
    if stats["perfect_missions"] >= 1:
        add("survivor")
    if level >= 5:
        add("level_5")

    unlocked = []
    unlocked_at = now()
    for achievement_id in eligible:
        cursor = db.execute(
            "INSERT OR IGNORE INTO achievements (steam_id, achievement_id, unlocked_at) VALUES (?, ?, ?)",
            (steam_id, achievement_id, unlocked_at),
        )
        if cursor.rowcount:
            unlocked.append(achievement_id)
    return unlocked


class ApiHandler(BaseHTTPRequestHandler):
    server_version = "TCW"
    sys_version = ""

    def version_string(self) -> str:
        return "TCW"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"{self.address_string()} - {fmt % args}")

    def send_json(self, status: int, value: Any, headers: dict[str, str] | None = None) -> None:
        body = json_bytes(value)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        origin = self.headers.get("Origin", "").rstrip("/")
        if origin in ALLOWED_CORS_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        for key, header_value in (headers or {}).items():
            self.send_header(key, header_value)
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:  # noqa: N802
        origin = self.headers.get("Origin", "").rstrip("/")
        if origin not in ALLOWED_CORS_ORIGINS:
            self.send_response(HTTPStatus.FORBIDDEN)
            self.end_headers()
            return
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Access-Control-Allow-Origin", origin)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Vary", "Origin")
        self.end_headers()

    def send_html(self, status: int, title: str, message: str) -> None:
        body = (
            "<!doctype html><meta charset='utf-8'><title>"
            + html.escape(title)
            + "</title><style>body{background:#11151c;color:#f1f4f8;font-family:system-ui;"
            "display:grid;place-items:center;min-height:100vh;margin:0}.card{background:#181e28;"
            "border:1px solid #4f7898;border-radius:12px;padding:32px;max-width:560px}</style>"
            "<div class='card'><h1>"
            + html.escape(title)
            + "</h1><p>"
            + html.escape(message)
            + "</p></div>"
        ).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_steam_return_html(self, status: int, title: str, message: str, result: str, user_code: str) -> None:
        query = {"steam": result}
        if user_code:
            query["user_code"] = user_code
        return_url = f"{WEB_BASE_URL}/profile.html?{urllib.parse.urlencode(query)}"
        escaped_url = html.escape(return_url, quote=True)
        body = (
            "<!doctype html><html lang='en'><head><meta charset='utf-8'><title>"
            + html.escape(title)
            + "</title><meta name='viewport' content='width=device-width,initial-scale=1'>"
            + (f"<meta http-equiv='refresh' content='2;url={escaped_url}'>" if status < 400 else "")
            + "<style>body{background:#070b12;color:#f1f4f8;font-family:system-ui,sans-serif;"
            "display:grid;place-items:center;min-height:100vh;margin:0}.card{background:#101722;"
            "border:1px solid #4f7898;border-radius:12px;padding:32px;max-width:620px}"
            "a{display:inline-block;margin-top:18px;color:#111;background:#f1f4f8;border-radius:8px;"
            "padding:12px 18px;text-decoration:none;font-weight:800}</style></head><body><div class='card'><h1>"
            + html.escape(title)
            + "</h1><p>"
            + html.escape(message)
            + "</p><a href='"
            + escaped_url
            + "'>Return to TCWA3 Profile</a></div></body></html>"
        ).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_body(self, max_bytes: int = MAX_BODY_BYTES) -> bytes:
        length = int(self.headers.get("Content-Length", "0"))
        if length < 0 or length > max_bytes:
            raise ValueError("Request body is too large")
        return self.rfile.read(length)

    def read_json(self, body: bytes | None = None, max_bytes: int = MAX_BODY_BYTES) -> dict[str, Any]:
        decoded = json.loads((body if body is not None else self.read_body(max_bytes)).decode("utf-8"))
        if not isinstance(decoded, dict):
            raise ValueError("JSON body must be an object")
        return decoded

    def bearer_steam_id(self, db: sqlite3.Connection) -> str | None:
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            return None
        hashed = token_hash(authorization[7:].strip())
        timestamp = now()
        session = db.execute(
            "SELECT steam_id FROM sessions WHERE token_hash = ? AND expires_at > ?",
            (hashed, timestamp),
        ).fetchone()
        if session is None:
            return None
        db.execute(
            "UPDATE sessions SET last_used_at = ?, expires_at = ? WHERE token_hash = ?",
            (timestamp, timestamp + SESSION_DAYS * 86400, hashed),
        )
        db.commit()
        return session["steam_id"]

    def has_admin_token(self) -> bool:
        if not NEWS_ADMIN_TOKEN:
            return False
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            return False
        return hmac.compare_digest(authorization[7:].strip(), NEWS_ADMIN_TOKEN)

    def has_community_manager_token(self) -> bool:
        if not COMMUNITY_MANAGER_TOKEN:
            return False
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            return False
        return hmac.compare_digest(authorization[7:].strip(), COMMUNITY_MANAGER_TOKEN)

    def do_GET(self) -> None:  # noqa: N802
        # This handler is intentionally small and explicit. Adding a route here
        # should also update docs/ARCHITECTURE.md and any Cloudflare WAF rules.
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path in ["/health", "/v1/health"]:
            self.send_json(HTTPStatus.OK, {"status": "ok"})
            return
        if parsed.path == "/v1/news":
            self.send_json(HTTPStatus.OK, {"items": load_news(), "updated_at": now()})
            return
        if parsed.path == "/v1/events":
            self.send_json(HTTPStatus.OK, load_event_manifest())
            return
        if parsed.path == "/v1/youtube/latest":
            self.send_json(HTTPStatus.OK, latest_youtube_video())
            return
        if parsed.path == "/v1/audio":
            self.send_json(HTTPStatus.OK, load_audio_manifest())
            return
        if parsed.path == "/v1/themes":
            self.send_json(HTTPStatus.OK, load_theme_manifest())
            return
        if parsed.path == "/v1/avatars":
            self.send_json(HTTPStatus.OK, {"avatars": avatar_catalog(), "default_avatar_id": DEFAULT_AVATAR_ID, "updated_at": now()})
            return
        if parsed.path == "/v1/marketplace":
            with connect_db() as db:
                steam_id = self.bearer_steam_id(db)
                self.send_json(HTTPStatus.OK, marketplace_catalog_for_player(db, steam_id) if steam_id else marketplace_catalog_for_player())
            return
        if parsed.path == "/v1/profiles":
            query = urllib.parse.parse_qs(parsed.query)
            unit = str(query.get("unit", [""])[0])[:32].strip()
            sort_mode = str(query.get("sort", ["active"])[0]).strip().lower()
            if sort_mode not in {"active", "legion", "level"}:
                sort_mode = "active"
            with connect_db() as db:
                self.send_json(
                    HTTPStatus.OK,
                    {
                        "profiles": list_public_profiles(db, unit, sort_mode),
                        "units": public_profile_units(db),
                        "updated_at": now(),
                    },
                )
            return
        if parsed.path == "/v1/admin/news":
            if not self.has_admin_token():
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_admin_token"})
                return
            self.send_json(HTTPStatus.OK, {"items": load_news(), "updated_at": now()})
            return
        if parsed.path == "/v1/admin/assets":
            if not self.has_community_manager_token():
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
                return
            self.send_json(HTTPStatus.OK, load_community_asset_inventory())
            return
        if parsed.path == "/v1/admin/events":
            if not self.has_community_manager_token():
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
                return
            self.send_json(HTTPStatus.OK, {"events": load_event_banners(include_inactive=True), "updated_at": now()})
            return
        if parsed.path == "/v1/launcher/latest":
            query = urllib.parse.parse_qs(parsed.query)
            current_version = str(query.get("version", [""])[0])
            self.send_json(HTTPStatus.OK, load_release_manifest(current_version))
            return
        if parsed.path == "/v1/server-status":
            query = urllib.parse.parse_qs(parsed.query)
            ip = str(query.get("ip", [""])[0])
            name = str(query.get("name", [""])[0])
            try:
                port = int(query.get("port", ["0"])[0])
            except (TypeError, ValueError):
                port = 0
            self.send_json(HTTPStatus.OK, battlemetrics_status(ip, port, name))
            return
        if parsed.path == "/v1/me":
            with connect_db() as db:
                steam_id = self.bearer_steam_id(db)
                if steam_id is None:
                    self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                    return
                profile = profile_for(db, steam_id)
            self.send_json(HTTPStatus.OK, {"profile": profile})
            return
        if parsed.path == "/v1/me/recent":
            with connect_db() as db:
                steam_id = self.bearer_steam_id(db)
                if steam_id is None:
                    self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                    return
                self.send_json(HTTPStatus.OK, {"profiles": recently_played_with(db, steam_id), "updated_at": now()})
            return
        if parsed.path == "/v1/auth/steam":
            self.start_steam_login(parsed)
            return
        if parsed.path == "/v1/auth/steam/callback":
            self.finish_steam_login(parsed)
            return
        self.send_json(HTTPStatus.NOT_FOUND, {"error": "not_found"})

    def do_POST(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        try:
            if parsed.path == "/v1/auth/device/start":
                self.start_device_auth()
                return
            if parsed.path == "/v1/auth/device/token":
                self.exchange_device_token()
                return
            if parsed.path == "/v1/auth/logout":
                self.logout()
                return
            if parsed.path == "/v1/me":
                self.update_profile()
                return
            if parsed.path == "/v1/me/achievements/acknowledge":
                self.acknowledge_achievements()
                return
            if parsed.path == "/v1/me/roster-link":
                self.link_roster_profile()
                return
            if parsed.path == "/v1/marketplace/purchase":
                self.purchase_marketplace_item()
                return
            if parsed.path == "/v1/admin/news":
                self.update_news()
                return
            if parsed.path == "/v1/admin/events":
                self.update_events()
                return
            if parsed.path == "/v1/admin/assets/upload":
                self.upload_community_asset()
                return
            if parsed.path == "/v1/admin/assets/delete":
                self.delete_community_asset()
                return
            if parsed.path == "/v1/server/events":
                self.ingest_events()
                return
        except (ValueError, json.JSONDecodeError) as exc:
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": "bad_request", "message": str(exc)})
            return
        self.send_json(HTTPStatus.NOT_FOUND, {"error": "not_found"})

    def start_device_auth(self) -> None:
        if not PUBLIC_BASE_URL:
            self.send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": "public_url_not_configured"})
            return
        # The launcher cannot safely embed Steam credentials, so it receives a
        # short-lived device_code and opens the browser for real Steam OpenID.
        device_code = secrets.token_urlsafe(32)
        alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        user_code = "".join(secrets.choice(alphabet) for _ in range(8))
        timestamp = now()
        with connect_db() as db:
            db.execute("DELETE FROM device_codes WHERE expires_at <= ?", (timestamp,))
            db.execute(
                "INSERT INTO device_codes (device_hash, user_code, created_at, expires_at) VALUES (?, ?, ?, ?)",
                (token_hash(device_code), user_code, timestamp, timestamp + DEVICE_CODE_TTL),
            )
        verification_uri = f"{PUBLIC_BASE_URL}/v1/auth/steam?{urllib.parse.urlencode({'user_code': user_code})}"
        self.send_json(
            HTTPStatus.OK,
            {
                "device_code": device_code,
                "user_code": user_code,
                "verification_uri": verification_uri,
                "expires_in": DEVICE_CODE_TTL,
                "interval": 3,
            },
        )

    def start_steam_login(self, parsed: urllib.parse.ParseResult) -> None:
        query = urllib.parse.parse_qs(parsed.query)
        user_code = str(query.get("user_code", [""])[0]).upper()
        with connect_db() as db:
            device = db.execute(
                "SELECT user_code FROM device_codes WHERE user_code = ? AND status = 'pending' AND expires_at > ?",
                (user_code, now()),
            ).fetchone()
        if device is None:
            self.send_html(HTTPStatus.BAD_REQUEST, "Invalid code", "This TCWA3 sign-in code is invalid or expired.")
            return
        return_to = f"{PUBLIC_BASE_URL}/v1/auth/steam/callback?{urllib.parse.urlencode({'user_code': user_code})}"
        parameters = {
            "openid.ns": "http://specs.openid.net/auth/2.0",
            "openid.mode": "checkid_setup",
            "openid.return_to": return_to,
            "openid.realm": PUBLIC_BASE_URL + "/",
            "openid.identity": "http://specs.openid.net/auth/2.0/identifier_select",
            "openid.claimed_id": "http://specs.openid.net/auth/2.0/identifier_select",
        }
        self.send_response(HTTPStatus.FOUND)
        self.send_header("Location", STEAM_OPENID + "?" + urllib.parse.urlencode(parameters))
        self.end_headers()

    def finish_steam_login(self, parsed: urllib.parse.ParseResult) -> None:
        query = urllib.parse.parse_qs(parsed.query)
        user_code = str(query.get("user_code", [""])[0]).upper()
        openid = {key: values[0] for key, values in query.items() if key.startswith("openid.")}
        claimed_id = openid.get("openid.claimed_id", "")
        steam_id = claimed_id.rsplit("/", 1)[-1]
        if not STEAM_ID_PATTERN.fullmatch(steam_id) or not self.verify_steam_openid(openid):
            self.send_steam_return_html(HTTPStatus.UNAUTHORIZED, "Sign-in failed", "Steam could not verify this sign-in.", "failed", user_code)
            return
        # Approval is stored against the pending device code. The launcher later
        # exchanges its private device_code for a bearer token; the user_code in
        # the browser is not enough to create a launcher session by itself.
        timestamp = now()
        with connect_db() as db:
            device = db.execute(
                "SELECT user_code FROM device_codes WHERE user_code = ? AND status = 'pending' AND expires_at > ?",
                (user_code, timestamp),
            ).fetchone()
            if device is None:
                self.send_steam_return_html(HTTPStatus.BAD_REQUEST, "Code expired", "Return to TCWA3 and start sign-in again.", "failed", user_code)
                return
            steam_display_name = fetch_steam_display_name(steam_id) or DEFAULT_DISPLAY_NAME
            db.execute(
                """
                INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(steam_id) DO UPDATE SET
                    verified_at = excluded.verified_at,
                    display_name = CASE
                        WHEN (users.arma_profile_name IS NULL OR users.arma_profile_name = '')
                         AND (users.roster_name IS NULL OR users.roster_name = '')
                         AND (users.display_name IS NULL OR users.display_name = ''
                              OR users.display_name IN ('Unknown', 'Unknown Steam', 'Unknown Trooper', 'Clone trooper'))
                        THEN excluded.display_name ELSE users.display_name END,
                    updated_at = excluded.updated_at
                """,
                (steam_id, steam_display_name, timestamp, timestamp, timestamp),
            )
            db.execute("INSERT OR IGNORE INTO stats (steam_id) VALUES (?)", (steam_id,))
            db.execute(
                "UPDATE device_codes SET steam_id = ?, status = 'approved' WHERE user_code = ?",
                (steam_id, user_code),
            )
        self.send_steam_return_html(
            HTTPStatus.OK,
            "Steam verified",
            "Your TCW profile is connected. Returning you to the website profile page now.",
            "verified",
            user_code,
        )

    @staticmethod
    def verify_steam_openid(openid: dict[str, str]) -> bool:
        payload = dict(openid)
        payload["openid.mode"] = "check_authentication"
        request = urllib.request.Request(
            STEAM_OPENID,
            data=urllib.parse.urlencode(payload).encode("utf-8"),
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                result = response.read().decode("utf-8", "replace")
        except (urllib.error.URLError, TimeoutError):
            return False
        return "is_valid:true" in result

    def exchange_device_token(self) -> None:
        payload = self.read_json()
        device_code = str(payload.get("device_code", ""))
        if not device_code:
            raise ValueError("device_code is required")
        timestamp = now()
        with connect_db() as db:
            device = db.execute(
                "SELECT steam_id, status, expires_at, consumed_at FROM device_codes WHERE device_hash = ?",
                (token_hash(device_code),),
            ).fetchone()
            if device is None or device["expires_at"] <= timestamp:
                self.send_json(HTTPStatus.BAD_REQUEST, {"error": "expired_token"})
                return
            if device["status"] == "pending":
                self.send_json(HTTPStatus.ACCEPTED, {"status": "pending"})
                return
            if not device["steam_id"]:
                self.send_json(
                    HTTPStatus.CONFLICT,
                    {
                        "error": "already_consumed",
                        "message": "This Steam sign-in was already used. Press Login With Steam to start a fresh sign-in.",
                    },
                )
                return
            session_token = secrets.token_urlsafe(48)
            db.execute(
                "INSERT INTO sessions (token_hash, steam_id, created_at, expires_at, last_used_at) VALUES (?, ?, ?, ?, ?)",
                (token_hash(session_token), device["steam_id"], timestamp, timestamp + SESSION_DAYS * 86400, timestamp),
            )
            if device["consumed_at"] is None:
                db.execute("UPDATE device_codes SET consumed_at = ? WHERE device_hash = ?", (timestamp, token_hash(device_code)))
            profile = profile_for(db, device["steam_id"])
        self.send_json(HTTPStatus.OK, {"access_token": session_token, "token_type": "Bearer", "profile": profile})

    def logout(self) -> None:
        authorization = self.headers.get("Authorization", "")
        if authorization.startswith("Bearer "):
            with connect_db() as db:
                db.execute("DELETE FROM sessions WHERE token_hash = ?", (token_hash(authorization[7:].strip()),))
        self.send_json(HTTPStatus.OK, {"status": "signed_out"})

    def update_profile(self) -> None:
        payload = self.read_json()
        bio = clean_profile_bio(payload.get("bio", ""))
        profile_public = bool(payload.get("profile_public", True))
        avatar_id = None
        if "avatar_id" in payload:
            avatar_id = clean_avatar_id(payload.get("avatar_id", DEFAULT_AVATAR_ID))
            if not avatar_id_is_available(avatar_id):
                raise ValueError("avatar_id is not available")
        timestamp = now()
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            if avatar_id is None:
                db.execute(
                    "UPDATE users SET bio = ?, profile_public = ?, updated_at = ? WHERE steam_id = ?",
                    (bio, 1 if profile_public else 0, timestamp, steam_id),
                )
            else:
                db.execute(
                    "UPDATE users SET bio = ?, profile_public = ?, avatar_id = ?, updated_at = ? WHERE steam_id = ?",
                    (bio, 1 if profile_public else 0, avatar_id, timestamp, steam_id),
                )
            profile = profile_for(db, steam_id)
            safe_write_player_profile_snapshot(db, steam_id)
        self.send_json(HTTPStatus.OK, {"status": "saved", "profile": profile, "max_bio_chars": MAX_PROFILE_BIO_CHARS})

    def acknowledge_achievements(self) -> None:
        payload = self.read_json()
        achievement_ids = payload.get("achievement_ids", [])
        if achievement_ids is None:
            achievement_ids = []
        if not isinstance(achievement_ids, list):
            raise ValueError("achievement_ids must be a list")
        clean_ids = [str(achievement_id) for achievement_id in achievement_ids if str(achievement_id) in ACHIEVEMENTS]
        timestamp = now()
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            if clean_ids:
                placeholders = ",".join("?" for _ in clean_ids)
                db.execute(
                    f"UPDATE achievements SET acknowledged_at = ? WHERE steam_id = ? AND achievement_id IN ({placeholders})",
                    [timestamp, steam_id, *clean_ids],
                )
            else:
                db.execute(
                    "UPDATE achievements SET acknowledged_at = ? WHERE steam_id = ? AND acknowledged_at IS NULL",
                    (timestamp, steam_id),
                )
            profile = profile_for(db, steam_id)
            safe_write_player_profile_snapshot(db, steam_id)
        self.send_json(HTTPStatus.OK, {"status": "acknowledged", "profile": profile})

    def link_roster_profile(self) -> None:
        # Roster linking is automatic when the player's SteamID64 exists in the
        # configured TCW squad XML. This endpoint lets the UI force a fresh check.
        try:
            sync_roster()
        except Exception as exc:
            print(f"Manual roster sync failed: {exc}")
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            profile = profile_for(db, steam_id)
            if profile:
                safe_write_player_profile_snapshot(db, steam_id)
        self.send_json(HTTPStatus.OK, {"status": "checked", "profile": profile})

    def purchase_marketplace_item(self) -> None:
        payload = self.read_json()
        item_id = str(payload.get("item_id", "")).strip()
        if not item_id:
            raise ValueError("item_id is required")
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            status, result = purchase_marketplace_item(db, steam_id, item_id)
        self.send_json(status, result)

    def update_news(self) -> None:
        if not self.has_admin_token():
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_admin_token"})
            return
        payload = save_news_payload(self.read_json())
        self.send_json(HTTPStatus.OK, {"status": "saved", "items": payload["items"], "updated_at": now()})

    def update_events(self) -> None:
        if not self.has_community_manager_token():
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
            return
        payload = save_events_payload(self.read_json())
        self.send_json(
            HTTPStatus.OK,
            {
                "status": "saved",
                "events": payload["events"],
                "manifest": load_event_manifest(),
                "updated_at": now(),
            },
        )

    def upload_community_asset(self) -> None:
        if not self.has_community_manager_token():
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
            return
        payload = self.read_json(max_bytes=max(MAX_BODY_BYTES, COMMUNITY_MANAGER_MAX_FILE_BYTES * 2))
        file_payload = payload.get("file")
        if not isinstance(file_payload, dict):
            raise ValueError("file is required")
        filename = file_payload.get("name")
        data = decode_asset_upload(file_payload.get("data_base64") or file_payload.get("data"))
        target = str(payload.get("target", "")).strip().lower()
        if target == "audio":
            asset = save_audio_upload(payload.get("category"), filename, data)
            self.send_json(
                HTTPStatus.OK,
                {"status": "saved", "asset": asset, "inventory": load_community_asset_inventory()},
            )
            return
        if target == "theme":
            theme = save_theme_upload(
                payload.get("theme_id"),
                payload.get("theme_name"),
                payload.get("asset_type"),
                filename,
                data,
            )
            self.send_json(
                HTTPStatus.OK,
                {"status": "saved", "theme": theme, "inventory": load_community_asset_inventory()},
            )
            return
        if target == "theme_manifest":
            theme = save_theme_metadata(payload)
            self.send_json(
                HTTPStatus.OK,
                {"status": "saved", "theme": theme, "inventory": load_community_asset_inventory()},
            )
            return
        raise ValueError("target must be audio, theme, or theme_manifest")

    def delete_community_asset(self) -> None:
        if not self.has_community_manager_token():
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
            return
        payload = self.read_json()
        kind = str(payload.get("kind", "")).strip().lower()
        binned: dict[str, Any] | None
        if kind == "audio":
            binned = delete_audio_asset(payload.get("category"), payload.get("filename"))
        elif kind == "theme":
            binned = delete_theme_asset(payload.get("theme_id"), payload.get("path"))
        else:
            raise ValueError("kind must be audio or theme")
        self.send_json(HTTPStatus.OK, {"status": "binned", "bin_item": binned, "inventory": load_community_asset_inventory()})

    def ingest_events(self) -> None:
        body = self.read_body()
        server_id = self.headers.get("X-TCW-Server", "")
        timestamp_text = self.headers.get("X-TCW-Timestamp", "")
        signature = self.headers.get("X-TCW-Signature", "").lower()
        secret = SERVER_KEYS.get(server_id)
        if not secret or not timestamp_text.isdigit() or abs(now() - int(timestamp_text)) > 300:
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_server_auth"})
            return
        # Official Arma servers sign the exact raw JSON body. The timestamp is
        # included in the HMAC input so captured requests cannot be replayed.
        expected = hmac.new(secret.encode("utf-8"), timestamp_text.encode("ascii") + b"." + body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, signature):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_server_signature"})
            return
        payload = self.read_json(body)
        events = payload.get("events", [])
        if not isinstance(events, list) or not events or len(events) > 500:
            raise ValueError("events must contain between 1 and 500 items")
        accepted = 0
        duplicates = 0
        unlocked: dict[str, list[str]] = {}
        active_xp_event_ids: set[str] = set()
        with connect_db() as db:
            for event in events:
                if not isinstance(event, dict):
                    raise ValueError("each event must be an object")
                event_id = str(event.get("event_id", ""))[:128]
                steam_id = str(event.get("steam_id", ""))
                if not event_id or not STEAM_ID_PATTERN.fullmatch(steam_id):
                    raise ValueError("event_id and a valid SteamID64 are required")
                timestamp = now()
                cursor = db.execute(
                    "INSERT OR IGNORE INTO server_events (event_id, official_server, steam_id, payload_json, received_at) VALUES (?, ?, ?, ?, ?)",
                    (event_id, server_id, steam_id, json.dumps(event, ensure_ascii=False), timestamp),
                )
                if not cursor.rowcount:
                    # event_id is the idempotency key. Server retries are safe
                    # because duplicates are counted but do not affect stats.
                    duplicates += 1
                    continue
                display_name = clean_profile_name(event.get("profile_name"))
                has_real_arma_name = not is_generic_display_name(display_name)
                db.execute(
                    """
                    INSERT INTO users (steam_id, display_name, arma_profile_name, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(steam_id) DO UPDATE SET
                        display_name = CASE
                            WHEN excluded.arma_profile_name != ''
                             AND excluded.arma_profile_name NOT IN ('Unknown', 'Unknown Steam', 'Unknown Trooper', 'Clone trooper')
                            THEN excluded.display_name ELSE users.display_name END,
                        arma_profile_name = CASE
                            WHEN excluded.arma_profile_name != ''
                             AND excluded.arma_profile_name NOT IN ('Unknown', 'Unknown Steam', 'Unknown Trooper', 'Clone trooper')
                            THEN excluded.arma_profile_name ELSE users.arma_profile_name END,
                        updated_at = excluded.updated_at
                    """,
                    (steam_id, display_name, display_name if has_real_arma_name else "", timestamp, timestamp),
                )
                db.execute("INSERT OR IGNORE INTO stats (steam_id) VALUES (?)", (steam_id,))
                deltas = event.get("stats", {})
                if not isinstance(deltas, dict):
                    raise ValueError("stats must be an object")
                values: dict[str, int] = {}
                for stat, limit in EVENT_STAT_LIMITS.items():
                    value = int(deltas.get(stat, 0))
                    if value < 0 or value > limit:
                        raise ValueError(f"invalid {stat} delta")
                    values[stat] = value
                xp_bonus_percent, xp_event_ids = active_event_xp_bonus(timestamp)
                active_xp_event_ids.update(xp_event_ids)
                values["xp"] = apply_xp_bonus(values["xp"], xp_bonus_percent)
                contextual_ids, mission_progress = achievement_context_for_event(event, values, timestamp)
                droid_kills_delta = values["droid_kills"] or values["enemy_kills"] or values["kills"]
                db.execute(
                    """
                    UPDATE stats SET kills = kills + ?, deaths = deaths + ?, credits = credits + ?,
                                     xp = xp + ?, missions = missions + ?, playtime_seconds = playtime_seconds + ?,
                                     droid_kills = droid_kills + ?, friendly_kills = friendly_kills + ?,
                                     kamino_visits = kamino_visits + ?, geonosis_missions = geonosis_missions + ?,
                                     friendly_fire_missions = friendly_fire_missions + ?,
                                     high_death_missions = high_death_missions + ?, perfect_missions = perfect_missions + ?
                    WHERE steam_id = ?
                    """,
                    (
                        values["kills"], values["deaths"], values["credits"], values["xp"],
                        values["missions"], values["playtime_seconds"], droid_kills_delta,
                        values["friendly_kills"], mission_progress["kamino_visits"],
                        mission_progress["geonosis_missions"], mission_progress["friendly_fire_missions"],
                        mission_progress["high_death_missions"], mission_progress["perfect_missions"], steam_id,
                    ),
                )
                new_achievements = unlock_achievements(db, steam_id, contextual_ids)
                if event_mission_completed(event, values):
                    record_campaign_deployment(db, steam_id, event_id, server_id, event, new_achievements, timestamp)
                if new_achievements:
                    unlocked[steam_id] = new_achievements
                safe_write_player_profile_snapshot(db, steam_id)
                accepted += 1
        response: dict[str, Any] = {"accepted": accepted, "duplicates": duplicates, "achievements_unlocked": unlocked}
        if active_xp_event_ids:
            response["active_xp_events"] = sorted(active_xp_event_ids)
        self.send_json(HTTPStatus.OK, response)


def main() -> None:
    initialize_database()
    try:
        print(f"Initial roster sync: {sync_roster()}")
    except Exception as exc:
        print(f"Initial roster sync failed: {exc}")
    threading.Thread(target=roster_sync_loop, name="roster-sync", daemon=True).start()
    server = ThreadingHTTPServer((BIND_HOST, PORT), ApiHandler)
    print(f"TCW profile API listening on {BIND_HOST}:{PORT}")
    server.serve_forever()


if __name__ == "__main__":
    main()
