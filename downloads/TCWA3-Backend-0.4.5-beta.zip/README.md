# TCW Profile API

Core services for verified Steam profiles, official-server progression, achievements, and launcher sessions.

## Legal notice

This backend is part of the TCWA3 Launcher project owned by Hacket2130, also known as Logan Greaves. Redistribution, resale, rebranding, or modification outside approved TCWA3 development work is prohibited without written permission.

Created with the brilliant work of Codex.

Star Wars, The Clone Wars, and related names, marks, characters, and imagery are the property of Lucasfilm Ltd. and Disney. All rights reserved by their respective owners. This project is an unofficial community tool and is not affiliated with, endorsed by, sponsored by, or approved by Lucasfilm, Disney, Bohemia Interactive, Valve, or Steam.

## Trust boundaries

- Players authenticate through Steam OpenID. A submitted SteamID is never treated as proof of identity.
- Only servers with a configured HMAC key can submit progression events.
- Every event has a globally unique `event_id`; retries do not double-count stats.
- The Arma profile name is accepted only from a signed official-server event.
- The public TCW squad XML is synchronized every 15 minutes for roster names, units and ranks.
- Mission-reported Arma names take priority over roster names after a player joins an official server.

## Steam profile sign-in

Launcher and website sign-in both use the same device-auth pattern:

1. Client calls `POST /v1/auth/device/start`.
2. Backend creates a short-lived device code and returns a Steam verification URL.
3. Player signs in with Steam through `GET /v1/auth/steam`.
4. Steam returns to `GET /v1/auth/steam/callback`.
5. Client polls `POST /v1/auth/device/token` until it receives a bearer token.

The website stores the pending device code in browser local storage so mobile
browsers can leave for Steam and return without losing the login. The callback
uses `TCW_WEB_BASE_URL` to return the player to `/profile.html?steam=verified`.
Cloudflare must allow browser `OPTIONS` preflight requests for this flow.

## Signed event format

`POST /v1/server/events` with headers:

- `X-TCW-Server`: configured official server ID
- `X-TCW-Timestamp`: current Unix timestamp
- `X-TCW-Signature`: lowercase SHA-256 HMAC of `<timestamp>.<raw-json-body>`

```json
{
  "events": [
    {
      "event_id": "server-1:mission-id:steam-id:sequence",
      "steam_id": "76561198000000000",
      "profile_name": "CT-2130 \"Hacket\"",
      "stats": {
        "kills": 1,
        "deaths": 0,
        "credits": 5,
        "xp": 10,
        "missions": 0,
        "playtime_seconds": 60
      }
    }
  ]
}
```

Use `tools/sign_server_event_request.py` from the repo root to generate the
same headers, print a curl command, or send an official-server smoke request
without printing the server secret.

## Production requirements

The API binds to localhost. Put Caddy or nginx in front of it and configure HTTPS before enabling Steam sign-in. Never expose profile tokens over plain HTTP.

Recommended production API domain:

```text
https://api.tcwa3.co.uk
```

Create an `A` record for `api.tcwa3.co.uk` pointing to the Hetzner server IPv4 address, then configure the reverse proxy to serve HTTPS for that hostname.
