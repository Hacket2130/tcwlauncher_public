#!/usr/bin/env python3
"""TCW Launcher profile and progression API.

Dependency-free by design. HTTPS should be terminated by a reverse proxy.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import html
import json
import math
import os
import re
import secrets
import shutil
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


def parse_env_utc_timestamp(name: str, default_value: str) -> int:
    value = os.getenv(name, default_value).strip() or default_value
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        parsed = datetime.fromisoformat(default_value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return int(parsed.astimezone(timezone.utc).timestamp())


DATABASE_PATH = Path(os.getenv("TCW_DATABASE_PATH", "/srv/tcw-launcher/data/tcw.sqlite3"))
PLAYER_DATA_ROOT = Path(os.getenv("TCW_PLAYER_DATA_ROOT", "/srv/tcw-launcher/data/players"))
PUBLIC_BASE_URL = os.getenv("TCW_PUBLIC_BASE_URL", "").rstrip("/")
WEB_BASE_URL = os.getenv("TCW_WEB_BASE_URL", "https://tcwa3.co.uk").rstrip("/")
BIND_HOST = os.getenv("TCW_BIND_HOST", "127.0.0.1")
PORT = int(os.getenv("TCW_PORT", "8080"))
SQUAD_XML_URL = os.getenv(
    "TCW_SQUAD_XML_URL",
    "https://arma-stats.root-storm.com/public/squads/tcwa3/squad.xml",
)
ROSTER_SYNC_SECONDS = int(os.getenv("TCW_ROSTER_SYNC_SECONDS", "900"))
STATS_PROXY_URL = os.getenv(
    "TCWA3_STATS_PROXY_URL",
    "https://app--tcwa3.base44.app/api/apps/6986a916d70fdb8646418766/functions/armaProxy",
).strip()
STATS_PROXY_TIMEOUT_SECONDS = float(os.getenv("TCWA3_STATS_PROXY_TIMEOUT_SECONDS", "12"))
STATS_PROXY_DISCORD_LOOKUP_PATH = os.getenv("TCWA3_STATS_PROXY_DISCORD_LOOKUP_PATH", "").strip()
ROOT_STORM_API_BASE_URL = os.getenv("ROOT_STORM_API_BASE_URL", "https://arma-stats.root-storm.com").strip().rstrip("/")
ROOT_STORM_DISCORD_LOOKUP_PATH = os.getenv("ROOT_STORM_DISCORD_LOOKUP_PATH", "").strip()
ROOT_STORM_MACHINE_TOKEN = os.getenv("ROOT_STORM_MACHINE_TOKEN", "").strip()
ROOT_STORM_MACHINE_TOKEN_PATH = os.getenv("ROOT_STORM_MACHINE_TOKEN_PATH", "").strip()
ROOT_STORM_TIMEOUT_SECONDS = float(os.getenv("ROOT_STORM_TIMEOUT_SECONDS", str(STATS_PROXY_TIMEOUT_SECONDS)))
NEWS_PATH = Path(os.getenv("TCW_NEWS_PATH", "/srv/tcw-launcher/data/news.json"))
EVENTS_PATH = Path(os.getenv("TCW_EVENTS_PATH", "/srv/tcw-launcher/data/events.json"))
SERVER_CONTROLS_PATH = Path(os.getenv("TCW_SERVER_CONTROLS_PATH", "/srv/tcw-launcher/data/server_controls.json"))
SERVER_CATALOG_PATH = Path(os.getenv("TCW_SERVER_CATALOG_PATH", "/srv/tcw-launcher/data/server_catalog.json"))
DEFAULT_SERVER_CATALOG_PATH = Path(__file__).with_name("default_server_catalog.json")
MARKETPLACE_PATH = Path(os.getenv("TCW_MARKETPLACE_PATH", "/srv/tcw-launcher/data/marketplace.json"))
AUDIO_ROOT = Path(os.getenv("TCW_AUDIO_ROOT", "/srv/tcw-launcher/public/audio"))
AUDIO_BASE_URL = os.getenv("TCW_AUDIO_BASE_URL", "https://tcwa3.co.uk/audio").rstrip("/")
THEME_ROOT = Path(os.getenv("TCW_THEME_ROOT", "/srv/tcw-launcher/public/themes"))
THEME_BASE_URL = os.getenv("TCW_THEME_BASE_URL", "https://tcwa3.co.uk/themes").rstrip("/")
AVATAR_ROOT = Path(os.getenv("TCW_AVATAR_ROOT", "/srv/tcw-launcher/public/avatars"))
AVATAR_BASE_URL = os.getenv("TCW_AVATAR_BASE_URL", "https://tcwa3.co.uk/avatars").rstrip("/")
ASSET_BIN_ROOT = Path(os.getenv("TCW_ASSET_BIN_ROOT", "/srv/tcw-launcher/data/asset_bin"))
ASSET_BIN_RETENTION_SECONDS = int(os.getenv("TCW_ASSET_BIN_RETENTION_SECONDS", str(7 * 86400)))
RELEASE_PATH = Path(os.getenv("TCW_RELEASE_PATH", "/srv/tcw-launcher/release.json"))
SESSION_DAYS = int(os.getenv("TCW_SESSION_DAYS", "365"))
PUBLIC_PROFILE_DEFAULT_LIMIT = 24
PUBLIC_PROFILE_MAX_LIMIT = 60
DEFAULT_CORS_ORIGINS = "https://tcwa3.co.uk,https://www.tcwa3.co.uk"
ALLOWED_CORS_ORIGINS = {
    origin.strip().rstrip("/")
    for origin in os.getenv("TCW_CORS_ORIGINS", DEFAULT_CORS_ORIGINS).split(",")
    if origin.strip()
}
NEWS_ADMIN_TOKEN = os.getenv("TCW_NEWS_ADMIN_TOKEN", "")
COMMUNITY_MANAGER_TOKEN = os.getenv("TCW_COMMUNITY_MANAGER_TOKEN", "")
OWNER_ADMIN_TOKEN = os.getenv("TCW_OWNER_ADMIN_TOKEN", NEWS_ADMIN_TOKEN).strip()
COMMUNITY_MANAGER_MAX_FILE_BYTES = int(os.getenv("TCW_COMMUNITY_MANAGER_MAX_FILE_BYTES", str(50 * 1024 * 1024)))
YOUTUBE_HANDLE = os.getenv("TCW_YOUTUBE_HANDLE", "TheCloneWarsArma-3").strip().lstrip("@")
YOUTUBE_CHANNEL_ID = os.getenv("TCW_YOUTUBE_CHANNEL_ID", "").strip()
YOUTUBE_CACHE_SECONDS = int(os.getenv("TCW_YOUTUBE_CACHE_SECONDS", "900"))
STEAM_WEB_API_KEY = os.getenv("STEAM_WEB_API_KEY", "").strip()
STEAM_NAME_CACHE_SECONDS = int(os.getenv("TCW_STEAM_NAME_CACHE_SECONDS", "86400"))
GEONOSIS_LAUNCH_WEEK_START = parse_env_utc_timestamp("TCW_GEONOSIS_LAUNCH_WEEK_START", "2026-06-22T00:00:00Z")
GEONOSIS_LAUNCH_WEEK_END = parse_env_utc_timestamp("TCW_GEONOSIS_LAUNCH_WEEK_END", "2026-06-29T00:00:00Z")
DEVICE_CODE_TTL = 600
MAX_BODY_BYTES = 1024 * 1024
STEAM_OPENID = "https://steamcommunity.com/openid/login"
STEAM_ID_PATTERN = re.compile(r"^7656119\d{10}$")
PROFILE_NAME_PATTERN = re.compile(r"[^\w\-\[\]()\"' .#]", re.UNICODE)
DISCORD_UNIT_TAG_PATTERN = re.compile(r"(?<![A-Za-z0-9])(\d{2,4})(st|nd|rd|th)(?![A-Za-z0-9])", re.IGNORECASE)
DISCORD_RANK_TAG_PATTERN = re.compile(r"(?<![A-Za-z0-9])([A-Z]{2,5})(?:-\d{1,6})?(?![A-Za-z0-9])")
DISCORD_RANK_TAGS = {
    "ARC",
    "ARF",
    "CC",
    "CMD",
    "COM",
    "CPL",
    "CS",
    "CSM",
    "CT",
    "LCPL",
    "LT",
    "PVT",
    "RC",
    "SCT",
    "SGT",
}

STAT_LIMITS = {
    "kills": 5_000,
    "deaths": 5_000,
    "credits": 1_000_000,
    "xp": 1_000_000,
    "missions": 10_000,
    "playtime_seconds": 172_800,
}

EVENT_STAT_LIMITS = {
    **STAT_LIMITS,
    "droid_kills": 5_000,
    "enemy_kills": 5_000,
    "vehicle_kills": 5_000,
    "aircraft_kills": 5_000,
    "friendly_kills": 5_000,
    "support_score": 1_000_000,
    "revives": 10_000,
    "heals": 10_000,
    "repairs": 10_000,
    "resupplies": 10_000,
    "transport_assists": 10_000,
    "objective_support": 10_000,
    "deployment_attempts": 10_000,
    "deployments_completed": 10_000,
    "deployments_failed": 10_000,
    "deployment_xp_adjustments": 1_000_000,
}

EVENT_STAT_MINIMUMS = {
    "xp": -1_000_000,
    "deployment_xp_adjustments": -1_000_000,
}

LEGACY_LEVEL_BASE_XP = 500
LEGACY_LEVEL_GROWTH_FACTOR = 1.2
LEVEL_BASE_XP = int(os.getenv("TCW_LEVEL_BASE_XP", "1000"))
LEVEL_GROWTH_FACTOR = float(os.getenv("TCW_LEVEL_GROWTH_FACTOR", "1.3"))
MAX_LEVEL_ITERATION = int(os.getenv("TCW_MAX_LEVEL_ITERATION", "500"))

DIFFICULTY_MISSION_XP = {
    1: 0,
    2: 125,
    3: 175,
    4: 250,
    5: 325,
    6: 400,
    7: 500,
    8: 125,
}

DEPLOYMENT_COMPLETION_SUPPORT_SCORE = 25
DROID_KILL_CREDIT_REWARD = int(os.getenv("TCW_DROID_KILL_CREDIT_REWARD", "1"))
VEHICLE_KILL_CREDIT_REWARD = int(os.getenv("TCW_VEHICLE_KILL_CREDIT_REWARD", "5"))
AIRCRAFT_KILL_CREDIT_REWARD = int(os.getenv("TCW_AIRCRAFT_KILL_CREDIT_REWARD", "10"))
REPUBLIC_WEEKLY_WAGE_CREDITS = int(os.getenv("TCW_REPUBLIC_WEEKLY_WAGE_CREDITS", "500"))
REPUBLIC_WAGE_LOOP_SECONDS = int(os.getenv("TCW_REPUBLIC_WAGE_LOOP_SECONDS", "3600"))

SUPPORT_ACTION_REWARDS = {
    "revive": ("revives", 10),
    "heal": ("heals", 2),
    "repair": ("repairs", 5),
    "resupply": ("resupplies", 3),
    "transport_assist": ("transport_assists", 10),
    "objective_support": ("objective_support", 10),
}

SUPPORT_ACTION_ALIASES = {
    "revive": "revive",
    "revived": "revive",
    "medical_revive": "revive",
    "ace_revive": "revive",
    "heal": "heal",
    "healed": "heal",
    "medical_heal": "heal",
    "ace_heal": "heal",
    "repair": "repair",
    "repaired": "repair",
    "vehicle_repair": "repair",
    "resupply": "resupply",
    "resupplied": "resupply",
    "ammo_resupply": "resupply",
    "transport": "transport_assist",
    "transport_assist": "transport_assist",
    "transport_assisted": "transport_assist",
    "objective": "objective_support",
    "objective_support": "objective_support",
    "objective_completed": "objective_support",
}

PROGRESSION_STAT_COLUMNS = {
    "droid_kills": "INTEGER NOT NULL DEFAULT 0",
    "vehicle_kills": "INTEGER NOT NULL DEFAULT 0",
    "aircraft_kills": "INTEGER NOT NULL DEFAULT 0",
    "friendly_kills": "INTEGER NOT NULL DEFAULT 0",
    "support_score": "INTEGER NOT NULL DEFAULT 0",
    "revives": "INTEGER NOT NULL DEFAULT 0",
    "heals": "INTEGER NOT NULL DEFAULT 0",
    "repairs": "INTEGER NOT NULL DEFAULT 0",
    "resupplies": "INTEGER NOT NULL DEFAULT 0",
    "transport_assists": "INTEGER NOT NULL DEFAULT 0",
    "objective_support": "INTEGER NOT NULL DEFAULT 0",
    "kamino_visits": "INTEGER NOT NULL DEFAULT 0",
    "geonosis_missions": "INTEGER NOT NULL DEFAULT 0",
    "friendly_fire_missions": "INTEGER NOT NULL DEFAULT 0",
    "high_death_missions": "INTEGER NOT NULL DEFAULT 0",
    "perfect_missions": "INTEGER NOT NULL DEFAULT 0",
    "deployment_attempts": "INTEGER NOT NULL DEFAULT 0",
    "deployments_completed": "INTEGER NOT NULL DEFAULT 0",
    "deployments_failed": "INTEGER NOT NULL DEFAULT 0",
    "deployment_xp_adjustments": "INTEGER NOT NULL DEFAULT 0",
    "level_floor": "INTEGER NOT NULL DEFAULT 0",
    "level_floor_xp": "INTEGER NOT NULL DEFAULT 0",
    "last_republic_wage_week": "TEXT NOT NULL DEFAULT ''",
    "last_republic_wage_at": "INTEGER NOT NULL DEFAULT 0",
    "republic_wages_received": "INTEGER NOT NULL DEFAULT 0",
    "republic_wage_credits": "INTEGER NOT NULL DEFAULT 0",
}

CAMPAIGN_DEPLOYMENT_COLUMNS = {
    "outcome": "TEXT NOT NULL DEFAULT 'completed'",
    "started_at": "INTEGER NOT NULL DEFAULT 0",
    "ended_at": "INTEGER NOT NULL DEFAULT 0",
    "xp_earned": "INTEGER NOT NULL DEFAULT 0",
    "xp_penalty": "INTEGER NOT NULL DEFAULT 0",
}

ACHIEVEMENT_COLUMNS = {
    "acknowledged_at": "INTEGER",
}

ACHIEVEMENTS = {
    "first_blood": {"name": "First Blood", "description": "Record your first confirmed kill."},
    "trooper_10": {"name": "Battle Ready", "description": "Record 10 confirmed kills."},
    "veteran_100": {"name": "Veteran of the Republic", "description": "Record 100 confirmed kills."},
    "first_deployment": {"name": "First Deployment", "description": "Complete your first official deployment."},
    "seasoned_10": {"name": "Seasoned Trooper", "description": "Complete 10 official deployments."},
    "credit_1000": {"name": "Quartermaster's Friend", "description": "Earn 1,000 credits."},
    "level_5": {"name": "Rising Through the Ranks", "description": "Reach level 5."},
    "level_50": {"name": "To be remembered", "description": "Reach lvl 50."},
    "geonosis_not_shiny_for_long": {
        "name": "Not shiny for long - the battle of geonosis",
        "description": "Complete a Geonosis mission during the first launch week.",
    },
    "kamino_shiny": {"name": "Shiny", "description": "Play on any Kamino hub world."},
    "droid_bait": {"name": "Droid bait", "description": "Die 20 times in the same mission."},
    "master_scrapper": {"name": "Master scrapper", "description": "Destroy 1,000 droids."},
    "same_team": {
        "name": "We're on the same team!",
        "description": "Finish a mission with more friendly kills than enemy kills.",
    },
    "enemy_is_over_there": {
        "name": "The enemy is over there!",
        "description": "Record 100 friendly kills.",
    },
    "welcome_to_the_front": {"name": "Welcome to the front", "description": "Complete your first TCWA3 mission."},
    "roger_roger": {"name": "Roger roger remover", "description": "Destroy 100 droids."},
    "hold_the_line": {"name": "Hold the line", "description": "Complete 5 official missions."},
    "survivor": {"name": "Still standing", "description": "Complete a mission without dying."},
    "veteran_of_geonosis": {"name": "Veteran of Geonosis", "description": "Complete 5 Geonosis missions."},
    "payday": {"name": "Republic payday", "description": "Earn 10,000 credits."},
    "vehicle_breaker_25": {"name": "Armor breaker", "description": "Destroy 25 enemy ground vehicles."},
    "vehicle_column_100": {"name": "Column killer", "description": "Destroy 100 enemy ground vehicles."},
    "air_superiority_10": {"name": "Air superiority", "description": "Destroy 10 enemy aircraft."},
    "gunship_graveyard_50": {"name": "Gunship graveyard", "description": "Destroy 50 enemy aircraft."},
    "campaign_regular_25": {"name": "Campaign regular", "description": "Complete 25 official deployments."},
    "campaign_veteran_50": {"name": "Campaign veteran", "description": "Complete 50 official deployments."},
    "hard_contact": {"name": "Hard contact", "description": "Survive a failed official deployment report."},
    "clean_streak_10": {"name": "Clean section", "description": "Record 10 perfect official deployments."},
    "multi_front_veteran": {"name": "Multi-front veteran", "description": "Fight on three different tracked campaign fronts."},
    "first_support": {"name": "For the squad", "description": "Record your first tracked support action."},
    "battlefield_medic_25": {"name": "Battlefield medic", "description": "Record 25 tracked revives."},
    "field_engineer_50": {"name": "Field engineer", "description": "Record 50 tracked repairs."},
    "quartermaster_100": {"name": "Quartermaster", "description": "Record 100 tracked resupplies."},
    "service_before_glory": {"name": "Service before glory", "description": "Earn 1,000 support score."},
}

DEFAULT_DISPLAY_NAME = "Clone trooper"
GENERIC_DISPLAY_NAMES = {"Unknown", "Unknown Steam", "Unknown Trooper", DEFAULT_DISPLAY_NAME}
MAX_PROFILE_BIO_CHARS = 600
MAX_QUEST_TEXT_CHARS = 1200
MAX_QUEST_HISTORY = 80
DEFAULT_AVATAR_ID = "tcw-standard"
DEFAULT_AVATAR_NAME = "TCW Standard"
DEFAULT_AVATAR_URL = f"{WEB_BASE_URL}/assets/default-profile-avatar.png"
AVATAR_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}

USER_PROFILE_COLUMNS = {
    "bio": "TEXT NOT NULL DEFAULT ''",
    "profile_public": "INTEGER NOT NULL DEFAULT 1",
    "avatar_id": f"TEXT NOT NULL DEFAULT '{DEFAULT_AVATAR_ID}'",
}

DEFAULT_NEWS = [
    {
        "title": "Profiles Online",
        "body": "TCW launcher profiles are now connected to api.tcwa3.co.uk.",
        "date": "2026-06-18",
        "priority": 10,
    },
    {
        "title": "Galaxy Map",
        "body": "The campaign galaxy map is available from the launcher.",
        "date": "2026-06-18",
        "priority": 8,
    },
    {
        "title": "Stats Tracking",
        "body": "Official server stat tracking is being prepared for Root Storm integration.",
        "date": "2026-06-18",
        "priority": 5,
    },
]

DEFAULT_EVENTS: list[dict[str, Any]] = []
EVENT_EFFECTS = {"none", "glow", "pulse", "scanline", "urgent"}
EVENT_POPUP_STYLES = {"banner", "center", "toast", "holonet", "minimal"}
EVENT_FONTS = {"tcw", "military", "holonet", "serif", "mono"}
EVENT_PLACEMENTS = {"top", "center", "bottom", "bottom-left", "bottom-right", "dock-only"}
EVENT_SIZES = {"compact", "standard", "wide"}
COMMUNITY_REACTION_TARGET_TYPES = {"profile", "quest", "activity", "leaderboard", "event"}
COMMUNITY_REACTIONS = {"salute", "medal", "cheer", "boost"}
BOT_LINK_CODE_TTL_SECONDS = int(os.getenv("TCW_DISCORD_BOT_LINK_CODE_TTL_SECONDS", "900"))
BOT_SIGNATURE_WINDOW_SECONDS = int(os.getenv("TCW_DISCORD_BOT_SIGNATURE_WINDOW_SECONDS", "300"))
BOT_LINK_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
COMLINK_ENABLED = os.getenv("TCW_COMLINK_ENABLED", "").strip().lower() in {"1", "true", "yes", "on"}
COMLINK_TRANSPORT = "livekit"
COMLINK_LIVEKIT_URL = os.getenv("TCW_COMLINK_LIVEKIT_URL", "").strip().rstrip("/")
COMLINK_LIVEKIT_API_KEY = os.getenv("TCW_COMLINK_LIVEKIT_API_KEY", "").strip()
COMLINK_LIVEKIT_API_SECRET = os.getenv("TCW_COMLINK_LIVEKIT_API_SECRET", "").strip()
try:
    COMLINK_TOKEN_TTL_SECONDS = int(os.getenv("TCW_COMLINK_TOKEN_TTL_SECONDS", "90"))
except ValueError:
    COMLINK_TOKEN_TTL_SECONDS = 90
COMLINK_TOKEN_TTL_SECONDS = max(30, min(600, COMLINK_TOKEN_TTL_SECONDS))
try:
    COMLINK_LIVEKIT_API_TIMEOUT_SECONDS = float(os.getenv("TCW_COMLINK_LIVEKIT_API_TIMEOUT_SECONDS", "5"))
except ValueError:
    COMLINK_LIVEKIT_API_TIMEOUT_SECONDS = 5.0
COMLINK_LIVEKIT_API_TIMEOUT_SECONDS = max(1.0, min(20.0, COMLINK_LIVEKIT_API_TIMEOUT_SECONDS))
COMLINK_ID_RE = re.compile(r"[^a-z0-9_-]+")
COMLINK_COMMAND_MARKERS = (
    "commander",
    "captain",
    "lieutenant",
    "marshal",
    "major",
    "colonel",
    "general",
    "officer",
)
COMLINK_STAFF_MARKERS = ("admin", "staff", "zeus", "curator", "game master")
COMLINK_DEFAULT_CHANNELS: tuple[dict[str, Any], ...] = (
    {
        "id": "squad",
        "display_name": "Squad Net",
        "channel_kind": "squad",
        "minimum_role": "player",
        "can_publish": True,
        "can_subscribe": True,
    },
    {
        "id": "command",
        "display_name": "Command Net",
        "channel_kind": "command",
        "minimum_role": "command",
        "can_publish": True,
        "can_subscribe": True,
    },
    {
        "id": "staff",
        "display_name": "Staff Net",
        "channel_kind": "staff",
        "minimum_role": "staff",
        "can_publish": True,
        "can_subscribe": True,
    },
)
COMLINK_SESSION_COLUMNS = {
    "client_report_token_hash": "TEXT NOT NULL DEFAULT ''",
}
COMLINK_CLIENT_EVENT_STATUS = {
    "join_succeeded": "joined",
    "join_failed": "failed",
    "media_failed": "failed",
    "reconnecting": "reconnecting",
    "reconnected": "joined",
    "client_left": "left",
}

COMMUNITY_MANAGER_ALLOWED_ROUTES: dict[str, tuple[str, ...]] = {
    "GET": (
        "/v1/admin/assets",
        "/v1/admin/events",
        "/v1/admin/servers",
        "/v1/admin/server-controls",
    ),
    "POST": (
        "/v1/admin/assets/delete",
        "/v1/admin/assets/upload",
        "/v1/admin/events",
        "/v1/admin/servers",
        "/v1/admin/server-controls",
    ),
}
OWNER_ADMIN_ALLOWED_ROUTES: dict[str, tuple[str, ...]] = {
    "GET": (
        "/v1/admin/assets",
        "/v1/admin/events",
        "/v1/admin/servers",
        "/v1/admin/server-controls",
        "/v1/admin/news",
        "/v1/admin/roster-link-requests",
        "/v1/admin/audit-log",
        "/v1/admin/comlink/sessions",
        "/v1/admin/comlink/audit",
    ),
    "POST": (
        "/v1/admin/assets/delete",
        "/v1/admin/assets/upload",
        "/v1/admin/events",
        "/v1/admin/servers",
        "/v1/admin/server-controls",
        "/v1/admin/roster-link-requests",
        "/v1/admin/player-support",
        "/v1/admin/news",
        "/v1/admin/comlink/revoke",
    ),
}
COMMUNITY_MANAGER_CAPABILITIES = (
    "Upload and delete approved public audio, theme artwork, and profile pictures.",
    "Create, edit, activate, deactivate, and delete launcher/website event banners.",
    "Add, edit, remove, and maintenance-toggle official launcher/website servers.",
)
OWNER_ADMIN_CAPABILITIES = (
    *COMMUNITY_MANAGER_CAPABILITIES,
    "Review and approve roster-link requests when Discord OAuth blocks a verified player.",
    "Apply audited player-support corrections for XP, credits, unit, rank, and roster state.",
    "Review the admin audit log for high-power website actions.",
    "Review Project Bly comlink sessions and privacy-redacted audit events.",
)
COMMUNITY_MANAGER_PROTECTED_AREAS = (
    {
        "area": "Player progression and profile authority",
        "owner": "Player sessions, Discord roster sync, and signed official server events",
        "routes": (
            "POST /v1/me",
            "POST /v1/me/achievements/acknowledge",
            "POST /v1/me/roster-link",
            "POST /v1/roster/me",
            "POST /v1/server/events",
            "POST /v1/server/profile-snapshots",
        ),
    },
    {
        "area": "Credits, marketplace purchases, and owned items",
        "owner": "Authenticated player sessions and backend purchase checks",
        "routes": (
            "POST /v1/marketplace/purchase",
            "POST /v1/server/ownership/check",
        ),
    },
    {
        "area": "Release manifests and deploy state",
        "owner": "Release preparation, deploy process, and server filesystem access",
        "routes": (),
    },
    {
        "area": "Secrets and raw database rows",
        "owner": "Environment variables, SSH access, and backend code only",
        "routes": (),
    },
)
OWNER_ADMIN_PROTECTED_AREAS = (
    {
        "area": "Secrets and raw database rows",
        "owner": "Environment variables, SSH access, and backend code only",
        "routes": (),
    },
    {
        "area": "Release manifests and deploy state",
        "owner": "Release preparation, deploy process, and server filesystem access",
        "routes": (),
    },
)

DEFAULT_QUESTS = [
    {
        "id": "geonosis_frontline",
        "title": "Geonosis Frontline",
        "category": "Campaign",
        "state": "ACTIVE",
        "description": "Deploy during the Geonosis launch window and build your first campaign record.",
        "reward": "+10% launch-week XP when the event banner is active.",
    },
    {
        "id": "roster_ready",
        "title": "Roster Ready",
        "category": "Community",
        "state": "ACTIVE",
        "description": "Link your Steam profile to the TCW roster so your unit and rank follow you across the launcher and website.",
        "reward": "Verified roster identity on your public trooper record.",
    },
    {
        "id": "veteran_deployments",
        "title": "Veteran Deployments",
        "category": "Progression",
        "state": "ACTIVE",
        "description": "Complete official operations to grow your level, credits, achievements, and public service record.",
        "reward": "Campaign history, achievements, credits, and leaderboard placement.",
    },
]

MARKETPLACE_CATEGORIES = [
    {
        "id": "customisations",
        "name": "Customisations",
        "description": "Visual and identity extras for player expression.",
    },
    {
        "id": "custom_armour",
        "name": "Custom Armour",
        "description": "Approved armour options that can be granted through the kit system.",
    },
    {
        "id": "unique_items",
        "name": "Unique Items",
        "description": "Rare or event-specific rewards controlled by TCW staff.",
    },
    {
        "id": "rp_items",
        "name": "RP Items",
        "description": "Roleplay utility items for official TCW scenarios.",
    },
]

DEFAULT_MARKETPLACE = {
    "categories": MARKETPLACE_CATEGORIES,
    "items": [],
}

MARKETPLACE_POLICY = {
    "currency": "in_game_credits",
    "real_money_purchases": False,
    "message": "TCWA3 marketplace purchases use in-game credits only. No real money is accepted or required.",
}

AUDIO_CATEGORIES = {
    "menu_music": {
        "label": "Menu Music",
        "directory": "menu_music",
        "description": "Background tracks for the launcher main menu.",
    },
    "menu_sounds": {
        "label": "Menu Sounds",
        "directory": "menu_sounds",
        "description": "Short UI button sounds played by the launcher.",
    },
    "event_sounds": {
        "label": "Event And Banner Sounds",
        "directory": "event_sounds",
        "description": "Short MP3 stingers for launcher and website event banners.",
    },
    "holonet_radio": {
        "label": "Holonet Radio",
        "directory": "holonet_radio",
        "description": "Longer MP3 tracks players can cycle through in the Holonet radio box.",
    },
}
AUDIO_EXTENSIONS = {".mp3"}
THEME_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}
THEME_ASSET_TYPES = {"background", "logo"}

DEFAULT_THEMES = [
    {
        "id": "tcw_standard",
        "name": "TCW Standard",
        "description": "The current TCWA3 launcher look.",
        "accent_color": "#8fb9d4",
        "panel_color": "#05090f",
        "text_color": "#f8fafc",
        "built_in": True,
    },
    {
        "id": "dark",
        "name": "Dark",
        "description": "A deeper, gloomier TCWA3 presentation theme that keeps text readable.",
        "accent_color": "#5f87a5",
        "panel_color": "#010308",
        "text_color": "#f2f6fb",
        "built_in": True,
    },
    {
        "id": "light",
        "name": "Light",
        "description": "A bright TCWA3 presentation theme for players who prefer a white interface.",
        "accent_color": "#466f86",
        "panel_color": "#f1f4f7",
        "text_color": "#111827",
        "built_in": True,
    },
]

DEFAULT_RELEASE = {
    "version": "0.4.11-beta",
    "channel": "beta",
    "title": "TCW Launcher 0.4.10 Beta",
    "summary": "Launcher join hotfix, TeamSpeak detection hardening, and clearer combat stat labels.",
    "mandatory": False,
    "download_url": "",
    "installer_url": "",
    "sha256": "",
    "notes": [
        "Launcher themes now accept backend theme asset metadata for custom backgrounds and logos.",
        "Theme changes re-apply immediately, including readable built-in dark and light palettes.",
    ],
    "published_at": "2026-06-28",
    "downloads": {
        "windows": {
            "url": "",
            "installer_url": "",
            "sha256": "",
        },
        "linux": {
            "url": "",
            "sha256": "",
        },
    },
}

YOUTUBE_CACHE_LOCK = threading.Lock()
YOUTUBE_CACHE_EXPIRES = 0.0
YOUTUBE_LATEST_CACHE: dict[str, Any] = {}
YOUTUBE_DISCOVERED_CHANNEL_ID = ""
STEAM_NAME_CACHE_LOCK = threading.Lock()
STEAM_NAME_CACHE: dict[str, tuple[float, str]] = {}


def now() -> int:
    return int(time.time())


def republic_wage_week_id(timestamp: int | None = None) -> str:
    moment = datetime.fromtimestamp(int(timestamp if timestamp is not None else now()), tz=timezone.utc)
    iso_year, iso_week, _ = moment.isocalendar()
    return f"{iso_year}-W{iso_week:02d}"


def republic_wage_week_start(timestamp: int | None = None) -> int:
    moment = datetime.fromtimestamp(int(timestamp if timestamp is not None else now()), tz=timezone.utc)
    iso_year, iso_week, _ = moment.isocalendar()
    week_start = datetime.fromisocalendar(iso_year, iso_week, 1).replace(tzinfo=timezone.utc)
    return int(week_start.timestamp())


def republic_wage_status(db: sqlite3.Connection, steam_id: str, timestamp: int | None = None) -> dict[str, Any]:
    reference_time = int(timestamp if timestamp is not None else now())
    week_id = republic_wage_week_id(reference_time)
    week_start = republic_wage_week_start(reference_time)
    next_week_start = week_start + 7 * 24 * 60 * 60
    stats = db.execute(
        """
        SELECT last_republic_wage_week, last_republic_wage_at,
               republic_wages_received, republic_wage_credits
        FROM stats
        WHERE steam_id = ?
        """,
        (steam_id,),
    ).fetchone()
    grant = db.execute(
        "SELECT credits, granted_at FROM republic_wage_grants WHERE steam_id = ? AND week_id = ?",
        (steam_id, week_id),
    ).fetchone()
    paid_this_week = grant is not None
    last_paid_at = int(stats["last_republic_wage_at"] or 0) if stats else 0
    last_paid_week = str(stats["last_republic_wage_week"] or "") if stats else ""
    return {
        "schema": "tcwa3_republic_wage_v1",
        "weekly_credits": REPUBLIC_WEEKLY_WAGE_CREDITS,
        "current_week_id": week_id,
        "current_week_started_at": week_start,
        "next_week_starts_at": next_week_start,
        "last_paid_week": last_paid_week,
        "last_paid_at": last_paid_at,
        "paid_this_week": paid_this_week,
        "state": "paid_this_week" if paid_this_week else "scheduled",
        "wages_received": int(stats["republic_wages_received"] or 0) if stats else 0,
        "total_wage_credits": int(stats["republic_wage_credits"] or 0) if stats else 0,
        "message": (
            f"Galactic Republic wage paid: +{REPUBLIC_WEEKLY_WAGE_CREDITS} credits for {week_id}."
            if paid_this_week
            else f"Galactic Republic wage scheduled: +{REPUBLIC_WEEKLY_WAGE_CREDITS} credits this week."
        ),
    }


def grant_weekly_republic_wage(
    db: sqlite3.Connection,
    steam_id: str,
    timestamp: int | None = None,
) -> dict[str, Any]:
    if not STEAM_ID_PATTERN.fullmatch(str(steam_id or "")):
        return {"granted": False, "reason": "invalid_steam_id"}
    if db.execute("SELECT 1 FROM users WHERE steam_id = ?", (steam_id,)).fetchone() is None:
        return {"granted": False, "reason": "profile_not_found"}
    reference_time = int(timestamp if timestamp is not None else now())
    week_id = republic_wage_week_id(reference_time)
    db.execute("INSERT OR IGNORE INTO stats (steam_id) VALUES (?)", (steam_id,))
    cursor = db.execute(
        """
        INSERT OR IGNORE INTO republic_wage_grants (steam_id, week_id, credits, granted_at)
        VALUES (?, ?, ?, ?)
        """,
        (steam_id, week_id, REPUBLIC_WEEKLY_WAGE_CREDITS, reference_time),
    )
    granted = cursor.rowcount > 0
    if granted:
        db.execute(
            """
            UPDATE stats
            SET credits = MIN(?, credits + ?),
                last_republic_wage_week = ?,
                last_republic_wage_at = ?,
                republic_wages_received = republic_wages_received + 1,
                republic_wage_credits = republic_wage_credits + ?
            WHERE steam_id = ?
            """,
            (
                STAT_LIMITS["credits"],
                REPUBLIC_WEEKLY_WAGE_CREDITS,
                week_id,
                reference_time,
                REPUBLIC_WEEKLY_WAGE_CREDITS,
                steam_id,
            ),
        )
    status = republic_wage_status(db, steam_id, reference_time)
    status["granted"] = granted
    return status


def grant_weekly_republic_wages(db: sqlite3.Connection, timestamp: int | None = None) -> dict[str, Any]:
    reference_time = int(timestamp if timestamp is not None else now())
    rows = db.execute("SELECT steam_id FROM users").fetchall()
    granted = 0
    skipped = 0
    for row in rows:
        result = grant_weekly_republic_wage(db, row["steam_id"], reference_time)
        if result.get("granted"):
            granted += 1
        else:
            skipped += 1
    return {"eligible": len(rows), "granted": granted, "skipped": skipped, "week_id": republic_wage_week_id(reference_time)}


def republic_wage_loop() -> None:
    while True:
        time.sleep(max(300, REPUBLIC_WAGE_LOOP_SECONDS))
        try:
            with connect_db() as db:
                result = grant_weekly_republic_wages(db)
            if result.get("granted"):
                log_backend_event("republic_wage_cycle", **result)
        except Exception as exc:
            log_backend_event("republic_wage_cycle_failed", reason=type(exc).__name__)


SENSITIVE_LOG_FIELD_NAMES = {
    "access_token",
    "authorization",
    "body",
    "device_code",
    "handoff_code",
    "payload",
    "refresh_token",
    "secret",
    "signature",
    "token",
}


def safe_log_value(value: Any) -> Any | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return round(value, 3)
    text = str(value).replace("\r", " ").replace("\n", " ").strip()
    if not text:
        return None
    return text[:180]


def log_backend_event(event: str, **fields: Any) -> None:
    """Emit one safe JSON log line for production filtering."""
    entry: dict[str, Any] = {"event": str(event), "timestamp": now()}
    for key, value in fields.items():
        clean_key = str(key or "").strip()
        if not clean_key or clean_key.lower() in SENSITIVE_LOG_FIELD_NAMES:
            continue
        clean_value = safe_log_value(value)
        if clean_value is not None:
            entry[clean_key] = clean_value
    print(json.dumps(entry, sort_keys=True, ensure_ascii=False), flush=True)


def community_manager_route_allowed(method: str, path: str) -> bool:
    return path in COMMUNITY_MANAGER_ALLOWED_ROUTES.get(str(method or "").upper(), ())


def owner_admin_route_allowed(method: str, path: str) -> bool:
    method_key = str(method or "").upper()
    return (
        path in OWNER_ADMIN_ALLOWED_ROUTES.get(method_key, ())
        or path in COMMUNITY_MANAGER_ALLOWED_ROUTES.get(method_key, ())
    )


def authority_scope_for_role(role: str) -> dict[str, Any]:
    if role == "owner_admin":
        return {
            "role": "owner_admin",
            "summary": "Full admin console. High-power actions are audited and should be used for support and operations only.",
            "capabilities": list(OWNER_ADMIN_CAPABILITIES),
            "allowed_routes": {
                method: sorted(set(paths).union(COMMUNITY_MANAGER_ALLOWED_ROUTES.get(method, ())))
                for method, paths in sorted(OWNER_ADMIN_ALLOWED_ROUTES.items())
            },
            "protected_areas": [
                {
                    "area": str(area["area"]),
                    "owner": str(area["owner"]),
                    "routes": list(area["routes"]),
                }
                for area in OWNER_ADMIN_PROTECTED_AREAS
            ],
        }
    return {
        "role": "community_manager",
        "summary": "Public content and server-maintenance tools only.",
        "capabilities": list(COMMUNITY_MANAGER_CAPABILITIES),
        "allowed_routes": {
            method: list(paths)
            for method, paths in sorted(COMMUNITY_MANAGER_ALLOWED_ROUTES.items())
        },
        "protected_areas": [
            {
                "area": str(area["area"]),
                "owner": str(area["owner"]),
                "routes": list(area["routes"]),
            }
            for area in COMMUNITY_MANAGER_PROTECTED_AREAS
        ],
    }


def community_manager_authority_scope() -> dict[str, Any]:
    return authority_scope_for_role("community_manager")


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def level_step_xp(level: int) -> int:
    """XP needed to move from this level to the next one."""
    safe_level = max(1, int(level or 1))
    return max(1, int(round(LEVEL_BASE_XP * (LEVEL_GROWTH_FACTOR ** (safe_level - 1)))))


def legacy_level_step_xp(level: int) -> int:
    """XP needed by the pre-slowdown curve used to preserve current displayed levels."""
    safe_level = max(1, int(level or 1))
    return max(1, int(round(LEGACY_LEVEL_BASE_XP * (LEGACY_LEVEL_GROWTH_FACTOR ** (safe_level - 1)))))


def total_xp_for_level(level: int) -> int:
    """Lifetime XP required to arrive at a level."""
    safe_level = max(1, int(level or 1))
    total = 0
    for step_level in range(1, safe_level):
        total += level_step_xp(step_level)
    return total


def level_for_xp(xp: int) -> int:
    """Return the player level for lifetime XP using the current slowed scaling curve."""
    safe_xp = max(0, int(xp or 0))
    level = 1
    total = 0
    while level < MAX_LEVEL_ITERATION:
        needed = level_step_xp(level)
        if safe_xp < total + needed:
            break
        total += needed
        level += 1
    return level


def legacy_level_for_xp(xp: int) -> int:
    """Return the old displayed level so existing players do not lose ranks on migration."""
    safe_xp = max(0, int(xp or 0))
    level = 1
    total = 0
    while level < MAX_LEVEL_ITERATION:
        needed = legacy_level_step_xp(level)
        if safe_xp < total + needed:
            break
        total += needed
        level += 1
    return level


def current_level_xp(level: int) -> int:
    return total_xp_for_level(level)


def next_level_xp(level: int) -> int:
    return total_xp_for_level(max(1, int(level or 1)) + 1)


def progression_xp_bounds(
    xp: int,
    displayed_level: int,
    level_floor: int = 0,
    level_floor_xp: int = 0,
) -> tuple[int, int]:
    """Return the XP window shown for a profile's current displayed level.

    Level floors preserve pre-slowdown ranks. When a player is floor-protected
    above their current curve level, use a stable baseline below their current
    XP so the bar still moves while they climb toward the next displayed level.
    """
    safe_xp = max(0, int(xp or 0))
    safe_level = max(1, int(displayed_level or 1))
    current_xp = current_level_xp(safe_level)
    next_xp = next_level_xp(safe_level)
    actual_level = level_for_xp(safe_xp)
    protected_level = max(0, int(level_floor or 0))
    floor_baseline = max(0, int(level_floor_xp or 0))
    if protected_level > actual_level and safe_level >= protected_level:
        if floor_baseline <= 0 or floor_baseline > safe_xp:
            floor_baseline = current_level_xp(actual_level)
        current_xp = max(0, min(floor_baseline, safe_xp))
        next_xp = max(next_xp, safe_xp + 1)
    if next_xp <= current_xp:
        next_xp = current_xp + level_step_xp(safe_level)
    return current_xp, next_xp


def clean_profile_name(value: Any) -> str:
    name = PROFILE_NAME_PATTERN.sub("", str(value or "")).strip()
    return name[:64] or DEFAULT_DISPLAY_NAME


def is_generic_display_name(value: Any) -> bool:
    return str(value or "").strip() in GENERIC_DISPLAY_NAMES


def public_display_name(value: Any) -> str:
    name = str(value or "").strip()
    if not name or is_generic_display_name(name):
        return DEFAULT_DISPLAY_NAME
    return name


def clean_profile_bio(value: Any) -> str:
    """Keep player-written lore readable and harmless for public profile views."""
    bio = str(value or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    bio = re.sub(r"\n{3,}", "\n\n", bio)
    return bio[:MAX_PROFILE_BIO_CHARS]


def bounded_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def clean_comlink_id(value: Any, fallback: str = "", limit: int = 64) -> str:
    cleaned = COMLINK_ID_RE.sub("-", str(value or "").strip().lower()).strip("-_")
    return (cleaned or fallback)[:limit]


def comlink_transport_configured() -> bool:
    return bool(COMLINK_LIVEKIT_URL and COMLINK_LIVEKIT_API_KEY and COMLINK_LIVEKIT_API_SECRET)


def comlink_ready() -> bool:
    return bool(COMLINK_ENABLED and comlink_transport_configured())


def comlink_role_for_profile(profile: dict[str, Any] | None) -> str:
    profile = profile or {}
    text = " ".join(
        str(profile.get(key, ""))
        for key in ("rank", "unit", "display_name", "roster_name")
    ).lower()
    if any(marker in text for marker in COMLINK_STAFF_MARKERS):
        return "staff"
    if any(marker in text for marker in COMLINK_COMMAND_MARKERS):
        return "command"
    return "player"


def comlink_role_allows(role: str, minimum_role: str) -> bool:
    order = {"player": 0, "command": 1, "staff": 2}
    return order.get(role, 0) >= order.get(minimum_role, 0)


def comlink_channels_for_profile(profile: dict[str, Any] | None) -> list[dict[str, Any]]:
    role = comlink_role_for_profile(profile)
    channels: list[dict[str, Any]] = []
    for channel in COMLINK_DEFAULT_CHANNELS:
        if not comlink_role_allows(role, str(channel["minimum_role"])):
            continue
        channels.append(
            {
                "id": channel["id"],
                "display_name": channel["display_name"],
                "channel_kind": channel["channel_kind"],
                "minimum_role": channel["minimum_role"],
                "can_publish": bool(channel["can_publish"]),
                "can_subscribe": bool(channel["can_subscribe"]),
            }
        )
    return channels


def comlink_channel_by_id(channel_id: str) -> dict[str, Any] | None:
    for channel in COMLINK_DEFAULT_CHANNELS:
        if channel["id"] == channel_id:
            return dict(channel)
    return None


def comlink_status_payload(db: sqlite3.Connection, steam_id: str, server_id: str = "") -> dict[str, Any]:
    profile = profile_for(db, steam_id) or {}
    server_id = clean_comlink_id(server_id, "unassigned")
    configured = comlink_transport_configured()
    ready = comlink_ready()
    return {
        "feature": "project_bly_comlink",
        "enabled": bool(COMLINK_ENABLED),
        "ready": ready,
        "transport": COMLINK_TRANSPORT,
        "transport_configured": configured,
        "server_id": server_id,
        "livekit_url": COMLINK_LIVEKIT_URL if configured else "",
        "token_ttl_seconds": COMLINK_TOKEN_TTL_SECONDS,
        "channels": comlink_channels_for_profile(profile),
        "fallback": {
            "required": not ready,
            "voice_paths": ["teamspeak", "afar"],
            "message": (
                "Project Bly comlink is not live yet. Use the current TeamSpeak/AFAR fallback until "
                "the dedicated-server acceptance test passes."
            ),
        },
        "updated_at": now(),
    }


def livekit_base64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def livekit_jwt_segment(payload: dict[str, Any]) -> str:
    return livekit_base64url(json_bytes(payload))


def build_livekit_participant_token(
    *,
    identity: str,
    name: str,
    room: str,
    can_publish: bool,
    can_subscribe: bool,
    ttl_seconds: int = COMLINK_TOKEN_TTL_SECONDS,
    timestamp: int | None = None,
) -> tuple[str, int]:
    if not COMLINK_LIVEKIT_API_KEY or not COMLINK_LIVEKIT_API_SECRET:
        raise ValueError("LiveKit API key and secret are required")
    issued_at = timestamp if timestamp is not None else now()
    expires_at = issued_at + max(30, min(600, int(ttl_seconds or COMLINK_TOKEN_TTL_SECONDS)))
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "iss": COMLINK_LIVEKIT_API_KEY,
        "sub": identity,
        "name": name,
        "nbf": issued_at - 5,
        "exp": expires_at,
        "video": {
            "roomJoin": True,
            "room": room,
            "canPublish": bool(can_publish),
            "canSubscribe": bool(can_subscribe),
            "canPublishData": True,
        },
    }
    signing_input = f"{livekit_jwt_segment(header)}.{livekit_jwt_segment(payload)}"
    signature = hmac.new(COMLINK_LIVEKIT_API_SECRET.encode("utf-8"), signing_input.encode("ascii"), hashlib.sha256).digest()
    return f"{signing_input}.{livekit_base64url(signature)}", expires_at


def build_livekit_room_admin_token(room: str, ttl_seconds: int = 60) -> str:
    if not COMLINK_LIVEKIT_API_KEY or not COMLINK_LIVEKIT_API_SECRET:
        raise ValueError("LiveKit API key and secret are required")
    issued_at = now()
    expires_at = issued_at + max(30, min(300, int(ttl_seconds or 60)))
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "iss": COMLINK_LIVEKIT_API_KEY,
        "sub": "tcwa3-comlink-admin",
        "nbf": issued_at - 5,
        "exp": expires_at,
        "video": {
            "room": room,
            "roomAdmin": True,
        },
    }
    signing_input = f"{livekit_jwt_segment(header)}.{livekit_jwt_segment(payload)}"
    signature = hmac.new(COMLINK_LIVEKIT_API_SECRET.encode("utf-8"), signing_input.encode("ascii"), hashlib.sha256).digest()
    return f"{signing_input}.{livekit_base64url(signature)}"


def livekit_service_base_url() -> str:
    parsed = urllib.parse.urlparse(COMLINK_LIVEKIT_URL)
    if not parsed.scheme or not parsed.netloc:
        return ""
    scheme = {"wss": "https", "ws": "http"}.get(parsed.scheme.lower(), parsed.scheme.lower())
    if scheme not in {"http", "https"}:
        return ""
    return f"{scheme}://{parsed.netloc}"


def remove_livekit_participant(room: str, identity: str) -> dict[str, Any]:
    room = str(room or "").strip()
    identity = str(identity or "").strip()
    base_url = livekit_service_base_url()
    if not room or not identity or not base_url or not comlink_transport_configured():
        return {"attempted": False, "removed": False, "reason": "livekit_api_unavailable"}
    token = build_livekit_room_admin_token(room)
    request = urllib.request.Request(
        base_url + "/twirp/livekit.RoomService/RemoveParticipant",
        data=json_bytes({"room": room, "identity": identity}),
        headers={
            "Accept": "application/json",
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json",
            "User-Agent": "TCW-Comlink-Moderation/1.0",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=COMLINK_LIVEKIT_API_TIMEOUT_SECONDS) as response:
            response.read()
            status_code = int(getattr(response, "status", 200) or 200)
            return {"attempted": True, "removed": 200 <= status_code < 300, "status_code": status_code}
    except urllib.error.HTTPError as exc:
        return {"attempted": True, "removed": False, "status_code": int(exc.code), "error": "livekit_http_error"}
    except (OSError, TimeoutError, urllib.error.URLError):
        return {"attempted": True, "removed": False, "error": "livekit_unreachable"}


def record_comlink_audit(
    db: sqlite3.Connection,
    actor_role: str,
    action: str,
    steam_id: str = "",
    server_id: str = "",
    channel_id: str = "",
    details: dict[str, Any] | None = None,
) -> None:
    safe_details = dict(details or {})
    for secret_key in ("participant_token", "client_report_token", "token", "authorization", "livekit_api_secret"):
        safe_details.pop(secret_key, None)
    db.execute(
        """
        INSERT INTO comlink_audit_log
            (audit_id, actor_role, action, steam_id, server_id, channel_id, details_json, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            secrets.token_urlsafe(18),
            actor_role,
            action,
            steam_id,
            server_id,
            channel_id,
            json.dumps(safe_details, separators=(",", ":"), ensure_ascii=False),
            now(),
        ),
    )


def issue_comlink_token(db: sqlite3.Connection, steam_id: str, payload: dict[str, Any]) -> tuple[HTTPStatus, dict[str, Any]]:
    if not COMLINK_ENABLED:
        return HTTPStatus.SERVICE_UNAVAILABLE, {
            "error": "comlink_disabled",
            "fallback": comlink_status_payload(db, steam_id).get("fallback"),
        }
    if not comlink_transport_configured():
        return HTTPStatus.SERVICE_UNAVAILABLE, {
            "error": "comlink_transport_unconfigured",
            "fallback": comlink_status_payload(db, steam_id).get("fallback"),
        }
    server_id = clean_comlink_id(payload.get("server_id", ""), "unassigned")
    channel_id = clean_comlink_id(payload.get("channel_id", ""), "squad")
    client_nonce = str(payload.get("client_nonce", ""))[:128]
    client_kind = clean_comlink_id(payload.get("client_kind", ""), "launcher", 32)
    channel = comlink_channel_by_id(channel_id)
    if channel is None:
        return HTTPStatus.NOT_FOUND, {"error": "comlink_channel_not_found"}
    profile = profile_for(db, steam_id) or {}
    role = comlink_role_for_profile(profile)
    if not comlink_role_allows(role, str(channel["minimum_role"])):
        record_comlink_audit(
            db,
            "player",
            "token_denied",
            steam_id,
            server_id,
            channel_id,
            {"reason": "insufficient_role", "role": role, "minimum_role": channel["minimum_role"]},
        )
        return HTTPStatus.FORBIDDEN, {"error": "comlink_channel_denied"}
    room = f"project-bly:{server_id}:{channel_id}"
    identity = f"steam:{steam_id}:{server_id}"
    participant_token, expires_at = build_livekit_participant_token(
        identity=identity,
        name=public_display_name(profile.get("display_name", DEFAULT_DISPLAY_NAME)),
        room=room,
        can_publish=bool(channel["can_publish"]),
        can_subscribe=bool(channel["can_subscribe"]),
    )
    timestamp = now()
    session_id = secrets.token_urlsafe(18)
    client_report_token = secrets.token_urlsafe(32)
    db.execute(
        """
        INSERT INTO comlink_sessions
            (session_id, steam_id, server_id, channel_id, livekit_room, livekit_identity,
             client_nonce, client_kind, client_report_token_hash, issued_at, expires_at, last_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            session_id,
            steam_id,
            server_id,
            channel_id,
            room,
            identity,
            client_nonce,
            client_kind,
            token_hash(client_report_token),
            timestamp,
            expires_at,
            "issued",
        ),
    )
    record_comlink_audit(
        db,
        "player",
        "token_issued",
        steam_id,
        server_id,
        channel_id,
        {"session_id": session_id, "client_kind": client_kind, "expires_at": expires_at},
    )
    return HTTPStatus.OK, {
        "status": "issued",
        "transport": COMLINK_TRANSPORT,
        "server_id": server_id,
        "channel_id": channel["id"],
        "livekit_url": COMLINK_LIVEKIT_URL,
        "room": room,
        "identity": identity,
        "participant_token": participant_token,
        "client_report_token": client_report_token,
        "session_id": session_id,
        "expires_at": expires_at,
        "token_ttl_seconds": max(0, expires_at - timestamp),
        "channel": {
            "id": channel["id"],
            "display_name": channel["display_name"],
            "channel_kind": channel["channel_kind"],
            "can_publish": bool(channel["can_publish"]),
            "can_subscribe": bool(channel["can_subscribe"]),
        },
        "channels": comlink_channels_for_profile(profile),
        "fallback": comlink_status_payload(db, steam_id, server_id).get("fallback"),
    }


def summarize_livekit_removal(results: list[dict[str, Any]]) -> dict[str, int]:
    return {
        "attempted": sum(1 for item in results if item.get("attempted")),
        "removed": sum(1 for item in results if item.get("removed")),
        "failed": sum(1 for item in results if item.get("attempted") and not item.get("removed")),
        "skipped": sum(1 for item in results if not item.get("attempted")),
    }


def switch_comlink_channel(db: sqlite3.Connection, payload: dict[str, Any]) -> tuple[HTTPStatus, dict[str, Any]]:
    session_id = str(payload.get("session_id", "")).strip()
    report_token = str(payload.get("client_report_token", "")).strip()
    target_channel_id = clean_comlink_id(payload.get("channel_id", ""), "")
    if not session_id or not report_token or not target_channel_id:
        return HTTPStatus.BAD_REQUEST, {"error": "invalid_comlink_switch"}
    current = db.execute(
        """
        SELECT session_id, steam_id, server_id, channel_id, livekit_room, livekit_identity,
               client_report_token_hash, ended_at
        FROM comlink_sessions
        WHERE session_id = ?
        """,
        (session_id,),
    ).fetchone()
    if current is None or not hmac.compare_digest(str(current["client_report_token_hash"] or ""), token_hash(report_token)):
        return HTTPStatus.UNAUTHORIZED, {"error": "invalid_comlink_client_report"}
    if current["ended_at"] is not None:
        return HTTPStatus.CONFLICT, {"error": "comlink_session_not_active"}
    current_server_id = str(current["server_id"])
    requested_server_id = clean_comlink_id(payload.get("server_id", ""), "")
    if requested_server_id and requested_server_id != current_server_id:
        return HTTPStatus.FORBIDDEN, {"error": "comlink_server_mismatch"}
    if target_channel_id == str(current["channel_id"]):
        return HTTPStatus.BAD_REQUEST, {"error": "comlink_channel_unchanged"}

    switch_payload = dict(payload)
    switch_payload["server_id"] = current_server_id
    switch_payload["channel_id"] = target_channel_id
    switch_payload["client_kind"] = clean_comlink_id(payload.get("client_kind", ""), "hosted-browser-switch", 32)
    status, result = issue_comlink_token(db, str(current["steam_id"]), switch_payload)
    if status != HTTPStatus.OK:
        return status, result

    timestamp = now()
    db.execute(
        """
        UPDATE comlink_sessions
        SET ended_at = ?, last_status = 'switched'
        WHERE session_id = ? AND ended_at IS NULL
        """,
        (timestamp, session_id),
    )
    media_summary = summarize_livekit_removal(
        [remove_livekit_participant(str(current["livekit_room"]), str(current["livekit_identity"]))]
    )
    record_comlink_audit(
        db,
        "client",
        "channel_switched",
        str(current["steam_id"]),
        current_server_id,
        target_channel_id,
        {
            "previous_session_id": session_id,
            "previous_channel_id": str(current["channel_id"]),
            "new_session_id": result.get("session_id", ""),
            "new_channel_id": target_channel_id,
            "livekit_removal": media_summary,
        },
    )
    result["switch_status"] = "switched"
    result["previous_session_id"] = session_id
    result["previous_channel_id"] = str(current["channel_id"])
    result["livekit_removal"] = media_summary
    return HTTPStatus.OK, result


def leave_comlink_session(db: sqlite3.Connection, steam_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    session_id = str(payload.get("session_id", "")).strip()
    timestamp = now()
    if session_id:
        cursor = db.execute(
            """
            UPDATE comlink_sessions
            SET ended_at = ?, last_status = 'left'
            WHERE session_id = ? AND steam_id = ? AND ended_at IS NULL
            """,
            (timestamp, session_id, steam_id),
        )
    else:
        cursor = db.execute(
            """
            UPDATE comlink_sessions
            SET ended_at = ?, last_status = 'left'
            WHERE steam_id = ? AND ended_at IS NULL
            """,
            (timestamp, steam_id),
        )
    record_comlink_audit(db, "player", "left", steam_id, details={"session_id": session_id, "ended": cursor.rowcount})
    return {"status": "left", "ended": cursor.rowcount, "updated_at": timestamp}


def record_comlink_client_event(db: sqlite3.Connection, payload: dict[str, Any]) -> tuple[HTTPStatus, dict[str, Any]]:
    session_id = str(payload.get("session_id", "")).strip()
    report_token = str(payload.get("client_report_token", "")).strip()
    event = clean_comlink_id(payload.get("event", ""), "", 32)
    if not session_id or not report_token or event not in COMLINK_CLIENT_EVENT_STATUS:
        return HTTPStatus.BAD_REQUEST, {"error": "invalid_comlink_client_event"}
    session = db.execute(
        """
        SELECT session_id, steam_id, server_id, channel_id, client_report_token_hash, ended_at
        FROM comlink_sessions
        WHERE session_id = ?
        """,
        (session_id,),
    ).fetchone()
    if session is None or not hmac.compare_digest(str(session["client_report_token_hash"] or ""), token_hash(report_token)):
        return HTTPStatus.UNAUTHORIZED, {"error": "invalid_comlink_client_report"}
    timestamp = now()
    last_status = COMLINK_CLIENT_EVENT_STATUS[event]
    ended_at = timestamp if event == "client_left" else session["ended_at"]
    db.execute(
        """
        UPDATE comlink_sessions
        SET last_status = ?, ended_at = COALESCE(?, ended_at)
        WHERE session_id = ?
        """,
        (last_status, ended_at, session_id),
    )
    record_comlink_audit(
        db,
        "client",
        event,
        str(session["steam_id"]),
        str(session["server_id"]),
        str(session["channel_id"]),
        {
            "session_id": session_id,
            "message": clean_support_text(payload.get("message", ""), 240),
            "connection_state": clean_comlink_id(payload.get("connection_state", ""), "", 32),
        },
    )
    return HTTPStatus.OK, {"status": "recorded", "event": event, "last_status": last_status, "updated_at": timestamp}


def list_comlink_sessions(db: sqlite3.Connection, limit: int = 100) -> list[dict[str, Any]]:
    safe_limit = max(1, min(250, int(limit or 100)))
    rows = db.execute(
        """
        SELECT session_id, steam_id, server_id, channel_id, livekit_room, livekit_identity,
               client_kind, issued_at, expires_at, ended_at, last_status
        FROM comlink_sessions
        ORDER BY issued_at DESC
        LIMIT ?
        """,
        (safe_limit,),
    ).fetchall()
    return [dict(row) for row in rows]


def list_comlink_audit(
    db: sqlite3.Connection,
    limit: int = 100,
    *,
    action: str = "",
    steam_id: str = "",
    server_id: str = "",
    channel_id: str = "",
) -> list[dict[str, Any]]:
    safe_limit = max(1, min(250, int(limit or 100)))
    where: list[str] = []
    parameters: list[Any] = []
    if action:
        where.append("action = ?")
        parameters.append(clean_comlink_id(action, "", 64))
    if steam_id:
        where.append("steam_id = ?")
        parameters.append(str(steam_id).strip()[:64])
    if server_id:
        where.append("server_id = ?")
        parameters.append(clean_comlink_id(server_id, "", 64))
    if channel_id:
        where.append("channel_id = ?")
        parameters.append(clean_comlink_id(channel_id, "", 64))
    query = """
        SELECT audit_id, actor_role, action, steam_id, server_id, channel_id, details_json, created_at
        FROM comlink_audit_log
    """
    if where:
        query += " WHERE " + " AND ".join(where)
    query += " ORDER BY created_at DESC LIMIT ?"
    parameters.append(safe_limit)
    rows = db.execute(query, tuple(parameters)).fetchall()
    items: list[dict[str, Any]] = []
    for row in rows:
        item = dict(row)
        try:
            details = json.loads(str(item.pop("details_json", "{}") or "{}"))
        except json.JSONDecodeError:
            details = {}
        if not isinstance(details, dict):
            details = {}
        for secret_key in ("participant_token", "client_report_token", "token", "authorization", "livekit_api_secret"):
            details.pop(secret_key, None)
        item["details"] = details
        items.append(item)
    return items


def revoke_comlink_sessions(db: sqlite3.Connection, payload: dict[str, Any], actor_role: str) -> tuple[HTTPStatus, dict[str, Any]]:
    session_id = str(payload.get("session_id", "")).strip()
    steam_id = str(payload.get("steam_id", "")).strip()
    channel_id = clean_comlink_id(payload.get("channel_id", ""), "")
    server_id = clean_comlink_id(payload.get("server_id", ""), "")
    timestamp = now()
    parameters: list[Any] = [timestamp]
    where = ["ended_at IS NULL"]
    if session_id:
        where.append("session_id = ?")
        parameters.append(session_id)
    if steam_id:
        where.append("steam_id = ?")
        parameters.append(steam_id)
    if channel_id:
        where.append("channel_id = ?")
        parameters.append(channel_id)
    if server_id:
        where.append("server_id = ?")
        parameters.append(server_id)
    if len(where) == 1:
        return HTTPStatus.BAD_REQUEST, {"error": "comlink_revoke_target_required"}
    select_parameters = tuple(parameters[1:])
    sessions = db.execute(
        f"""
        SELECT session_id, livekit_room, livekit_identity
        FROM comlink_sessions
        WHERE {' AND '.join(where)}
        """,
        select_parameters,
    ).fetchall()
    media_results = [
        remove_livekit_participant(str(row["livekit_room"]), str(row["livekit_identity"]))
        for row in sessions
    ]
    cursor = db.execute(
        f"UPDATE comlink_sessions SET ended_at = ?, last_status = 'revoked' WHERE {' AND '.join(where)}",
        tuple(parameters),
    )
    media_summary = summarize_livekit_removal(media_results)
    record_comlink_audit(
        db,
        actor_role,
        "revoked",
        steam_id,
        server_id,
        channel_id,
        {
            "session_id": session_id,
            "revoked": cursor.rowcount,
            "livekit_removal": media_summary,
        },
    )
    return HTTPStatus.OK, {
        "status": "revoked",
        "revoked": cursor.rowcount,
        "livekit_removal": media_summary,
        "updated_at": timestamp,
    }


def event_container_values(event: dict[str, Any], keys: tuple[str, ...]) -> list[str]:
    values: list[str] = []
    for key in keys:
        value = event.get(key)
        if isinstance(value, dict):
            for nested_key in ("name", "map", "world", "terrain", "mission", "mission_name", "server_name"):
                nested_value = value.get(nested_key)
                if nested_value:
                    values.append(str(nested_value))
        elif value:
            values.append(str(value))
    return values


def event_location_text(event: dict[str, Any]) -> str:
    fields = ("map", "world", "terrain", "mission", "mission_name", "server_name", "location", "context")
    return " ".join(event_container_values(event, fields)).lower()


def event_has_location(event: dict[str, Any], location_name: str) -> bool:
    return location_name.lower() in event_location_text(event)


def clean_campaign_text(value: Any, fallback: str, limit: int = 96) -> str:
    text = PROFILE_NAME_PATTERN.sub("", str(value or "")).strip()
    text = re.sub(r"\s+", " ", text)
    return (text or fallback)[:limit]


def event_named_value(event: dict[str, Any], keys: tuple[str, ...]) -> str:
    for key in keys:
        value = event.get(key)
        if isinstance(value, dict):
            for nested_key in ("display_name", "title", "name", "mission_name", "map", "world", "terrain"):
                nested_value = value.get(nested_key)
                if nested_value:
                    return str(nested_value)
        elif value:
            return str(value)
    return ""


def campaign_for_event(event: dict[str, Any]) -> dict[str, str]:
    """Map official server event context into the player-facing campaign log."""
    if event_has_location(event, "geonosis"):
        return {"id": "battle_of_geonosis", "name": "The Battle of Geonosis", "planet": "Geonosis"}
    if event_has_location(event, "kamino"):
        return {"id": "kamino_training", "name": "Kamino Training Rotation", "planet": "Kamino"}
    location = clean_campaign_text(
        event_named_value(event, ("planet", "location", "map", "world", "terrain", "server_name")),
        "Unknown Front",
        48,
    )
    campaign_id = re.sub(r"[^a-z0-9]+", "_", location.lower()).strip("_") or "tcwa3_campaign"
    campaign_name = "TCWA3 Campaign" if location == "Unknown Front" else f"{location} Campaign"
    return {"id": campaign_id[:64], "name": campaign_name[:96], "planet": location}


def mission_name_for_event(event: dict[str, Any], campaign: dict[str, str]) -> str:
    mission_name = event_named_value(
        event,
        (
            "deployment_name",
            "operation_name",
            "mission_name",
            "scenario_name",
            "mission",
            "operation",
            "briefing_name",
        ),
    )
    fallback = f"Official {campaign['planet']} deployment" if campaign.get("planet") else "Official deployment"
    return clean_campaign_text(mission_name, fallback, 112)


def event_boolean(event: dict[str, Any], keys: tuple[str, ...]) -> bool:
    for key in keys:
        value = event.get(key)
        if isinstance(value, bool):
            return value
        if isinstance(value, str) and value.strip().lower() in {"1", "true", "yes", "complete", "completed"}:
            return True
    return False


def event_boolean_false(event: dict[str, Any], keys: tuple[str, ...]) -> bool:
    for key in keys:
        value = event.get(key)
        if isinstance(value, bool):
            return not value
        if isinstance(value, str) and value.strip().lower() in {"0", "false", "no", "failed", "failure"}:
            return True
    return False


def event_mission_failed(event: dict[str, Any]) -> bool:
    event_type = str(event.get("event_type") or event.get("type") or event.get("kind") or "").strip().lower()
    failure_types = {"mission_failed", "mission_failure", "deployment_failed", "deployment_failure", "mission_aborted", "deployment_aborted"}
    outcome = str(event.get("outcome") or event.get("result") or event.get("state") or "").strip().lower()
    return (
        event_type in failure_types
        or outcome in {"failed", "failure", "lost", "aborted"}
        or event_boolean(event, ("mission_failed", "deployment_failed", "failed"))
        or event_boolean_false(event, ("success", "completed", "mission_completed", "deployment_complete"))
    )


def event_deployment_started(event: dict[str, Any]) -> bool:
    event_type = str(event.get("event_type") or event.get("type") or event.get("kind") or "").strip().lower()
    start_types = {"mission_start", "mission_started", "deployment_start", "deployment_started", "operation_start", "operation_started"}
    return event_type in start_types or event_boolean(event, ("mission_started", "deployment_started", "deployment_start", "operation_started"))


def event_mission_completed(event: dict[str, Any], values: dict[str, int]) -> bool:
    if event_mission_failed(event):
        return False
    event_type = str(event.get("event_type") or event.get("type") or event.get("kind") or "").strip().lower()
    completion_types = {"mission_complete", "mission_completed", "mission_end", "deployment_complete", "deployment_completed"}
    return values.get("missions", 0) > 0 or event_type in completion_types or event_boolean(
        event,
        ("mission_completed", "mission_complete", "deployment_complete", "completed"),
    )


def event_deployment_outcome(event: dict[str, Any], values: dict[str, int]) -> str:
    if event_mission_failed(event):
        return "failed"
    if event_mission_completed(event, values):
        return "completed"
    if event_deployment_started(event):
        return "started"
    return ""


def deployment_id_for_event(event: dict[str, Any], steam_id: str, fallback_event_id: str) -> str:
    raw = event_named_value(
        event,
        (
            "deployment_id",
            "operation_id",
            "mission_id",
            "round_id",
            "session_id",
        ),
    )
    text = str(raw or fallback_event_id or "").strip()
    text = re.sub(r"[^A-Za-z0-9_.:-]+", "_", text).strip("_")
    if steam_id and steam_id not in text:
        text = f"{text}:{steam_id}"
    return (text or fallback_event_id)[:128]


EVENT_REWARD_TEXT_KEYS = (
    "event_type",
    "type",
    "kind",
    "category",
    "action",
    "target_type",
    "victim_type",
    "vehicle_type",
    "unit_type",
    "unit_class",
    "class_name",
    "object_type",
    "target",
    "victim",
    "vehicle",
    "unit",
    "attacker",
    "mission",
    "operation",
    "context",
    "attacker_side",
    "victim_side",
    "target_side",
    "weapon_type",
)


def event_text_blob(event: dict[str, Any]) -> str:
    chunks: list[str] = []

    def collect(value: Any, depth: int = 0) -> None:
        if depth > 2:
            return
        if isinstance(value, dict):
            for nested_value in value.values():
                collect(nested_value, depth + 1)
        elif isinstance(value, list):
            for nested_value in value:
                collect(nested_value, depth + 1)
        elif isinstance(value, (str, int, float)):
            chunks.append(str(value))

    for key in EVENT_REWARD_TEXT_KEYS:
        collect(event.get(key))
    return re.sub(r"[^a-z0-9_]+", " ", " ".join(chunks).lower())


def event_has_text(text: str, markers: tuple[str, ...]) -> bool:
    return any(marker in text for marker in markers)


def event_difficulty(event: dict[str, Any]) -> int | None:
    containers: list[Any] = [event, event.get("mission"), event.get("operation"), event.get("mission_stats"), event.get("context")]
    for container in containers:
        if not isinstance(container, dict):
            continue
        for key in ("difficulty", "mission_difficulty", "difficulty_tier", "tier"):
            if key not in container:
                continue
            try:
                difficulty = int(float(str(container.get(key)).strip()))
            except (TypeError, ValueError):
                continue
            if difficulty in DIFFICULTY_MISSION_XP:
                return difficulty
    return None


def event_has_raw_delta(raw_deltas: dict[str, Any], stat: str) -> bool:
    return stat in raw_deltas and raw_deltas.get(stat) not in (None, "")


def add_event_delta(values: dict[str, int], stat: str, amount: int) -> None:
    values[stat] = int(values.get(stat, 0)) + int(amount)


def clamp_event_stat_values(values: dict[str, int]) -> None:
    for stat, limit in EVENT_STAT_LIMITS.items():
        minimum = EVENT_STAT_MINIMUMS.get(stat, 0)
        values[stat] = max(minimum, min(limit, int(values.get(stat, 0))))


def support_action_for_event(event: dict[str, Any]) -> str:
    explicit = str(
        event.get("support_action")
        or event.get("action_type")
        or event.get("support_type")
        or event.get("activity_type")
        or ""
    ).strip().lower()
    if explicit:
        normalized = explicit.replace("-", "_").replace(" ", "_")
        if normalized in SUPPORT_ACTION_ALIASES:
            return SUPPORT_ACTION_ALIASES[normalized]
        if normalized in SUPPORT_ACTION_REWARDS:
            return normalized

    text = event_text_blob(event)
    event_type = str(event.get("event_type") or event.get("type") or "").lower()
    if event_type in {"support_action", "tcwa3_support_action", "support"}:
        for alias, action in SUPPORT_ACTION_ALIASES.items():
            if event_has_text(text, (alias.replace("_", " "), alias)):
                return action
    for alias, action in SUPPORT_ACTION_ALIASES.items():
        if event_type == alias or event_type == action:
            return action
    return ""


def support_action_amount(event: dict[str, Any], values: dict[str, int], stat: str) -> int:
    if values.get(stat, 0):
        return max(1, int(values[stat]))
    for container in (event.get("stats"), event):
        if isinstance(container, dict):
            for key in ("amount", "count", "support_count", stat):
                if key in container:
                    return max(1, bounded_int(container.get(key), default=1))
    return 1


def apply_official_event_rewards(event: dict[str, Any], values: dict[str, int], raw_deltas: dict[str, Any]) -> None:
    """Derive TCWA3 rewards for signed official events that omit exact deltas."""
    text = event_text_blob(event)
    event_type = str(event.get("event_type") or event.get("type") or "").lower()
    stat_mode = str(event.get("stat_mode") or event.get("mode") or "").strip().lower()
    is_kill = event_has_text(text, ("kill", "killed", "destroy", "destroyed", "eliminated"))
    is_atomic_kill_event = (
        event_has_text(event_type, ("kill", "killed", "destroy", "destroyed", "eliminated"))
        and not event_has_text(event_type, ("mission", "deployment", "summary", "snapshot", "total", "session"))
        and stat_mode not in {"total", "totals", "absolute", "snapshot", "summary"}
    )
    is_teamkill = event_has_text(text, ("teamkill", "team kill", "friendly_fire", "friendly fire", "friendly kill")) or (
        is_kill and event_has_text(text, ("friendly", "bluefor", "republic")) and not event_has_text(text, ("enemy", "cis", "droid"))
    )
    is_death = event_has_text(text, ("death", "died", "player_down", "player killed"))
    is_tank = event_has_text(text, ("tank", "armor", "armour", "apc", "ifv", "ground_vehicle"))
    is_aircraft = event_has_text(text, ("aircraft", "plane", "jet", "helicopter", "helo", "vtol", "gunship", "laat"))
    is_infantry = event_has_text(text, ("infantry", "droid", "enemy", "man", "soldier", "trooper", "unit"))
    support_action = support_action_for_event(event)

    if is_teamkill:
        if not event_has_raw_delta(raw_deltas, "xp"):
            add_event_delta(values, "xp", -100)
        if not event_has_raw_delta(raw_deltas, "friendly_kills"):
            add_event_delta(values, "friendly_kills", 1)
    elif is_kill:
        if is_tank:
            xp_delta, credit_delta = 25, VEHICLE_KILL_CREDIT_REWARD
        elif is_aircraft:
            xp_delta, credit_delta = 35, AIRCRAFT_KILL_CREDIT_REWARD
        elif is_infantry or event_has_text(text, ("kill", "killed")):
            xp_delta, credit_delta = 5, DROID_KILL_CREDIT_REWARD
        else:
            xp_delta, credit_delta = 0, 0
        if xp_delta and not event_has_raw_delta(raw_deltas, "xp"):
            add_event_delta(values, "xp", xp_delta)
        if credit_delta and not event_has_raw_delta(raw_deltas, "credits"):
            add_event_delta(values, "credits", credit_delta)
        if not event_has_raw_delta(raw_deltas, "kills"):
            add_event_delta(values, "kills", 1)
        if not event_has_raw_delta(raw_deltas, "enemy_kills"):
            add_event_delta(values, "enemy_kills", 1)
        if not event_has_raw_delta(raw_deltas, "droid_kills"):
            add_event_delta(values, "droid_kills", 1)
        if is_tank and not event_has_raw_delta(raw_deltas, "vehicle_kills"):
            add_event_delta(values, "vehicle_kills", 1)
        if is_aircraft and not event_has_raw_delta(raw_deltas, "aircraft_kills"):
            add_event_delta(values, "aircraft_kills", 1)
        if is_atomic_kill_event and values.get("credits", 0) > 0:
            if is_tank:
                credited_actions = max(1, int(values.get("vehicle_kills") or values.get("kills") or 1))
                max_credits = credited_actions * VEHICLE_KILL_CREDIT_REWARD
            elif is_aircraft:
                credited_actions = max(1, int(values.get("aircraft_kills") or values.get("kills") or 1))
                max_credits = credited_actions * AIRCRAFT_KILL_CREDIT_REWARD
            else:
                credited_actions = max(1, int(values.get("droid_kills") or values.get("enemy_kills") or values.get("kills") or 1))
                max_credits = credited_actions * DROID_KILL_CREDIT_REWARD
            values["credits"] = min(values["credits"], max_credits)

    if is_death:
        if not event_has_raw_delta(raw_deltas, "xp"):
            add_event_delta(values, "xp", -20)
        if not event_has_raw_delta(raw_deltas, "deaths"):
            add_event_delta(values, "deaths", 1)

    if event_mission_completed(event, values):
        if not event_has_raw_delta(raw_deltas, "missions"):
            add_event_delta(values, "missions", 1)
        if not event_has_raw_delta(raw_deltas, "deployments_completed"):
            add_event_delta(values, "deployments_completed", 1)
        if not event_has_raw_delta(raw_deltas, "support_score"):
            add_event_delta(values, "support_score", DEPLOYMENT_COMPLETION_SUPPORT_SCORE)
        difficulty = event_difficulty(event)
        if difficulty is not None and not event_has_raw_delta(raw_deltas, "xp"):
            add_event_delta(values, "xp", DIFFICULTY_MISSION_XP[difficulty])

    if support_action:
        stat, score = SUPPORT_ACTION_REWARDS[support_action]
        amount = support_action_amount(event, values, stat)
        if not event_has_raw_delta(raw_deltas, stat):
            add_event_delta(values, stat, amount)
        if not event_has_raw_delta(raw_deltas, "support_score"):
            add_event_delta(values, "support_score", score * amount)

    clamp_event_stat_values(values)


def mission_stat_value(event: dict[str, Any], values: dict[str, int], keys: tuple[str, ...]) -> int:
    containers = [event.get("mission_stats"), event.get("round_stats"), event.get("stats"), event.get("mission")]
    for container in containers:
        if not isinstance(container, dict):
            continue
        for key in keys:
            if key in container:
                return bounded_int(container.get(key))
    for key in keys:
        if key in event:
            return bounded_int(event.get(key))
        if key in values:
            return values[key]
    return 0


def achievement_context_for_event(event: dict[str, Any], values: dict[str, int], timestamp: int) -> tuple[list[str], dict[str, int]]:
    """Return one-mission awards and stat increments from a signed server event."""
    mission_completed = event_mission_completed(event, values)
    mission_deaths = mission_stat_value(event, values, ("mission_deaths", "deaths"))
    enemy_kills = mission_stat_value(event, values, ("enemy_kills", "droid_kills", "kills"))
    friendly_kills = mission_stat_value(event, values, ("friendly_kills", "team_kills"))
    has_mission_stat_context = mission_completed or isinstance(event.get("mission_stats"), dict) or isinstance(event.get("round_stats"), dict)

    contextual: list[str] = []
    progress = {
        "kamino_visits": 0,
        "geonosis_missions": 0,
        "friendly_fire_missions": 0,
        "high_death_missions": 0,
        "perfect_missions": 0,
    }
    if event_has_location(event, "kamino"):
        contextual.append("kamino_shiny")
        progress["kamino_visits"] = 1
    if mission_completed and event_has_location(event, "geonosis"):
        progress["geonosis_missions"] = 1
        if GEONOSIS_LAUNCH_WEEK_START <= timestamp < GEONOSIS_LAUNCH_WEEK_END:
            contextual.append("geonosis_not_shiny_for_long")
    if has_mission_stat_context and mission_deaths >= 20:
        contextual.append("droid_bait")
        progress["high_death_missions"] = 1
    if mission_completed and friendly_kills > enemy_kills:
        contextual.append("same_team")
        progress["friendly_fire_missions"] = 1
    if mission_completed and mission_deaths == 0:
        contextual.append("survivor")
        progress["perfect_missions"] = 1
    if event_mission_failed(event):
        contextual.append("hard_contact")
    return contextual, progress


def request_url(url: str, timeout: int = 10, user_agent: str = "TCWLauncher/1.0") -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": user_agent})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def fetch_steam_display_name(steam_id: str) -> str:
    if not STEAM_ID_PATTERN.fullmatch(steam_id):
        return ""
    timestamp = time.time()
    with STEAM_NAME_CACHE_LOCK:
        cached = STEAM_NAME_CACHE.get(steam_id)
        if cached and timestamp < cached[0]:
            return cached[1]

    name = fetch_steam_webapi_name(steam_id) or fetch_steam_xml_name(steam_id)
    cleaned = clean_profile_name(name) if name else ""
    if is_generic_display_name(cleaned):
        cleaned = ""

    with STEAM_NAME_CACHE_LOCK:
        STEAM_NAME_CACHE[steam_id] = (timestamp + STEAM_NAME_CACHE_SECONDS, cleaned)
    return cleaned


def fetch_steam_webapi_name(steam_id: str) -> str:
    if not STEAM_WEB_API_KEY:
        return ""
    query = urllib.parse.urlencode({"key": STEAM_WEB_API_KEY, "steamids": steam_id})
    url = f"https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?{query}"
    try:
        payload = json.loads(request_url(url, timeout=8).decode("utf-8", "replace"))
    except (OSError, urllib.error.URLError, json.JSONDecodeError, TimeoutError):
        return ""
    players = payload.get("response", {}).get("players", []) if isinstance(payload, dict) else []
    if not players or not isinstance(players[0], dict):
        return ""
    return str(players[0].get("personaname", "")).strip()


def fetch_steam_xml_name(steam_id: str) -> str:
    # Steam's profile XML endpoint does not need a secret and gives us a useful
    # public-name fallback when the official Web API key is not configured.
    url = f"https://steamcommunity.com/profiles/{urllib.parse.quote(steam_id)}/?xml=1"
    try:
        root = ET.fromstring(request_url(url, timeout=8, user_agent="TCW-Profile-API/1.0"))
    except (OSError, urllib.error.URLError, ET.ParseError, TimeoutError):
        return ""
    return str(root.findtext("steamID", "") or "").strip()


def youtube_channel_url() -> str:
    return f"https://www.youtube.com/@{YOUTUBE_HANDLE}" if YOUTUBE_HANDLE else ""


def youtube_embed_url(video_id: str) -> str:
    query = urllib.parse.urlencode(
        {
            "autoplay": "1",
            "mute": "1",
            "controls": "1",
            "playsinline": "1",
            "rel": "0",
            "modestbranding": "1",
        }
    )
    return f"https://www.youtube-nocookie.com/embed/{urllib.parse.quote(video_id)}?{query}"


def unavailable_youtube_video(message: str = "Latest video unavailable") -> dict[str, Any]:
    return {
        "available": False,
        "title": message,
        "video_id": "",
        "published_at": "",
        "url": youtube_channel_url(),
        "embed_url": "",
        "thumbnail_url": "",
        "channel_url": youtube_channel_url(),
        "updated_at": now(),
    }


def discover_youtube_channel_id() -> str:
    global YOUTUBE_DISCOVERED_CHANNEL_ID
    if YOUTUBE_CHANNEL_ID:
        return YOUTUBE_CHANNEL_ID
    if YOUTUBE_DISCOVERED_CHANNEL_ID:
        return YOUTUBE_DISCOVERED_CHANNEL_ID
    if not YOUTUBE_HANDLE:
        return ""

    url = f"https://www.youtube.com/@{urllib.parse.quote(YOUTUBE_HANDLE, safe='-_')}"
    try:
        page = request_url(url, timeout=10, user_agent="Mozilla/5.0 TCW-Profile-API/1.0").decode("utf-8", "replace")
    except (OSError, urllib.error.URLError, TimeoutError):
        return ""
    for pattern in [r'"channelId":"(UC[^"]+)"', r'"externalId":"(UC[^"]+)"', r"channel/(UC[0-9A-Za-z_-]+)"]:
        match = re.search(pattern, page)
        if match:
            YOUTUBE_DISCOVERED_CHANNEL_ID = match.group(1)
            return YOUTUBE_DISCOVERED_CHANNEL_ID
    return ""


def parse_youtube_feed(feed_xml: bytes) -> dict[str, Any]:
    namespaces = {
        "atom": "http://www.w3.org/2005/Atom",
        "yt": "http://www.youtube.com/xml/schemas/2015",
        "media": "http://search.yahoo.com/mrss/",
    }
    root = ET.fromstring(feed_xml)
    entry = root.find("atom:entry", namespaces)
    if entry is None:
        return unavailable_youtube_video("No YouTube videos found")

    video_id = str(entry.findtext("yt:videoId", "", namespaces)).strip()
    if not video_id:
        return unavailable_youtube_video("No YouTube video ID found")
    title = html.unescape(str(entry.findtext("atom:title", "Latest TCWA3 video", namespaces)).strip())[:160]
    published = str(entry.findtext("atom:published", "", namespaces)).strip()[:40]
    video_url = f"https://www.youtube.com/watch?v={video_id}"
    link = entry.find("atom:link[@rel='alternate']", namespaces)
    if link is not None:
        video_url = str(link.attrib.get("href", video_url)).strip()[:500] or video_url

    thumbnail_url = ""
    media_group = entry.find("media:group", namespaces)
    if media_group is not None:
        thumbnail = media_group.find("media:thumbnail", namespaces)
        if thumbnail is not None:
            thumbnail_url = str(thumbnail.attrib.get("url", "")).strip()[:500]

    return {
        "available": True,
        "title": title or "Latest TCWA3 video",
        "video_id": video_id,
        "published_at": published,
        "url": video_url,
        "embed_url": youtube_embed_url(video_id),
        "thumbnail_url": thumbnail_url,
        "channel_url": youtube_channel_url(),
        "updated_at": now(),
    }


def latest_youtube_video(force: bool = False) -> dict[str, Any]:
    global YOUTUBE_CACHE_EXPIRES, YOUTUBE_LATEST_CACHE
    timestamp = time.time()
    with YOUTUBE_CACHE_LOCK:
        if not force and YOUTUBE_LATEST_CACHE and timestamp < YOUTUBE_CACHE_EXPIRES:
            return dict(YOUTUBE_LATEST_CACHE)

    video = unavailable_youtube_video()
    channel_id = discover_youtube_channel_id()
    if channel_id:
        feed_url = "https://www.youtube.com/feeds/videos.xml?" + urllib.parse.urlencode({"channel_id": channel_id})
        try:
            video = parse_youtube_feed(request_url(feed_url, timeout=10, user_agent="TCW-Profile-API/1.0"))
        except (OSError, urllib.error.URLError, ET.ParseError, TimeoutError):
            with YOUTUBE_CACHE_LOCK:
                if YOUTUBE_LATEST_CACHE:
                    return dict(YOUTUBE_LATEST_CACHE)
            video = unavailable_youtube_video()

    with YOUTUBE_CACHE_LOCK:
        YOUTUBE_LATEST_CACHE = video
        cache_seconds = YOUTUBE_CACHE_SECONDS if video.get("available") else min(300, YOUTUBE_CACHE_SECONDS)
        YOUTUBE_CACHE_EXPIRES = timestamp + cache_seconds
    return dict(video)


def clean_news_item(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    title = str(value.get("title", "Update")).strip()[:80] or "Update"
    body = str(value.get("body", "")).strip()[:500]
    date = str(value.get("date", "")).strip()[:32]
    link = str(value.get("link", "")).strip()[:300]
    try:
        priority = int(value.get("priority", 0))
    except (TypeError, ValueError):
        priority = 0
    return {"title": title, "body": body, "date": date, "link": link, "priority": priority}


def load_news() -> list[dict[str, Any]]:
    if not NEWS_PATH.exists():
        return DEFAULT_NEWS
    try:
        parsed = json.loads(NEWS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return DEFAULT_NEWS
    raw_items = parsed.get("items", parsed) if isinstance(parsed, dict) else parsed
    if not isinstance(raw_items, list):
        return DEFAULT_NEWS
    items = [item for item in (clean_news_item(raw) for raw in raw_items) if item is not None]
    items.sort(key=lambda item: int(item.get("priority", 0)), reverse=True)
    return items[:20] or DEFAULT_NEWS


def clean_news_payload(value: Any) -> dict[str, list[dict[str, Any]]]:
    raw_items = value.get("items", value) if isinstance(value, dict) else value
    if not isinstance(raw_items, list):
        raise ValueError("News payload must include an items list")
    items = [item for item in (clean_news_item(raw) for raw in raw_items) if item is not None]
    if not items:
        raise ValueError("At least one valid news item is required")
    items.sort(key=lambda item: int(item.get("priority", 0)), reverse=True)
    return {"items": items[:20]}


def save_news_payload(value: Any) -> dict[str, list[dict[str, Any]]]:
    payload = clean_news_payload(value)
    NEWS_PATH.parent.mkdir(parents=True, exist_ok=True)
    NEWS_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return payload


def clean_hex_color(value: Any, fallback: str) -> str:
    color = str(value or "").strip()
    if re.fullmatch(r"#[0-9A-Fa-f]{6}", color):
        return color.upper()
    return fallback


def clean_iso_text(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return ""
    return text[:40]


def timestamp_from_iso_text(value: Any) -> int | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return int(parsed.astimezone(timezone.utc).timestamp())


def clean_event_id(value: Any, fallback_title: str) -> str:
    raw = str(value or fallback_title or "event").strip().lower()
    event_id = re.sub(r"[^a-z0-9]+", "-", raw).strip("-")[:72]
    return event_id or f"event-{now()}"


def clean_event_banner(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    title = str(value.get("title", "Community Event")).strip()[:96] or "Community Event"
    description = str(value.get("description", "")).strip()[:700]
    xp_bonus_percent = bounded_int(value.get("xp_bonus_percent"), 0)
    xp_bonus_percent = max(0, min(500, xp_bonus_percent))
    priority = bounded_int(value.get("priority"), 0)
    effect = str(value.get("effect", "glow")).strip().lower()
    if effect not in EVENT_EFFECTS:
        effect = "glow"
    popup_style = str(value.get("popup_style", "banner")).strip().lower()
    if popup_style not in EVENT_POPUP_STYLES:
        popup_style = "banner"
    font_family = str(value.get("font_family", "tcw")).strip().lower()
    if font_family not in EVENT_FONTS:
        font_family = "tcw"
    placement = str(value.get("placement", "center")).strip().lower()
    if placement not in EVENT_PLACEMENTS:
        placement = "center"
    size = str(value.get("size", "standard")).strip().lower()
    if size not in EVENT_SIZES:
        size = "standard"
    duration_seconds = bounded_int(value.get("duration_seconds"), 10)
    duration_seconds = max(3, min(120, duration_seconds))
    sound_url = str(value.get("sound_url", "")).strip()[:500]
    if sound_url and not (sound_url.startswith(AUDIO_BASE_URL + "/") or sound_url.startswith("/audio/")):
        sound_url = ""
    start_at = clean_iso_text(value.get("start_at") or value.get("starts_at"))
    end_at = clean_iso_text(value.get("end_at") or value.get("ends_at"))
    return {
        "id": clean_event_id(value.get("id"), title),
        "title": title,
        "description": description,
        "active": bool(value.get("active", True)),
        "start_at": start_at,
        "end_at": end_at,
        "priority": max(-1000, min(1000, priority)),
        "accent_color": clean_hex_color(value.get("accent_color"), "#D9B36C"),
        "background_color": clean_hex_color(value.get("background_color"), "#070B12"),
        "effect": effect,
        "popup_style": popup_style,
        "font_family": font_family,
        "placement": placement,
        "size": size,
        "duration_seconds": duration_seconds,
        "sound_url": sound_url,
        "xp_bonus_percent": xp_bonus_percent,
    }


def clean_events_payload(value: Any) -> dict[str, list[dict[str, Any]]]:
    raw_events = value.get("events", value) if isinstance(value, dict) else value
    if not isinstance(raw_events, list):
        raise ValueError("Events payload must include an events list")
    events = [event for event in (clean_event_banner(raw) for raw in raw_events) if event is not None]
    seen: set[str] = set()
    unique_events: list[dict[str, Any]] = []
    for event in events[:30]:
        base_id = event["id"]
        event_id = base_id
        suffix = 2
        while event_id in seen:
            event_id = f"{base_id}-{suffix}"[:80]
            suffix += 1
        event["id"] = event_id
        seen.add(event_id)
        unique_events.append(event)
    unique_events.sort(key=lambda item: int(item.get("priority", 0)), reverse=True)
    return {"events": unique_events}


def save_events_payload(value: Any) -> dict[str, list[dict[str, Any]]]:
    payload = clean_events_payload(value)
    EVENTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    EVENTS_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return payload


def load_event_banners(include_inactive: bool = False, timestamp: int | None = None) -> list[dict[str, Any]]:
    if not EVENTS_PATH.exists():
        events = list(DEFAULT_EVENTS)
    else:
        try:
            parsed = json.loads(EVENTS_PATH.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            parsed = {"events": DEFAULT_EVENTS}
        try:
            events = clean_events_payload(parsed)["events"]
        except ValueError:
            events = list(DEFAULT_EVENTS)
    if include_inactive:
        return events
    check_time = timestamp if timestamp is not None else now()
    active_events: list[dict[str, Any]] = []
    for event in events:
        if not bool(event.get("active", True)):
            continue
        start_ts = timestamp_from_iso_text(event.get("start_at"))
        end_ts = timestamp_from_iso_text(event.get("end_at"))
        if start_ts is not None and check_time < start_ts:
            continue
        if end_ts is not None and check_time >= end_ts:
            continue
        active_events.append(event)
    return active_events


def load_event_manifest(timestamp: int | None = None) -> dict[str, Any]:
    active_events = load_event_banners(include_inactive=False, timestamp=timestamp)
    xp_bonus_percent = min(500, sum(bounded_int(event.get("xp_bonus_percent")) for event in active_events))
    return {
        "updated_at": now(),
        "events": active_events,
        "modifiers": {
            "xp_bonus_percent": xp_bonus_percent,
            "xp_multiplier": round(1.0 + (xp_bonus_percent / 100.0), 3),
        },
    }


def active_event_xp_bonus(timestamp: int) -> tuple[int, list[str]]:
    active_events = load_event_banners(include_inactive=False, timestamp=timestamp)
    bonus = min(500, sum(bounded_int(event.get("xp_bonus_percent")) for event in active_events))
    event_ids = [str(event.get("id", "")) for event in active_events if bounded_int(event.get("xp_bonus_percent")) > 0]
    return bonus, event_ids


def server_control_key(ip: Any, port: Any) -> str:
    clean_ip = str(ip or "").strip()
    clean_port = max(0, bounded_int(port))
    return f"{clean_ip}:{clean_port}"


def clean_server_control(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    ip = str(value.get("ip", "")).strip()
    port = max(0, bounded_int(value.get("port")))
    if not ip or port <= 0:
        return None
    name = str(value.get("name", "")).strip()[:96]
    reason = str(value.get("reason", "")).replace("\r\n", "\n").replace("\r", "\n").strip()[:240]
    maintenance = bool(value.get("maintenance", value.get("in_maintenance", False)))
    return {
        "key": server_control_key(ip, port),
        "name": name or f"{ip}:{port}",
        "ip": ip,
        "port": port,
        "maintenance": maintenance,
        "reason": reason or "Under maintenance",
        "updated_at": bounded_int(value.get("updated_at"), now()),
    }


def clean_server_controls_payload(value: Any) -> dict[str, list[dict[str, Any]]]:
    raw_servers = value.get("servers", value) if isinstance(value, dict) else value
    if isinstance(raw_servers, dict):
        raw_servers = list(raw_servers.values())
    if not isinstance(raw_servers, list):
        raise ValueError("Server controls payload must include a servers list")
    controls: dict[str, dict[str, Any]] = {}
    for raw_server in raw_servers[:200]:
        control = clean_server_control(raw_server)
        if control is not None:
            controls[control["key"]] = control
    return {"servers": sorted(controls.values(), key=lambda item: (item["name"].lower(), item["key"]))}


def clean_server_catalog_id(value: Any, fallback: str = "") -> str:
    candidate = str(value or fallback or "").strip().lower()
    candidate = re.sub(r"[^a-z0-9_]+", "_", candidate).strip("_")
    return candidate[:72]


def clean_server_catalog_teamspeak_url(value: Any) -> str:
    url = str(value or "").strip().replace("\r", "").replace("\n", "")[:300]
    if not url:
        return ""
    if not url.lower().startswith("ts3server://"):
        return ""
    return url


def clean_server_catalog_entry(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    ip = str(value.get("ip", value.get("host", ""))).strip()[:80]
    port = max(0, bounded_int(value.get("port")))
    if not ip or port <= 0 or port > 65535:
        return None
    name = re.sub(r"\s+", " ", str(value.get("name", "")).strip())[:96]
    server_id = clean_server_catalog_id(value.get("id", value.get("key", "")), name or f"{ip}_{port}")
    if not server_id:
        server_id = clean_server_catalog_id(f"{ip}_{port}")
    category = clean_server_catalog_id(
        value.get("category", value.get("category_id", "")),
        "roleplay_global",
    )
    reason = str(value.get("reason", value.get("maintenance_message", ""))).replace("\r\n", "\n").replace("\r", "\n").strip()[:240]
    return {
        "id": server_id,
        "key": server_control_key(ip, port),
        "name": name or f"{ip}:{port}",
        "ip": ip,
        "port": port,
        "category": category or "roleplay_global",
        "type": str(value.get("type", "action" if category.startswith("action_") else "roleplay")).strip().lower()[:32] or "roleplay",
        "visible": bool(value.get("visible", True)),
        "enabled": bool(value.get("enabled", value.get("active", True))),
        "active": bool(value.get("active", value.get("enabled", True))),
        "maintenance": bool(value.get("maintenance", value.get("in_maintenance", False))),
        "reason": reason or "Under maintenance",
        "max_players": max(0, bounded_int(value.get("max_players", value.get("maxPlayers", 40)))),
        "password": str(value.get("password", "")).strip()[:64],
        "teamspeak_url": clean_server_catalog_teamspeak_url(value.get("teamspeak_url", value.get("teamspeakUrl", ""))),
        "updated_at": bounded_int(value.get("updated_at"), now()),
    }


def clean_server_catalog_category(value: Any, server_ids: set[str]) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    category_id = clean_server_catalog_id(value.get("id", value.get("key", "")))
    if not category_id:
        return None
    server_list: list[str] = []
    raw_servers = value.get("servers", [])
    if isinstance(raw_servers, list):
        for item in raw_servers:
            server_id = clean_server_catalog_id(item)
            if server_id in server_ids and server_id not in server_list:
                server_list.append(server_id)
    if not server_list:
        return None
    name = re.sub(r"\s+", " ", str(value.get("name", value.get("display_name", category_id.replace("_", " ").title()))).strip())[:80]
    return {
        "id": category_id,
        "key": category_id,
        "name": name or category_id.replace("_", " ").title(),
        "display_name": name or category_id.replace("_", " ").title(),
        "servers": server_list,
    }


def clean_server_catalog_payload(value: Any) -> dict[str, Any]:
    raw_servers = value.get("servers", []) if isinstance(value, dict) else []
    if isinstance(raw_servers, dict):
        raw_servers = [dict(server, id=server_id) for server_id, server in raw_servers.items() if isinstance(server, dict)]
    if not isinstance(raw_servers, list):
        raise ValueError("Server catalog payload must include a servers list")
    servers: dict[str, dict[str, Any]] = {}
    for raw_server in raw_servers[:260]:
        server = clean_server_catalog_entry(raw_server)
        if server is not None:
            servers[server["id"]] = server

    raw_categories = value.get("categories", []) if isinstance(value, dict) else []
    if isinstance(raw_categories, dict):
        raw_categories = [dict(category, id=category_id) for category_id, category in raw_categories.items() if isinstance(category, dict)]
    categories: dict[str, dict[str, Any]] = {}
    server_ids = set(servers)
    if isinstance(raw_categories, list):
        for raw_category in raw_categories[:80]:
            category = clean_server_catalog_category(raw_category, server_ids)
            if category is not None:
                categories[category["id"]] = category

    if not categories and servers:
        grouped: dict[str, list[str]] = {}
        for server_id, server in servers.items():
            grouped.setdefault(str(server.get("category", "roleplay_global")), []).append(server_id)
        for category_id, category_servers in grouped.items():
            display_name = category_id.replace("_", " ").title()
            categories[category_id] = {
                "id": category_id,
                "key": category_id,
                "name": display_name,
                "display_name": display_name,
                "servers": category_servers,
            }

    return {
        "servers": sorted(servers.values(), key=lambda item: (str(item["category"]), str(item["name"]).lower(), str(item["id"]))),
        "categories": sorted(categories.values(), key=lambda item: (str(item["display_name"]).lower(), str(item["id"]))),
    }


def load_default_server_catalog() -> dict[str, Any]:
    if not DEFAULT_SERVER_CATALOG_PATH.exists():
        return {"servers": [], "categories": []}
    try:
        parsed = json.loads(DEFAULT_SERVER_CATALOG_PATH.read_text(encoding="utf-8"))
        return clean_server_catalog_payload(parsed)
    except (OSError, json.JSONDecodeError, ValueError):
        return {"servers": [], "categories": []}


def load_server_catalog(include_hidden: bool = False) -> dict[str, Any]:
    if SERVER_CATALOG_PATH.exists():
        try:
            parsed = json.loads(SERVER_CATALOG_PATH.read_text(encoding="utf-8"))
            catalog = clean_server_catalog_payload(parsed)
        except (OSError, json.JSONDecodeError, ValueError):
            catalog = load_default_server_catalog()
    else:
        catalog = load_default_server_catalog()
    controls = {str(item.get("key", "")): item for item in load_server_controls().get("servers", [])}
    servers: list[dict[str, Any]] = []
    for server in catalog["servers"]:
        updated = dict(server)
        control = controls.get(str(updated.get("key", "")))
        if control:
            updated["maintenance"] = bool(control.get("maintenance"))
            updated["reason"] = str(control.get("reason") or updated.get("reason") or "Under maintenance")
            updated["updated_at"] = max(bounded_int(updated.get("updated_at")), bounded_int(control.get("updated_at")))
        if include_hidden or bool(updated.get("visible", True)):
            servers.append(updated)
    visible_ids = {server["id"] for server in servers}
    categories: list[dict[str, Any]] = []
    for category in catalog["categories"]:
        category_servers = [server_id for server_id in category.get("servers", []) if server_id in visible_ids]
        if category_servers or include_hidden:
            updated_category = dict(category)
            updated_category["servers"] = category_servers
            categories.append(updated_category)
    return {"servers": servers, "categories": categories}


def parse_extra_official_progression_server_ids() -> set[str]:
    ids: set[str] = set()
    raw_json = os.getenv("TCW_OFFICIAL_PROGRESS_SERVER_IDS_JSON", "").strip()
    if raw_json:
        try:
            parsed = json.loads(raw_json)
        except json.JSONDecodeError:
            parsed = []
        if isinstance(parsed, dict):
            candidates = list(parsed.keys()) + list(parsed.values())
        elif isinstance(parsed, list):
            candidates = parsed
        else:
            candidates = []
        for item in candidates:
            server_id = clean_server_catalog_id(item)
            if server_id:
                ids.add(server_id)
    for item in os.getenv("TCW_OFFICIAL_PROGRESS_SERVER_IDS", "").split(","):
        server_id = clean_server_catalog_id(item)
        if server_id:
            ids.add(server_id)
    return ids


def add_official_progression_alias(aliases: dict[str, str], value: Any, canonical: str) -> None:
    text = str(value or "").strip()
    if not text or not canonical:
        return
    aliases.setdefault(text.lower(), canonical)
    cleaned = clean_server_catalog_id(text)
    if cleaned:
        aliases.setdefault(cleaned, canonical)


def official_progression_server_aliases() -> dict[str, str]:
    aliases: dict[str, str] = {}
    for item in load_server_catalog(include_hidden=True).get("servers", []):
        canonical = clean_server_catalog_id(item.get("id"))
        if not canonical:
            continue
        add_official_progression_alias(aliases, canonical, canonical)
        add_official_progression_alias(aliases, item.get("name"), canonical)
        add_official_progression_alias(aliases, item.get("key"), canonical)
        ip = str(item.get("ip", "")).strip()
        port = bounded_int(item.get("port"))
        if ip and port:
            add_official_progression_alias(aliases, f"{ip}:{port}", canonical)
            add_official_progression_alias(aliases, f"{ip}_{port}", canonical)
    for server_id in parse_extra_official_progression_server_ids():
        add_official_progression_alias(aliases, server_id, server_id)
    return aliases


def canonical_official_progression_server_id(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    aliases = official_progression_server_aliases()
    return aliases.get(text.lower()) or aliases.get(clean_server_catalog_id(text), "")


OFFICIAL_EVENT_SERVER_ID_FIELDS = (
    "server_id",
    "serverId",
    "tcwa3_server_id",
    "tcwa3ServerId",
    "catalog_server_id",
    "catalogServerId",
    "official_server",
    "officialServer",
)

OFFICIAL_EVENT_SERVER_NAME_FIELDS = (
    "server_name",
    "serverName",
    "host_name",
    "hostName",
    "host",
)


def official_event_server_id(auth_server_id: str, event: dict[str, Any]) -> str:
    declared_id_present = False
    for key in OFFICIAL_EVENT_SERVER_ID_FIELDS:
        value = event.get(key)
        if value not in (None, ""):
            declared_id_present = True
            canonical = canonical_official_progression_server_id(value)
            if canonical:
                return canonical
    if declared_id_present:
        return ""
    for key in OFFICIAL_EVENT_SERVER_NAME_FIELDS:
        canonical = canonical_official_progression_server_id(event.get(key))
        if canonical:
            return canonical
    return canonical_official_progression_server_id(auth_server_id)


def declared_event_server_identity(event: dict[str, Any]) -> str:
    values: list[str] = []
    for key in (*OFFICIAL_EVENT_SERVER_ID_FIELDS, *OFFICIAL_EVENT_SERVER_NAME_FIELDS):
        value = event.get(key)
        if value not in (None, ""):
            values.append(f"{key}={str(value)[:96]}")
    return ", ".join(values)[:500]


def save_server_catalog_payload(value: Any) -> dict[str, Any]:
    payload = clean_server_catalog_payload(value)
    SERVER_CATALOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    SERVER_CATALOG_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return load_server_catalog(include_hidden=True)


def load_server_controls() -> dict[str, list[dict[str, Any]]]:
    if not SERVER_CONTROLS_PATH.exists():
        return {"servers": []}
    try:
        parsed = json.loads(SERVER_CONTROLS_PATH.read_text(encoding="utf-8"))
        return clean_server_controls_payload(parsed)
    except (OSError, json.JSONDecodeError, ValueError):
        parsed = {"servers": []}
    return parsed


def save_server_controls_payload(value: Any) -> dict[str, list[dict[str, Any]]]:
    payload = clean_server_controls_payload(value)
    SERVER_CONTROLS_PATH.parent.mkdir(parents=True, exist_ok=True)
    SERVER_CONTROLS_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return payload


def find_server_control(ip: Any, port: Any) -> dict[str, Any] | None:
    key = server_control_key(ip, port)
    for server in load_server_catalog(include_hidden=True)["servers"]:
        if server.get("key") == key and bool(server.get("maintenance")):
            return {
                "key": key,
                "name": server.get("name", ""),
                "ip": server.get("ip", ""),
                "port": server.get("port", 0),
                "maintenance": True,
                "reason": server.get("reason", "Under maintenance"),
                "updated_at": server.get("updated_at", now()),
            }
    for control in load_server_controls()["servers"]:
        if control.get("key") == key:
            return control
    return None


def apply_server_control(status: dict[str, Any], ip: Any, port: Any) -> dict[str, Any]:
    control = find_server_control(ip, port)
    if not control or not bool(control.get("maintenance")):
        return status
    payload = dict(status)
    reason = str(control.get("reason") or "Under maintenance")
    payload.update(
        {
            "status": "maintenance",
            "maintenance": True,
            "message": reason,
            "mission": reason,
            "server_control": {
                "name": control.get("name", ""),
                "reason": reason,
                "updated_at": control.get("updated_at", now()),
            },
        }
    )
    return payload


def apply_xp_bonus(xp: int, bonus_percent: int) -> int:
    if xp <= 0 or bonus_percent <= 0:
        return xp
    return int(round(xp * (100 + bonus_percent) / 100.0))


def clean_marketplace_category(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    category_id = re.sub(r"[^a-z0-9_]+", "_", str(value.get("id", "")).strip().lower()).strip("_")[:48]
    if not category_id:
        return None
    return {
        "id": category_id,
        "name": str(value.get("name", category_id.replace("_", " ").title())).strip()[:80],
        "description": str(value.get("description", "")).strip()[:240],
    }


def marketplace_category_ids(categories: list[dict[str, Any]]) -> set[str]:
    return {str(category.get("id", "")) for category in categories if category.get("id")}


def marketplace_requirement_values(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return list(value)
    return [value]


def clean_marketplace_requirement_ids(value: Any, limit: int = 12) -> list[str]:
    ids: list[str] = []
    for raw_item in marketplace_requirement_values(value):
        item_id = re.sub(r"[^a-z0-9_\-]+", "-", str(raw_item).strip().lower()).strip("-_")[:80]
        if item_id and item_id not in ids:
            ids.append(item_id)
        if len(ids) >= limit:
            break
    return ids


def clean_marketplace_requirement_texts(value: Any, limit: int = 12) -> list[str]:
    texts: list[str] = []
    for raw_item in marketplace_requirement_values(value):
        text = re.sub(r"\s+", " ", str(raw_item or "")).strip()[:64]
        if text and text not in texts:
            texts.append(text)
        if len(texts) >= limit:
            break
    return texts


def clean_marketplace_requirements(value: Any) -> dict[str, Any]:
    raw = value if isinstance(value, dict) else {}
    requirements: dict[str, Any] = {}

    min_level = bounded_int(
        raw.get(
            "min_level",
            raw.get("minimum_level", raw.get("level", 0)),
        ),
        0,
    )
    if min_level > 1:
        requirements["min_level"] = max(1, min(MAX_LEVEL_ITERATION, min_level))

    achievements = clean_marketplace_requirement_ids(
        raw.get(
            "achievements",
            raw.get("achievement_ids", raw.get("achievement_id", raw.get("achievement", []))),
        )
    )
    if achievements:
        requirements["achievements"] = achievements

    ranks = clean_marketplace_requirement_texts(raw.get("ranks", raw.get("rank", [])))
    if ranks:
        requirements["ranks"] = ranks

    units = clean_marketplace_requirement_texts(raw.get("units", raw.get("unit", [])))
    if units:
        requirements["units"] = units

    campaigns = clean_marketplace_requirement_ids(
        raw.get(
            "campaigns",
            raw.get("campaign_ids", raw.get("campaign_id", raw.get("campaign", []))),
        )
    )
    if campaigns:
        requirements["campaigns"] = campaigns

    return requirements


def clean_marketplace_item(value: Any, category_ids: set[str]) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    item_id = re.sub(r"[^a-z0-9_\-]+", "-", str(value.get("id", "")).strip().lower()).strip("-")[:80]
    category = re.sub(r"[^a-z0-9_]+", "_", str(value.get("category", "")).strip().lower()).strip("_")[:48]
    if not item_id or category not in category_ids:
        return None
    try:
        cost = int(value.get("cost", 0))
    except (TypeError, ValueError):
        cost = 0
    item = {
        "id": item_id,
        "category": category,
        "name": str(value.get("name", item_id.replace("-", " ").replace("_", " ").title())).strip()[:96],
        "description": str(value.get("description", "")).strip()[:700],
        "cost": max(0, min(1_000_000, cost)),
        "class_name": str(value.get("class_name", "")).strip()[:160],
        "image_url": str(value.get("image_url", "")).strip()[:300],
        "enabled": bool(value.get("enabled", True)),
        "visible": bool(value.get("visible", True)),
        "one_time": bool(value.get("one_time", True)),
        "tags": [str(tag).strip()[:32] for tag in value.get("tags", [])[:8] if str(tag).strip()]
        if isinstance(value.get("tags", []), list)
        else [],
    }
    requirements = clean_marketplace_requirements(value.get("requirements", {}))
    if requirements:
        item["requirements"] = requirements
    return item


def clean_marketplace_payload(value: Any) -> dict[str, Any]:
    raw = value if isinstance(value, dict) else {}
    categories = [
        category
        for category in (clean_marketplace_category(item) for item in raw.get("categories", MARKETPLACE_CATEGORIES))
        if category is not None
    ]
    if not categories:
        categories = [dict(category) for category in MARKETPLACE_CATEGORIES]
    category_ids = marketplace_category_ids(categories)
    items = [
        item
        for item in (clean_marketplace_item(raw_item, category_ids) for raw_item in raw.get("items", []))
        if item is not None and bool(item.get("visible", True))
    ]
    items.sort(key=lambda item: (str(item.get("category", "")), int(item.get("cost", 0)), str(item.get("name", ""))))
    return {"categories": categories, "items": items}


def marketplace_active_item_count(items: list[dict[str, Any]]) -> int:
    return sum(1 for item in items if bool(item.get("enabled", True)) and bool(item.get("visible", True)))


def load_marketplace_catalog() -> dict[str, Any]:
    if not MARKETPLACE_PATH.exists():
        return clean_marketplace_payload(DEFAULT_MARKETPLACE)
    try:
        parsed = json.loads(MARKETPLACE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return clean_marketplace_payload(DEFAULT_MARKETPLACE)
    return clean_marketplace_payload(parsed)


def marketplace_item_by_id(item_id: str) -> dict[str, Any] | None:
    cleaned = re.sub(r"[^a-z0-9_\-]+", "-", str(item_id).strip().lower()).strip("-")[:80]
    for item in load_marketplace_catalog()["items"]:
        if item["id"] == cleaned:
            return item
    return None


def public_file_url(root: Path, path: Path, base_url: str) -> str:
    try:
        relative_path = path.relative_to(root).as_posix()
    except ValueError:
        return ""
    return base_url + "/" + urllib.parse.quote(relative_path, safe="/-_.~")


def display_title_from_filename(path: Path) -> str:
    title = re.sub(r"[_\-]+", " ", path.stem).strip()
    return re.sub(r"\s+", " ", title).title()[:90] or path.stem[:90]


def clean_avatar_id(value: Any) -> str:
    cleaned = re.sub(r"[^a-z0-9_\-/]+", "-", str(value or "").strip().lower()).strip("-/")
    return cleaned[:80] or DEFAULT_AVATAR_ID


def avatar_entry(path: Path) -> dict[str, Any] | None:
    if path.suffix.lower() not in AVATAR_EXTENSIONS:
        return None
    try:
        stat = path.stat()
        relative_path = path.relative_to(AVATAR_ROOT)
    except (OSError, ValueError):
        return None
    avatar_id = clean_avatar_id(relative_path.with_suffix("").as_posix())
    url = public_file_url(AVATAR_ROOT, path, AVATAR_BASE_URL)
    if not url:
        return None
    return {
        "id": avatar_id,
        "name": display_title_from_filename(path),
        "url": url,
        "path": relative_path.as_posix(),
        "filename": path.name[:180],
        "size_bytes": stat.st_size,
        "updated_at": int(stat.st_mtime),
    }


def avatar_catalog() -> list[dict[str, Any]]:
    catalog: list[dict[str, Any]] = [
        {
            "id": DEFAULT_AVATAR_ID,
            "name": DEFAULT_AVATAR_NAME,
            "url": DEFAULT_AVATAR_URL,
            "path": "",
            "filename": "",
            "size_bytes": 0,
            "updated_at": 0,
        }
    ]
    seen = {DEFAULT_AVATAR_ID}
    if AVATAR_ROOT.exists() and AVATAR_ROOT.is_dir():
        for path in sorted(AVATAR_ROOT.rglob("*"), key=lambda item: item.as_posix().lower()):
            if not path.is_file():
                continue
            entry = avatar_entry(path)
            if entry is not None and entry["id"] not in seen:
                seen.add(entry["id"])
                catalog.append(entry)
    return catalog


def avatar_by_id(avatar_id: Any) -> dict[str, Any]:
    cleaned = clean_avatar_id(avatar_id)
    for entry in avatar_catalog():
        if entry["id"] == cleaned:
            return entry
    return avatar_catalog()[0]


def avatar_id_is_available(avatar_id: Any) -> bool:
    cleaned = clean_avatar_id(avatar_id)
    return any(entry["id"] == cleaned for entry in avatar_catalog())


def audio_track_entry(category: str, path: Path) -> dict[str, Any] | None:
    if path.suffix.lower() not in AUDIO_EXTENSIONS:
        return None
    try:
        stat = path.stat()
    except OSError:
        return None
    url = public_file_url(AUDIO_ROOT, path, AUDIO_BASE_URL)
    if not url:
        return None
    return {
        "id": re.sub(r"[^a-z0-9]+", "-", path.stem.lower()).strip("-")[:80] or path.stem[:80],
        "category": category,
        "title": display_title_from_filename(path),
        "filename": path.name[:180],
        "url": url,
        "size_bytes": stat.st_size,
        "updated_at": int(stat.st_mtime),
    }


def load_audio_manifest() -> dict[str, Any]:
    categories: dict[str, dict[str, Any]] = {}
    for category, metadata in AUDIO_CATEGORIES.items():
        directory = AUDIO_ROOT / str(metadata["directory"])
        tracks: list[dict[str, Any]] = []
        if directory.exists() and directory.is_dir():
            for path in sorted(directory.iterdir(), key=lambda item: item.name.lower()):
                if path.is_file():
                    track = audio_track_entry(category, path)
                    if track is not None:
                        tracks.append(track)
        categories[category] = {
            "label": metadata["label"],
            "description": metadata["description"],
            "tracks": tracks,
        }
    return {"updated_at": now(), "categories": categories}


def clean_theme_id(value: Any) -> str:
    return re.sub(r"[^a-z0-9_-]+", "-", str(value or "").lower()).strip("-")[:64]


def clean_theme_manifest(value: Any, theme_dir: Path) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    theme_id = clean_theme_id(value.get("id", theme_dir.name))
    if not theme_id:
        return None
    background_files = value.get("backgrounds", [])
    if not isinstance(background_files, list):
        background_files = []
    backgrounds: list[str] = []
    for background in background_files[:24]:
        relative = Path(str(background).replace("\\", "/"))
        if relative.is_absolute() or ".." in relative.parts:
            continue
        candidate = theme_dir / relative
        if candidate.exists() and candidate.is_file():
            backgrounds.append(public_file_url(THEME_ROOT, candidate, THEME_BASE_URL))
    logo_url = ""
    logo_value = str(value.get("logo", "")).replace("\\", "/")
    if logo_value:
        relative_logo = Path(logo_value)
        if not relative_logo.is_absolute() and ".." not in relative_logo.parts:
            candidate_logo = theme_dir / relative_logo
            if candidate_logo.exists() and candidate_logo.is_file():
                logo_url = public_file_url(THEME_ROOT, candidate_logo, THEME_BASE_URL)
    return {
        "id": theme_id,
        "name": str(value.get("name", theme_id.replace("_", " ").title())).strip()[:80],
        "description": str(value.get("description", "")).strip()[:240],
        "accent_color": clean_hex_color(value.get("accent_color"), ""),
        "panel_color": clean_hex_color(value.get("panel_color"), ""),
        "text_color": clean_hex_color(value.get("text_color"), ""),
        "logo_url": logo_url,
        "backgrounds": backgrounds,
        "active": bool(value.get("active", True)),
        "built_in": False,
    }


def load_theme_manifest(include_inactive: bool = False) -> dict[str, Any]:
    themes = [dict(theme) for theme in DEFAULT_THEMES]
    if THEME_ROOT.exists() and THEME_ROOT.is_dir():
        for theme_dir in sorted(THEME_ROOT.iterdir(), key=lambda item: item.name.lower()):
            if not theme_dir.is_dir():
                continue
            manifest_path = theme_dir / "theme.json"
            if not manifest_path.exists():
                continue
            try:
                parsed = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            theme = clean_theme_manifest(parsed, theme_dir)
            if theme is not None and (include_inactive or bool(theme.get("active", True))):
                existing_index = next((index for index, item in enumerate(themes) if item.get("id") == theme.get("id")), -1)
                if existing_index >= 0:
                    merged = dict(themes[existing_index])
                    merged.update(theme)
                    merged["built_in"] = bool(themes[existing_index].get("built_in", False))
                    themes[existing_index] = merged
                else:
                    themes.append(theme)
    return {"updated_at": now(), "themes": themes}


def safe_asset_filename(value: Any, allowed_extensions: set[str]) -> str:
    raw_name = str(value or "").replace("\\", "/").rsplit("/", 1)[-1].strip()
    if not raw_name:
        raise ValueError("File name is required")
    path = Path(raw_name)
    extension = path.suffix.lower()
    if extension not in allowed_extensions:
        allowed = ", ".join(sorted(allowed_extensions))
        raise ValueError(f"Unsupported file type. Allowed: {allowed}")
    stem = re.sub(r"[^A-Za-z0-9._ -]+", "-", path.stem).strip(" .-_")
    stem = re.sub(r"\s+", " ", stem)[:80]
    if not stem:
        stem = "asset"
    return stem + extension


def safe_theme_directory_id(value: Any) -> str:
    theme_id = clean_theme_id(value)
    if not theme_id:
        raise ValueError("Theme id is required")
    return theme_id


def clean_theme_upload_asset_type(asset_type_value: Any, relative_path_value: Any, filename: Any) -> str:
    asset_type = str(asset_type_value or "").strip().lower()
    if asset_type:
        if asset_type not in THEME_ASSET_TYPES:
            raise ValueError("Theme asset type must be background or logo")
        return asset_type
    path_hint = str(relative_path_value or filename or "").replace("\\", "/").lower()
    return "logo" if re.search(r"(^|[/._ -])(logos?|marks?|icons?)([/._ -]|$)", path_hint) else "background"


def safe_theme_asset_relative_path(
    theme_id: str,
    asset_type: str,
    filename: Any,
    relative_path_value: Any = "",
) -> Path:
    safe_name = safe_asset_filename(filename, THEME_IMAGE_EXTENSIONS)
    raw_path = str(relative_path_value or filename or "").replace("\\", "/").strip().strip("/")
    raw_parts = [part for part in raw_path.split("/") if part and part not in {".", ".."}]
    if not raw_parts:
        raw_parts = [safe_name]

    known_asset_roots = {"background", "backgrounds", "logo", "logos", "mark", "marks", "icon", "icons"}
    first = raw_parts[0].strip().lower()
    if len(raw_parts) > 1 and first not in known_asset_roots:
        raw_parts = raw_parts[1:]

    leaf_name = safe_asset_filename(raw_parts[-1] if raw_parts else safe_name, THEME_IMAGE_EXTENSIONS)
    cleaned_dirs: list[str] = []
    for segment in raw_parts[:-1]:
        cleaned = re.sub(r"[^A-Za-z0-9._ -]+", "-", segment).strip(" .-_")
        cleaned = re.sub(r"\s+", "-", cleaned)[:48]
        if cleaned:
            cleaned_dirs.append(cleaned)

    if asset_type == "logo":
        if not cleaned_dirs or cleaned_dirs[0].lower() not in {"logo", "logos", "mark", "marks", "icon", "icons"}:
            cleaned_dirs.insert(0, "logos")
    else:
        if not cleaned_dirs or cleaned_dirs[0].lower() not in {"background", "backgrounds"}:
            cleaned_dirs.insert(0, "backgrounds")

    relative_path = Path(*cleaned_dirs, leaf_name)
    if relative_path.is_absolute() or ".." in relative_path.parts:
        raise ValueError("Invalid theme asset path")
    return relative_path


def decode_asset_upload(value: Any) -> bytes:
    data_text = str(value or "").strip()
    if "," in data_text and data_text.lower().startswith("data:"):
        data_text = data_text.split(",", 1)[1]
    if not data_text:
        raise ValueError("File data is required")
    try:
        data = base64.b64decode(data_text, validate=True)
    except (ValueError, TypeError) as exc:
        raise ValueError("File data must be base64 encoded") from exc
    if not data:
        raise ValueError("Uploaded file is empty")
    if len(data) > COMMUNITY_MANAGER_MAX_FILE_BYTES:
        raise ValueError("Uploaded file is too large")
    return data


def relative_public_path(root: Path, path: Path) -> str:
    return path.relative_to(root).as_posix()


def resolve_public_child(root: Path, relative_path: Any) -> Path:
    relative = Path(str(relative_path or "").replace("\\", "/"))
    if relative.is_absolute() or ".." in relative.parts or not relative.parts:
        raise ValueError("Invalid asset path")
    candidate = (root / relative).resolve()
    root_resolved = root.resolve()
    try:
        candidate.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError("Invalid asset path") from exc
    return candidate


def asset_bin_manifest_path() -> Path:
    return ASSET_BIN_ROOT / "manifest.json"


def load_asset_bin_manifest() -> list[dict[str, Any]]:
    manifest_path = asset_bin_manifest_path()
    if not manifest_path.exists():
        return []
    try:
        parsed = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    items = parsed.get("items", []) if isinstance(parsed, dict) else []
    if not isinstance(items, list):
        return []
    cleaned: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        bin_path = str(item.get("bin_path", "")).replace("\\", "/")
        if not bin_path:
            continue
        try:
            resolve_public_child(ASSET_BIN_ROOT, bin_path)
        except ValueError:
            continue
        cleaned.append(item)
    return cleaned


def save_asset_bin_manifest(items: list[dict[str, Any]]) -> None:
    ASSET_BIN_ROOT.mkdir(parents=True, exist_ok=True)
    payload = {"updated_at": now(), "items": items}
    asset_bin_manifest_path().write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def unique_private_bin_path(relative_path: Path) -> Path:
    candidate = ASSET_BIN_ROOT / relative_path
    if not candidate.exists():
        return candidate
    stem = candidate.stem
    suffix = candidate.suffix
    parent = candidate.parent
    for index in range(1, 1000):
        numbered = parent / f"{stem}-{index}{suffix}"
        if not numbered.exists():
            return numbered
    raise ValueError("Could not create a unique bin file path")


def move_asset_to_private_bin(kind: str, group: str, source_path: Path, original_path: str) -> dict[str, Any] | None:
    if not source_path.exists() or not source_path.is_file():
        return None
    timestamp = now()
    deletion_day = time.strftime("%Y-%m-%d", time.gmtime(timestamp))
    safe_group = clean_theme_id(group) or "misc"
    original_relative = Path(str(original_path).replace("\\", "/"))
    safe_parts = [re.sub(r"[^A-Za-z0-9._ -]+", "-", part).strip(" .-_") or "asset" for part in original_relative.parts]
    target_relative = Path(kind) / safe_group / deletion_day / Path(*safe_parts)
    target_path = unique_private_bin_path(target_relative)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(source_path), str(target_path))
    try:
        size_bytes = target_path.stat().st_size
    except OSError:
        size_bytes = 0
    bin_path = relative_public_path(ASSET_BIN_ROOT, target_path)
    entry = {
        "id": secrets.token_urlsafe(10),
        "kind": kind,
        "group": safe_group,
        "filename": target_path.name,
        "original_path": str(original_path).replace("\\", "/"),
        "bin_path": bin_path,
        "github_archive_path": f"backend_asset_archive/community_assets/{bin_path}",
        "size_bytes": size_bytes,
        "deleted_at": timestamp,
        "expires_at": timestamp + ASSET_BIN_RETENTION_SECONDS,
    }
    items = load_asset_bin_manifest()
    items.append(entry)
    save_asset_bin_manifest(items)
    return entry


def load_asset_bin_inventory() -> dict[str, Any]:
    items: list[dict[str, Any]] = []
    for item in load_asset_bin_manifest():
        try:
            path = resolve_public_child(ASSET_BIN_ROOT, item.get("bin_path"))
        except ValueError:
            continue
        if not path.exists() or not path.is_file():
            continue
        copy = dict(item)
        copy["days_until_cleanup"] = max(0, math.ceil((int(copy.get("expires_at", 0)) - now()) / 86400))
        items.append(copy)
    return {
        "retention_seconds": ASSET_BIN_RETENTION_SECONDS,
        "items": sorted(items, key=lambda value: int(value.get("deleted_at", 0)), reverse=True),
    }


def load_theme_json(theme_dir: Path, theme_id: str, name: str = "") -> dict[str, Any]:
    manifest_path = theme_dir / "theme.json"
    parsed: dict[str, Any] = {}
    if manifest_path.exists():
        try:
            loaded = json.loads(manifest_path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                parsed = loaded
        except (OSError, json.JSONDecodeError):
            parsed = {}
    parsed["id"] = theme_id
    parsed["name"] = str(name or parsed.get("name") or theme_id.replace("-", " ").replace("_", " ").title()).strip()[:80]
    parsed["description"] = str(parsed.get("description", "")).strip()[:240]
    parsed["accent_color"] = clean_hex_color(parsed.get("accent_color"), "")
    parsed["panel_color"] = clean_hex_color(parsed.get("panel_color"), "")
    parsed["text_color"] = clean_hex_color(parsed.get("text_color"), "")
    parsed["active"] = bool(parsed.get("active", True))
    backgrounds = parsed.get("backgrounds", [])
    parsed["backgrounds"] = backgrounds if isinstance(backgrounds, list) else []
    return parsed


def write_theme_json(theme_dir: Path, manifest: dict[str, Any]) -> None:
    theme_dir.mkdir(parents=True, exist_ok=True)
    (theme_dir / "theme.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def save_audio_upload(category: Any, filename: Any, data: bytes) -> dict[str, Any]:
    category_key = str(category or "")
    metadata = AUDIO_CATEGORIES.get(category_key)
    if not metadata:
        raise ValueError("Unknown audio category")
    safe_name = safe_asset_filename(filename, AUDIO_EXTENSIONS)
    target_dir = AUDIO_ROOT / str(metadata["directory"])
    target_dir.mkdir(parents=True, exist_ok=True)
    target_path = target_dir / safe_name
    target_path.write_bytes(data)
    track = audio_track_entry(category_key, target_path)
    if track is None:
        raise ValueError("Could not save audio file")
    return track


def save_avatar_upload(filename: Any, data: bytes) -> dict[str, Any]:
    safe_name = safe_asset_filename(filename, AVATAR_EXTENSIONS)
    AVATAR_ROOT.mkdir(parents=True, exist_ok=True)
    target_path = AVATAR_ROOT / safe_name
    target_path.write_bytes(data)
    avatar = avatar_entry(target_path)
    if avatar is None:
        raise ValueError("Could not save profile picture")
    return avatar


def save_theme_upload(
    theme_id_value: Any,
    theme_name: Any,
    asset_type_value: Any,
    filename: Any,
    data: bytes,
    relative_path_value: Any = "",
) -> dict[str, Any]:
    theme_id = safe_theme_directory_id(theme_id_value)
    asset_type = clean_theme_upload_asset_type(asset_type_value, relative_path_value, filename)
    theme_dir = THEME_ROOT / theme_id
    relative_path = safe_theme_asset_relative_path(theme_id, asset_type, filename, relative_path_value)
    target_path = theme_dir / relative_path
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_bytes(data)

    manifest = load_theme_json(theme_dir, theme_id, str(theme_name or ""))
    relative_text = relative_path.as_posix()
    if asset_type == "logo":
        manifest["logo"] = relative_text
    else:
        backgrounds = [str(item) for item in manifest.get("backgrounds", []) if str(item).strip()]
        if relative_text not in backgrounds:
            backgrounds.append(relative_text)
        manifest["backgrounds"] = backgrounds[:24]
    write_theme_json(theme_dir, manifest)
    theme = clean_theme_manifest(manifest, theme_dir)
    if theme is None:
        raise ValueError("Could not save theme asset")
    return theme


def save_theme_metadata(payload: dict[str, Any]) -> dict[str, Any]:
    theme_id = safe_theme_directory_id(payload.get("theme_id") or payload.get("id"))
    theme_dir = THEME_ROOT / theme_id
    manifest = load_theme_json(theme_dir, theme_id, str(payload.get("theme_name") or payload.get("name") or ""))
    if "name" in payload or "theme_name" in payload:
        manifest["name"] = str(payload.get("theme_name") or payload.get("name") or manifest["name"]).strip()[:80]
    if "description" in payload:
        manifest["description"] = str(payload.get("description") or "").strip()[:240]
    for key in ("accent_color", "panel_color", "text_color"):
        if key in payload:
            manifest[key] = clean_hex_color(payload.get(key), "")
    if "active" in payload:
        manifest["active"] = bool(payload.get("active"))
    write_theme_json(theme_dir, manifest)
    theme = clean_theme_manifest(manifest, theme_dir)
    if theme is None:
        raise ValueError("Could not save theme metadata")
    return theme


def delete_audio_asset(category: Any, filename: Any) -> dict[str, Any] | None:
    category_key = str(category or "")
    metadata = AUDIO_CATEGORIES.get(category_key)
    if not metadata:
        raise ValueError("Unknown audio category")
    safe_name = safe_asset_filename(filename, AUDIO_EXTENSIONS)
    path = AUDIO_ROOT / str(metadata["directory"]) / safe_name
    return move_asset_to_private_bin("audio", category_key, path, safe_name)


def delete_theme_asset(theme_id_value: Any, relative_path_value: Any) -> dict[str, Any] | None:
    theme_id = safe_theme_directory_id(theme_id_value)
    theme_dir = THEME_ROOT / theme_id
    target_path = resolve_public_child(theme_dir, relative_path_value)
    relative_text = relative_public_path(theme_dir, target_path)
    public_url = public_file_url(THEME_ROOT, target_path, THEME_BASE_URL)
    binned = move_asset_to_private_bin("images", theme_id, target_path, relative_text)
    manifest = load_theme_json(theme_dir, theme_id)
    if str(manifest.get("logo", "")) == relative_text:
        manifest["logo"] = ""
    if str(manifest.get("logo_url", "")) in {relative_text, public_url}:
        manifest["logo_url"] = ""
    manifest["backgrounds"] = [
        str(item) for item in manifest.get("backgrounds", [])
        if str(item).replace("\\", "/") != relative_text
    ]
    write_theme_json(theme_dir, manifest)
    return binned


def delete_avatar_asset(avatar_id_value: Any = "", relative_path_value: Any = "") -> dict[str, Any] | None:
    relative_text = str(relative_path_value or "").replace("\\", "/").strip()
    avatar_id = clean_avatar_id(avatar_id_value)
    if relative_text:
        target_path = resolve_public_child(AVATAR_ROOT, relative_text)
        avatar_id = clean_avatar_id(Path(relative_text).with_suffix("").as_posix())
    else:
        if avatar_id == DEFAULT_AVATAR_ID:
            raise ValueError("Default profile picture cannot be deleted")
        avatar = next(
            (entry for entry in avatar_catalog() if entry.get("id") == avatar_id and entry.get("id") != DEFAULT_AVATAR_ID),
            None,
        )
        if avatar is None:
            raise ValueError("Profile picture was not found")
        relative_text = str(avatar.get("path", ""))
        target_path = resolve_public_child(AVATAR_ROOT, relative_text)
    if avatar_id == DEFAULT_AVATAR_ID:
        raise ValueError("Default profile picture cannot be deleted")
    return move_asset_to_private_bin("images", "avatars", target_path, relative_text)


def load_community_asset_inventory(role: str = "community_manager") -> dict[str, Any]:
    themes: list[dict[str, Any]] = []
    if THEME_ROOT.exists() and THEME_ROOT.is_dir():
        for theme_dir in sorted(THEME_ROOT.iterdir(), key=lambda item: item.name.lower()):
            if not theme_dir.is_dir():
                continue
            manifest_path = theme_dir / "theme.json"
            if not manifest_path.exists():
                continue
            try:
                parsed = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            theme = clean_theme_manifest(parsed, theme_dir)
            if theme is None:
                continue
            logo_path = str(parsed.get("logo", "")).replace("\\", "/")
            backgrounds = parsed.get("backgrounds", [])
            theme["logo"] = {
                "path": logo_path,
                "url": theme.get("logo_url", ""),
                "filename": Path(logo_path).name if logo_path else "",
            } if logo_path else None
            theme["background_assets"] = []
            if isinstance(backgrounds, list):
                for background in backgrounds:
                    relative = str(background).replace("\\", "/")
                    try:
                        candidate = resolve_public_child(theme_dir, relative)
                    except ValueError:
                        continue
                    if candidate.exists() and candidate.is_file():
                        theme["background_assets"].append(
                            {
                                "path": relative,
                                "filename": candidate.name,
                                "url": public_file_url(THEME_ROOT, candidate, THEME_BASE_URL),
                            }
                        )
            themes.append(theme)
    return {
        "updated_at": now(),
        "audio": load_audio_manifest()["categories"],
        "themes": themes,
        "avatars": avatar_catalog(),
        "events": load_event_banners(include_inactive=True),
        "event_options": {
            "effects": sorted(EVENT_EFFECTS),
            "popup_styles": sorted(EVENT_POPUP_STYLES),
            "fonts": sorted(EVENT_FONTS),
            "placements": sorted(EVENT_PLACEMENTS),
            "sizes": sorted(EVENT_SIZES),
        },
        "server_controls": load_server_controls(),
        "server_catalog": load_server_catalog(include_hidden=True),
        "bin": load_asset_bin_inventory(),
        "built_in_themes": DEFAULT_THEMES,
        "authority": authority_scope_for_role(role),
        "limits": {
            "max_file_bytes": COMMUNITY_MANAGER_MAX_FILE_BYTES,
            "audio_extensions": sorted(AUDIO_EXTENSIONS),
            "theme_image_extensions": sorted(THEME_IMAGE_EXTENSIONS),
            "avatar_extensions": sorted(AVATAR_EXTENSIONS),
        },
    }


def version_parts(value: Any) -> list[int]:
    return [int(part) for part in re.findall(r"\d+", str(value or ""))]


def is_newer_version(latest: Any, current: Any) -> bool:
    latest_parts = version_parts(latest)
    current_parts = version_parts(current)
    length = max(len(latest_parts), len(current_parts))
    latest_parts.extend([0] * (length - len(latest_parts)))
    current_parts.extend([0] * (length - len(current_parts)))
    return latest_parts > current_parts


def clean_sha256(value: Any) -> str:
    digest = str(value or "").strip()
    if not digest:
        return ""
    if re.fullmatch(r"[A-Fa-f0-9]{64}", digest):
        return digest.upper()
    return ""


def clean_release_manifest(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return dict(DEFAULT_RELEASE)
    manifest = dict(DEFAULT_RELEASE)
    manifest.update(
        {
            "version": str(value.get("version", manifest["version"])).strip()[:40] or manifest["version"],
            "channel": str(value.get("channel", manifest["channel"])).strip()[:24] or manifest["channel"],
            "title": str(value.get("title", manifest["title"])).strip()[:80] or manifest["title"],
            "summary": str(value.get("summary", manifest["summary"])).strip()[:500],
            "mandatory": bool(value.get("mandatory", manifest["mandatory"])),
            "download_url": str(value.get("download_url", manifest["download_url"])).strip()[:500],
            "installer_url": str(value.get("installer_url", manifest["installer_url"])).strip()[:500],
            "sha256": clean_sha256(value.get("sha256", manifest["sha256"])),
            "published_at": str(value.get("published_at", manifest["published_at"])).strip()[:40],
        }
    )
    notes = value.get("notes", manifest["notes"])
    if isinstance(notes, list):
        manifest["notes"] = [str(note).strip()[:240] for note in notes[:12] if str(note).strip()]
    downloads = value.get("downloads", manifest["downloads"])
    if isinstance(downloads, dict):
        cleaned_downloads: dict[str, dict[str, str]] = {}
        for platform, data in downloads.items():
            if not isinstance(data, dict):
                continue
            cleaned_downloads[str(platform).lower()[:32]] = {
                "url": str(data.get("url", "")).strip()[:500],
                "installer_url": str(data.get("installer_url", "")).strip()[:500],
                "sha256": clean_sha256(data.get("sha256", "")),
            }
        manifest["downloads"] = cleaned_downloads
    return manifest


def apply_release_platform(manifest: dict[str, Any], platform: str = "windows") -> dict[str, Any]:
    platform_key = str(platform or "windows").strip().lower()[:32]
    downloads = manifest.get("downloads", {})
    if not isinstance(downloads, dict):
        return manifest
    platform_download = downloads.get(platform_key)
    if not isinstance(platform_download, dict):
        return manifest
    platform_url = str(platform_download.get("url", "")).strip()[:500]
    platform_installer_url = str(platform_download.get("installer_url", "") or platform_url).strip()[:500]
    platform_sha256 = clean_sha256(platform_download.get("sha256", ""))
    if platform_url:
        manifest["download_url"] = platform_url
    if platform_installer_url:
        manifest["installer_url"] = platform_installer_url
    if platform_sha256:
        manifest["sha256"] = platform_sha256
    return manifest


def load_release_manifest(current_version: str = "", platform: str = "windows") -> dict[str, Any]:
    if not RELEASE_PATH.exists():
        manifest = dict(DEFAULT_RELEASE)
    else:
        try:
            parsed = json.loads(RELEASE_PATH.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            parsed = DEFAULT_RELEASE
        manifest = clean_release_manifest(parsed)
    manifest = apply_release_platform(manifest, platform)
    manifest["update_available"] = is_newer_version(manifest.get("version", ""), current_version)
    manifest["checked_at"] = now()
    return manifest


def normalize_server_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


BATTLEMETRICS_CACHE_SECONDS = 60
BATTLEMETRICS_CACHE_LOCK = threading.Lock()
BATTLEMETRICS_CACHE_EXPIRES = 0.0
BATTLEMETRICS_BY_NAME: dict[str, dict[str, Any]] = {}
BATTLEMETRICS_BY_ADDRESS: dict[tuple[str, int], dict[str, Any]] = {}


def battlemetrics_request(search: str, timeout: int = 8) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode(
        {
            "filter[game]": "arma3",
            "filter[search]": search,
            "page[size]": "100",
        }
    )
    request = urllib.request.Request(
        f"https://api.battlemetrics.com/servers?{query}",
        headers={"User-Agent": "TCWLauncher/1.0"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))
    data = payload.get("data", []) if isinstance(payload, dict) else []
    return data if isinstance(data, list) else []


def refresh_battlemetrics_cache(force: bool = False) -> None:
    global BATTLEMETRICS_CACHE_EXPIRES, BATTLEMETRICS_BY_NAME, BATTLEMETRICS_BY_ADDRESS

    # BattleMetrics is a third-party dependency, so cache successful lookups and
    # briefly suppress retries after failures. This keeps the launcher responsive
    # and avoids hammering BattleMetrics when many users open the server browser.
    timestamp = time.time()
    with BATTLEMETRICS_CACHE_LOCK:
        if not force and timestamp < BATTLEMETRICS_CACHE_EXPIRES and BATTLEMETRICS_BY_NAME:
            return

        by_name: dict[str, dict[str, Any]] = {}
        by_address: dict[tuple[str, int], dict[str, Any]] = {}
        try:
            data = battlemetrics_request("TCW", timeout=10)
        except (OSError, urllib.error.URLError, json.JSONDecodeError, TimeoutError):
            BATTLEMETRICS_CACHE_EXPIRES = timestamp + 15
            return

        for item in data:
            if not isinstance(item, dict):
                continue
            attributes = item.get("attributes", {})
            if not isinstance(attributes, dict):
                continue
            name_key = normalize_server_name(str(attributes.get("name", "")))
            ip = str(attributes.get("ip", ""))
            port = int(attributes.get("port", 0) or 0)
            if name_key:
                by_name[name_key] = attributes
            if ip and port:
                by_address[(ip, port)] = attributes

        BATTLEMETRICS_BY_NAME = by_name
        BATTLEMETRICS_BY_ADDRESS = by_address
        BATTLEMETRICS_CACHE_EXPIRES = timestamp + BATTLEMETRICS_CACHE_SECONDS


def cached_battlemetrics_match(ip: str, port: int, normalized_name: str) -> dict[str, Any] | None:
    refresh_battlemetrics_cache()
    with BATTLEMETRICS_CACHE_LOCK:
        exact_address = BATTLEMETRICS_BY_ADDRESS.get((ip, port))
        if exact_address:
            return exact_address
        if normalized_name:
            exact_name = BATTLEMETRICS_BY_NAME.get(normalized_name)
            if exact_name:
                return exact_name
            # TCW server display names and game ports can drift slightly between
            # hosts/providers. Fuzzy name and near-port matching gives the UI a
            # useful status instead of showing "unknown" for a renamed server.
            for found_name, attributes in BATTLEMETRICS_BY_NAME.items():
                if normalized_name == found_name or normalized_name in found_name or found_name in normalized_name:
                    found_port = int(attributes.get("port", 0) or 0)
                    if found_port == port or abs(found_port - port) <= 10:
                        return attributes
        for (found_ip, found_port), attributes in BATTLEMETRICS_BY_ADDRESS.items():
            if found_ip == ip and abs(found_port - port) <= 10:
                return attributes
    return None


def battlemetrics_status(ip: str, port: int, name: str = "") -> dict[str, Any]:
    ip = ip.strip()
    if not ip or port <= 0 or port > 65535:
        return {"status": "unknown", "players": 0, "max_players": 0, "mission": "Unavailable"}

    name = name.strip()
    normalized_name = normalize_server_name(name)
    cached = cached_battlemetrics_match(ip, port, normalized_name)
    if cached:
        return format_battlemetrics_status(cached)

    searches = [f"{ip}:{port}"]
    if name:
        searches.append(name)
    searches.append(ip)
    fallback: dict[str, Any] = {}

    for search in searches:
        try:
            data = battlemetrics_request(search)
        except (OSError, urllib.error.URLError, json.JSONDecodeError, TimeoutError):
            continue

        for item in data:
            if not isinstance(item, dict):
                continue
            attributes = item.get("attributes", {})
            if not isinstance(attributes, dict):
                continue
            found_ip = str(attributes.get("ip", ""))
            found_port = int(attributes.get("port", 0) or 0)
            found_name = str(attributes.get("name", ""))
            normalized_found_name = normalize_server_name(found_name)
            if found_port == port:
                if found_ip == ip:
                    return format_battlemetrics_status(attributes)
                if normalized_name and (
                    normalized_name == normalized_found_name
                    or normalized_name in normalized_found_name
                    or normalized_found_name in normalized_name
                ):
                    return format_battlemetrics_status(attributes)
            if found_ip == ip and not fallback and abs(found_port - port) <= 10:
                fallback = attributes
            if normalized_name and not fallback and (
                normalized_name == normalized_found_name
                or normalized_name in normalized_found_name
                or normalized_found_name in normalized_name
            ):
                fallback = attributes

        if fallback:
            return format_battlemetrics_status(fallback)

    return {"status": "unknown", "players": 0, "max_players": 0, "mission": "Unavailable"}


def format_battlemetrics_status(attributes: dict[str, Any]) -> dict[str, Any]:
    details = attributes.get("details", {})
    if not isinstance(details, dict):
        details = {}
    mission = "Unavailable"
    for key in ["map", "mapName", "world", "worldName", "terrain", "mission", "missionName", "scenario"]:
        value = str(details.get(key, attributes.get(key, ""))).strip()
        if value and value.lower() not in ["unknown", "n/a", "none"]:
            mission = value.replace("_", " ")
            break

    return {
        "status": str(attributes.get("status", "unknown")).lower(),
        "players": int(attributes.get("players", 0) or 0),
        "max_players": int(attributes.get("maxPlayers", 0) or 0),
        "mission": mission,
    }


def load_server_keys() -> dict[str, str]:
    raw = os.getenv("TCW_SERVER_KEYS_JSON", "{}")
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    if not isinstance(parsed, dict):
        return {}
    return {str(key): str(value) for key, value in parsed.items() if str(value)}


SERVER_KEYS = load_server_keys()


def load_discord_bot_keys() -> dict[str, str]:
    raw = os.getenv("TCW_DISCORD_BOT_KEYS_JSON", "{}")
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    keys: dict[str, str] = {}
    if isinstance(parsed, dict):
        for key, value in parsed.items():
            if isinstance(value, dict):
                secret = str(value.get("secret", "")).strip()
            else:
                secret = str(value).strip()
            if str(key).strip() and secret:
                keys[str(key).strip()] = secret
    elif isinstance(parsed, list):
        for item in parsed:
            if not isinstance(item, dict):
                continue
            bot_id = str(item.get("id") or item.get("bot_id") or "").strip()
            secret = str(item.get("secret") or item.get("key") or "").strip()
            if bot_id and secret:
                keys[bot_id] = secret
    return keys


DISCORD_BOT_KEYS = load_discord_bot_keys()


@contextmanager
def connect_db():
    connection = sqlite3.connect(DATABASE_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA journal_mode = WAL")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def ensure_table_columns(db: sqlite3.Connection, table: str, columns: dict[str, str]) -> None:
    existing = {row["name"] for row in db.execute(f"PRAGMA table_info({table})").fetchall()}
    for column, definition in columns.items():
        if column not in existing:
            db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def write_json_file(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_name(f"{path.name}.tmp")
    temporary_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary_path.replace(path)


def write_player_profile_snapshot(db: sqlite3.Connection, steam_id: str) -> None:
    """Write readable per-player JSON mirrors for team inspection and future tools."""
    if not STEAM_ID_PATTERN.fullmatch(steam_id):
        return
    profile = profile_for(db, steam_id)
    if profile is None:
        return
    player_dir = PLAYER_DATA_ROOT / steam_id
    stats = {
        "steam_id": steam_id,
        "display_name": profile["display_name"],
        "level": profile["level"],
        "xp": profile["xp"],
        "credits": profile["credits"],
        "kills": profile["kills"],
        "deaths": profile["deaths"],
        "missions": profile["missions"],
        "playtime_seconds": profile["playtime_seconds"],
        "droid_kills": profile["droid_kills"],
        "vehicle_kills": profile["vehicle_kills"],
        "aircraft_kills": profile["aircraft_kills"],
        "friendly_kills": profile["friendly_kills"],
        "support_score": profile["support_score"],
        "revives": profile["revives"],
        "heals": profile["heals"],
        "repairs": profile["repairs"],
        "resupplies": profile["resupplies"],
        "transport_assists": profile["transport_assists"],
        "objective_support": profile["objective_support"],
        "kamino_visits": profile["kamino_visits"],
        "geonosis_missions": profile["geonosis_missions"],
        "friendly_fire_missions": profile["friendly_fire_missions"],
        "high_death_missions": profile["high_death_missions"],
        "perfect_missions": profile["perfect_missions"],
        "deployment_attempts": profile["deployment_attempts"],
        "deployments_completed": profile["deployments_completed"],
        "deployments_failed": profile["deployments_failed"],
        "deployment_xp_adjustments": profile["deployment_xp_adjustments"],
        "avatar_id": profile["avatar_id"],
        "avatar_url": profile["avatar_url"],
        "updated_at": profile["updated_at"],
    }
    write_json_file(player_dir / "profile.json", profile)
    write_json_file(player_dir / "stats.json", stats)
    write_json_file(
        player_dir / "achievements.json",
        {
            "steam_id": steam_id,
            "display_name": profile["display_name"],
            "achievements": profile["achievements"],
            "updated_at": profile["updated_at"],
        },
    )
    write_json_file(
        player_dir / "inventory.json",
        {
            "steam_id": steam_id,
            "display_name": profile["display_name"],
            "items": profile.get("inventory", []),
            "updated_at": profile["updated_at"],
        },
    )
    write_json_file(
        player_dir / "campaigns.json",
        {
            "steam_id": steam_id,
            "display_name": profile["display_name"],
            "campaigns": profile.get("campaigns", []),
            "updated_at": profile["updated_at"],
        },
    )
    write_json_file(
        player_dir / "quests.json",
        {
            "steam_id": steam_id,
            "display_name": profile["display_name"],
            "quests": profile.get("quests", []),
            "updated_at": profile["updated_at"],
        },
    )


def safe_write_player_profile_snapshot(db: sqlite3.Connection, steam_id: str) -> None:
    try:
        write_player_profile_snapshot(db, steam_id)
    except OSError as exc:
        print(f"Player profile snapshot failed for {steam_id}: {exc}")


def initialize_database() -> None:
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    PLAYER_DATA_ROOT.mkdir(parents=True, exist_ok=True)
    with connect_db() as db:
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                steam_id TEXT PRIMARY KEY,
                display_name TEXT NOT NULL DEFAULT 'Clone trooper',
                arma_profile_name TEXT,
                roster_name TEXT,
                unit TEXT,
                rank TEXT,
                rostered INTEGER NOT NULL DEFAULT 0,
                bio TEXT NOT NULL DEFAULT '',
                profile_public INTEGER NOT NULL DEFAULT 1,
                avatar_id TEXT NOT NULL DEFAULT 'tcw-standard',
                verified_at INTEGER,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS stats (
                steam_id TEXT PRIMARY KEY REFERENCES users(steam_id) ON DELETE CASCADE,
                kills INTEGER NOT NULL DEFAULT 0,
                deaths INTEGER NOT NULL DEFAULT 0,
                credits INTEGER NOT NULL DEFAULT 0,
                xp INTEGER NOT NULL DEFAULT 0,
                missions INTEGER NOT NULL DEFAULT 0,
                playtime_seconds INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS achievements (
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                achievement_id TEXT NOT NULL,
                unlocked_at INTEGER NOT NULL,
                PRIMARY KEY (steam_id, achievement_id)
            );

            CREATE TABLE IF NOT EXISTS device_codes (
                device_hash TEXT PRIMARY KEY,
                user_code TEXT NOT NULL UNIQUE,
                steam_id TEXT REFERENCES users(steam_id),
                status TEXT NOT NULL DEFAULT 'pending',
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                consumed_at INTEGER
            );

            CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY,
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                last_used_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS server_events (
                event_id TEXT PRIMARY KEY,
                official_server TEXT NOT NULL,
                steam_id TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                received_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS roster_members (
                external_id TEXT PRIMARY KEY,
                steam_id TEXT,
                discord_id TEXT,
                display_name TEXT NOT NULL,
                unit TEXT,
                rank TEXT,
                synced_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS marketplace_purchases (
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                item_id TEXT NOT NULL,
                category TEXT NOT NULL,
                class_name TEXT NOT NULL DEFAULT '',
                cost INTEGER NOT NULL,
                purchased_at INTEGER NOT NULL,
                PRIMARY KEY (steam_id, item_id)
            );

            CREATE TABLE IF NOT EXISTS republic_wage_grants (
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                week_id TEXT NOT NULL,
                credits INTEGER NOT NULL,
                granted_at INTEGER NOT NULL,
                PRIMARY KEY (steam_id, week_id)
            );

            CREATE TABLE IF NOT EXISTS campaign_deployments (
                deployment_id TEXT PRIMARY KEY,
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                campaign_id TEXT NOT NULL,
                campaign_name TEXT NOT NULL,
                mission_name TEXT NOT NULL,
                planet TEXT NOT NULL DEFAULT '',
                official_server TEXT NOT NULL DEFAULT '',
                completed_at INTEGER NOT NULL,
                outcome TEXT NOT NULL DEFAULT 'completed',
                started_at INTEGER NOT NULL DEFAULT 0,
                ended_at INTEGER NOT NULL DEFAULT 0,
                xp_earned INTEGER NOT NULL DEFAULT 0,
                xp_penalty INTEGER NOT NULL DEFAULT 0,
                awards_json TEXT NOT NULL DEFAULT '[]'
            );

            CREATE TABLE IF NOT EXISTS quest_progress (
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                quest_id TEXT NOT NULL,
                title TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'Main',
                state TEXT NOT NULL DEFAULT 'ASSIGNED',
                stage_index INTEGER NOT NULL DEFAULT 0,
                stage_title TEXT NOT NULL DEFAULT '',
                stage_description TEXT NOT NULL DEFAULT '',
                lore_json TEXT NOT NULL DEFAULT '[]',
                history_json TEXT NOT NULL DEFAULT '[]',
                official_server TEXT NOT NULL DEFAULT '',
                started_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                completed_at INTEGER,
                PRIMARY KEY (steam_id, quest_id)
            );

            CREATE TABLE IF NOT EXISTS roster_link_requests (
                request_id TEXT PRIMARY KEY,
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                display_name TEXT NOT NULL DEFAULT '',
                requested_roster_name TEXT NOT NULL DEFAULT '',
                requested_unit TEXT NOT NULL DEFAULT '',
                requested_rank TEXT NOT NULL DEFAULT '',
                message TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'pending',
                reviewer TEXT NOT NULL DEFAULT '',
                decision_note TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                decided_at INTEGER
            );

            CREATE TABLE IF NOT EXISTS discord_link_codes (
                code_hash TEXT PRIMARY KEY,
                link_id TEXT NOT NULL UNIQUE,
                discord_id TEXT NOT NULL,
                guild_id TEXT NOT NULL DEFAULT '',
                discord_username TEXT NOT NULL DEFAULT '',
                nickname TEXT NOT NULL DEFAULT '',
                roles_json TEXT NOT NULL DEFAULT '[]',
                status TEXT NOT NULL DEFAULT 'pending',
                steam_id TEXT NOT NULL DEFAULT '',
                created_by_bot_id TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                claimed_at INTEGER,
                updated_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS discord_links (
                discord_id TEXT PRIMARY KEY,
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                guild_id TEXT NOT NULL DEFAULT '',
                discord_username TEXT NOT NULL DEFAULT '',
                nickname TEXT NOT NULL DEFAULT '',
                roles_json TEXT NOT NULL DEFAULT '[]',
                status TEXT NOT NULL DEFAULT 'linked',
                source TEXT NOT NULL DEFAULT 'bot',
                linked_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS bot_audit_log (
                audit_id TEXT PRIMARY KEY,
                bot_id TEXT NOT NULL,
                action TEXT NOT NULL,
                target TEXT NOT NULL DEFAULT '',
                details_json TEXT NOT NULL DEFAULT '{}',
                created_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS community_reactions (
                target_type TEXT NOT NULL,
                target_id TEXT NOT NULL,
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                reaction TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                PRIMARY KEY (target_type, target_id, steam_id, reaction)
            );

            CREATE TABLE IF NOT EXISTS admin_audit_log (
                audit_id TEXT PRIMARY KEY,
                actor_role TEXT NOT NULL,
                action TEXT NOT NULL,
                target TEXT NOT NULL DEFAULT '',
                details_json TEXT NOT NULL DEFAULT '{}',
                created_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS schema_migrations (
                migration_id TEXT PRIMARY KEY,
                applied_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS comlink_sessions (
                session_id TEXT PRIMARY KEY,
                steam_id TEXT NOT NULL REFERENCES users(steam_id) ON DELETE CASCADE,
                server_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                livekit_room TEXT NOT NULL,
                livekit_identity TEXT NOT NULL,
                client_nonce TEXT NOT NULL DEFAULT '',
                client_kind TEXT NOT NULL DEFAULT 'launcher',
                client_report_token_hash TEXT NOT NULL DEFAULT '',
                issued_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                ended_at INTEGER,
                last_status TEXT NOT NULL DEFAULT 'issued'
            );

            CREATE TABLE IF NOT EXISTS comlink_audit_log (
                audit_id TEXT PRIMARY KEY,
                actor_role TEXT NOT NULL,
                action TEXT NOT NULL,
                steam_id TEXT NOT NULL DEFAULT '',
                server_id TEXT NOT NULL DEFAULT '',
                channel_id TEXT NOT NULL DEFAULT '',
                details_json TEXT NOT NULL DEFAULT '{}',
                created_at INTEGER NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_sessions_steam_id ON sessions(steam_id);
            CREATE INDEX IF NOT EXISTS idx_device_codes_expiry ON device_codes(expires_at);
            CREATE INDEX IF NOT EXISTS idx_republic_wage_grants_week ON republic_wage_grants(week_id, granted_at DESC);
            CREATE INDEX IF NOT EXISTS idx_campaign_deployments_steam_id ON campaign_deployments(steam_id, completed_at DESC);
            CREATE INDEX IF NOT EXISTS idx_quest_progress_steam_id ON quest_progress(steam_id, updated_at DESC);
            CREATE INDEX IF NOT EXISTS idx_roster_link_requests_status ON roster_link_requests(status, updated_at DESC);
            CREATE INDEX IF NOT EXISTS idx_discord_link_codes_link_id ON discord_link_codes(link_id);
            CREATE INDEX IF NOT EXISTS idx_discord_link_codes_discord ON discord_link_codes(discord_id, updated_at DESC);
            CREATE INDEX IF NOT EXISTS idx_discord_links_steam ON discord_links(steam_id, updated_at DESC);
            CREATE INDEX IF NOT EXISTS idx_bot_audit_log_created ON bot_audit_log(created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_community_reactions_target ON community_reactions(target_type, target_id);
            CREATE INDEX IF NOT EXISTS idx_community_reactions_steam ON community_reactions(steam_id, created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_admin_audit_log_created ON admin_audit_log(created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_comlink_sessions_steam ON comlink_sessions(steam_id, issued_at DESC);
            CREATE INDEX IF NOT EXISTS idx_comlink_sessions_active ON comlink_sessions(server_id, channel_id, ended_at);
            CREATE INDEX IF NOT EXISTS idx_comlink_audit_created ON comlink_audit_log(created_at DESC);
            """
        )
        ensure_table_columns(db, "users", USER_PROFILE_COLUMNS)
        ensure_table_columns(db, "stats", PROGRESSION_STAT_COLUMNS)
        ensure_table_columns(db, "campaign_deployments", CAMPAIGN_DEPLOYMENT_COLUMNS)
        ensure_table_columns(db, "achievements", ACHIEVEMENT_COLUMNS)
        ensure_table_columns(db, "comlink_sessions", COMLINK_SESSION_COLUMNS)
        level_floor_migration = "progression_level_floor_20260628"
        if db.execute("SELECT 1 FROM schema_migrations WHERE migration_id = ?", (level_floor_migration,)).fetchone() is None:
            db.execute(
                """
                UPDATE stats
                SET level_floor = MAX(COALESCE(level_floor, 0), ?)
                WHERE xp > 0
                """,
                (1,),
            )
            for row in db.execute("SELECT steam_id, xp, level_floor FROM stats WHERE xp > 0").fetchall():
                legacy_level = legacy_level_for_xp(row["xp"])
                if legacy_level > int(row["level_floor"] or 0):
                    baseline = current_level_xp(level_for_xp(row["xp"]))
                    db.execute(
                        "UPDATE stats SET level_floor = ?, level_floor_xp = ? WHERE steam_id = ?",
                        (legacy_level, baseline, row["steam_id"]),
                    )
            db.execute(
                "INSERT INTO schema_migrations (migration_id, applied_at) VALUES (?, ?)",
                (level_floor_migration, now()),
            )
        level_floor_xp_migration = "progression_level_floor_xp_baseline_20260628"
        if db.execute("SELECT 1 FROM schema_migrations WHERE migration_id = ?", (level_floor_xp_migration,)).fetchone() is None:
            for row in db.execute(
                "SELECT steam_id, xp, level_floor, level_floor_xp FROM stats WHERE xp > 0 AND level_floor > 0"
            ).fetchall():
                xp_value = int(row["xp"] or 0)
                floor_level = int(row["level_floor"] or 0)
                actual_level = level_for_xp(xp_value)
                floor_xp = int(row["level_floor_xp"] or 0)
                if floor_level > actual_level and (floor_xp <= 0 or floor_xp > xp_value):
                    db.execute(
                        "UPDATE stats SET level_floor_xp = ? WHERE steam_id = ?",
                        (current_level_xp(actual_level), row["steam_id"]),
                    )
            db.execute(
                "INSERT INTO schema_migrations (migration_id, applied_at) VALUES (?, ?)",
                (level_floor_xp_migration, now()),
            )
        db.execute("UPDATE stats SET deployments_completed = MAX(deployments_completed, missions)")
        db.execute("UPDATE stats SET deployment_attempts = MAX(deployment_attempts, deployments_completed + deployments_failed)")


def sync_roster() -> dict[str, int]:
    if not SQUAD_XML_URL:
        return {"members": 0, "steam_linked": 0, "discord_only": 0}
    request = urllib.request.Request(SQUAD_XML_URL, headers={"User-Agent": "TCW-Profile-API/1.0"})
    with urllib.request.urlopen(request, timeout=15) as response:
        root = ET.fromstring(response.read())
    timestamp = now()
    members = 0
    steam_linked = 0
    discord_only = 0
    duplicates_skipped = 0
    duplicate_external_ids: list[str] = []
    seen_external_ids: set[str] = set()
    current_steam_ids: set[str] = set()
    with connect_db() as db:
        previous_steam_ids = {
            str(row["steam_id"])
            for row in db.execute("SELECT steam_id FROM roster_members WHERE steam_id IS NOT NULL AND steam_id != ''").fetchall()
        }
        db.execute("DELETE FROM roster_members")
        for member in root.findall("member"):
            external_id = str(member.attrib.get("id", "")).strip()
            if not external_id:
                continue
            if external_id in seen_external_ids:
                duplicates_skipped += 1
                if len(duplicate_external_ids) < 8:
                    duplicate_external_ids.append(external_id)
                continue
            seen_external_ids.add(external_id)
            roster_name = clean_profile_name(member.attrib.get("nick", ""))
            remark = str(member.findtext("remark", ""))
            remark_parts = [part.strip() for part in remark.split(",")]
            unit = remark_parts[0][:32] if remark_parts else ""
            rank = remark_parts[1][:32] if len(remark_parts) > 1 and remark_parts[1] != "N/A" else ""
            steam_id = external_id if STEAM_ID_PATTERN.fullmatch(external_id) else None
            discord_id = external_id[8:] if external_id.startswith("discord:") else None
            db.execute(
                """
                INSERT INTO roster_members
                    (external_id, steam_id, discord_id, display_name, unit, rank, synced_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (external_id, steam_id, discord_id, roster_name, unit, rank, timestamp),
            )
            members += 1
            if steam_id:
                current_steam_ids.add(steam_id)
                steam_linked += 1
                db.execute(
                    """
                    INSERT INTO users
                        (steam_id, display_name, roster_name, unit, rank, rostered, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, 1, ?, ?)
                    ON CONFLICT(steam_id) DO UPDATE SET
                        roster_name = excluded.roster_name,
                        unit = excluded.unit,
                        rank = excluded.rank,
                        rostered = 1,
                        display_name = CASE
                            WHEN users.arma_profile_name IS NULL OR users.arma_profile_name = ''
                            THEN excluded.roster_name ELSE users.display_name END,
                        updated_at = excluded.updated_at
                    """,
                    (steam_id, roster_name, roster_name, unit, rank, timestamp, timestamp),
                )
                db.execute("INSERT OR IGNORE INTO stats (steam_id) VALUES (?)", (steam_id,))
            elif discord_id:
                discord_only += 1
        removed_steam_ids = sorted(previous_steam_ids - current_steam_ids)
        if removed_steam_ids:
            placeholders = ",".join("?" for _ in removed_steam_ids)
            db.execute(f"UPDATE users SET rostered = 0, updated_at = ? WHERE steam_id IN ({placeholders})", [timestamp, *removed_steam_ids])
    if duplicates_skipped:
        log_backend_event(
            "discord_roster_squad_duplicates_skipped",
            duplicates_skipped=duplicates_skipped,
            duplicate_external_ids=",".join(duplicate_external_ids),
        )
    return {
        "members": members,
        "steam_linked": steam_linked,
        "discord_only": discord_only,
        "duplicates_skipped": duplicates_skipped,
        "removed_steam": len(removed_steam_ids),
    }


def stats_proxy_redirect_url(path: str, params: dict[str, Any] | None = None) -> str:
    if not STATS_PROXY_URL:
        return ""
    query: dict[str, Any] = {"path": path}
    query.update(params or {})
    return f"{STATS_PROXY_URL}?{urllib.parse.urlencode(query)}"


def stats_proxy_request(
    path: str,
    method: str = "GET",
    params: dict[str, Any] | None = None,
    body: dict[str, Any] | None = None,
    access_token: str = "",
) -> tuple[int, dict[str, Any]]:
    if not STATS_PROXY_URL:
        return HTTPStatus.SERVICE_UNAVAILABLE, {"ok": False, "error": "stats_proxy_not_configured"}
    payload: dict[str, Any] = {"path": path, "method": method.upper()}
    if params:
        payload["params"] = params
    if body:
        payload["body"] = body
    if access_token:
        payload["access_token"] = access_token
    request = urllib.request.Request(
        STATS_PROXY_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "TCW-Profile-API/1.0",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=STATS_PROXY_TIMEOUT_SECONDS) as response:
            raw = response.read().decode("utf-8", errors="replace")
            parsed = json.loads(raw) if raw else {}
            return response.status, parsed if isinstance(parsed, dict) else {"ok": True, "data": parsed}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            parsed = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            parsed = {"ok": False, "error": "stats_proxy_http_error", "message": raw}
        log_backend_event(
            "stats_proxy_request_failed",
            path=path,
            method=method.upper(),
            status_code=exc.code,
            reason=parsed.get("error") if isinstance(parsed, dict) else "http_error",
        )
        return exc.code, parsed if isinstance(parsed, dict) else {"ok": False, "data": parsed}
    except (OSError, TimeoutError, urllib.error.URLError) as exc:
        log_backend_event(
            "stats_proxy_request_failed",
            path=path,
            method=method.upper(),
            status_code=HTTPStatus.BAD_GATEWAY,
            reason=type(exc).__name__,
        )
        return HTTPStatus.BAD_GATEWAY, {"ok": False, "error": "stats_proxy_unreachable", "message": str(exc)}


def read_optional_secret_file(path_text: str, event_name: str) -> str:
    if not path_text:
        return ""
    try:
        return Path(path_text).read_text(encoding="utf-8").strip()
    except OSError as exc:
        log_backend_event(event_name, reason=type(exc).__name__)
        return ""


def root_storm_machine_token() -> str:
    return ROOT_STORM_MACHINE_TOKEN or read_optional_secret_file(
        ROOT_STORM_MACHINE_TOKEN_PATH,
        "root_storm_machine_token_read_failed",
    )


def is_absolute_http_url(value: str) -> bool:
    parsed = urllib.parse.urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def root_storm_direct_lookup_configured() -> bool:
    path_configured = bool(ROOT_STORM_DISCORD_LOOKUP_PATH)
    base_configured = bool(ROOT_STORM_API_BASE_URL) or is_absolute_http_url(ROOT_STORM_DISCORD_LOOKUP_PATH)
    return bool(base_configured and path_configured and root_storm_machine_token())


def root_storm_lookup_config() -> dict[str, Any]:
    stats_proxy_configured = bool(STATS_PROXY_DISCORD_LOOKUP_PATH)
    direct_configured = root_storm_direct_lookup_configured()
    if stats_proxy_configured:
        state = "configured_stats_proxy"
        source = "stats_proxy"
        message = "Root Storm Discord lookup is configured through the TCWA3 stats proxy."
    elif direct_configured:
        state = "configured_machine_token"
        source = "machine_token"
        message = "Root Storm Discord lookup is configured through the direct JT machine-token bridge."
    else:
        state = "needs_jt_lookup_path"
        source = "none"
        message = (
            "Root Storm/JT member stats need either TCWA3_STATS_PROXY_DISCORD_LOOKUP_PATH or "
            "ROOT_STORM_DISCORD_LOOKUP_PATH plus ROOT_STORM_MACHINE_TOKEN_PATH/ROOT_STORM_MACHINE_TOKEN."
        )
    return {
        "state": state,
        "source": source,
        "configured": stats_proxy_configured or direct_configured,
        "stats_proxy_lookup_configured": stats_proxy_configured,
        "machine_token_lookup_configured": direct_configured,
        "root_storm_api_base_configured": bool(ROOT_STORM_API_BASE_URL) or is_absolute_http_url(ROOT_STORM_DISCORD_LOOKUP_PATH),
        "message": message,
    }


def root_storm_machine_request(
    path: str,
    method: str = "GET",
    params: dict[str, Any] | None = None,
    body: dict[str, Any] | None = None,
) -> tuple[int, dict[str, Any]]:
    token = root_storm_machine_token()
    if not path or not token or (not ROOT_STORM_API_BASE_URL and not is_absolute_http_url(path)):
        return HTTPStatus.SERVICE_UNAVAILABLE, {
            "ok": False,
            "error": "root_storm_machine_bridge_not_configured",
            "message": "Root Storm direct bridge is missing base URL, lookup path, or machine token.",
        }
    url = path if is_absolute_http_url(path) else f"{ROOT_STORM_API_BASE_URL}/{path.lstrip('/')}"
    if params:
        url = f"{url}?{urllib.parse.urlencode(params)}"
    request_body = json.dumps(body).encode("utf-8") if body is not None else None
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
        "User-Agent": "TCW-Profile-API/1.0",
    }
    if request_body is not None:
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(
        url,
        data=request_body,
        headers=headers,
        method=method.upper(),
    )
    try:
        with urllib.request.urlopen(request, timeout=ROOT_STORM_TIMEOUT_SECONDS) as response:
            raw = response.read().decode("utf-8", errors="replace")
            try:
                parsed = json.loads(raw) if raw else {}
            except json.JSONDecodeError:
                log_backend_event(
                    "root_storm_machine_request_failed",
                    path=path,
                    method=method.upper(),
                    status_code=HTTPStatus.BAD_GATEWAY,
                    reason="non_json_response",
                )
                return HTTPStatus.BAD_GATEWAY, {
                    "ok": False,
                    "error": "root_storm_non_json_response",
                    "message": "Root Storm returned a non-JSON response to the authenticated bridge request.",
                }
            return response.status, parsed if isinstance(parsed, dict) else {"ok": True, "data": parsed}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            parsed = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            parsed = {"ok": False, "error": "root_storm_http_error", "message": raw}
        log_backend_event(
            "root_storm_machine_request_failed",
            path=path,
            method=method.upper(),
            status_code=exc.code,
            reason=parsed.get("error") if isinstance(parsed, dict) else "http_error",
        )
        return exc.code, parsed if isinstance(parsed, dict) else {"ok": False, "data": parsed}
    except (OSError, TimeoutError, urllib.error.URLError) as exc:
        log_backend_event(
            "root_storm_machine_request_failed",
            path=path,
            method=method.upper(),
            status_code=HTTPStatus.BAD_GATEWAY,
            reason=type(exc).__name__,
        )
        return HTTPStatus.BAD_GATEWAY, {
            "ok": False,
            "error": "root_storm_unreachable",
            "message": str(exc),
        }


def normalise_roster_return_to(value: str) -> str:
    """Allow Discord handoff returns only to TCWA3-owned web origins."""
    default = f"{WEB_BASE_URL}/profile.html?roster_return=1"
    candidate = str(value or "").strip() or default
    parsed = urllib.parse.urlparse(candidate)
    allowed_hosts = {"tcwa3.co.uk", "www.tcwa3.co.uk", "localhost", "127.0.0.1"}
    for origin in ALLOWED_CORS_ORIGINS:
        host = urllib.parse.urlparse(origin).hostname
        if host:
            allowed_hosts.add(host.lower())
    host = (parsed.hostname or "").lower()
    if parsed.scheme not in {"http", "https"} or host not in allowed_hosts:
        return default
    return candidate


def first_dict(*values: Any) -> dict[str, Any]:
    for value in values:
        if isinstance(value, dict):
            return value
    return {}


def first_list(*values: Any) -> list[Any]:
    for value in values:
        if isinstance(value, list):
            return value
    return []


def first_non_empty(*values: Any) -> str:
    for value in values:
        text = str(value or "").strip()
        if text:
            return text
    return ""


def safe_external_int(value: Any, default: int = 0) -> int:
    try:
        text = str(value).replace(",", "").strip()
        if not text:
            return default
        return max(0, int(float(text)))
    except (TypeError, ValueError):
        return default


def stat_from_sources(sources: list[dict[str, Any]], keys: list[str], default: int = 0) -> int:
    for source in sources:
        for key in keys:
            if key in source and source[key] not in (None, ""):
                return safe_external_int(source[key], default)
    return default


def normalise_external_membership(player_payload: dict[str, Any]) -> dict[str, Any]:
    memberships = first_list(player_payload.get("battalion_memberships"), player_payload.get("memberships"))
    for membership in memberships:
        if isinstance(membership, dict):
            return membership
    return first_dict(player_payload.get("membership"), player_payload.get("unit"))


def extract_external_roster_profile(
    me_payload: dict[str, Any],
    player_payload: dict[str, Any] | None = None,
    operations_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    player_payload = player_payload or {}
    operations_payload = operations_payload or {}
    me_user = first_dict(me_payload.get("user"))
    me_steam = first_dict(me_payload.get("steam_linked"), me_payload.get("steam"))
    linked_player = first_dict(player_payload.get("linked_player"), player_payload.get("player"))
    scoreboard = first_dict(player_payload.get("scoreboard_totals"), player_payload.get("scoreboard"))
    summary = first_dict(player_payload.get("summary"), player_payload.get("totals"))
    stats_payload = first_dict(player_payload.get("stats"), player_payload.get("statistics"))
    membership = normalise_external_membership(player_payload)
    sources = [scoreboard, summary, stats_payload, linked_player, player_payload, me_user]

    steam_id = first_non_empty(
        me_user.get("steam_id"),
        me_user.get("steam_id64"),
        me_steam.get("steam_id"),
        me_steam.get("steam_id64"),
        me_steam.get("id"),
        linked_player.get("steam_id"),
        linked_player.get("steam_id64"),
        player_payload.get("steam_id"),
        player_payload.get("steam_id64"),
    )
    display_name = first_non_empty(
        linked_player.get("display_name"),
        linked_player.get("name"),
        player_payload.get("display_name"),
        player_payload.get("name"),
        me_user.get("display_name"),
        me_user.get("discord_username"),
    )
    unit = first_non_empty(
        membership.get("unit"),
        membership.get("unit_name"),
        membership.get("battalion"),
        membership.get("legion"),
        linked_player.get("unit"),
        linked_player.get("legion"),
        player_payload.get("unit"),
        player_payload.get("unit_name"),
        player_payload.get("battalion"),
    )
    rank = first_non_empty(
        membership.get("rank"),
        membership.get("rank_name"),
        membership.get("role"),
        linked_player.get("rank"),
        player_payload.get("rank"),
        player_payload.get("rank_name"),
    )

    playtime_seconds = stat_from_sources(sources, ["playtime_seconds", "total_playtime_seconds", "seconds_played"])
    if not playtime_seconds:
        playtime_seconds = stat_from_sources(sources, ["playtime_minutes", "minutes_played"]) * 60
    if not playtime_seconds:
        playtime_seconds = stat_from_sources(sources, ["playtime_hours", "hours_played"]) * 3600

    return {
        "steam_id": steam_id,
        "display_name": display_name,
        "roster_name": display_name,
        "unit": unit[:32],
        "rank": rank[:32],
        "discord_id": first_non_empty(
            me_user.get("discord_id"),
            me_user.get("discord_user_id"),
            me_user.get("discordId"),
            me_payload.get("discord_id"),
            me_payload.get("discord_user_id"),
        ),
        "guild_id": first_non_empty(me_user.get("guild_id"), me_user.get("discord_guild_id"), me_payload.get("guild_id")),
        "discord_username": first_non_empty(me_user.get("discord_username"), me_user.get("username"), me_payload.get("discord_username")),
        "steam_linked": bool(me_payload.get("steam_linked") or me_steam or steam_id),
        "stats": {
            "kills": stat_from_sources(sources, ["kills", "enemy_kills", "infantry_kills"]),
            "deaths": stat_from_sources(sources, ["deaths"]),
            "credits": stat_from_sources(sources, ["credits", "currency"]),
            "xp": stat_from_sources(sources, ["xp", "experience", "total_xp"]),
            "missions": stat_from_sources(sources, ["missions", "deployments", "operations", "completed_missions"]),
            "playtime_seconds": playtime_seconds,
            "droid_kills": stat_from_sources(sources, ["droid_kills", "droids", "enemy_kills"]),
            "vehicle_kills": stat_from_sources(sources, ["vehicle_kills", "vehicles_destroyed", "ground_vehicle_kills"]),
            "aircraft_kills": stat_from_sources(sources, ["aircraft_kills", "aircraft_destroyed", "air_kills"]),
            "friendly_kills": stat_from_sources(sources, ["friendly_kills", "teamkills", "team_kills"]),
            "support_score": stat_from_sources(sources, ["support_score", "service_score", "legion_score"]),
            "revives": stat_from_sources(sources, ["revives", "revive_count", "medical_revives"]),
            "heals": stat_from_sources(sources, ["heals", "heal_count", "medical_heals"]),
            "repairs": stat_from_sources(sources, ["repairs", "repair_count", "vehicle_repairs"]),
            "resupplies": stat_from_sources(sources, ["resupplies", "resupply_count", "ammo_resupplies"]),
            "transport_assists": stat_from_sources(sources, ["transport_assists", "transport_count"]),
            "objective_support": stat_from_sources(sources, ["objective_support", "objective_support_count"]),
            "geonosis_missions": stat_from_sources(sources, ["geonosis_missions", "geonosis_deployments"]),
            "deployment_attempts": stat_from_sources(sources, ["deployment_attempts", "deployment_count", "deployments"]),
            "deployments_completed": stat_from_sources(sources, ["deployments_completed", "completed_deployments", "completed_missions"]),
            "deployments_failed": stat_from_sources(sources, ["deployments_failed", "failed_deployments", "failed_missions"]),
        },
        "operations": first_list(
            operations_payload.get("operations"),
            operations_payload.get("items"),
            operations_payload.get("history"),
        ),
    }


def merge_external_roster_profile(db: sqlite3.Connection, roster_profile: dict[str, Any]) -> dict[str, Any] | None:
    steam_id = str(roster_profile.get("steam_id", "")).strip()
    if not STEAM_ID_PATTERN.fullmatch(steam_id):
        return None
    timestamp = now()
    raw_display_name = first_non_empty(roster_profile.get("display_name"), roster_profile.get("roster_name"))
    display_name = clean_profile_name(raw_display_name) if raw_display_name else DEFAULT_DISPLAY_NAME
    roster_name = clean_profile_name(raw_display_name) if raw_display_name else ""
    unit = str(roster_profile.get("unit", "") or "")[:32]
    rank = str(roster_profile.get("rank", "") or "")[:32]
    db.execute(
        """
        INSERT INTO users
            (steam_id, display_name, roster_name, unit, rank, rostered, verified_at, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)
        ON CONFLICT(steam_id) DO UPDATE SET
            roster_name = COALESCE(NULLIF(excluded.roster_name, ''), users.roster_name),
            unit = COALESCE(NULLIF(excluded.unit, ''), users.unit),
            rank = COALESCE(NULLIF(excluded.rank, ''), users.rank),
            rostered = 1,
            display_name = CASE
                WHEN users.arma_profile_name IS NULL OR users.arma_profile_name = ''
                THEN COALESCE(NULLIF(excluded.roster_name, ''), NULLIF(excluded.display_name, ''), users.display_name)
                ELSE users.display_name END,
            verified_at = COALESCE(users.verified_at, excluded.verified_at),
            updated_at = excluded.updated_at
        """,
        (steam_id, display_name, roster_name, unit, rank, timestamp, timestamp, timestamp),
    )
    db.execute("INSERT OR IGNORE INTO stats (steam_id) VALUES (?)", (steam_id,))
    stats = first_dict(roster_profile.get("stats"))
    for column in [
        "kills",
        "deaths",
        "credits",
        "xp",
        "missions",
        "playtime_seconds",
        "droid_kills",
        "vehicle_kills",
        "aircraft_kills",
        "friendly_kills",
        "support_score",
        "revives",
        "heals",
        "repairs",
        "resupplies",
        "transport_assists",
        "objective_support",
        "geonosis_missions",
        "deployment_attempts",
        "deployments_completed",
        "deployments_failed",
    ]:
        value = safe_external_int(stats.get(column), 0)
        if value > 0:
            db.execute(f"UPDATE stats SET {column} = MAX(COALESCE({column}, 0), ?) WHERE steam_id = ?", (value, steam_id))
    db.execute("UPDATE stats SET deployments_completed = MAX(deployments_completed, missions) WHERE steam_id = ?", (steam_id,))
    db.execute(
        "UPDATE stats SET deployment_attempts = MAX(deployment_attempts, deployments_completed + deployments_failed) WHERE steam_id = ?",
        (steam_id,),
    )
    unlock_achievements(db, steam_id)
    profile = profile_for(db, steam_id)
    safe_write_player_profile_snapshot(db, steam_id)
    return profile


def upsert_discord_link_from_roster_profile(db: sqlite3.Connection, steam_id: str, roster_profile: dict[str, Any]) -> sqlite3.Row | None:
    discord_id = clean_discord_snowflake(
        first_non_empty(roster_profile.get("discord_id"), roster_profile.get("discord_user_id")),
        required=False,
    )
    if not discord_id:
        return None
    timestamp = now()
    guild_id = clean_discord_snowflake(roster_profile.get("guild_id"), required=False)
    discord_username = clean_support_text(roster_profile.get("discord_username") or roster_profile.get("username"), 120)
    nickname = clean_support_text(roster_profile.get("display_name") or roster_profile.get("roster_name"), 120)
    db.execute(
        """
        INSERT INTO discord_links
            (discord_id, steam_id, guild_id, discord_username, nickname, roles_json, status, source, linked_at, updated_at)
        VALUES (?, ?, ?, ?, ?, '[]', 'linked', 'root_storm_oauth', ?, ?)
        ON CONFLICT(discord_id) DO UPDATE SET
            steam_id = excluded.steam_id,
            guild_id = COALESCE(NULLIF(excluded.guild_id, ''), discord_links.guild_id),
            discord_username = COALESCE(NULLIF(excluded.discord_username, ''), discord_links.discord_username),
            nickname = COALESCE(NULLIF(excluded.nickname, ''), discord_links.nickname),
            status = 'linked',
            source = 'root_storm_oauth',
            updated_at = excluded.updated_at
        """,
        (discord_id, steam_id, guild_id, discord_username, nickname, timestamp, timestamp),
    )
    return db.execute("SELECT * FROM discord_links WHERE discord_id = ?", (discord_id,)).fetchone()


def fetch_external_roster_profile(access_token: str, expected_steam_id: str = "") -> tuple[int, dict[str, Any]]:
    access_token = str(access_token or "").strip()
    if not access_token:
        log_backend_event("discord_roster_profile_fetch_failed", path="/v1/me", reason="missing_access_token")
        return HTTPStatus.BAD_REQUEST, {"ok": False, "error": "missing_access_token"}
    me_status, me_payload = stats_proxy_request("/v1/me", method="GET", access_token=access_token)
    if me_status >= 400:
        log_backend_event(
            "discord_roster_profile_fetch_failed",
            path="/v1/me",
            status_code=me_status,
            reason=me_payload.get("error"),
        )
        return me_status, me_payload
    player_status, player_payload = stats_proxy_request("/v1/me/player", method="GET", access_token=access_token)
    if player_status >= 400:
        log_backend_event(
            "discord_roster_profile_partial_failed",
            path="/v1/me/player",
            status_code=player_status,
            reason=player_payload.get("error"),
        )
        player_payload = {}
    operations_status, operations_payload = stats_proxy_request("/v1/me/operations", method="GET", access_token=access_token)
    if operations_status >= 400:
        log_backend_event(
            "discord_roster_profile_partial_failed",
            path="/v1/me/operations",
            status_code=operations_status,
            reason=operations_payload.get("error"),
        )
        operations_payload = {}
    roster_profile = extract_external_roster_profile(me_payload, player_payload, operations_payload)
    roster_steam_id = str(roster_profile.get("steam_id", "") or "").strip()
    expected_steam_id = str(expected_steam_id or "").strip()
    if expected_steam_id:
        if roster_steam_id and roster_steam_id != expected_steam_id:
            return HTTPStatus.CONFLICT, {
                "ok": False,
                "error": "steam_mismatch",
                "message": "Root Storm returned a different SteamID64 than the TCWA3 Steam session. Sign into the matching Steam account or ask staff to correct the roster link.",
            }
        if not roster_steam_id:
            roster_profile["steam_id"] = expected_steam_id
    with connect_db() as db:
        profile = merge_external_roster_profile(db, roster_profile)
        linked_discord = None
        if profile is not None:
            linked_discord = upsert_discord_link_from_roster_profile(db, profile["steam_id"], roster_profile)
            if linked_discord is not None:
                profile = profile_for(db, profile["steam_id"])
    if profile is None:
        log_backend_event("discord_roster_profile_fetch_failed", path="/v1/me", reason="missing_steam_id")
        return HTTPStatus.BAD_GATEWAY, {
            "ok": False,
            "error": "roster_profile_missing_steam_id",
            "message": "The TCW roster did not return a linked SteamID64 for this Discord account.",
        }
    return HTTPStatus.OK, {
        "ok": True,
        "profile": profile,
        "external": {
            "steam_linked": bool(roster_profile.get("steam_linked")),
            "discord_username": roster_profile.get("discord_username", ""),
            "discord_linked": bool(linked_discord),
            "operations_synced": len(roster_profile.get("operations", [])),
        },
    }


def external_lookup_profile_payload(payload: dict[str, Any]) -> dict[str, Any]:
    direct_profile = first_dict(
        payload.get("roster_profile"),
        payload.get("roster"),
        payload.get("root_storm_roster"),
        payload.get("profile"),
        payload.get("player_profile"),
        payload.get("data"),
    )
    if not direct_profile:
        direct_profile = payload
    operations = first_list(payload.get("operations"), payload.get("operation_history"), direct_profile.get("operations"))
    operations_payload = first_dict(payload.get("operations"), payload.get("operation_history"))
    if not operations_payload and operations:
        operations_payload = {"operations": operations}
    me_payload = first_dict(payload.get("me"), payload.get("account"), payload.get("user"), direct_profile)
    player_payload = first_dict(payload.get("player"), payload.get("linked_player"), direct_profile)
    return extract_external_roster_profile(me_payload, player_payload, operations_payload)


def root_storm_discord_lookup_body(discord_row: sqlite3.Row, steam_id: str) -> dict[str, Any]:
    discord = discord_link_payload(discord_row, include_roles=True)
    return {
        "source": "tcwa3_discord_bot_bridge",
        "steam_id": steam_id,
        "discord_id": discord.get("discord_id", ""),
        "guild_id": discord.get("guild_id", ""),
        "discord_username": discord.get("username", ""),
        "nickname": discord.get("nickname", ""),
        "roles": discord.get("roles", []),
    }


def try_link_root_storm_roster_from_discord(db: sqlite3.Connection, steam_id: str) -> tuple[HTTPStatus, dict[str, Any]]:
    discord_row = db.execute(
        "SELECT * FROM discord_links WHERE steam_id = ? ORDER BY updated_at DESC LIMIT 1",
        (steam_id,),
    ).fetchone()
    if discord_row is None:
        return HTTPStatus.NOT_FOUND, {
            "ok": False,
            "status": "discord_not_linked",
            "error": "discord_not_linked",
            "discord_linked": False,
            "message": "Link Discord with the TCW bot before TCWA3 can try the Root Storm roster bridge.",
        }
    discord = discord_link_payload(discord_row, include_roles=True)
    lookup_config = root_storm_lookup_config()
    if not lookup_config["configured"]:
        return HTTPStatus.ACCEPTED, {
            "ok": False,
            "status": "root_storm_lookup_not_configured",
            "error": "root_storm_discord_lookup_not_configured",
            "discord_linked": True,
            "discord": discord,
            "root_storm_authenticated_stats": lookup_config,
            "message": (
                "Discord is linked. Root Storm/JT still needs to expose the authenticated member lookup and configure "
                "either TCWA3_STATS_PROXY_DISCORD_LOOKUP_PATH or ROOT_STORM_DISCORD_LOOKUP_PATH with a machine token "
                "before TCWA3 can roster-link from the bot automatically."
            ),
        }
    lookup_body = root_storm_discord_lookup_body(discord_row, steam_id)
    if STATS_PROXY_DISCORD_LOOKUP_PATH:
        lookup_source = "stats_proxy"
        lookup_path = STATS_PROXY_DISCORD_LOOKUP_PATH
        status, payload = stats_proxy_request(lookup_path, method="POST", body=lookup_body)
    else:
        lookup_source = "machine_token"
        lookup_path = ROOT_STORM_DISCORD_LOOKUP_PATH
        status, payload = root_storm_machine_request(lookup_path, method="POST", body=lookup_body)
    if status >= 400:
        log_backend_event(
            "root_storm_discord_lookup_failed",
            path=lookup_path,
            source=lookup_source,
            status_code=status,
            reason=payload.get("error") if isinstance(payload, dict) else "stats_proxy_error",
        )
        result = payload if isinstance(payload, dict) else {"error": "root_storm_lookup_failed"}
        result.setdefault("ok", False)
        result.setdefault("status", "root_storm_lookup_failed")
        result.setdefault("message", "Root Storm did not accept the Discord roster lookup. Use Galaxy Map sign-in or staff roster review for now.")
        result["discord_linked"] = True
        result["discord"] = discord
        return HTTPStatus(status), result
    roster_profile = external_lookup_profile_payload(payload if isinstance(payload, dict) else {})
    roster_steam_id = str(roster_profile.get("steam_id", "") or "").strip()
    if not STEAM_ID_PATTERN.fullmatch(roster_steam_id):
        log_backend_event(
            "root_storm_discord_lookup_missing_steam",
            path=lookup_path,
            source=lookup_source,
            status_code=status,
        )
        return HTTPStatus.NOT_FOUND, {
            "ok": False,
            "status": "root_storm_roster_not_found",
            "error": "root_storm_roster_not_found",
            "discord_linked": True,
            "discord": discord,
            "message": "Root Storm did not return a Steam-linked roster profile for this Discord account.",
        }
    if roster_steam_id != steam_id:
        log_backend_event(
            "root_storm_discord_lookup_steam_mismatch",
            path=lookup_path,
            source=lookup_source,
            status_code=status,
            expected_steam_id=steam_id,
            returned_steam_id=roster_steam_id,
        )
        return HTTPStatus.CONFLICT, {
            "ok": False,
            "status": "root_storm_steam_mismatch",
            "error": "root_storm_steam_mismatch",
            "discord_linked": True,
            "discord": discord,
            "message": "Root Storm returned a roster profile for a different SteamID64, so TCWA3 did not link it.",
        }
    profile = merge_external_roster_profile(db, roster_profile)
    if profile is None:
        log_backend_event(
            "root_storm_discord_lookup_merge_failed",
            path=lookup_path,
            source=lookup_source,
            status_code=status,
        )
        return HTTPStatus.BAD_GATEWAY, {
            "ok": False,
            "status": "root_storm_roster_merge_failed",
            "error": "root_storm_roster_merge_failed",
            "discord_linked": True,
            "discord": discord,
            "message": "Root Storm returned roster data, but TCWA3 could not merge it safely.",
        }
    log_backend_event(
        "root_storm_discord_lookup_linked",
        path=lookup_path,
        source=lookup_source,
        status_code=status,
        steam_id=steam_id,
    )
    return HTTPStatus.OK, {
        "ok": True,
        "status": "linked",
        "discord_linked": True,
        "discord": discord,
        "profile": profile,
        "external": {
            "steam_linked": bool(roster_profile.get("steam_linked")),
            "discord_username": roster_profile.get("discord_username", ""),
            "operations_synced": len(roster_profile.get("operations", [])),
            "lookup_path": lookup_path,
            "lookup_source": lookup_source,
        },
        "message": "Root Storm roster linked through the TCWA3 Discord bot bridge.",
    }


def roster_sync_loop() -> None:
    while True:
        try:
            result = sync_roster()
            print(f"Roster synced: {result}")
        except Exception as exc:
            log_backend_event("discord_roster_squad_sync_failed", reason=type(exc).__name__)
        time.sleep(max(60, ROSTER_SYNC_SECONDS))


def tcw_tools_pair_record(fields: list[tuple[str, Any]]) -> list[list[Any]]:
    return [[key, value] for key, value in fields]


def tcw_tools_achievement_records(achievements: list[dict[str, Any]]) -> list[list[list[Any]]]:
    records: list[list[list[Any]]] = []
    for achievement in achievements:
        if not isinstance(achievement, dict):
            continue
        records.append(
            tcw_tools_pair_record(
                [
                    ("id", str(achievement.get("id", ""))),
                    ("title", str(achievement.get("name") or achievement.get("title") or achievement.get("id") or "Achievement")),
                    ("description", str(achievement.get("description", ""))),
                    ("unlockedAt", achievement.get("unlocked_at", "")),
                    ("acknowledgedAt", achievement.get("acknowledged_at", "")),
                ]
            )
        )
    return records


def tcw_tools_lore_records(quests: list[dict[str, Any]]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for quest in quests:
        if not isinstance(quest, dict):
            continue
        quest_id = str(quest.get("id", "") or "")
        quest_title = str(quest.get("title", "") or quest_id or "TCW Quest")
        lore_entries = quest.get("lore", [])
        if not isinstance(lore_entries, list):
            continue
        for index, entry in enumerate(lore_entries, start=1):
            if isinstance(entry, dict):
                text = str(entry.get("text", "") or "")
                lore_id = str(entry.get("id", "") or f"{quest_id}-lore-{index}")
                title = str(entry.get("title", "") or quest_title)
                recorded_at = entry.get("recorded_at", entry.get("updated_at", quest.get("updated_at", "")))
                event_id = str(entry.get("event_id", "") or "")
            else:
                text = str(entry or "")
                lore_id = f"{quest_id}-lore-{index}"
                title = quest_title
                recorded_at = quest.get("updated_at", "")
                event_id = ""
            text = text.strip()
            if not text:
                continue
            dedupe_key = (quest_id, text)
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            records.append(
                {
                    "id": lore_id[:128],
                    "title": title[:160],
                    "text": text[:2000],
                    "quest_id": quest_id,
                    "quest_title": quest_title,
                    "recorded_at": recorded_at,
                    "event_id": event_id[:128],
                }
            )
    return records


def tcw_tools_lore_pair_records(lore_records: list[dict[str, Any]]) -> list[list[list[Any]]]:
    return [
        tcw_tools_pair_record(
            [
                ("id", lore.get("id", "")),
                ("title", lore.get("title", "")),
                ("text", lore.get("text", "")),
                ("questId", lore.get("quest_id", "")),
                ("questTitle", lore.get("quest_title", "")),
                ("recordedAt", lore.get("recorded_at", "")),
                ("eventId", lore.get("event_id", "")),
            ]
        )
        for lore in lore_records
        if isinstance(lore, dict)
    ]


def tcw_tools_quest_records(quests: list[dict[str, Any]]) -> list[list[list[Any]]]:
    records: list[list[list[Any]]] = []
    for quest in quests:
        if not isinstance(quest, dict):
            continue
        lore_records = tcw_tools_lore_records([quest])
        history_rows = []
        history = quest.get("history", [])
        if isinstance(history, list):
            for entry in history:
                if not isinstance(entry, dict):
                    continue
                history_rows.append(
                    tcw_tools_pair_record(
                        [
                            ("eventId", str(entry.get("event_id", ""))),
                            ("state", str(entry.get("state", ""))),
                            ("stageIndex", entry.get("stage_index", entry.get("stage", 0))),
                            ("stageTitle", str(entry.get("stage_title", ""))),
                            ("recordedAt", entry.get("recorded_at", "")),
                            ("choiceId", str(entry.get("choice_id", ""))),
                            ("choiceLabel", str(entry.get("choice_label", ""))),
                        ]
                    )
                )
        records.append(
            tcw_tools_pair_record(
                [
                    ("id", str(quest.get("id", ""))),
                    ("title", str(quest.get("title", ""))),
                    ("category", str(quest.get("category", ""))),
                    ("state", str(quest.get("state", ""))),
                    ("stageIndex", quest.get("stage_index", 0)),
                    ("stageTitle", str(quest.get("stage_title", ""))),
                    ("stageDescription", str(quest.get("stage_description", ""))),
                    ("lore", tcw_tools_lore_pair_records(lore_records)),
                    ("history", history_rows),
                    ("officialServer", str(quest.get("official_server", ""))),
                    ("startedAt", quest.get("started_at", "")),
                    ("updatedAt", quest.get("updated_at", "")),
                    ("completedAt", quest.get("completed_at", "")),
                ]
            )
        )
    return records


def attach_tcw_tools_profile_snapshot(profile: dict[str, Any]) -> dict[str, Any]:
    current_level_xp_value = int(profile.get("current_level_xp", 0) or 0)
    next_level_xp_value = int(profile.get("next_level_xp", 500) or 500)
    if next_level_xp_value <= current_level_xp_value:
        next_level_xp_value = current_level_xp_value + 500
    xp_value = int(profile.get("xp", 0) or 0)
    xp_needed = max(1, next_level_xp_value - current_level_xp_value)
    xp_into_level = max(0, min(xp_needed, xp_value - current_level_xp_value))
    xp_remaining = max(0, next_level_xp_value - xp_value)
    xp_progress = max(0.0, min(1.0, xp_into_level / xp_needed))

    achievements = profile.get("achievements", [])
    if not isinstance(achievements, list):
        achievements = []
    quests = profile.get("quests", [])
    if not isinstance(quests, list):
        quests = []
    lore = tcw_tools_lore_records(quests)
    updated_at = profile.get("updated_at", "")
    revision = f"profile-{updated_at}" if updated_at not in (None, "") else ""

    profile.update(
        {
            "profile_schema": "tcwa3_profile_v1",
            "xp_into_level": xp_into_level,
            "xp_remaining": xp_remaining,
            "xp_progress": xp_progress,
            "xp_progress_percent": round(xp_progress * 100),
            "achievement_count": len(achievements),
            "quest_count": len(quests),
            "lore_count": len(lore),
            "lore": lore,
            "source": "tcwa3_backend",
            "revision": revision,
        }
    )
    profile["tcw_tools_snapshot"] = tcw_tools_pair_record(
        [
            ("profileSchema", "tcwa3_profile_v1"),
            ("steamId", profile.get("steam_id", "")),
            ("displayName", profile.get("display_name", "")),
            ("rank", profile.get("rank", "")),
            ("level", profile.get("level", 1)),
            ("xp", xp_value),
            ("currentLevelXp", current_level_xp_value),
            ("nextLevelXp", next_level_xp_value),
            ("xpIntoLevel", xp_into_level),
            ("xpRemaining", xp_remaining),
            ("xpProgress", xp_progress),
            ("xpProgressPercent", round(xp_progress * 100)),
            ("credits", profile.get("credits", 0)),
            ("weeklyWageCredits", profile.get("republic_wage", {}).get("weekly_credits", REPUBLIC_WEEKLY_WAGE_CREDITS)),
            ("republicWageState", profile.get("republic_wage", {}).get("state", "scheduled")),
            ("lastRepublicWageAt", profile.get("republic_wage", {}).get("last_paid_at", 0)),
            ("nextRepublicWageAt", profile.get("republic_wage", {}).get("next_week_starts_at", 0)),
            ("supportScore", profile.get("support_score", 0)),
            ("revives", profile.get("revives", 0)),
            ("heals", profile.get("heals", 0)),
            ("repairs", profile.get("repairs", 0)),
            ("resupplies", profile.get("resupplies", 0)),
            ("transportAssists", profile.get("transport_assists", 0)),
            ("objectiveSupport", profile.get("objective_support", 0)),
            ("achievements", tcw_tools_achievement_records(achievements)),
            ("quests", tcw_tools_quest_records(quests)),
            ("lore", tcw_tools_lore_pair_records(lore)),
            ("achievementCount", len(achievements)),
            ("questCount", len(quests)),
            ("loreCount", len(lore)),
            ("source", "tcwa3_backend"),
            ("revision", revision),
            ("updatedAt", updated_at),
            ("authoritative", True),
        ]
    )
    return profile


def tcw_tools_profile_snapshot_payload(profile: dict[str, Any]) -> dict[str, Any]:
    return {
        "profile_schema": profile.get("profile_schema", "tcwa3_profile_v1"),
        "steam_id": profile.get("steam_id", ""),
        "display_name": profile.get("display_name", ""),
        "rank": profile.get("rank", ""),
        "level": profile.get("level", 1),
        "xp": profile.get("xp", 0),
        "current_level_xp": profile.get("current_level_xp", 0),
        "next_level_xp": profile.get("next_level_xp", 500),
        "xp_into_level": profile.get("xp_into_level", 0),
        "xp_remaining": profile.get("xp_remaining", 0),
        "xp_progress": profile.get("xp_progress", 0),
        "xp_progress_percent": profile.get("xp_progress_percent", 0),
        "credits": profile.get("credits", 0),
        "republic_wage": profile.get("republic_wage", {}),
        "kills": profile.get("kills", 0),
        "droid_kills": profile.get("droid_kills", 0),
        "vehicle_kills": profile.get("vehicle_kills", 0),
        "aircraft_kills": profile.get("aircraft_kills", 0),
        "friendly_kills": profile.get("friendly_kills", 0),
        "support_score": profile.get("support_score", 0),
        "revives": profile.get("revives", 0),
        "heals": profile.get("heals", 0),
        "repairs": profile.get("repairs", 0),
        "resupplies": profile.get("resupplies", 0),
        "transport_assists": profile.get("transport_assists", 0),
        "objective_support": profile.get("objective_support", 0),
        "deployment_attempts": profile.get("deployment_attempts", 0),
        "deployments_completed": profile.get("deployments_completed", profile.get("missions", 0)),
        "deployments_failed": profile.get("deployments_failed", 0),
        "achievement_count": profile.get("achievement_count", 0),
        "quest_count": profile.get("quest_count", 0),
        "lore_count": profile.get("lore_count", 0),
        "source": profile.get("source", "tcwa3_backend"),
        "revision": profile.get("revision", ""),
        "updated_at": profile.get("updated_at", ""),
        "tcw_tools_snapshot": profile.get("tcw_tools_snapshot", []),
    }


def tcw_tools_profile_snapshots_for(db: sqlite3.Connection, steam_ids: list[str]) -> list[dict[str, Any]]:
    profiles: list[dict[str, Any]] = []
    seen: set[str] = set()
    for steam_id in steam_ids:
        steam_id = str(steam_id or "").strip()
        if steam_id in seen or not STEAM_ID_PATTERN.fullmatch(steam_id):
            continue
        seen.add(steam_id)
        profile = profile_for(db, steam_id)
        if profile:
            profiles.append(tcw_tools_profile_snapshot_payload(profile))
    return profiles


def service_record_for_profile(profile: dict[str, Any]) -> dict[str, Any]:
    """Build a read-only progression briefing for launcher and website surfaces."""
    campaigns = profile.get("campaigns", [])
    if not isinstance(campaigns, list):
        campaigns = []
    achievements = profile.get("achievements", [])
    if not isinstance(achievements, list):
        achievements = []
    quests = profile.get("quests", [])
    if not isinstance(quests, list):
        quests = []
    completed_quests = [
        quest
        for quest in quests
        if isinstance(quest, dict) and str(quest.get("state", "")).upper() in {"SUCCEEDED", "FAILED", "CANCELED"}
    ]
    deployments = int(profile.get("deployments", profile.get("missions", 0)) or 0)
    deployment_attempts = int(profile.get("deployment_attempts", deployments) or 0)
    deployments_completed = int(profile.get("deployments_completed", profile.get("missions", 0)) or 0)
    deployments_failed = int(profile.get("deployments_failed", 0) or 0)
    level = int(profile.get("level", 1) or 1)
    if deployments >= 25 or level >= 10:
        title = "Veteran service record"
    elif deployments >= 5 or level >= 5:
        title = "Seasoned service record"
    elif deployments > 0 or int(profile.get("xp", 0) or 0) > 0:
        title = "Active service record"
    else:
        title = "New trooper record"

    latest_campaign = campaigns[0] if campaigns and isinstance(campaigns[0], dict) else {}
    latest_deployment: dict[str, Any] = {}
    if latest_campaign:
        deployments_list = latest_campaign.get("deployments", [])
        if isinstance(deployments_list, list) and deployments_list and isinstance(deployments_list[0], dict):
            latest_deployment = deployments_list[0]
    latest_achievement = achievements[0] if achievements and isinstance(achievements[0], dict) else {}
    latest_quest = quests[0] if quests and isinstance(quests[0], dict) else {}

    next_actions: list[str] = []
    if not bool(profile.get("rostered", False)):
        next_actions.append("Link the Root Storm roster so rank and unit appear everywhere.")
    if not STATS_PROXY_DISCORD_LOOKUP_PATH and not any(
        int(profile.get(field, 0) or 0) > 0
        for field in ("xp", "credits", "kills", "droid_kills", "missions", "playtime_seconds")
    ):
        next_actions.append("JT/Root Storm authenticated stat sync is not connected yet, so live member stats are still waiting on the bridge.")
    if deployments == 0:
        next_actions.append("Join an official deployment to begin campaign history.")
    if not achievements:
        next_actions.append("Complete official objectives to unlock the first achievement.")
    if not quests:
        next_actions.append("TCW Tools quest and lore records will appear after signed in-game events.")
    if not next_actions:
        next_actions.append("Continue official operations to grow campaigns, awards, quests, and credits.")

    return {
        "schema": "tcwa3_service_record_v1",
        "title": title,
        "summary": (
            f"Level {level} / {deployments_completed} completed deployment{'s' if deployments_completed != 1 else ''} / "
            f"{deployments_failed} failed / {deployment_attempts} attempt{'s' if deployment_attempts != 1 else ''} / "
            f"{int(profile.get('support_score', 0) or 0)} support score / "
            f"{len(achievements)} award{'s' if len(achievements) != 1 else ''} / "
            f"{len(completed_quests)} quest{'s' if len(completed_quests) != 1 else ''} complete"
        ),
        "level": level,
        "xp": int(profile.get("xp", 0) or 0),
        "xp_into_level": int(profile.get("xp_into_level", 0) or 0),
        "xp_remaining": int(profile.get("xp_remaining", 0) or 0),
        "xp_progress_percent": int(profile.get("xp_progress_percent", 0) or 0),
        "credits": int(profile.get("credits", 0) or 0),
        "republic_wage": profile.get("republic_wage", {}),
        "weekly_wage_credits": int(
            profile.get("republic_wage", {}).get("weekly_credits", REPUBLIC_WEEKLY_WAGE_CREDITS)
            if isinstance(profile.get("republic_wage", {}), dict)
            else REPUBLIC_WEEKLY_WAGE_CREDITS
        ),
        "kills": int(profile.get("kills", 0) or 0),
        "droid_kills": int(profile.get("droid_kills", 0) or 0),
        "vehicle_kills": int(profile.get("vehicle_kills", 0) or 0),
        "aircraft_kills": int(profile.get("aircraft_kills", 0) or 0),
        "friendly_kills": int(profile.get("friendly_kills", 0) or 0),
        "support_score": int(profile.get("support_score", 0) or 0),
        "revives": int(profile.get("revives", 0) or 0),
        "heals": int(profile.get("heals", 0) or 0),
        "repairs": int(profile.get("repairs", 0) or 0),
        "resupplies": int(profile.get("resupplies", 0) or 0),
        "transport_assists": int(profile.get("transport_assists", 0) or 0),
        "objective_support": int(profile.get("objective_support", 0) or 0),
        "deaths": int(profile.get("deaths", 0) or 0),
        "deployments": deployments,
        "deployment_attempts": deployment_attempts,
        "deployments_completed": deployments_completed,
        "deployments_failed": deployments_failed,
        "deployment_xp_adjustments": int(profile.get("deployment_xp_adjustments", 0) or 0),
        "playtime_seconds": int(profile.get("playtime_seconds", 0) or 0),
        "achievement_count": len(achievements),
        "campaign_count": len(campaigns),
        "quest_count": len(quests),
        "completed_quest_count": len(completed_quests),
        "lore_count": int(profile.get("lore_count", 0) or 0),
        "latest_campaign": {
            "id": latest_campaign.get("id", "") if latest_campaign else "",
            "name": latest_campaign.get("name", "") if latest_campaign else "",
            "planet": latest_campaign.get("planet", "") if latest_campaign else "",
            "deployment_count": latest_campaign.get("deployment_count", 0) if latest_campaign else 0,
            "last_completed_at": latest_campaign.get("last_completed_at", 0) if latest_campaign else 0,
        },
        "latest_deployment": {
            "id": latest_deployment.get("id", "") if latest_deployment else "",
            "mission_name": latest_deployment.get("mission_name", "") if latest_deployment else "",
            "planet": latest_deployment.get("planet", "") if latest_deployment else "",
            "completed_at": latest_deployment.get("completed_at", 0) if latest_deployment else 0,
            "ended_at": latest_deployment.get("ended_at", latest_deployment.get("completed_at", 0)) if latest_deployment else 0,
            "outcome": latest_deployment.get("outcome", "") if latest_deployment else "",
            "awards": latest_deployment.get("awards", []) if latest_deployment else [],
        },
        "latest_achievement": {
            "id": latest_achievement.get("id", "") if latest_achievement else "",
            "name": latest_achievement.get("name", "") if latest_achievement else "",
            "unlocked_at": latest_achievement.get("unlocked_at", 0) if latest_achievement else 0,
        },
        "latest_quest": {
            "id": latest_quest.get("id", "") if latest_quest else "",
            "title": latest_quest.get("title", "") if latest_quest else "",
            "category": latest_quest.get("category", "") if latest_quest else "",
            "state": latest_quest.get("state", "") if latest_quest else "",
            "updated_at": latest_quest.get("updated_at", 0) if latest_quest else 0,
        },
        "next_actions": next_actions[:4],
        "authority": (
            "Read-only TCWA3 backend summary. Signed official server events and authenticated Root Storm/JT sync "
            "are the only sources allowed to populate progression stats."
        ),
    }


def profile_for(db: sqlite3.Connection, steam_id: str) -> dict[str, Any] | None:
    row = db.execute(
        """
        SELECT u.steam_id,
               COALESCE(NULLIF(u.arma_profile_name, ''), NULLIF(u.roster_name, ''), u.display_name) AS display_name,
               u.unit, u.rank, u.rostered, u.bio, u.profile_public, u.avatar_id, u.verified_at, u.updated_at,
               s.kills, s.deaths, s.credits, s.xp, s.missions, s.playtime_seconds,
               s.droid_kills, s.vehicle_kills, s.aircraft_kills, s.friendly_kills,
               s.support_score, s.revives, s.heals, s.repairs, s.resupplies,
               s.transport_assists, s.objective_support,
               s.kamino_visits, s.geonosis_missions, s.friendly_fire_missions,
               s.high_death_missions, s.perfect_missions, s.deployment_attempts,
               s.deployments_completed, s.deployments_failed, s.deployment_xp_adjustments,
               s.level_floor, s.level_floor_xp, s.last_republic_wage_week, s.last_republic_wage_at,
               s.republic_wages_received, s.republic_wage_credits
        FROM users u JOIN stats s ON s.steam_id = u.steam_id
        WHERE u.steam_id = ?
        """,
        (steam_id,),
    ).fetchone()
    if row is None:
        return None
    avatar = avatar_by_id(row["avatar_id"])
    level = max(level_for_xp(row["xp"]), int(row["level_floor"] or 0))
    current_xp_value, next_xp_value = progression_xp_bounds(
        row["xp"],
        level,
        row["level_floor"],
        row["level_floor_xp"],
    )
    unlocked_rows = db.execute(
        "SELECT achievement_id, unlocked_at, acknowledged_at FROM achievements WHERE steam_id = ? ORDER BY unlocked_at DESC",
        (steam_id,),
    ).fetchall()
    unlocked = []
    unacknowledged = []
    for achievement in unlocked_rows:
        payload = achievement_payload(
            achievement["achievement_id"],
            achievement["unlocked_at"],
            achievement["acknowledged_at"],
        )
        unlocked.append(payload)
        if achievement["acknowledged_at"] is None:
            unacknowledged.append(payload)
    profile = {
        "steam_id": row["steam_id"],
        "display_name": public_display_name(row["display_name"]),
        "unit": row["unit"] or "",
        "rank": row["rank"] or "",
        "rostered": bool(row["rostered"]),
        "bio": row["bio"] or "",
        "profile_public": bool(row["profile_public"]),
        "avatar_id": avatar["id"],
        "avatar_name": avatar["name"],
        "avatar_url": avatar["url"],
        "verified": row["verified_at"] is not None,
        "level": level,
        "xp": row["xp"],
        "current_level_xp": current_xp_value,
        "next_level_xp": next_xp_value,
        "credits": row["credits"],
        "republic_wage": republic_wage_status(db, row["steam_id"]),
        "kills": row["kills"],
        "deaths": row["deaths"],
        "missions": row["missions"],
        "deployments": max(row["deployment_attempts"], row["missions"]),
        "deployment_attempts": row["deployment_attempts"],
        "deployments_completed": max(row["deployments_completed"], row["missions"]),
        "deployments_failed": row["deployments_failed"],
        "deployment_xp_adjustments": row["deployment_xp_adjustments"],
        "level_floor": row["level_floor"],
        "level_floor_xp": row["level_floor_xp"],
        "playtime_seconds": row["playtime_seconds"],
        "droid_kills": row["droid_kills"],
        "vehicle_kills": row["vehicle_kills"],
        "aircraft_kills": row["aircraft_kills"],
        "friendly_kills": row["friendly_kills"],
        "support_score": row["support_score"],
        "revives": row["revives"],
        "heals": row["heals"],
        "repairs": row["repairs"],
        "resupplies": row["resupplies"],
        "transport_assists": row["transport_assists"],
        "objective_support": row["objective_support"],
        "kamino_visits": row["kamino_visits"],
        "geonosis_missions": row["geonosis_missions"],
        "friendly_fire_missions": row["friendly_fire_missions"],
        "high_death_missions": row["high_death_missions"],
        "perfect_missions": row["perfect_missions"],
        "achievements": unlocked,
        "unacknowledged_achievements": unacknowledged,
        "campaigns": campaign_log_for(db, steam_id),
        "quests": quest_progress_for(db, steam_id),
        "updated_at": row["updated_at"],
    }
    profile["inventory"] = marketplace_inventory_for(db, steam_id)
    discord_row = db.execute(
        "SELECT * FROM discord_links WHERE steam_id = ? ORDER BY updated_at DESC LIMIT 1",
        (steam_id,),
    ).fetchone()
    profile["discord"] = discord_link_payload(discord_row, include_roles=False)
    profile["external_sources"] = roster_bridge_status(db)
    attach_tcw_tools_profile_snapshot(profile)
    profile["service_record"] = service_record_for_profile(profile)
    return profile


def achievement_payload(achievement_id: str, unlocked_at: int, acknowledged_at: int | None = None) -> dict[str, Any]:
    definition = ACHIEVEMENTS.get(achievement_id, {})
    payload = {
        "id": achievement_id,
        "name": definition.get("name", achievement_id),
        "description": definition.get("description", ""),
        "unlocked_at": unlocked_at,
    }
    if acknowledged_at is not None:
        payload["acknowledged_at"] = acknowledged_at
    return payload


def campaign_log_for(db: sqlite3.Connection, steam_id: str) -> list[dict[str, Any]]:
    rows = db.execute(
        """
        SELECT deployment_id, campaign_id, campaign_name, mission_name, planet,
               official_server, completed_at, outcome, started_at, ended_at,
               xp_earned, xp_penalty, awards_json
        FROM campaign_deployments
        WHERE steam_id = ?
        ORDER BY COALESCE(NULLIF(ended_at, 0), completed_at, started_at) DESC, deployment_id DESC
        LIMIT 80
        """,
        (steam_id,),
    ).fetchall()
    campaigns_by_id: dict[str, dict[str, Any]] = {}
    ordered_ids: list[str] = []
    for row in rows:
        campaign_id = row["campaign_id"]
        if campaign_id not in campaigns_by_id:
            campaigns_by_id[campaign_id] = {
                "id": campaign_id,
                "name": row["campaign_name"],
                "planet": row["planet"],
                "deployment_count": 0,
                "completed_count": 0,
                "failed_count": 0,
                "last_completed_at": row["completed_at"],
                "deployments": [],
            }
            ordered_ids.append(campaign_id)
        try:
            awards = json.loads(row["awards_json"] or "[]")
        except json.JSONDecodeError:
            awards = []
        outcome = str(row["outcome"] or "completed")
        campaigns_by_id[campaign_id]["deployment_count"] += 1
        if outcome == "completed":
            campaigns_by_id[campaign_id]["completed_count"] += 1
        elif outcome == "failed":
            campaigns_by_id[campaign_id]["failed_count"] += 1
        campaigns_by_id[campaign_id]["deployments"].append(
            {
                "id": row["deployment_id"],
                "mission_name": row["mission_name"],
                "planet": row["planet"],
                "official_server": row["official_server"],
                "outcome": outcome,
                "started_at": row["started_at"],
                "ended_at": row["ended_at"] or row["completed_at"],
                "completed_at": row["completed_at"],
                "xp_earned": row["xp_earned"],
                "xp_penalty": row["xp_penalty"],
                "awards": awards if isinstance(awards, list) else [],
            }
        )
    return [campaigns_by_id[campaign_id] for campaign_id in ordered_ids]


def clean_quest_text(value: Any, fallback: str = "", limit: int = MAX_QUEST_TEXT_CHARS) -> str:
    text = str(value or "").strip()
    text = re.sub(r"\s+", " ", text)
    return (text or fallback)[:limit]


def clean_quest_id(value: Any) -> str:
    text = str(value or "").strip()
    text = re.sub(r"[^A-Za-z0-9_.:-]+", "_", text).strip("_")
    return text[:96]


def quest_container(event: dict[str, Any]) -> dict[str, Any]:
    quest = event.get("quest")
    if isinstance(quest, dict):
        return quest
    return event


def quest_event_id(event: dict[str, Any]) -> str:
    quest = quest_container(event)
    return clean_quest_id(
        first_non_empty(
            quest.get("quest_id"),
            quest.get("id"),
            event.get("quest_id"),
            event.get("tcw_quest_id"),
        )
    )


def quest_event_state(event: dict[str, Any]) -> str:
    quest = quest_container(event)
    state = first_non_empty(quest.get("state"), event.get("quest_state"), event.get("state"))
    event_type = str(event.get("event_type") or event.get("type") or "").strip().lower()
    if not state and event_type in {"quest_complete", "quest_completed", "quest_success", "quest_succeeded"}:
        state = "SUCCEEDED"
    if not state and event_boolean(event, ("quest_completed", "quest_complete", "completed")):
        state = "SUCCEEDED"
    state = re.sub(r"[^A-Za-z_]+", "_", state or "ASSIGNED").strip("_").upper()
    aliases = {"COMPLETE": "SUCCEEDED", "COMPLETED": "SUCCEEDED", "SUCCESS": "SUCCEEDED"}
    return aliases.get(state, state or "ASSIGNED")[:32]


def quest_progress_for(db: sqlite3.Connection, steam_id: str) -> list[dict[str, Any]]:
    rows = db.execute(
        """
        SELECT quest_id, title, category, state, stage_index, stage_title, stage_description,
               lore_json, history_json, official_server, started_at, updated_at, completed_at
        FROM quest_progress
        WHERE steam_id = ?
        ORDER BY COALESCE(completed_at, updated_at) DESC, updated_at DESC, quest_id
        LIMIT 120
        """,
        (steam_id,),
    ).fetchall()
    quests: list[dict[str, Any]] = []
    for row in rows:
        try:
            lore = json.loads(row["lore_json"] or "[]")
        except json.JSONDecodeError:
            lore = []
        try:
            history = json.loads(row["history_json"] or "[]")
        except json.JSONDecodeError:
            history = []
        quests.append(
            {
                "id": row["quest_id"],
                "title": row["title"],
                "category": row["category"],
                "state": row["state"],
                "stage_index": row["stage_index"],
                "stage_title": row["stage_title"],
                "stage_description": row["stage_description"],
                "lore": lore if isinstance(lore, list) else [],
                "history": history if isinstance(history, list) else [],
                "official_server": row["official_server"],
                "started_at": row["started_at"],
                "updated_at": row["updated_at"],
                "completed_at": row["completed_at"],
            }
        )
    return quests


def record_quest_progress(
    db: sqlite3.Connection,
    steam_id: str,
    event_id: str,
    official_server: str,
    event: dict[str, Any],
    timestamp: int,
) -> bool:
    quest = quest_container(event)
    quest_id = quest_event_id(event)
    if not quest_id:
        return False

    state = quest_event_state(event)
    title = clean_quest_text(first_non_empty(quest.get("title"), quest.get("name"), event.get("quest_title")), quest_id, 160)
    category = clean_quest_text(first_non_empty(quest.get("category"), event.get("quest_category")), "Main", 64)
    stage_payload = quest.get("stage") if isinstance(quest.get("stage"), dict) else {}
    try:
        stage_index = int(float(first_non_empty(quest.get("stage_index"), event.get("stage_index"), stage_payload.get("index"), 0)))
    except (TypeError, ValueError):
        stage_index = 0
    stage_title = clean_quest_text(
        first_non_empty(quest.get("stage_title"), event.get("stage_title"), stage_payload.get("title"), stage_payload.get("name")),
        "Current stage",
        160,
    )
    stage_description = clean_quest_text(
        first_non_empty(
            quest.get("stage_description"),
            event.get("stage_description"),
            stage_payload.get("description"),
            quest.get("description"),
            event.get("quest_description"),
        ),
        "",
        600,
    )
    lore_text = clean_quest_text(
        first_non_empty(
            quest.get("lore"),
            quest.get("lore_entry"),
            quest.get("journal_entry"),
            event.get("lore"),
            event.get("lore_entry"),
            event.get("journal_entry"),
        ),
        "",
        MAX_QUEST_TEXT_CHARS,
    )

    existing = db.execute(
        "SELECT started_at, lore_json, history_json FROM quest_progress WHERE steam_id = ? AND quest_id = ?",
        (steam_id, quest_id),
    ).fetchone()
    started_at = int(existing["started_at"]) if existing else timestamp
    try:
        lore_entries = json.loads(existing["lore_json"] or "[]") if existing else []
    except json.JSONDecodeError:
        lore_entries = []
    try:
        history = json.loads(existing["history_json"] or "[]") if existing else []
    except json.JSONDecodeError:
        history = []
    if not isinstance(lore_entries, list):
        lore_entries = []
    if not isinstance(history, list):
        history = []

    if lore_text and all(entry.get("text") != lore_text for entry in lore_entries if isinstance(entry, dict)):
        lore_entries.append({"text": lore_text, "title": stage_title, "recorded_at": timestamp})
        lore_entries = lore_entries[-MAX_QUEST_HISTORY:]

    history.append(
        {
            "event_id": event_id,
            "state": state,
            "stage_index": stage_index,
            "stage_title": stage_title,
            "stage_description": stage_description,
            "lore": lore_text,
            "official_server": official_server,
            "recorded_at": timestamp,
        }
    )
    history = history[-MAX_QUEST_HISTORY:]
    completed_at = timestamp if state in {"SUCCEEDED", "FAILED", "CANCELED"} else None

    db.execute(
        """
        INSERT INTO quest_progress
            (steam_id, quest_id, title, category, state, stage_index, stage_title,
             stage_description, lore_json, history_json, official_server,
             started_at, updated_at, completed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(steam_id, quest_id) DO UPDATE SET
            title = excluded.title,
            category = excluded.category,
            state = excluded.state,
            stage_index = excluded.stage_index,
            stage_title = excluded.stage_title,
            stage_description = excluded.stage_description,
            lore_json = excluded.lore_json,
            history_json = excluded.history_json,
            official_server = excluded.official_server,
            updated_at = excluded.updated_at,
            completed_at = COALESCE(excluded.completed_at, quest_progress.completed_at)
        """,
        (
            steam_id,
            quest_id,
            title,
            category,
            state,
            stage_index,
            stage_title,
            stage_description,
            json.dumps(lore_entries, ensure_ascii=False),
            json.dumps(history, ensure_ascii=False),
            official_server,
            started_at,
            timestamp,
            completed_at,
        ),
    )
    return True


def record_campaign_deployment(
    db: sqlite3.Connection,
    steam_id: str,
    deployment_id: str,
    official_server: str,
    event: dict[str, Any],
    achievement_ids: list[str],
    completed_at: int,
    outcome: str = "completed",
    xp_earned_delta: int = 0,
    xp_penalty: int = 0,
) -> None:
    campaign = campaign_for_event(event)
    awards = [achievement_payload(achievement_id, completed_at) for achievement_id in achievement_ids]
    clean_outcome = outcome if outcome in {"started", "completed", "failed"} else "completed"
    started_at = completed_at
    ended_at = completed_at if clean_outcome in {"completed", "failed"} else 0
    completion_time = completed_at if clean_outcome == "completed" else 0
    db.execute(
        """
        INSERT INTO campaign_deployments
            (deployment_id, steam_id, campaign_id, campaign_name, mission_name,
             planet, official_server, completed_at, outcome, started_at, ended_at,
             xp_earned, xp_penalty, awards_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(deployment_id) DO UPDATE SET
            campaign_id = excluded.campaign_id,
            campaign_name = excluded.campaign_name,
            mission_name = excluded.mission_name,
            planet = excluded.planet,
            official_server = excluded.official_server,
            completed_at = CASE
                WHEN excluded.completed_at > 0 THEN excluded.completed_at
                ELSE campaign_deployments.completed_at END,
            outcome = CASE
                WHEN excluded.outcome = 'started' AND campaign_deployments.outcome IN ('completed', 'failed')
                THEN campaign_deployments.outcome
                ELSE excluded.outcome END,
            started_at = CASE
                WHEN campaign_deployments.started_at > 0 THEN campaign_deployments.started_at
                ELSE excluded.started_at END,
            ended_at = CASE
                WHEN excluded.ended_at > 0 THEN excluded.ended_at
                ELSE campaign_deployments.ended_at END,
            xp_earned = campaign_deployments.xp_earned + excluded.xp_earned,
            xp_penalty = MAX(campaign_deployments.xp_penalty, excluded.xp_penalty),
            awards_json = CASE
                WHEN excluded.awards_json != '[]' THEN excluded.awards_json
                ELSE campaign_deployments.awards_json END
        """,
        (
            deployment_id,
            steam_id,
            campaign["id"],
            campaign["name"],
            mission_name_for_event(event, campaign),
            campaign["planet"],
            official_server,
            completion_time,
            clean_outcome,
            started_at,
            ended_at,
            max(0, int(xp_earned_delta or 0)),
            max(0, int(xp_penalty or 0)),
            json.dumps(awards, ensure_ascii=False),
        ),
    )


def find_deployment_row(db: sqlite3.Connection, deployment_id: str) -> sqlite3.Row | None:
    if not deployment_id:
        return None
    return db.execute(
        "SELECT * FROM campaign_deployments WHERE deployment_id = ?",
        (deployment_id,),
    ).fetchone()


def find_active_deployment(
    db: sqlite3.Connection,
    steam_id: str,
    official_server: str,
    deployment_id: str = "",
) -> sqlite3.Row | None:
    row = find_deployment_row(db, deployment_id)
    if row is not None and row["outcome"] == "started":
        return row
    return db.execute(
        """
        SELECT *
        FROM campaign_deployments
        WHERE steam_id = ?
          AND official_server = ?
          AND outcome = 'started'
        ORDER BY started_at DESC, deployment_id DESC
        LIMIT 1
        """,
        (steam_id, official_server),
    ).fetchone()


def add_xp_to_active_deployment(
    db: sqlite3.Connection,
    steam_id: str,
    official_server: str,
    deployment_id: str,
    xp_amount: int,
) -> None:
    xp_amount = max(0, int(xp_amount or 0))
    if xp_amount <= 0:
        return
    row = find_active_deployment(db, steam_id, official_server, deployment_id)
    if row is None:
        return
    db.execute(
        "UPDATE campaign_deployments SET xp_earned = xp_earned + ? WHERE deployment_id = ?",
        (xp_amount, row["deployment_id"]),
    )


def marketplace_inventory_for(db: sqlite3.Connection, steam_id: str) -> list[dict[str, Any]]:
    rows = db.execute(
        """
        SELECT item_id, category, class_name, cost, purchased_at
        FROM marketplace_purchases
        WHERE steam_id = ?
        ORDER BY purchased_at DESC, item_id ASC
        """,
        (steam_id,),
    ).fetchall()
    return [
        {
            "item_id": row["item_id"],
            "category": row["category"],
            "class_name": row["class_name"],
            "cost": row["cost"],
            "purchased_at": row["purchased_at"],
        }
        for row in rows
    ]


def clean_marketplace_check_item_ids(value: Any) -> list[str]:
    if not isinstance(value, list):
        raise ValueError("item_ids must be a list")
    item_ids: list[str] = []
    for raw_item in value:
        item_id = re.sub(r"[^a-z0-9_\-]+", "-", str(raw_item).strip().lower()).strip("-")[:80]
        if item_id and item_id not in item_ids:
            item_ids.append(item_id)
        if len(item_ids) >= 100:
            break
    if not item_ids:
        raise ValueError("item_ids must contain at least one item")
    return item_ids


def marketplace_ownership_check(
    db: sqlite3.Connection,
    steam_id: str,
    item_ids: list[str],
) -> tuple[HTTPStatus, dict[str, Any]]:
    if not STEAM_ID_PATTERN.fullmatch(steam_id):
        return HTTPStatus.BAD_REQUEST, {"error": "invalid_steam_id"}
    profile_exists = db.execute(
        """
        SELECT 1
        FROM users u JOIN stats s ON s.steam_id = u.steam_id
        WHERE u.steam_id = ?
        """,
        (steam_id,),
    ).fetchone()
    if profile_exists is None:
        return HTTPStatus.NOT_FOUND, {"error": "profile_not_found", "message": "Profile stats were not found."}
    placeholders = ",".join("?" for _ in item_ids)
    rows = db.execute(
        f"""
        SELECT item_id, category, class_name, cost, purchased_at
        FROM marketplace_purchases
        WHERE steam_id = ? AND item_id IN ({placeholders})
        """,
        [steam_id, *item_ids],
    ).fetchall()
    owned_by_id = {row["item_id"]: row for row in rows}
    items: list[dict[str, Any]] = []
    for item_id in item_ids:
        row = owned_by_id.get(item_id)
        if row is None:
            items.append({"item_id": item_id, "owned": False})
            continue
        items.append(
            {
                "item_id": item_id,
                "owned": True,
                "category": row["category"],
                "class_name": row["class_name"],
                "purchased_at": row["purchased_at"],
            }
        )
    return HTTPStatus.OK, {
        "verified": True,
        "steam_id": steam_id,
        "items": items,
        "owned_item_ids": [item["item_id"] for item in items if item["owned"]],
        "missing_item_ids": [item["item_id"] for item in items if not item["owned"]],
    }


def marketplace_match_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().casefold()


def marketplace_display_list(values: list[Any], conjunction: str = "or") -> str:
    clean_values = [str(value) for value in values if str(value)]
    if not clean_values:
        return ""
    if len(clean_values) == 1:
        return clean_values[0]
    return f"{', '.join(clean_values[:-1])} {conjunction} {clean_values[-1]}"


def marketplace_achievement_label(achievement_id: str) -> str:
    return str(ACHIEVEMENTS.get(achievement_id, {}).get("name", achievement_id))


def marketplace_requirement_status(profile: dict[str, Any] | None, item: dict[str, Any]) -> dict[str, Any]:
    requirements = item.get("requirements", {})
    if not isinstance(requirements, dict) or not requirements:
        return {"eligible": True, "missing": []}

    missing: list[dict[str, Any]] = []
    if profile is None:
        return {
            "eligible": False,
            "missing": [
                {
                    "type": "profile",
                    "message": "Requires a signed-in TCWA3 profile.",
                }
            ],
        }

    min_level = bounded_int(requirements.get("min_level"), 0)
    if min_level > 1 and int(profile.get("level", 1)) < min_level:
        missing.append(
            {
                "type": "level",
                "required": min_level,
                "current": int(profile.get("level", 1)),
                "message": f"Requires level {min_level}.",
            }
        )

    required_achievements = requirements.get("achievements", [])
    if isinstance(required_achievements, list) and required_achievements:
        owned_achievements = {
            str(achievement.get("id", ""))
            for achievement in profile.get("achievements", [])
            if isinstance(achievement, dict)
        }
        missing_achievements = [
            str(achievement_id)
            for achievement_id in required_achievements
            if str(achievement_id) not in owned_achievements
        ]
        if missing_achievements:
            labels = [marketplace_achievement_label(achievement_id) for achievement_id in missing_achievements]
            missing.append(
                {
                    "type": "achievement",
                    "required": missing_achievements,
                    "message": f"Requires achievement: {marketplace_display_list(labels, 'and')}.",
                }
            )

    required_ranks = requirements.get("ranks", [])
    if isinstance(required_ranks, list) and required_ranks:
        allowed_ranks = {marketplace_match_text(rank) for rank in required_ranks}
        current_rank = str(profile.get("rank", "") or "")
        if marketplace_match_text(current_rank) not in allowed_ranks:
            missing.append(
                {
                    "type": "rank",
                    "required": [str(rank) for rank in required_ranks],
                    "current": current_rank,
                    "message": f"Requires rank: {marketplace_display_list([str(rank) for rank in required_ranks])}.",
                }
            )

    required_units = requirements.get("units", [])
    if isinstance(required_units, list) and required_units:
        allowed_units = {marketplace_match_text(unit) for unit in required_units}
        current_unit = str(profile.get("unit", "") or "")
        if marketplace_match_text(current_unit) not in allowed_units:
            missing.append(
                {
                    "type": "unit",
                    "required": [str(unit) for unit in required_units],
                    "current": current_unit,
                    "message": f"Requires unit: {marketplace_display_list([str(unit) for unit in required_units])}.",
                }
            )

    required_campaigns = requirements.get("campaigns", [])
    if isinstance(required_campaigns, list) and required_campaigns:
        completed_campaigns = {
            str(campaign.get("id", ""))
            for campaign in profile.get("campaigns", [])
            if isinstance(campaign, dict)
        }
        missing_campaigns = [
            str(campaign_id)
            for campaign_id in required_campaigns
            if str(campaign_id) not in completed_campaigns
        ]
        if missing_campaigns:
            missing.append(
                {
                    "type": "campaign",
                    "required": missing_campaigns,
                    "message": f"Requires campaign: {marketplace_display_list(missing_campaigns, 'and')}.",
                }
            )

    return {"eligible": not missing, "missing": missing}


def marketplace_catalog_for_player(db: sqlite3.Connection | None = None, steam_id: str | None = None) -> dict[str, Any]:
    catalog = load_marketplace_catalog()
    items = [dict(item) for item in catalog["items"]]
    active_item_count = marketplace_active_item_count(items)
    payload = {
        "categories": [dict(category) for category in catalog["categories"]],
        "items": items,
        "active_item_count": active_item_count,
        "marketplace_open": active_item_count > 0,
        "policy": dict(MARKETPLACE_POLICY),
        "updated_at": now(),
    }
    if db is not None and steam_id:
        owned_rows = db.execute(
            "SELECT item_id FROM marketplace_purchases WHERE steam_id = ?",
            (steam_id,),
        ).fetchall()
        owned_ids = {row["item_id"] for row in owned_rows}
        for item in payload["items"]:
            item["owned"] = item["id"] in owned_ids
        profile = profile_for(db, steam_id)
        for item in payload["items"]:
            requirement_status = marketplace_requirement_status(profile, item)
            item["eligible"] = bool(requirement_status["eligible"])
            item["requirement_status"] = requirement_status
        payload["credits"] = int(profile["credits"]) if profile else 0
        payload["owned_item_ids"] = sorted(owned_ids)
    return payload


def purchase_marketplace_item(db: sqlite3.Connection, steam_id: str, item_id: str) -> tuple[HTTPStatus, dict[str, Any]]:
    item = marketplace_item_by_id(item_id)
    if item is None:
        return HTTPStatus.NOT_FOUND, {"error": "item_not_found", "message": "That marketplace item is not available."}
    if not bool(item.get("enabled", True)):
        return HTTPStatus.CONFLICT, {"error": "item_disabled", "message": "That marketplace item is not currently purchasable."}
    existing = db.execute(
        "SELECT item_id FROM marketplace_purchases WHERE steam_id = ? AND item_id = ?",
        (steam_id, item["id"]),
    ).fetchone()
    if existing is not None and bool(item.get("one_time", True)):
        return HTTPStatus.CONFLICT, {"error": "already_owned", "message": "You already own this item."}
    profile = profile_for(db, steam_id)
    if profile is None:
        return HTTPStatus.NOT_FOUND, {"error": "profile_not_found", "message": "Profile stats were not found."}
    requirement_status = marketplace_requirement_status(profile, item)
    if not bool(requirement_status["eligible"]):
        return HTTPStatus.FORBIDDEN, {
            "error": "requirements_not_met",
            "message": "You do not meet the requirements for this marketplace item.",
            "requirements": requirement_status,
        }
    cost = int(item.get("cost", 0))
    if int(profile.get("credits", 0)) < cost:
        return HTTPStatus.CONFLICT, {"error": "not_enough_credits", "message": "You do not have enough credits for this item."}
    timestamp = now()
    db.execute(
        "UPDATE stats SET credits = credits - ? WHERE steam_id = ?",
        (cost, steam_id),
    )
    db.execute(
        """
        INSERT OR REPLACE INTO marketplace_purchases
            (steam_id, item_id, category, class_name, cost, purchased_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (steam_id, item["id"], item["category"], item.get("class_name", ""), cost, timestamp),
    )
    profile = profile_for(db, steam_id)
    safe_write_player_profile_snapshot(db, steam_id)
    return HTTPStatus.OK, {
        "status": "purchased",
        "purchase": {
            "item_id": item["id"],
            "category": item["category"],
            "class_name": item.get("class_name", ""),
            "cost": cost,
            "purchased_at": timestamp,
        },
        "profile": profile,
        "marketplace": marketplace_catalog_for_player(db, steam_id),
    }


def public_profile_card(profile: dict[str, Any], extra: dict[str, Any] | None = None) -> dict[str, Any]:
    campaigns = profile.get("campaigns", [])
    latest_campaign = campaigns[0] if campaigns else {}
    quests = profile.get("quests", [])
    completed_quests = [
        quest for quest in quests
        if isinstance(quest, dict) and str(quest.get("state", "")).upper() in {"SUCCEEDED", "FAILED", "CANCELED"}
    ]
    latest_quest = quests[0] if quests else {}
    card = {
        "steam_id": profile["steam_id"],
        "display_name": profile["display_name"],
        "unit": profile["unit"],
        "rank": profile["rank"],
        "rostered": profile["rostered"],
        "verified": profile["verified"],
        "bio": profile["bio"],
        "avatar_id": profile["avatar_id"],
        "avatar_name": profile["avatar_name"],
        "avatar_url": profile["avatar_url"],
        "level": profile["level"],
        "credits": profile["credits"],
        "republic_wage": profile.get("republic_wage", {}),
        "current_level_xp": profile.get("current_level_xp", 0),
        "next_level_xp": profile.get("next_level_xp", 500),
        "xp_into_level": profile.get("xp_into_level", 0),
        "xp_remaining": profile.get("xp_remaining", 0),
        "xp_progress_percent": profile.get("xp_progress_percent", 0),
        "kills": profile["kills"],
        "droid_kills": profile["droid_kills"],
        "vehicle_kills": profile.get("vehicle_kills", 0),
        "aircraft_kills": profile.get("aircraft_kills", 0),
        "friendly_kills": profile.get("friendly_kills", 0),
        "support_score": profile.get("support_score", 0),
        "revives": profile.get("revives", 0),
        "heals": profile.get("heals", 0),
        "repairs": profile.get("repairs", 0),
        "resupplies": profile.get("resupplies", 0),
        "transport_assists": profile.get("transport_assists", 0),
        "objective_support": profile.get("objective_support", 0),
        "deaths": profile["deaths"],
        "missions": profile["missions"],
        "deployments": profile.get("deployments", profile["missions"]),
        "deployment_attempts": profile.get("deployment_attempts", profile.get("deployments", profile["missions"])),
        "deployments_completed": profile.get("deployments_completed", profile["missions"]),
        "deployments_failed": profile.get("deployments_failed", 0),
        "deployment_xp_adjustments": profile.get("deployment_xp_adjustments", 0),
        "playtime_seconds": profile["playtime_seconds"],
        "geonosis_missions": profile["geonosis_missions"],
        "achievement_count": len(profile["achievements"]),
        "recent_achievements": profile["achievements"][:3],
        "campaign_count": len(campaigns),
        "latest_campaign": latest_campaign.get("name", "") if isinstance(latest_campaign, dict) else "",
        "quest_count": len(quests),
        "completed_quest_count": len(completed_quests),
        "lore_count": profile.get("lore_count", 0),
        "latest_quest": latest_quest.get("title", "") if isinstance(latest_quest, dict) else "",
        "profile_schema": profile.get("profile_schema", "tcwa3_profile_v1"),
        "source": profile.get("source", "tcwa3_backend"),
        "revision": profile.get("revision", ""),
        "updated_at": profile["updated_at"],
        "service_record": profile.get("service_record", service_record_for_profile(profile)),
    }
    if extra:
        card.update(extra)
    return card


def clean_profile_search(value: Any) -> str:
    """Normalise public directory searches without exposing expensive wildcards."""
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    return text[:80]


def sql_like_pattern(value: str) -> str:
    """Build a LIKE pattern while treating user-entered wildcard characters as text."""
    escaped = value.lower().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def public_profile_detail(db: sqlite3.Connection, steam_id: str) -> dict[str, Any] | None:
    profile = profile_for(db, steam_id)
    if not profile or not profile["profile_public"] or not profile["verified"]:
        return None
    card = public_profile_card(profile)
    card["achievements"] = profile["achievements"]
    card["campaigns"] = profile["campaigns"]
    card["quests"] = profile["quests"]
    return card


def list_public_profiles(
    db: sqlite3.Connection,
    unit_filter: str = "",
    sort_mode: str = "active",
    search: str = "",
    page: int = 1,
    limit: int = PUBLIC_PROFILE_DEFAULT_LIMIT,
) -> dict[str, Any]:
    page = max(1, int(page or 1))
    limit = max(1, min(PUBLIC_PROFILE_MAX_LIMIT, int(limit or PUBLIC_PROFILE_DEFAULT_LIMIT)))
    offset = (page - 1) * limit
    where = """
        FROM users u
        JOIN (
            SELECT steam_id, MAX(xp) AS xp, MAX(missions) AS missions
            FROM stats
            GROUP BY steam_id
        ) s ON s.steam_id = u.steam_id
        WHERE u.profile_public = 1
          AND u.verified_at IS NOT NULL
    """
    params: list[Any] = []
    if unit_filter:
        where += " AND LOWER(COALESCE(u.unit, '')) = LOWER(?)"
        params.append(unit_filter)
    search = clean_profile_search(search)
    if search:
        search_like = sql_like_pattern(search)
        where += """
          AND (
            LOWER(COALESCE(u.display_name, '')) LIKE ? ESCAPE '\\'
            OR LOWER(COALESCE(u.arma_profile_name, '')) LIKE ? ESCAPE '\\'
            OR LOWER(COALESCE(u.roster_name, '')) LIKE ? ESCAPE '\\'
            OR LOWER(COALESCE(u.unit, '')) LIKE ? ESCAPE '\\'
            OR LOWER(COALESCE(u.rank, '')) LIKE ? ESCAPE '\\'
            OR LOWER(COALESCE(u.bio, '')) LIKE ? ESCAPE '\\'
          )
        """
        params.extend([search_like] * 6)
    if sort_mode == "legion":
        order_by = " ORDER BY LOWER(COALESCE(u.unit, 'zzzz')), LOWER(COALESCE(u.rank, 'zzzz')), LOWER(u.display_name), u.steam_id"
    elif sort_mode == "level":
        order_by = " ORDER BY s.xp DESC, s.missions DESC, u.updated_at DESC, u.steam_id"
    else:
        order_by = " ORDER BY u.updated_at DESC, s.missions DESC, u.steam_id"
    total = int(db.execute(f"SELECT COUNT(*) AS total {where}", params).fetchone()["total"])
    rows = db.execute(
        f"SELECT u.steam_id {where}{order_by} LIMIT ? OFFSET ?",
        [*params, limit, offset],
    ).fetchall()
    profiles: list[dict[str, Any]] = []
    for row in rows:
        profile = public_profile_detail(db, row["steam_id"])
        if profile:
            profile.pop("achievements", None)
            profile.pop("campaigns", None)
            profiles.append(profile)
    return {
        "profiles": profiles,
        "pagination": {
            "page": page,
            "limit": limit,
            "total": total,
            "has_more": offset + len(profiles) < total,
        },
    }


def public_profile_units(db: sqlite3.Connection) -> list[str]:
    rows = db.execute(
        """
        SELECT DISTINCT unit
        FROM users
        WHERE profile_public = 1
          AND verified_at IS NOT NULL
          AND unit IS NOT NULL
          AND unit != ''
        ORDER BY LOWER(unit)
        """
    ).fetchall()
    return [row["unit"] for row in rows]


def roster_member_units(db: sqlite3.Connection) -> list[str]:
    rows = db.execute(
        """
        SELECT DISTINCT unit
        FROM roster_members
        WHERE unit IS NOT NULL
          AND unit != ''
        ORDER BY LOWER(unit)
        """
    ).fetchall()
    return [row["unit"] for row in rows]


def roster_bridge_status(db: sqlite3.Connection) -> dict[str, Any]:
    roster = db.execute(
        """
        SELECT COUNT(*) AS members,
               SUM(CASE WHEN steam_id IS NOT NULL AND steam_id != '' THEN 1 ELSE 0 END) AS steam_linked,
               SUM(CASE WHEN discord_id IS NOT NULL AND discord_id != '' THEN 1 ELSE 0 END) AS discord_only,
               MAX(synced_at) AS last_roster_sync
        FROM roster_members
        """
    ).fetchone()
    stats = db.execute(
        """
        SELECT COUNT(*) AS total_profiles,
               SUM(CASE WHEN u.verified_at IS NOT NULL THEN 1 ELSE 0 END) AS verified_profiles,
               SUM(CASE WHEN u.rostered = 1 THEN 1 ELSE 0 END) AS rostered_profiles,
               SUM(CASE WHEN s.xp > 0 OR s.credits > 0 OR s.kills > 0 OR s.droid_kills > 0
                         OR s.vehicle_kills > 0 OR s.aircraft_kills > 0
                         OR s.support_score > 0 OR s.revives > 0 OR s.repairs > 0
                         OR s.missions > 0 OR s.deployment_attempts > 0
                         OR s.playtime_seconds > 0 THEN 1 ELSE 0 END) AS profiles_with_stats
        FROM users u
        LEFT JOIN stats s ON s.steam_id = u.steam_id
        """
    ).fetchone()
    events = db.execute("SELECT COUNT(*) AS total FROM server_events").fetchone()
    discord = db.execute("SELECT COUNT(*) AS total FROM discord_links").fetchone()
    lookup_config = root_storm_lookup_config()
    public_roster_connected = int(roster["members"] or 0) > 0
    signed_events_received = int(events["total"] or 0) > 0

    if signed_events_received:
        progression_state = "signed_events_active"
        progression_message = "Official server events are reaching TCWA3 and can populate progression."
    else:
        progression_state = "awaiting_signed_events"
        progression_message = "No signed official server events have reached TCWA3 yet, so TCWA3-owned stats remain at their defaults."

    return {
        "root_storm_public_roster": {
            "state": "connected" if public_roster_connected else "empty",
            "members": int(roster["members"] or 0),
            "steam_linked": int(roster["steam_linked"] or 0),
            "discord_only": int(roster["discord_only"] or 0),
            "last_sync": int(roster["last_roster_sync"] or 0),
            "source": SQUAD_XML_URL,
        },
        "root_storm_authenticated_stats": {
            "state": lookup_config["state"],
            "configured": lookup_config["configured"],
            "lookup_source": lookup_config["source"],
            "lookup_path_configured": bool(
                lookup_config["stats_proxy_lookup_configured"] or lookup_config["machine_token_lookup_configured"]
            ),
            "stats_proxy_lookup_configured": lookup_config["stats_proxy_lookup_configured"],
            "machine_token_lookup_configured": lookup_config["machine_token_lookup_configured"],
            "root_storm_api_base_configured": lookup_config["root_storm_api_base_configured"],
            "message": lookup_config["message"],
        },
        "tcwa3_progression": {
            "state": progression_state,
            "profiles": int(stats["total_profiles"] or 0),
            "verified_profiles": int(stats["verified_profiles"] or 0),
            "rostered_profiles": int(stats["rostered_profiles"] or 0),
            "profiles_with_stats": int(stats["profiles_with_stats"] or 0),
            "official_server_events": int(events["total"] or 0),
            "message": progression_message,
        },
        "discord_bot": {
            "linked_profiles": int(discord["total"] or 0),
            "state": "active" if int(discord["total"] or 0) > 0 else "waiting_for_links",
        },
        "updated_at": now(),
    }


def list_roster_members(
    db: sqlite3.Connection,
    unit_filter: str = "",
    search: str = "",
    page: int = 1,
    limit: int = PUBLIC_PROFILE_DEFAULT_LIMIT,
) -> dict[str, Any]:
    page = max(1, int(page or 1))
    limit = max(1, min(PUBLIC_PROFILE_MAX_LIMIT, int(limit or PUBLIC_PROFILE_DEFAULT_LIMIT)))
    offset = (page - 1) * limit
    where = """
        FROM roster_members rm
        LEFT JOIN users u ON u.steam_id = rm.steam_id
        LEFT JOIN stats s ON s.steam_id = rm.steam_id
        WHERE 1 = 1
    """
    params: list[Any] = []
    if unit_filter:
        where += " AND LOWER(COALESCE(rm.unit, '')) = LOWER(?)"
        params.append(unit_filter)
    search = clean_profile_search(search)
    if search:
        search_like = sql_like_pattern(search)
        where += """
          AND (
            LOWER(COALESCE(rm.display_name, '')) LIKE ? ESCAPE '\\'
            OR LOWER(COALESCE(rm.unit, '')) LIKE ? ESCAPE '\\'
            OR LOWER(COALESCE(rm.rank, '')) LIKE ? ESCAPE '\\'
          )
        """
        params.extend([search_like] * 3)
    total = int(db.execute(f"SELECT COUNT(*) AS total {where}", params).fetchone()["total"])
    rows = db.execute(
        f"""
        SELECT rm.external_id, rm.steam_id, rm.discord_id, rm.display_name, rm.unit, rm.rank, rm.synced_at,
               u.profile_public, u.verified_at, COALESCE(s.xp, 0) AS xp, COALESCE(s.missions, 0) AS missions
        {where}
        ORDER BY LOWER(COALESCE(rm.unit, 'zzzz')), LOWER(COALESCE(rm.rank, 'zzzz')), LOWER(rm.display_name), rm.external_id
        LIMIT ? OFFSET ?
        """,
        [*params, limit, offset],
    ).fetchall()
    members: list[dict[str, Any]] = []
    for row in rows:
        has_public_profile = bool(row["steam_id"] and row["profile_public"] and row["verified_at"] is not None)
        members.append(
            {
                "display_name": public_display_name(row["display_name"]),
                "unit": row["unit"] or "",
                "rank": row["rank"] or "",
                "identity_type": "steam" if row["steam_id"] else "discord",
                "steam_linked": bool(row["steam_id"]),
                "discord_only": bool(row["discord_id"] and not row["steam_id"]),
                "public_profile": has_public_profile,
                "steam_id": row["steam_id"] if has_public_profile else "",
                "level": level_for_xp(int(row["xp"] or 0)) if has_public_profile else 1,
                "deployments": int(row["missions"] or 0) if has_public_profile else 0,
                "synced_at": int(row["synced_at"] or 0),
            }
        )
    return {
        "members": members,
        "units": roster_member_units(db),
        "pagination": {
            "page": page,
            "limit": limit,
            "total": total,
            "has_more": offset + len(members) < total,
        },
        "status": roster_bridge_status(db),
        "updated_at": now(),
    }


def recently_played_with(db: sqlite3.Connection, steam_id: str) -> list[dict[str, Any]]:
    rows = db.execute(
        """
        WITH my_events AS (
            SELECT official_server, received_at
            FROM server_events
            WHERE steam_id = ?
            ORDER BY received_at DESC
            LIMIT 30
        )
        SELECT se.steam_id, MAX(se.received_at) AS last_played_at, MAX(se.official_server) AS server
        FROM server_events se
        JOIN my_events me ON me.official_server = se.official_server
                           AND ABS(se.received_at - me.received_at) <= 7200
        JOIN users u ON u.steam_id = se.steam_id
        WHERE se.steam_id != ?
          AND u.profile_public = 1
          AND u.verified_at IS NOT NULL
        GROUP BY se.steam_id
        ORDER BY last_played_at DESC
        LIMIT 24
        """,
        (steam_id, steam_id),
    ).fetchall()
    profiles: list[dict[str, Any]] = []
    for row in rows:
        profile = profile_for(db, row["steam_id"])
        if profile and profile["profile_public"]:
            profiles.append(public_profile_card(profile, {"last_played_at": row["last_played_at"], "server": row["server"]}))
    return profiles


def leaderboard_profiles(db: sqlite3.Connection, sort_mode: str, limit: int = 10) -> list[dict[str, Any]]:
    safe_limit = max(1, min(25, int(limit or 10)))
    order_by = {
        "level": "s.xp DESC, s.missions DESC, u.updated_at DESC, u.steam_id",
        "kills": "s.kills DESC, s.droid_kills DESC, s.xp DESC, u.steam_id",
        "droids": "s.droid_kills DESC, s.kills DESC, s.xp DESC, u.steam_id",
        "vehicles": "s.vehicle_kills DESC, s.kills DESC, s.xp DESC, u.steam_id",
        "aircraft": "s.aircraft_kills DESC, s.kills DESC, s.xp DESC, u.steam_id",
        "friendly_fire": "s.friendly_kills DESC, s.xp DESC, u.steam_id",
        "support_score": "s.support_score DESC, s.deployments_completed DESC, s.playtime_seconds DESC, u.steam_id",
        "revives": "s.revives DESC, s.support_score DESC, u.steam_id",
        "deployments": "s.deployments_completed DESC, s.missions DESC, s.playtime_seconds DESC, s.xp DESC, u.steam_id",
        "deployment_attempts": "s.deployment_attempts DESC, s.deployments_completed DESC, s.playtime_seconds DESC, u.steam_id",
        "failed_deployments": "s.deployments_failed DESC, s.deployment_attempts DESC, s.xp DESC, u.steam_id",
        "achievements": "achievement_count DESC, s.xp DESC, u.steam_id",
        "credits": "s.credits DESC, s.xp DESC, u.steam_id",
        "xp": "s.xp DESC, s.deployments_completed DESC, u.steam_id",
    }.get(sort_mode, "s.xp DESC, s.missions DESC, u.updated_at DESC, u.steam_id")
    rows = db.execute(
        f"""
        SELECT u.steam_id, COALESCE(a.achievement_count, 0) AS achievement_count
        FROM users u
        JOIN stats s ON s.steam_id = u.steam_id
        LEFT JOIN (
            SELECT steam_id, COUNT(*) AS achievement_count
            FROM achievements
            GROUP BY steam_id
        ) a ON a.steam_id = u.steam_id
        WHERE u.profile_public = 1
          AND u.verified_at IS NOT NULL
        ORDER BY {order_by}
        LIMIT ?
        """,
        (safe_limit,),
    ).fetchall()
    profiles: list[dict[str, Any]] = []
    for index, row in enumerate(rows, start=1):
        profile = public_profile_detail(db, row["steam_id"])
        if not profile:
            continue
        profile.pop("achievements", None)
        profile.pop("campaigns", None)
        profile["position"] = index
        profiles.append(profile)
    return profiles


def legion_service_leaderboard(db: sqlite3.Connection, limit: int = 10) -> list[dict[str, Any]]:
    safe_limit = max(1, min(25, int(limit or 10)))
    rows = db.execute(
        """
        SELECT TRIM(u.unit) AS unit,
               COUNT(*) AS member_count,
               COALESCE(SUM(s.support_score), 0) AS service_score,
               COALESCE(SUM(s.deployments_completed), 0) AS deployments_completed,
               COALESCE(SUM(s.deployment_attempts), 0) AS deployment_attempts,
               COALESCE(SUM(s.revives), 0) AS revives,
               COALESCE(SUM(s.heals), 0) AS heals,
               COALESCE(SUM(s.repairs), 0) AS repairs,
               COALESCE(SUM(s.resupplies), 0) AS resupplies,
               COALESCE(SUM(s.transport_assists), 0) AS transport_assists,
               COALESCE(SUM(s.objective_support), 0) AS objective_support
        FROM users u
        JOIN stats s ON s.steam_id = u.steam_id
        WHERE u.profile_public = 1
          AND u.verified_at IS NOT NULL
          AND TRIM(COALESCE(u.unit, '')) != ''
          AND LOWER(TRIM(COALESCE(u.unit, ''))) != 'unassigned'
        GROUP BY TRIM(u.unit)
        HAVING service_score > 0 OR deployments_completed > 0
        ORDER BY service_score DESC, deployments_completed DESC, member_count DESC, LOWER(unit)
        LIMIT ?
        """,
        (safe_limit,),
    ).fetchall()
    return [
        {
            "unit": row["unit"],
            "member_count": int(row["member_count"] or 0),
            "service_score": int(row["service_score"] or 0),
            "deployments_completed": int(row["deployments_completed"] or 0),
            "deployment_attempts": int(row["deployment_attempts"] or 0),
            "revives": int(row["revives"] or 0),
            "heals": int(row["heals"] or 0),
            "repairs": int(row["repairs"] or 0),
            "resupplies": int(row["resupplies"] or 0),
            "transport_assists": int(row["transport_assists"] or 0),
            "objective_support": int(row["objective_support"] or 0),
        }
        for row in rows
    ]


def community_leaderboards(db: sqlite3.Connection, limit: int = 10) -> dict[str, Any]:
    categories = [
        {"id": "level", "name": "Top Level", "metric": "level"},
        {"id": "droids", "name": "Top Infantry", "metric": "droid_kills"},
        {"id": "legion_service", "name": "Legion Service", "metric": "service_score", "legions": legion_service_leaderboard(db, limit)},
        {"id": "support_score", "name": "Top Support", "metric": "support_score"},
        {"id": "revives", "name": "Medics", "metric": "revives"},
        {"id": "vehicles", "name": "Vehicle Hunters", "metric": "vehicle_kills"},
        {"id": "aircraft", "name": "Aircraft Hunters", "metric": "aircraft_kills"},
        {"id": "friendly_fire", "name": "Friendly Fire", "metric": "friendly_kills"},
        {"id": "deployments", "name": "Completed Deployments", "metric": "deployments_completed"},
        {"id": "failed_deployments", "name": "Hard Fights", "metric": "deployments_failed"},
        {"id": "achievements", "name": "Most Achievements", "metric": "achievement_count"},
        {"id": "xp", "name": "XP Recorded", "metric": "xp"},
        {"id": "credits", "name": "Quartermaster Credits", "metric": "credits"},
    ]
    rows = db.execute(
        """
        SELECT COUNT(*) AS profile_count,
               COALESCE(SUM(s.deployment_attempts), 0) AS deployment_attempts,
               COALESCE(SUM(s.deployments_completed), 0) AS deployments,
               COALESCE(SUM(s.deployments_failed), 0) AS deployments_failed,
               COALESCE(SUM(s.vehicle_kills), 0) AS vehicle_kills,
               COALESCE(SUM(s.aircraft_kills), 0) AS aircraft_kills,
               COALESCE(SUM(s.friendly_kills), 0) AS friendly_kills,
               COALESCE(SUM(s.support_score), 0) AS support_score,
               COALESCE(SUM(s.revives), 0) AS revives,
               COALESCE(SUM(s.heals), 0) AS heals,
               COALESCE(SUM(s.repairs), 0) AS repairs,
               COALESCE(SUM(s.resupplies), 0) AS resupplies,
               COALESCE(SUM(s.transport_assists), 0) AS transport_assists,
               COALESCE(SUM(s.objective_support), 0) AS objective_support,
               COALESCE(SUM(s.xp), 0) AS xp,
               COALESCE(SUM(s.credits), 0) AS credits
        FROM users u
        JOIN stats s ON s.steam_id = u.steam_id
        WHERE u.profile_public = 1
          AND u.verified_at IS NOT NULL
        """
    ).fetchone()
    for category in categories:
        if "legions" not in category:
            category["profiles"] = leaderboard_profiles(db, category["id"], limit)
    bridge_status = roster_bridge_status(db)
    roster_summary = bridge_status["root_storm_public_roster"]
    progression_summary = bridge_status["tcwa3_progression"]
    return {
        "leaderboards": categories,
        "summary": {
            "public_profiles": int(rows["profile_count"] or 0),
            "roster_members": roster_summary["members"],
            "roster_steam_linked": roster_summary["steam_linked"],
            "roster_discord_only": roster_summary["discord_only"],
            "deployment_attempts": int(rows["deployment_attempts"] or 0),
            "deployments": int(rows["deployments"] or 0),
            "deployments_completed": int(rows["deployments"] or 0),
            "deployments_failed": int(rows["deployments_failed"] or 0),
            "vehicle_kills": int(rows["vehicle_kills"] or 0),
            "aircraft_kills": int(rows["aircraft_kills"] or 0),
            "friendly_kills": int(rows["friendly_kills"] or 0),
            "support_score": int(rows["support_score"] or 0),
            "revives": int(rows["revives"] or 0),
            "heals": int(rows["heals"] or 0),
            "repairs": int(rows["repairs"] or 0),
            "resupplies": int(rows["resupplies"] or 0),
            "transport_assists": int(rows["transport_assists"] or 0),
            "objective_support": int(rows["objective_support"] or 0),
            "xp": int(rows["xp"] or 0),
            "credits": int(rows["credits"] or 0),
            "profiles_with_stats": progression_summary["profiles_with_stats"],
            "official_server_events": progression_summary["official_server_events"],
            "stats_bridge_state": bridge_status["root_storm_authenticated_stats"]["state"],
        },
        "status": bridge_status,
        "updated_at": now(),
    }


def quest_catalog(db: sqlite3.Connection) -> list[dict[str, Any]]:
    quests: dict[str, dict[str, Any]] = {str(quest["id"]): dict(quest) for quest in DEFAULT_QUESTS}
    rows = db.execute(
        """
        SELECT quest_id, title, category, state, stage_title, stage_description,
               COUNT(*) AS player_count,
               SUM(CASE WHEN state IN ('SUCCEEDED', 'FAILED', 'CANCELED') THEN 1 ELSE 0 END) AS completed_count,
               MAX(updated_at) AS updated_at
        FROM quest_progress
        GROUP BY quest_id, title, category, state, stage_title, stage_description
        ORDER BY MAX(updated_at) DESC, quest_id
        LIMIT 50
        """
    ).fetchall()
    for row in rows:
        quest_id = row["quest_id"]
        quests[quest_id] = {
            "id": quest_id,
            "title": row["title"],
            "category": row["category"],
            "state": row["state"],
            "stage_title": row["stage_title"],
            "description": row["stage_description"],
            "reward": "Progress is recorded from signed official TCWA3 events.",
            "player_count": int(row["player_count"] or 0),
            "completed_count": int(row["completed_count"] or 0),
            "updated_at": row["updated_at"],
        }
    return list(quests.values())


def public_quest_recent_progress(db: sqlite3.Connection, limit: int = 12) -> list[dict[str, Any]]:
    rows = db.execute(
        """
        SELECT q.steam_id, q.quest_id, q.title, q.category, q.state, q.updated_at
        FROM quest_progress q
        JOIN users u ON u.steam_id = q.steam_id
        WHERE u.profile_public = 1
          AND u.verified_at IS NOT NULL
        ORDER BY q.updated_at DESC, q.quest_id
        LIMIT ?
        """,
        (max(1, min(25, int(limit or 12))),),
    ).fetchall()
    progress: list[dict[str, Any]] = []
    for row in rows:
        profile = profile_for(db, row["steam_id"])
        if not profile:
            continue
        progress.append(
            {
                "steam_id": row["steam_id"],
                "display_name": profile["display_name"],
                "avatar_url": profile["avatar_url"],
                "unit": profile["unit"],
                "quest_id": row["quest_id"],
                "title": row["title"],
                "category": row["category"],
                "state": row["state"],
                "updated_at": row["updated_at"],
            }
        )
    return progress


def quest_overview(db: sqlite3.Connection, steam_id: str | None = None) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "quests": quest_catalog(db),
        "recent_progress": public_quest_recent_progress(db),
        "updated_at": now(),
    }
    if steam_id:
        payload["profile_quests"] = quest_progress_for(db, steam_id)
    return payload


def roster_link_request_payload(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "request_id": row["request_id"],
        "steam_id": row["steam_id"],
        "display_name": row["display_name"],
        "requested_roster_name": row["requested_roster_name"],
        "requested_unit": row["requested_unit"],
        "requested_rank": row["requested_rank"],
        "message": row["message"],
        "status": row["status"],
        "reviewer": row["reviewer"],
        "decision_note": row["decision_note"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "decided_at": row["decided_at"],
    }


def clean_support_text(value: Any, limit: int = 240) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:limit]


def create_roster_link_request(db: sqlite3.Connection, steam_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    profile = profile_for(db, steam_id)
    if not profile:
        raise ValueError("profile was not found")
    timestamp = now()
    existing = db.execute(
        "SELECT * FROM roster_link_requests WHERE steam_id = ? AND status = 'pending' ORDER BY updated_at DESC LIMIT 1",
        (steam_id,),
    ).fetchone()
    values = {
        "display_name": profile["display_name"],
        "requested_roster_name": clean_profile_name(payload.get("roster_name") or payload.get("requested_roster_name") or profile["display_name"]),
        "requested_unit": clean_support_text(payload.get("unit") or payload.get("requested_unit"), 32),
        "requested_rank": clean_support_text(payload.get("rank") or payload.get("requested_rank"), 32),
        "message": clean_support_text(payload.get("message"), 700),
    }
    if existing:
        db.execute(
            """
            UPDATE roster_link_requests
            SET display_name = ?, requested_roster_name = ?, requested_unit = ?,
                requested_rank = ?, message = ?, updated_at = ?
            WHERE request_id = ?
            """,
            (
                values["display_name"],
                values["requested_roster_name"],
                values["requested_unit"],
                values["requested_rank"],
                values["message"],
                timestamp,
                existing["request_id"],
            ),
        )
        request_id = existing["request_id"]
    else:
        request_id = "rlr_" + secrets.token_urlsafe(12)
        db.execute(
            """
            INSERT INTO roster_link_requests
                (request_id, steam_id, display_name, requested_roster_name, requested_unit,
                 requested_rank, message, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)
            """,
            (
                request_id,
                steam_id,
                values["display_name"],
                values["requested_roster_name"],
                values["requested_unit"],
                values["requested_rank"],
                values["message"],
                timestamp,
                timestamp,
            ),
        )
    row = db.execute("SELECT * FROM roster_link_requests WHERE request_id = ?", (request_id,)).fetchone()
    return roster_link_request_payload(row)


def list_roster_link_requests(db: sqlite3.Connection, status: str = "pending") -> list[dict[str, Any]]:
    safe_status = str(status or "pending").strip().lower()
    if safe_status not in {"pending", "approved", "rejected", "all"}:
        safe_status = "pending"
    if safe_status == "all":
        rows = db.execute("SELECT * FROM roster_link_requests ORDER BY updated_at DESC LIMIT 100").fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM roster_link_requests WHERE status = ? ORDER BY updated_at DESC LIMIT 100",
            (safe_status,),
        ).fetchall()
    return [roster_link_request_payload(row) for row in rows]


def record_admin_audit(
    db: sqlite3.Connection,
    actor_role: str,
    action: str,
    target: str = "",
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    entry = {
        "audit_id": "audit_" + secrets.token_urlsafe(12),
        "actor_role": actor_role,
        "action": clean_support_text(action, 96),
        "target": clean_support_text(target, 160),
        "details": details or {},
        "created_at": now(),
    }
    db.execute(
        """
        INSERT INTO admin_audit_log (audit_id, actor_role, action, target, details_json, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            entry["audit_id"],
            entry["actor_role"],
            entry["action"],
            entry["target"],
            json.dumps(entry["details"], ensure_ascii=False, sort_keys=True),
            entry["created_at"],
        ),
    )
    return entry


def list_admin_audit(db: sqlite3.Connection, limit: int = 100) -> list[dict[str, Any]]:
    rows = db.execute(
        "SELECT * FROM admin_audit_log ORDER BY created_at DESC LIMIT ?",
        (max(1, min(250, int(limit or 100))),),
    ).fetchall()
    items: list[dict[str, Any]] = []
    for row in rows:
        try:
            details = json.loads(row["details_json"] or "{}")
        except json.JSONDecodeError:
            details = {}
        items.append(
            {
                "audit_id": row["audit_id"],
                "actor_role": row["actor_role"],
                "action": row["action"],
                "target": row["target"],
                "details": details if isinstance(details, dict) else {},
                "created_at": row["created_at"],
            }
        )
    return items


def clean_discord_snowflake(value: Any, *, required: bool = True) -> str:
    text = re.sub(r"\D+", "", str(value or ""))
    if not text and not required:
        return ""
    if not (5 <= len(text) <= 32):
        raise ValueError("discord_id is invalid")
    return text


def clean_discord_roles(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    roles: list[str] = []
    seen: set[str] = set()
    for item in value[:80]:
        role = clean_support_text(item, 80)
        if role and role not in seen:
            seen.add(role)
            roles.append(role)
    return roles


def normalise_bot_link_code(value: Any) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).upper()[:16]


def generate_bot_link_code() -> str:
    return "".join(secrets.choice(BOT_LINK_CODE_ALPHABET) for _ in range(8))


def bot_link_code_hash(code: str) -> str:
    return token_hash(normalise_bot_link_code(code))


def discord_link_payload(row: sqlite3.Row | None, *, include_roles: bool = True) -> dict[str, Any]:
    if row is None:
        return {"linked": False}
    try:
        roles = json.loads(row["roles_json"] or "[]")
    except json.JSONDecodeError:
        roles = []
    payload = {
        "linked": True,
        "discord_id": row["discord_id"],
        "guild_id": row["guild_id"],
        "username": row["discord_username"],
        "nickname": row["nickname"],
        "status": row["status"],
        "linked_at": row["linked_at"],
        "updated_at": row["updated_at"],
    }
    if include_roles:
        payload["roles"] = roles if isinstance(roles, list) else []
    return payload


def discord_link_roles(row: sqlite3.Row | None) -> list[str]:
    if row is None:
        return []
    try:
        roles = json.loads(row["roles_json"] or "[]")
    except json.JSONDecodeError:
        return []
    if not isinstance(roles, list):
        return []
    return [clean_support_text(role, 80) for role in roles if clean_support_text(role, 80)]


def derive_discord_roster_identity(row: sqlite3.Row | None) -> dict[str, str]:
    if row is None:
        return {"unit": "", "rank": "", "roster_name": "", "source": "discord_tag"}
    candidates = [
        clean_support_text(row["nickname"], 120),
        clean_support_text(row["discord_username"], 120),
        *discord_link_roles(row),
    ]
    unit = ""
    rank = ""
    for candidate in candidates:
        if not unit:
            unit_match = DISCORD_UNIT_TAG_PATTERN.search(candidate)
            if unit_match:
                unit = f"{unit_match.group(1)}{unit_match.group(2).lower()}"[:32]
        if not rank:
            for rank_match in DISCORD_RANK_TAG_PATTERN.finditer(candidate.upper()):
                rank_candidate = rank_match.group(1)
                if rank_candidate in DISCORD_RANK_TAGS:
                    rank = rank_candidate[:32]
                    break
        if unit and rank:
            break
    roster_name = clean_profile_name(first_non_empty(row["nickname"], row["discord_username"])) if row else ""
    return {"unit": unit, "rank": rank, "roster_name": roster_name, "source": "discord_tag"}


def apply_discord_roster_tag_fallback(
    db: sqlite3.Connection,
    steam_id: str,
    discord_row: sqlite3.Row | None,
    reason: str = "",
) -> tuple[dict[str, Any] | None, dict[str, str]]:
    identity = derive_discord_roster_identity(discord_row)
    if not identity.get("unit") and not identity.get("rank"):
        return None, identity
    current = db.execute(
        "SELECT steam_id, roster_name, unit, rank, rostered FROM users WHERE steam_id = ?",
        (steam_id,),
    ).fetchone()
    if current is None:
        return None, identity
    current_unit = str(current["unit"] or "").strip()
    current_rank = str(current["rank"] or "").strip()
    current_roster_name = str(current["roster_name"] or "").strip()
    new_unit = current_unit or identity.get("unit", "")
    new_rank = current_rank or identity.get("rank", "")
    new_roster_name = current_roster_name or identity.get("roster_name", "")
    should_roster = bool(current["rostered"]) or bool(new_unit)
    changed = (
        new_unit != current_unit
        or new_rank != current_rank
        or new_roster_name != current_roster_name
        or int(bool(should_roster)) != int(bool(current["rostered"]))
    )
    if not changed:
        return None, identity
    timestamp = now()
    db.execute(
        """
        UPDATE users
        SET roster_name = COALESCE(NULLIF(?, ''), roster_name),
            unit = COALESCE(NULLIF(?, ''), unit),
            rank = COALESCE(NULLIF(?, ''), rank),
            rostered = CASE WHEN ? THEN 1 ELSE rostered END,
            updated_at = ?
        WHERE steam_id = ?
        """,
        (new_roster_name, new_unit, new_rank, 1 if should_roster else 0, timestamp, steam_id),
    )
    safe_write_player_profile_snapshot(db, steam_id)
    log_backend_event(
        "discord_roster_tag_fallback_applied",
        steam_id=steam_id,
        unit=new_unit,
        rank=new_rank,
        reason=reason,
    )
    return profile_for(db, steam_id), identity


def discord_roster_tag_fallback_response(
    db: sqlite3.Connection,
    steam_id: str,
    discord_row: sqlite3.Row,
    base_payload: dict[str, Any],
    reason: str,
    fallback_status: HTTPStatus,
) -> tuple[HTTPStatus, dict[str, Any]]:
    profile, identity = apply_discord_roster_tag_fallback(db, steam_id, discord_row, reason)
    if profile is None or not identity.get("unit"):
        return fallback_status, base_payload
    unit = identity.get("unit", "")
    return HTTPStatus.OK, {
        "ok": True,
        "status": "discord_tag_fallback",
        "discord_linked": True,
        "discord": discord_link_payload(discord_row, include_roles=True),
        "profile": profile,
        "external": {
            "lookup_source": "discord_tag_fallback",
            "unit_source": "linked_discord_tag",
            "unit": unit,
            "rank": identity.get("rank", ""),
            "fallback_from": base_payload.get("status", reason),
        },
        "message": (
            f"Unit roster synced from your linked comms tag ({unit}). "
            "The official roster feed can refresh this automatically when it returns a matching Steam record."
        ),
    }


def record_bot_audit(
    db: sqlite3.Connection,
    bot_id: str,
    action: str,
    target: str = "",
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    entry = {
        "audit_id": "bot_audit_" + secrets.token_urlsafe(12),
        "bot_id": clean_support_text(bot_id, 96),
        "action": clean_support_text(action, 96),
        "target": clean_support_text(target, 160),
        "details": details or {},
        "created_at": now(),
    }
    db.execute(
        """
        INSERT INTO bot_audit_log (audit_id, bot_id, action, target, details_json, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            entry["audit_id"],
            entry["bot_id"],
            entry["action"],
            entry["target"],
            json.dumps(entry["details"], ensure_ascii=False, sort_keys=True),
            entry["created_at"],
        ),
    )
    return entry


def create_discord_bot_link_code(db: sqlite3.Connection, payload: dict[str, Any], bot_id: str) -> dict[str, Any]:
    timestamp = now()
    discord_id = clean_discord_snowflake(payload.get("discord_id"))
    guild_id = clean_discord_snowflake(payload.get("guild_id"), required=False)
    discord_username = clean_support_text(payload.get("discord_username") or payload.get("username"), 120)
    nickname = clean_support_text(payload.get("nickname"), 120)
    roles = clean_discord_roles(payload.get("roles"))
    db.execute(
        "UPDATE discord_link_codes SET status = 'expired', updated_at = ? WHERE status = 'pending' AND expires_at <= ?",
        (timestamp, timestamp),
    )
    existing = db.execute(
        """
        SELECT * FROM discord_link_codes
        WHERE discord_id = ? AND status = 'pending' AND expires_at > ?
        ORDER BY created_at DESC LIMIT 1
        """,
        (discord_id, timestamp),
    ).fetchone()
    if existing is not None:
        record_bot_audit(db, bot_id, "discord_link_code_reused", discord_id, {"link_id": existing["link_id"], "guild_id": guild_id})
        return {
            "link_id": existing["link_id"],
            "code": "",
            "status": existing["status"],
            "expires_at": existing["expires_at"],
            "expires_in": max(0, int(existing["expires_at"]) - timestamp),
            "message": "A pending link code already exists; ask the player to use the most recent code.",
        }
    code = generate_bot_link_code()
    link_id = "discord_link_" + secrets.token_urlsafe(12)
    expires_at = timestamp + max(60, min(3600, BOT_LINK_CODE_TTL_SECONDS))
    db.execute(
        """
        INSERT INTO discord_link_codes
            (code_hash, link_id, discord_id, guild_id, discord_username, nickname, roles_json,
             status, steam_id, created_by_bot_id, created_at, expires_at, claimed_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', '', ?, ?, ?, NULL, ?)
        """,
        (
            bot_link_code_hash(code),
            link_id,
            discord_id,
            guild_id,
            discord_username,
            nickname,
            json.dumps(roles, ensure_ascii=False),
            clean_support_text(bot_id, 96),
            timestamp,
            expires_at,
            timestamp,
        ),
    )
    record_bot_audit(db, bot_id, "discord_link_code_created", discord_id, {"link_id": link_id, "guild_id": guild_id})
    return {"link_id": link_id, "code": code, "status": "pending", "expires_at": expires_at, "expires_in": expires_at - timestamp}


def discord_link_code_status(db: sqlite3.Connection, link_id: str) -> tuple[HTTPStatus, dict[str, Any]]:
    safe_link_id = clean_support_text(link_id, 120)
    row = db.execute("SELECT * FROM discord_link_codes WHERE link_id = ?", (safe_link_id,)).fetchone()
    if row is None:
        return HTTPStatus.NOT_FOUND, {"error": "link_not_found"}
    timestamp = now()
    status = row["status"]
    if status == "pending" and int(row["expires_at"]) <= timestamp:
        status = "expired"
        db.execute("UPDATE discord_link_codes SET status = 'expired', updated_at = ? WHERE link_id = ?", (timestamp, safe_link_id))
    return HTTPStatus.OK, {
        "link_id": row["link_id"],
        "discord_id": row["discord_id"],
        "guild_id": row["guild_id"],
        "status": status,
        "steam_id": row["steam_id"],
        "created_at": row["created_at"],
        "expires_at": row["expires_at"],
        "claimed_at": row["claimed_at"],
        "updated_at": timestamp if status == "expired" else row["updated_at"],
    }


def claim_discord_bot_link_code(db: sqlite3.Connection, steam_id: str, code: Any) -> tuple[HTTPStatus, dict[str, Any]]:
    normalised = normalise_bot_link_code(code)
    if not normalised:
        return HTTPStatus.BAD_REQUEST, {"error": "code_required", "message": "Enter the link code from the TCW Discord bot."}
    timestamp = now()
    row = db.execute("SELECT * FROM discord_link_codes WHERE code_hash = ?", (bot_link_code_hash(normalised),)).fetchone()
    if row is None:
        return HTTPStatus.NOT_FOUND, {"error": "link_code_not_found", "message": "That Discord link code was not found."}
    if row["status"] == "claimed":
        if row["steam_id"] == steam_id:
            linked = db.execute("SELECT * FROM discord_links WHERE discord_id = ?", (row["discord_id"],)).fetchone()
            return HTTPStatus.OK, {"status": "linked", "discord": discord_link_payload(linked)}
        return HTTPStatus.CONFLICT, {"error": "link_code_already_claimed", "message": "That Discord link code has already been claimed."}
    if int(row["expires_at"]) <= timestamp:
        db.execute("UPDATE discord_link_codes SET status = 'expired', updated_at = ? WHERE code_hash = ?", (timestamp, row["code_hash"]))
        return HTTPStatus.GONE, {"error": "link_code_expired", "message": "That Discord link code has expired. Ask the Discord bot for a fresh code."}
    db.execute(
        """
        UPDATE discord_link_codes
        SET status = 'claimed', steam_id = ?, claimed_at = ?, updated_at = ?
        WHERE code_hash = ?
        """,
        (steam_id, timestamp, timestamp, row["code_hash"]),
    )
    db.execute(
        """
        INSERT INTO discord_links
            (discord_id, steam_id, guild_id, discord_username, nickname, roles_json, status, source, linked_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, 'linked', 'bot', ?, ?)
        ON CONFLICT(discord_id) DO UPDATE SET
            steam_id = excluded.steam_id,
            guild_id = excluded.guild_id,
            discord_username = excluded.discord_username,
            nickname = excluded.nickname,
            roles_json = excluded.roles_json,
            status = 'linked',
            source = 'bot',
            updated_at = excluded.updated_at
        """,
        (
            row["discord_id"],
            steam_id,
            row["guild_id"],
            row["discord_username"],
            row["nickname"],
            row["roles_json"],
            timestamp,
            timestamp,
        ),
    )
    record_bot_audit(db, "player", "discord_link_claimed", row["discord_id"], {"link_id": row["link_id"], "steam_id": steam_id})
    linked = db.execute("SELECT * FROM discord_links WHERE discord_id = ?", (row["discord_id"],)).fetchone()
    root_storm_status, root_storm_result = try_link_root_storm_roster_from_discord(db, steam_id)
    profile = profile_for(db, steam_id)
    if root_storm_status == HTTPStatus.OK and root_storm_result.get("profile"):
        profile = root_storm_result["profile"]
    if profile:
        safe_write_player_profile_snapshot(db, steam_id)
    return HTTPStatus.OK, {
        "status": "linked",
        "discord": discord_link_payload(linked),
        "profile": profile,
        "root_storm": root_storm_result,
    }


def sync_discord_members(db: sqlite3.Connection, payload: dict[str, Any], bot_id: str) -> dict[str, Any]:
    members = payload.get("members", [])
    if isinstance(members, dict):
        members = [members]
    if not isinstance(members, list):
        raise ValueError("members must be a list")
    timestamp = now()
    updated = 0
    unlinked = 0
    for member in members[:250]:
        if not isinstance(member, dict):
            continue
        discord_id = clean_discord_snowflake(member.get("discord_id"))
        guild_id = clean_discord_snowflake(member.get("guild_id"), required=False)
        discord_username = clean_support_text(member.get("discord_username") or member.get("username"), 120)
        nickname = clean_support_text(member.get("nickname"), 120)
        roles = clean_discord_roles(member.get("roles"))
        existing = db.execute("SELECT * FROM discord_links WHERE discord_id = ?", (discord_id,)).fetchone()
        if existing is None:
            unlinked += 1
            continue
        db.execute(
            """
            UPDATE discord_links
            SET guild_id = ?, discord_username = ?, nickname = ?, roles_json = ?, status = 'linked', updated_at = ?
            WHERE discord_id = ?
            """,
            (guild_id, discord_username, nickname, json.dumps(roles, ensure_ascii=False), timestamp, discord_id),
        )
        updated += 1
    record_bot_audit(db, bot_id, "discord_member_sync", "discord_members", {"updated": updated, "unlinked": unlinked})
    return {"status": "synced", "updated": updated, "unlinked": unlinked, "updated_at": timestamp}


def record_discord_notification_events(db: sqlite3.Connection, payload: dict[str, Any], bot_id: str) -> dict[str, Any]:
    events = payload.get("events", [])
    if isinstance(events, dict):
        events = [events]
    if not isinstance(events, list):
        raise ValueError("events must be a list")
    accepted = 0
    for event in events[:100]:
        if not isinstance(event, dict):
            continue
        event_type = clean_support_text(event.get("type") or event.get("event_type"), 80)
        target = clean_support_text(event.get("target") or event.get("channel_id") or event.get("message_id"), 160)
        summary = clean_support_text(event.get("summary") or event.get("message"), 500)
        if not event_type:
            continue
        record_bot_audit(
            db,
            bot_id,
            "discord_notification_event",
            target or event_type,
            {"type": event_type, "summary": summary, "source": clean_support_text(event.get("source"), 80)},
        )
        accepted += 1
    return {"status": "accepted", "accepted": accepted, "updated_at": now()}


def clean_reaction_target(payload: dict[str, Any]) -> tuple[str, str, str]:
    target_type = str(payload.get("target_type", "")).strip().lower()
    if target_type not in COMMUNITY_REACTION_TARGET_TYPES:
        raise ValueError("target_type is invalid")
    target_id = clean_support_text(payload.get("target_id"), 160)
    if not target_id:
        raise ValueError("target_id is required")
    reaction = str(payload.get("reaction", "")).strip().lower()
    if reaction not in COMMUNITY_REACTIONS:
        raise ValueError("reaction is invalid")
    return target_type, target_id, reaction


def community_reaction_summary(
    db: sqlite3.Connection,
    target_type: str,
    target_id: str,
    steam_id: str | None = None,
) -> dict[str, Any]:
    rows = db.execute(
        """
        SELECT reaction, COUNT(*) AS total
        FROM community_reactions
        WHERE target_type = ? AND target_id = ?
        GROUP BY reaction
        """,
        (target_type, target_id),
    ).fetchall()
    counts = {reaction: 0 for reaction in sorted(COMMUNITY_REACTIONS)}
    counts.update({row["reaction"]: int(row["total"] or 0) for row in rows})
    my_reactions: list[str] = []
    if steam_id:
        my_rows = db.execute(
            """
            SELECT reaction FROM community_reactions
            WHERE target_type = ? AND target_id = ? AND steam_id = ?
            ORDER BY reaction
            """,
            (target_type, target_id, steam_id),
        ).fetchall()
        my_reactions = [row["reaction"] for row in my_rows]
    return {"target_type": target_type, "target_id": target_id, "counts": counts, "my_reactions": my_reactions}


def update_community_reaction(
    db: sqlite3.Connection,
    steam_id: str,
    payload: dict[str, Any],
) -> tuple[HTTPStatus, dict[str, Any]]:
    target_type, target_id, reaction = clean_reaction_target(payload)
    action = str(payload.get("action", "toggle")).strip().lower()
    timestamp = now()
    existing = db.execute(
        """
        SELECT 1 FROM community_reactions
        WHERE target_type = ? AND target_id = ? AND steam_id = ? AND reaction = ?
        """,
        (target_type, target_id, steam_id, reaction),
    ).fetchone()
    status = "unchanged"
    if action in {"remove", "delete"}:
        db.execute(
            "DELETE FROM community_reactions WHERE target_type = ? AND target_id = ? AND steam_id = ? AND reaction = ?",
            (target_type, target_id, steam_id, reaction),
        )
        status = "removed"
    elif action == "toggle" and existing is not None:
        db.execute(
            "DELETE FROM community_reactions WHERE target_type = ? AND target_id = ? AND steam_id = ? AND reaction = ?",
            (target_type, target_id, steam_id, reaction),
        )
        status = "removed"
    else:
        db.execute(
            """
            INSERT OR IGNORE INTO community_reactions (target_type, target_id, steam_id, reaction, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (target_type, target_id, steam_id, reaction, timestamp),
        )
        status = "added"
    summary = community_reaction_summary(db, target_type, target_id, steam_id)
    summary["status"] = status
    return HTTPStatus.OK, summary


def decide_roster_link_request(db: sqlite3.Connection, payload: dict[str, Any], actor_role: str) -> tuple[HTTPStatus, dict[str, Any]]:
    request_id = str(payload.get("request_id", "")).strip()
    action = str(payload.get("action", "")).strip().lower()
    if not request_id or action not in {"approve", "reject"}:
        return HTTPStatus.BAD_REQUEST, {"error": "invalid_request", "message": "request_id and action approve/reject are required."}
    row = db.execute("SELECT * FROM roster_link_requests WHERE request_id = ?", (request_id,)).fetchone()
    if row is None:
        return HTTPStatus.NOT_FOUND, {"error": "request_not_found", "message": "Roster-link request was not found."}
    timestamp = now()
    status = "approved" if action == "approve" else "rejected"
    note = clean_support_text(payload.get("note") or payload.get("decision_note"), 700)
    roster_name = clean_profile_name(payload.get("roster_name") or row["requested_roster_name"] or row["display_name"])
    unit = clean_support_text(payload.get("unit") or row["requested_unit"], 32)
    rank = clean_support_text(payload.get("rank") or row["requested_rank"], 32)
    if status == "approved":
        db.execute(
            """
            UPDATE users
            SET roster_name = ?, unit = ?, rank = ?, rostered = 1,
                display_name = CASE WHEN display_name = '' OR display_name = 'Clone trooper' THEN ? ELSE display_name END,
                updated_at = ?
            WHERE steam_id = ?
            """,
            (roster_name, unit, rank, roster_name, timestamp, row["steam_id"]),
        )
    db.execute(
        """
        UPDATE roster_link_requests
        SET status = ?, reviewer = ?, decision_note = ?, updated_at = ?, decided_at = ?
        WHERE request_id = ?
        """,
        (status, actor_role, note, timestamp, timestamp, request_id),
    )
    record_admin_audit(
        db,
        actor_role,
        f"roster_link_{status}",
        row["steam_id"],
        {"request_id": request_id, "unit": unit, "rank": rank, "note": note},
    )
    updated = db.execute("SELECT * FROM roster_link_requests WHERE request_id = ?", (request_id,)).fetchone()
    profile = profile_for(db, row["steam_id"])
    if profile:
        safe_write_player_profile_snapshot(db, row["steam_id"])
    return HTTPStatus.OK, {"status": status, "request": roster_link_request_payload(updated), "profile": profile}


def apply_player_support_action(db: sqlite3.Connection, payload: dict[str, Any], actor_role: str) -> tuple[HTTPStatus, dict[str, Any]]:
    steam_id = str(payload.get("steam_id", "")).strip()
    if not STEAM_ID_PATTERN.fullmatch(steam_id):
        return HTTPStatus.BAD_REQUEST, {"error": "invalid_steam_id"}
    action = str(payload.get("action", "")).strip().lower()
    reason = clean_support_text(payload.get("reason"), 700)
    if not reason:
        return HTTPStatus.BAD_REQUEST, {"error": "reason_required", "message": "A support reason is required for audited admin changes."}
    existing = db.execute("SELECT steam_id FROM users WHERE steam_id = ?", (steam_id,)).fetchone()
    if existing is None:
        return HTTPStatus.NOT_FOUND, {"error": "profile_not_found", "message": "That Steam profile is not known to TCWA3 yet."}
    timestamp = now()
    details: dict[str, Any] = {"reason": reason}
    if action == "adjust_progress":
        xp_delta = max(-1_000_000, min(1_000_000, int(payload.get("xp_delta", 0) or 0)))
        credits_delta = max(-1_000_000, min(1_000_000, int(payload.get("credits_delta", 0) or 0)))
        db.execute("INSERT OR IGNORE INTO stats (steam_id) VALUES (?)", (steam_id,))
        db.execute(
            "UPDATE stats SET xp = MAX(0, xp + ?), credits = MAX(0, credits + ?) WHERE steam_id = ?",
            (xp_delta, credits_delta, steam_id),
        )
        details.update({"xp_delta": xp_delta, "credits_delta": credits_delta})
    elif action == "set_roster":
        roster_name = clean_profile_name(payload.get("roster_name"))
        unit = clean_support_text(payload.get("unit"), 32)
        rank = clean_support_text(payload.get("rank"), 32)
        rostered = bool(payload.get("rostered", True))
        db.execute(
            "UPDATE users SET roster_name = ?, unit = ?, rank = ?, rostered = ?, updated_at = ? WHERE steam_id = ?",
            (roster_name, unit, rank, 1 if rostered else 0, timestamp, steam_id),
        )
        details.update({"roster_name": roster_name, "unit": unit, "rank": rank, "rostered": rostered})
    else:
        return HTTPStatus.BAD_REQUEST, {
            "error": "invalid_action",
            "message": "action must be adjust_progress or set_roster.",
        }
    record_admin_audit(db, actor_role, f"player_support_{action}", steam_id, details)
    profile = profile_for(db, steam_id)
    if profile:
        safe_write_player_profile_snapshot(db, steam_id)
    return HTTPStatus.OK, {"status": "saved", "profile": profile, "audit": list_admin_audit(db, 1)[0]}


def unlock_achievements(db: sqlite3.Connection, steam_id: str, contextual_ids: list[str] | None = None) -> list[str]:
    stats = db.execute("SELECT * FROM stats WHERE steam_id = ?", (steam_id,)).fetchone()
    if stats is None:
        return []
    level = max(level_for_xp(stats["xp"]), int(stats["level_floor"] or 0))
    eligible: list[str] = []

    def add(achievement_id: str) -> None:
        if achievement_id in ACHIEVEMENTS and achievement_id not in eligible:
            eligible.append(achievement_id)

    for achievement_id in contextual_ids or []:
        add(achievement_id)
    if stats["kills"] >= 1:
        add("first_blood")
    if stats["kills"] >= 10:
        add("trooper_10")
    if stats["kills"] >= 100:
        add("veteran_100")
    if stats["droid_kills"] >= 100:
        add("roger_roger")
    if stats["droid_kills"] >= 1000:
        add("master_scrapper")
    if stats["vehicle_kills"] >= 25:
        add("vehicle_breaker_25")
    if stats["vehicle_kills"] >= 100:
        add("vehicle_column_100")
    if stats["aircraft_kills"] >= 10:
        add("air_superiority_10")
    if stats["aircraft_kills"] >= 50:
        add("gunship_graveyard_50")
    if stats["friendly_kills"] >= 100:
        add("enemy_is_over_there")
    if (
        stats["support_score"] >= 1
        or stats["revives"] + stats["heals"] + stats["repairs"] + stats["resupplies"] + stats["transport_assists"] + stats["objective_support"] >= 1
    ):
        add("first_support")
    if stats["revives"] >= 25:
        add("battlefield_medic_25")
    if stats["repairs"] >= 50:
        add("field_engineer_50")
    if stats["resupplies"] >= 100:
        add("quartermaster_100")
    if stats["support_score"] >= 1000:
        add("service_before_glory")
    if stats["missions"] >= 1:
        add("first_deployment")
        add("welcome_to_the_front")
    if stats["missions"] >= 5:
        add("hold_the_line")
    if stats["missions"] >= 10:
        add("seasoned_10")
    if max(stats["deployments_completed"], stats["missions"]) >= 25:
        add("campaign_regular_25")
    if max(stats["deployments_completed"], stats["missions"]) >= 50:
        add("campaign_veteran_50")
    if stats["credits"] >= 1000:
        add("credit_1000")
    if stats["credits"] >= 10000:
        add("payday")
    if stats["kamino_visits"] >= 1:
        add("kamino_shiny")
    if stats["geonosis_missions"] >= 5:
        add("veteran_of_geonosis")
    if stats["friendly_fire_missions"] >= 1:
        add("same_team")
    if stats["high_death_missions"] >= 1:
        add("droid_bait")
    if stats["perfect_missions"] >= 1:
        add("survivor")
    if stats["perfect_missions"] >= 10:
        add("clean_streak_10")
    if level >= 5:
        add("level_5")
    if level >= 50:
        add("level_50")
    planet_count_row = db.execute(
        """
        SELECT COUNT(DISTINCT NULLIF(planet, '')) AS planet_count
        FROM campaign_deployments
        WHERE steam_id = ?
          AND outcome IN ('completed', 'failed')
        """,
        (steam_id,),
    ).fetchone()
    if int(planet_count_row["planet_count"] or 0) >= 3:
        add("multi_front_veteran")

    unlocked = []
    unlocked_at = now()
    for achievement_id in eligible:
        cursor = db.execute(
            "INSERT OR IGNORE INTO achievements (steam_id, achievement_id, unlocked_at) VALUES (?, ?, ?)",
            (steam_id, achievement_id, unlocked_at),
        )
        if cursor.rowcount:
            unlocked.append(achievement_id)
    return unlocked

def exchange_device_code_for_session(
    db: sqlite3.Connection,
    device_code: str,
    timestamp: int | None = None,
) -> tuple[HTTPStatus, dict[str, Any]]:
    """Exchange one approved Steam device code for one backend session."""
    timestamp = now() if timestamp is None else timestamp
    device = db.execute(
        "SELECT steam_id, status, expires_at, consumed_at FROM device_codes WHERE device_hash = ?",
        (token_hash(device_code),),
    ).fetchone()
    if device is None or device["expires_at"] <= timestamp:
        return HTTPStatus.BAD_REQUEST, {"error": "expired_token"}
    if device["status"] == "pending":
        return HTTPStatus.ACCEPTED, {"status": "pending"}
    if device["consumed_at"] is not None or not device["steam_id"]:
        return (
            HTTPStatus.CONFLICT,
            {
                "error": "already_consumed",
                "message": "This Steam sign-in was already used. Press Login With Steam to start a fresh sign-in.",
            },
        )

    session_token = secrets.token_urlsafe(48)
    session_expires_at = timestamp + SESSION_DAYS * 86400
    db.execute(
        "INSERT INTO sessions (token_hash, steam_id, created_at, expires_at, last_used_at) VALUES (?, ?, ?, ?, ?)",
        (token_hash(session_token), device["steam_id"], timestamp, session_expires_at, timestamp),
    )
    db.execute("UPDATE device_codes SET consumed_at = ? WHERE device_hash = ?", (timestamp, token_hash(device_code)))
    profile = profile_for(db, device["steam_id"])
    return HTTPStatus.OK, {
        "access_token": session_token,
        "token_type": "Bearer",
        "expires_in": SESSION_DAYS * 86400,
        "expires_at": session_expires_at,
        "profile": profile,
    }


class ApiHandler(BaseHTTPRequestHandler):
    server_version = "TCW"
    sys_version = ""

    def version_string(self) -> str:
        return "TCW"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"{self.address_string()} - {fmt % args}")

    def send_json(self, status: int, value: Any, headers: dict[str, str] | None = None) -> None:
        body = json_bytes(value)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        origin = self.headers.get("Origin", "").rstrip("/")
        if origin in ALLOWED_CORS_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        for key, header_value in (headers or {}).items():
            self.send_header(key, header_value)
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:  # noqa: N802
        origin = self.headers.get("Origin", "").rstrip("/")
        if origin not in ALLOWED_CORS_ORIGINS:
            self.send_response(HTTPStatus.FORBIDDEN)
            self.end_headers()
            return
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Access-Control-Allow-Origin", origin)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Vary", "Origin")
        self.end_headers()

    def send_html(self, status: int, title: str, message: str) -> None:
        body = (
            "<!doctype html><meta charset='utf-8'><title>"
            + html.escape(title)
            + "</title><style>body{background:#11151c;color:#f1f4f8;font-family:system-ui;"
            "display:grid;place-items:center;min-height:100vh;margin:0}.card{background:#181e28;"
            "border:1px solid #4f7898;border-radius:12px;padding:32px;max-width:560px}</style>"
            "<div class='card'><h1>"
            + html.escape(title)
            + "</h1><p>"
            + html.escape(message)
            + "</p></div>"
        ).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_steam_return_html(self, status: int, title: str, message: str, result: str, user_code: str) -> None:
        query = {"steam": result}
        if user_code:
            query["user_code"] = user_code
        return_url = f"{WEB_BASE_URL}/profile.html?{urllib.parse.urlencode(query)}"
        escaped_url = html.escape(return_url, quote=True)
        body = (
            "<!doctype html><html lang='en'><head><meta charset='utf-8'><title>"
            + html.escape(title)
            + "</title><meta name='viewport' content='width=device-width,initial-scale=1'>"
            + (f"<meta http-equiv='refresh' content='2;url={escaped_url}'>" if status < 400 else "")
            + "<style>body{background:#070b12;color:#f1f4f8;font-family:system-ui,sans-serif;"
            "display:grid;place-items:center;min-height:100vh;margin:0}.card{background:#101722;"
            "border:1px solid #4f7898;border-radius:12px;padding:32px;max-width:620px}"
            "a{display:inline-block;margin-top:18px;color:#111;background:#f1f4f8;border-radius:8px;"
            "padding:12px 18px;text-decoration:none;font-weight:800}</style></head><body><div class='card'><h1>"
            + html.escape(title)
            + "</h1><p>"
            + html.escape(message)
            + "</p><a href='"
            + escaped_url
            + "'>Return to TCWA3 Profile</a></div></body></html>"
        ).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_body(self, max_bytes: int = MAX_BODY_BYTES) -> bytes:
        length = int(self.headers.get("Content-Length", "0"))
        if length < 0 or length > max_bytes:
            raise ValueError("Request body is too large")
        return self.rfile.read(length)

    def read_json(self, body: bytes | None = None, max_bytes: int = MAX_BODY_BYTES) -> dict[str, Any]:
        decoded = json.loads((body if body is not None else self.read_body(max_bytes)).decode("utf-8"))
        if not isinstance(decoded, dict):
            raise ValueError("JSON body must be an object")
        return decoded

    def bearer_steam_id(self, db: sqlite3.Connection) -> str | None:
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            return None
        hashed = token_hash(authorization[7:].strip())
        timestamp = now()
        session = db.execute(
            "SELECT steam_id FROM sessions WHERE token_hash = ? AND expires_at > ?",
            (hashed, timestamp),
        ).fetchone()
        if session is None:
            return None
        db.execute(
            "UPDATE sessions SET last_used_at = ?, expires_at = ? WHERE token_hash = ?",
            (timestamp, timestamp + SESSION_DAYS * 86400, hashed),
        )
        db.commit()
        return session["steam_id"]

    def bearer_session_expires_at(self, db: sqlite3.Connection) -> int:
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            return 0
        row = db.execute(
            "SELECT expires_at FROM sessions WHERE token_hash = ?",
            (token_hash(authorization[7:].strip()),),
        ).fetchone()
        return int(row["expires_at"]) if row is not None else 0

    def has_admin_token(self) -> bool:
        if not NEWS_ADMIN_TOKEN:
            return False
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            return False
        return hmac.compare_digest(authorization[7:].strip(), NEWS_ADMIN_TOKEN)

    def has_owner_admin_token(self) -> bool:
        if not OWNER_ADMIN_TOKEN:
            return False
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            return False
        return hmac.compare_digest(authorization[7:].strip(), OWNER_ADMIN_TOKEN)

    def has_community_manager_token(self) -> bool:
        if not COMMUNITY_MANAGER_TOKEN:
            return False
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            return False
        return hmac.compare_digest(authorization[7:].strip(), COMMUNITY_MANAGER_TOKEN)

    def has_community_manager_access(self, method: str, path: str) -> bool:
        if self.has_owner_admin_token() and owner_admin_route_allowed(method, path):
            return True
        return community_manager_route_allowed(method, path) and self.has_community_manager_token()

    def has_owner_admin_access(self, method: str, path: str) -> bool:
        return owner_admin_route_allowed(method, path) and self.has_owner_admin_token()

    def admin_role(self) -> str:
        if self.has_owner_admin_token():
            return "owner_admin"
        if self.has_community_manager_token():
            return "community_manager"
        if self.has_admin_token():
            return "owner_admin"
        return ""

    def verify_official_server_request(self, body: bytes) -> tuple[str, tuple[HTTPStatus, dict[str, Any]] | None]:
        server_id = self.headers.get("X-TCW-Server", "")
        timestamp_text = self.headers.get("X-TCW-Timestamp", "")
        signature = self.headers.get("X-TCW-Signature", "").lower()
        secret = SERVER_KEYS.get(server_id)
        route = urllib.parse.urlparse(self.path).path
        if not secret:
            log_backend_event(
                "official_server_auth_failed",
                path=route,
                server_id=server_id or "missing",
                reason="unknown_server",
            )
            return "", (HTTPStatus.UNAUTHORIZED, {"error": "invalid_server_auth"})
        if not timestamp_text.isdigit():
            log_backend_event(
                "official_server_auth_failed",
                path=route,
                server_id=server_id,
                reason="invalid_timestamp",
            )
            return "", (HTTPStatus.UNAUTHORIZED, {"error": "invalid_server_auth"})
        timestamp_skew = abs(now() - int(timestamp_text))
        if timestamp_skew > 300:
            log_backend_event(
                "official_server_auth_failed",
                path=route,
                server_id=server_id,
                reason="timestamp_skew",
                skew_seconds=timestamp_skew,
            )
            return "", (HTTPStatus.UNAUTHORIZED, {"error": "invalid_server_auth"})
        # Official servers sign the exact raw JSON body. The timestamp is part
        # of the HMAC input so captured requests cannot be replayed later.
        expected = hmac.new(
            secret.encode("utf-8"),
            timestamp_text.encode("ascii") + b"." + body,
            hashlib.sha256,
        ).hexdigest()
        if not hmac.compare_digest(expected, signature):
            log_backend_event(
                "official_server_signature_failed",
                path=route,
                server_id=server_id,
                reason="signature_mismatch",
            )
            return "", (HTTPStatus.UNAUTHORIZED, {"error": "invalid_server_signature"})
        return server_id, None

    def verify_discord_bot_request(self, body: bytes) -> tuple[str, tuple[HTTPStatus, dict[str, Any]] | None]:
        bot_id = self.headers.get("X-TCWA3-Bot-Id", "").strip()
        timestamp_text = self.headers.get("X-TCWA3-Timestamp", "").strip()
        signature = self.headers.get("X-TCWA3-Signature", "").strip().lower()
        if signature.startswith("sha256="):
            signature = signature[7:]
        secret = DISCORD_BOT_KEYS.get(bot_id)
        parsed = urllib.parse.urlparse(self.path)
        if not secret:
            log_backend_event(
                "discord_bot_auth_failed",
                path=parsed.path,
                bot_id=bot_id or "missing",
                reason="unknown_bot",
            )
            return "", (HTTPStatus.UNAUTHORIZED, {"error": "invalid_bot_auth"})
        if not timestamp_text.isdigit():
            log_backend_event(
                "discord_bot_auth_failed",
                path=parsed.path,
                bot_id=bot_id,
                reason="invalid_timestamp",
            )
            return "", (HTTPStatus.UNAUTHORIZED, {"error": "invalid_bot_auth"})
        timestamp_skew = abs(now() - int(timestamp_text))
        if timestamp_skew > BOT_SIGNATURE_WINDOW_SECONDS:
            log_backend_event(
                "discord_bot_auth_failed",
                path=parsed.path,
                bot_id=bot_id,
                reason="timestamp_skew",
                skew_seconds=timestamp_skew,
            )
            return "", (HTTPStatus.UNAUTHORIZED, {"error": "invalid_bot_auth"})
        signed = (
            timestamp_text.encode("ascii")
            + b"."
            + self.command.upper().encode("ascii")
            + b"."
            + parsed.path.encode("utf-8")
            + b"."
            + parsed.query.encode("utf-8")
            + b"."
            + body
        )
        expected = hmac.new(secret.encode("utf-8"), signed, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, signature):
            log_backend_event(
                "discord_bot_signature_failed",
                path=parsed.path,
                bot_id=bot_id,
                reason="signature_mismatch",
            )
            return "", (HTTPStatus.UNAUTHORIZED, {"error": "invalid_bot_signature"})
        return bot_id, None

    def do_GET(self) -> None:  # noqa: N802
        # This handler is intentionally small and explicit. Adding a route here
        # should also update docs/ARCHITECTURE.md and any Cloudflare WAF rules.
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path in ["/health", "/v1/health"]:
            self.send_json(HTTPStatus.OK, {"status": "ok"})
            return
        if parsed.path == "/v1/news":
            self.send_json(HTTPStatus.OK, {"items": load_news(), "updated_at": now()})
            return
        if parsed.path == "/v1/events":
            self.send_json(HTTPStatus.OK, load_event_manifest())
            return
        if parsed.path == "/v1/youtube/latest":
            self.send_json(HTTPStatus.OK, latest_youtube_video())
            return
        if parsed.path == "/v1/audio":
            self.send_json(HTTPStatus.OK, load_audio_manifest())
            return
        if parsed.path == "/v1/themes":
            self.send_json(HTTPStatus.OK, load_theme_manifest())
            return
        if parsed.path == "/v1/avatars":
            self.send_json(HTTPStatus.OK, {"avatars": avatar_catalog(), "default_avatar_id": DEFAULT_AVATAR_ID, "updated_at": now()})
            return
        if parsed.path == "/v1/community/leaderboards":
            query = urllib.parse.parse_qs(parsed.query)
            try:
                limit = int(query.get("limit", ["10"])[0])
            except (TypeError, ValueError):
                limit = 10
            with connect_db() as db:
                self.send_json(HTTPStatus.OK, community_leaderboards(db, limit))
            return
        if parsed.path == "/v1/community/reactions":
            query = urllib.parse.parse_qs(parsed.query)
            target_type = str(query.get("target_type", [""])[0]).strip().lower()
            target_id = clean_support_text(query.get("target_id", [""])[0], 160)
            if target_type not in COMMUNITY_REACTION_TARGET_TYPES or not target_id:
                self.send_json(HTTPStatus.BAD_REQUEST, {"error": "invalid_reaction_target"})
                return
            with connect_db() as db:
                steam_id = self.bearer_steam_id(db)
                self.send_json(HTTPStatus.OK, community_reaction_summary(db, target_type, target_id, steam_id))
            return
        if parsed.path == "/v1/roster/status":
            with connect_db() as db:
                self.send_json(HTTPStatus.OK, roster_bridge_status(db))
            return
        if parsed.path == "/v1/roster/members":
            query = urllib.parse.parse_qs(parsed.query)
            unit = str(query.get("unit", [""])[0])[:32].strip()
            search = clean_profile_search(query.get("search", [""])[0])
            try:
                page = int(query.get("page", ["1"])[0])
            except (TypeError, ValueError):
                page = 1
            try:
                limit = int(query.get("limit", [str(PUBLIC_PROFILE_DEFAULT_LIMIT)])[0])
            except (TypeError, ValueError):
                limit = PUBLIC_PROFILE_DEFAULT_LIMIT
            with connect_db() as db:
                self.send_json(HTTPStatus.OK, list_roster_members(db, unit, search, page, limit))
            return
        if parsed.path == "/v1/bot/discord/link-status":
            body = b""
            bot_id, error = self.verify_discord_bot_request(body)
            if error is not None:
                self.send_json(error[0], error[1])
                return
            query = urllib.parse.parse_qs(parsed.query)
            with connect_db() as db:
                status, payload = discord_link_code_status(db, str(query.get("link_id", [""])[0]))
                if status == HTTPStatus.OK:
                    record_bot_audit(db, bot_id, "discord_link_status_checked", payload.get("discord_id", ""), {"link_id": payload.get("link_id", "")})
                self.send_json(status, payload)
            return
        if parsed.path == "/v1/quests":
            with connect_db() as db:
                self.send_json(HTTPStatus.OK, quest_overview(db))
            return
        if parsed.path == "/v1/servers":
            self.send_json(HTTPStatus.OK, {**load_server_catalog(), "updated_at": now()})
            return
        if parsed.path == "/v1/marketplace":
            with connect_db() as db:
                steam_id = self.bearer_steam_id(db)
                self.send_json(HTTPStatus.OK, marketplace_catalog_for_player(db, steam_id) if steam_id else marketplace_catalog_for_player())
            return
        if parsed.path.startswith("/v1/profiles/"):
            steam_id = parsed.path.rsplit("/", 1)[-1].strip()
            if not STEAM_ID_PATTERN.fullmatch(steam_id):
                self.send_json(HTTPStatus.BAD_REQUEST, {"error": "invalid_steam_id"})
                return
            with connect_db() as db:
                profile = public_profile_detail(db, steam_id)
                if not profile:
                    self.send_json(
                        HTTPStatus.NOT_FOUND,
                        {
                            "error": "profile_not_found",
                            "message": "That profile is private, missing, or not Steam verified yet.",
                        },
                    )
                    return
                self.send_json(HTTPStatus.OK, {"profile": profile, "updated_at": now()})
            return
        if parsed.path == "/v1/profiles":
            query = urllib.parse.parse_qs(parsed.query)
            unit = str(query.get("unit", [""])[0])[:32].strip()
            sort_mode = str(query.get("sort", ["active"])[0]).strip().lower()
            if sort_mode not in {"active", "legion", "level"}:
                sort_mode = "active"
            search = clean_profile_search(query.get("search", [""])[0])
            try:
                page = int(query.get("page", ["1"])[0])
            except (TypeError, ValueError):
                page = 1
            try:
                limit = int(query.get("limit", [str(PUBLIC_PROFILE_DEFAULT_LIMIT)])[0])
            except (TypeError, ValueError):
                limit = PUBLIC_PROFILE_DEFAULT_LIMIT
            with connect_db() as db:
                listing = list_public_profiles(db, unit, sort_mode, search, page, limit)
                self.send_json(
                    HTTPStatus.OK,
                    {
                        "profiles": listing["profiles"],
                        "pagination": listing["pagination"],
                        "units": public_profile_units(db),
                        "updated_at": now(),
                    },
                )
            return
        if parsed.path == "/v1/admin/news":
            if not (self.has_admin_token() or self.has_owner_admin_access("GET", parsed.path)):
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_admin_token"})
                return
            self.send_json(HTTPStatus.OK, {"items": load_news(), "updated_at": now()})
            return
        if parsed.path == "/v1/admin/assets":
            if not self.has_community_manager_access("GET", parsed.path):
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
                return
            self.send_json(HTTPStatus.OK, load_community_asset_inventory(self.admin_role() or "community_manager"))
            return
        if parsed.path == "/v1/admin/events":
            if not self.has_community_manager_access("GET", parsed.path):
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
                return
            self.send_json(HTTPStatus.OK, {"events": load_event_banners(include_inactive=True), "updated_at": now()})
            return
        if parsed.path == "/v1/admin/servers":
            if not self.has_community_manager_access("GET", parsed.path):
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
                return
            self.send_json(HTTPStatus.OK, {**load_server_catalog(include_hidden=True), "updated_at": now()})
            return
        if parsed.path == "/v1/admin/server-controls":
            if not self.has_community_manager_access("GET", parsed.path):
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
                return
            self.send_json(HTTPStatus.OK, {**load_server_controls(), "updated_at": now()})
            return
        if parsed.path == "/v1/admin/roster-link-requests":
            if not self.has_owner_admin_access("GET", parsed.path):
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_owner_admin_token"})
                return
            query = urllib.parse.parse_qs(parsed.query)
            with connect_db() as db:
                self.send_json(
                    HTTPStatus.OK,
                    {
                        "requests": list_roster_link_requests(db, str(query.get("status", ["pending"])[0])),
                        "updated_at": now(),
                    },
                )
            return
        if parsed.path == "/v1/admin/audit-log":
            if not self.has_owner_admin_access("GET", parsed.path):
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_owner_admin_token"})
                return
            query = urllib.parse.parse_qs(parsed.query)
            try:
                limit = int(query.get("limit", ["100"])[0])
            except (TypeError, ValueError):
                limit = 100
            with connect_db() as db:
                self.send_json(HTTPStatus.OK, {"items": list_admin_audit(db, limit), "updated_at": now()})
            return
        if parsed.path == "/v1/admin/comlink/sessions":
            self.get_admin_comlink_sessions(parsed)
            return
        if parsed.path == "/v1/admin/comlink/audit":
            self.get_admin_comlink_audit(parsed)
            return
        if parsed.path == "/v1/launcher/latest":
            query = urllib.parse.parse_qs(parsed.query)
            current_version = str(query.get("version", [""])[0])
            platform = str(query.get("platform", ["windows"])[0])
            self.send_json(HTTPStatus.OK, load_release_manifest(current_version, platform))
            return
        if parsed.path == "/v1/server-status":
            query = urllib.parse.parse_qs(parsed.query)
            ip = str(query.get("ip", [""])[0])
            name = str(query.get("name", [""])[0])
            try:
                port = int(query.get("port", ["0"])[0])
            except (TypeError, ValueError):
                port = 0
            self.send_json(HTTPStatus.OK, apply_server_control(battlemetrics_status(ip, port, name), ip, port))
            return
        if parsed.path == "/v1/roster/discord/start":
            self.start_roster_discord_login(parsed)
            return
        if parsed.path == "/v1/roster/operations":
            query = urllib.parse.parse_qs(parsed.query)
            params = {key: values[-1] for key, values in query.items() if key != "path" and values}
            status, payload = stats_proxy_request("/v1/operations", method="GET", params=params)
            self.send_json(status, payload)
            return
        if parsed.path == "/v1/comlink/status":
            self.get_comlink_status(parsed)
            return
        if parsed.path == "/v1/comlink/channels":
            self.get_comlink_channels(parsed)
            return
        if parsed.path == "/v1/me":
            with connect_db() as db:
                steam_id = self.bearer_steam_id(db)
                if steam_id is None:
                    self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                    return
                profile = profile_for(db, steam_id)
                session_expires_at = self.bearer_session_expires_at(db)
            self.send_json(
                HTTPStatus.OK,
                {
                    "profile": profile,
                    "session_expires_at": session_expires_at,
                    "session_expires_in": max(0, session_expires_at - now()) if session_expires_at else 0,
                },
            )
            return
        if parsed.path == "/v1/me/recent":
            with connect_db() as db:
                steam_id = self.bearer_steam_id(db)
                if steam_id is None:
                    self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                    return
                self.send_json(HTTPStatus.OK, {"profiles": recently_played_with(db, steam_id), "updated_at": now()})
            return
        if parsed.path == "/v1/me/quests":
            with connect_db() as db:
                steam_id = self.bearer_steam_id(db)
                if steam_id is None:
                    self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                    return
                self.send_json(HTTPStatus.OK, quest_overview(db, steam_id))
            return
        if parsed.path == "/v1/auth/steam":
            self.start_steam_login(parsed)
            return
        if parsed.path == "/v1/auth/steam/callback":
            self.finish_steam_login(parsed)
            return
        self.send_json(HTTPStatus.NOT_FOUND, {"error": "not_found"})

    def do_POST(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        try:
            if parsed.path == "/v1/auth/device/start":
                self.start_device_auth()
                return
            if parsed.path == "/v1/auth/device/token":
                self.exchange_device_token()
                return
            if parsed.path == "/v1/auth/logout":
                self.logout()
                return
            if parsed.path == "/v1/me":
                self.update_profile()
                return
            if parsed.path == "/v1/me/discord-link":
                self.claim_discord_link_code()
                return
            if parsed.path == "/v1/me/achievements/acknowledge":
                self.acknowledge_achievements()
                return
            if parsed.path == "/v1/community/reactions":
                self.update_community_reaction()
                return
            if parsed.path == "/v1/bot/discord/link-code":
                self.create_discord_bot_link_code()
                return
            if parsed.path == "/v1/bot/discord/member-sync":
                self.sync_discord_bot_members()
                return
            if parsed.path == "/v1/bot/discord/notification-events":
                self.ingest_discord_bot_notifications()
                return
            if parsed.path == "/v1/roster/discord/exchange":
                self.exchange_roster_discord_token()
                return
            if parsed.path == "/v1/roster/discord/refresh":
                self.refresh_roster_discord_token()
                return
            if parsed.path == "/v1/roster/discord/logout":
                self.logout_roster_discord()
                return
            if parsed.path == "/v1/roster/me":
                self.sync_roster_from_access_token()
                return
            if parsed.path == "/v1/me/roster-link":
                self.link_roster_profile()
                return
            if parsed.path == "/v1/roster-link-requests":
                self.create_roster_link_request()
                return
            if parsed.path == "/v1/marketplace/purchase":
                self.purchase_marketplace_item()
                return
            if parsed.path == "/v1/comlink/token":
                self.create_comlink_token()
                return
            if parsed.path == "/v1/comlink/switch":
                self.switch_comlink()
                return
            if parsed.path == "/v1/comlink/leave":
                self.leave_comlink()
                return
            if parsed.path == "/v1/comlink/client-event":
                self.report_comlink_client_event()
                return
            if parsed.path == "/v1/admin/news":
                self.update_news()
                return
            if parsed.path == "/v1/admin/events":
                self.update_events()
                return
            if parsed.path == "/v1/admin/servers":
                self.update_servers()
                return
            if parsed.path == "/v1/admin/server-controls":
                self.update_server_controls()
                return
            if parsed.path == "/v1/admin/assets/upload":
                self.upload_community_asset()
                return
            if parsed.path == "/v1/admin/assets/delete":
                self.delete_community_asset()
                return
            if parsed.path == "/v1/admin/roster-link-requests":
                self.review_roster_link_request()
                return
            if parsed.path == "/v1/admin/player-support":
                self.update_player_support()
                return
            if parsed.path == "/v1/admin/comlink/revoke":
                self.revoke_comlink()
                return
            if parsed.path == "/v1/server/ownership/check":
                self.check_marketplace_ownership()
                return
            if parsed.path == "/v1/server/profile-snapshots":
                self.get_server_profile_snapshots()
                return
            if parsed.path == "/v1/server/events":
                self.ingest_events()
                return
        except (ValueError, json.JSONDecodeError) as exc:
            if parsed.path == "/v1/server/events":
                log_backend_event("official_server_events_bad_payload", path=parsed.path, reason=str(exc))
            elif parsed.path.startswith("/v1/bot/"):
                log_backend_event("discord_bot_bad_request", path=parsed.path, reason=str(exc))
            elif parsed.path.startswith("/v1/roster/"):
                log_backend_event("discord_roster_bad_request", path=parsed.path, reason=str(exc))
            elif parsed.path.startswith("/v1/auth/"):
                log_backend_event("steam_auth_bad_request", path=parsed.path, reason=str(exc))
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": "bad_request", "message": str(exc)})
            return
        self.send_json(HTTPStatus.NOT_FOUND, {"error": "not_found"})

    def start_device_auth(self) -> None:
        if not PUBLIC_BASE_URL:
            log_backend_event("steam_device_start_failed", path="/v1/auth/device/start", reason="public_url_not_configured")
            self.send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": "public_url_not_configured"})
            return
        # The launcher cannot safely embed Steam credentials, so it receives a
        # short-lived device_code and opens the browser for real Steam OpenID.
        device_code = secrets.token_urlsafe(32)
        alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        user_code = "".join(secrets.choice(alphabet) for _ in range(8))
        timestamp = now()
        with connect_db() as db:
            db.execute("DELETE FROM device_codes WHERE expires_at <= ?", (timestamp,))
            db.execute(
                "INSERT INTO device_codes (device_hash, user_code, created_at, expires_at) VALUES (?, ?, ?, ?)",
                (token_hash(device_code), user_code, timestamp, timestamp + DEVICE_CODE_TTL),
            )
        verification_uri = f"{PUBLIC_BASE_URL}/v1/auth/steam?{urllib.parse.urlencode({'user_code': user_code})}"
        self.send_json(
            HTTPStatus.OK,
            {
                "device_code": device_code,
                "user_code": user_code,
                "verification_uri": verification_uri,
                "expires_in": DEVICE_CODE_TTL,
                "interval": 3,
            },
        )

    def start_steam_login(self, parsed: urllib.parse.ParseResult) -> None:
        query = urllib.parse.parse_qs(parsed.query)
        user_code = str(query.get("user_code", [""])[0]).upper()
        with connect_db() as db:
            device = db.execute(
                "SELECT user_code FROM device_codes WHERE user_code = ? AND status = 'pending' AND expires_at > ?",
                (user_code, now()),
            ).fetchone()
        if device is None:
            self.send_html(HTTPStatus.BAD_REQUEST, "Invalid code", "This TCWA3 sign-in code is invalid or expired.")
            return
        return_to = f"{PUBLIC_BASE_URL}/v1/auth/steam/callback?{urllib.parse.urlencode({'user_code': user_code})}"
        parameters = {
            "openid.ns": "http://specs.openid.net/auth/2.0",
            "openid.mode": "checkid_setup",
            "openid.return_to": return_to,
            "openid.realm": PUBLIC_BASE_URL + "/",
            "openid.identity": "http://specs.openid.net/auth/2.0/identifier_select",
            "openid.claimed_id": "http://specs.openid.net/auth/2.0/identifier_select",
        }
        self.send_response(HTTPStatus.FOUND)
        self.send_header("Location", STEAM_OPENID + "?" + urllib.parse.urlencode(parameters))
        self.end_headers()

    def finish_steam_login(self, parsed: urllib.parse.ParseResult) -> None:
        query = urllib.parse.parse_qs(parsed.query)
        user_code = str(query.get("user_code", [""])[0]).upper()
        openid = {key: values[0] for key, values in query.items() if key.startswith("openid.")}
        claimed_id = openid.get("openid.claimed_id", "")
        steam_id = claimed_id.rsplit("/", 1)[-1]
        if not STEAM_ID_PATTERN.fullmatch(steam_id):
            log_backend_event(
                "steam_login_failed",
                path="/v1/auth/steam/callback",
                reason="invalid_claimed_id",
                has_user_code=bool(user_code),
            )
            self.send_steam_return_html(HTTPStatus.UNAUTHORIZED, "Sign-in failed", "Steam could not verify this sign-in.", "failed", user_code)
            return
        if not self.verify_steam_openid(openid):
            log_backend_event(
                "steam_login_failed",
                path="/v1/auth/steam/callback",
                steam_id=steam_id,
                reason="openid_rejected",
                has_user_code=bool(user_code),
            )
            self.send_steam_return_html(HTTPStatus.UNAUTHORIZED, "Sign-in failed", "Steam could not verify this sign-in.", "failed", user_code)
            return
        # Approval is stored against the pending device code. The launcher later
        # exchanges its private device_code for a bearer token; the user_code in
        # the browser is not enough to create a launcher session by itself.
        timestamp = now()
        with connect_db() as db:
            device = db.execute(
                "SELECT user_code FROM device_codes WHERE user_code = ? AND status = 'pending' AND expires_at > ?",
                (user_code, timestamp),
            ).fetchone()
            if device is None:
                log_backend_event(
                    "steam_login_failed",
                    path="/v1/auth/steam/callback",
                    steam_id=steam_id,
                    reason="device_code_missing_or_expired",
                    has_user_code=bool(user_code),
                )
                self.send_steam_return_html(HTTPStatus.BAD_REQUEST, "Code expired", "Return to TCWA3 and start sign-in again.", "failed", user_code)
                return
            steam_display_name = fetch_steam_display_name(steam_id) or DEFAULT_DISPLAY_NAME
            db.execute(
                """
                INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(steam_id) DO UPDATE SET
                    verified_at = excluded.verified_at,
                    display_name = CASE
                        WHEN (users.arma_profile_name IS NULL OR users.arma_profile_name = '')
                         AND (users.roster_name IS NULL OR users.roster_name = '')
                         AND (users.display_name IS NULL OR users.display_name = ''
                              OR users.display_name IN ('Unknown', 'Unknown Steam', 'Unknown Trooper', 'Clone trooper'))
                        THEN excluded.display_name ELSE users.display_name END,
                    updated_at = excluded.updated_at
                """,
                (steam_id, steam_display_name, timestamp, timestamp, timestamp),
            )
            db.execute("INSERT OR IGNORE INTO stats (steam_id) VALUES (?)", (steam_id,))
            db.execute(
                "UPDATE device_codes SET steam_id = ?, status = 'approved' WHERE user_code = ?",
                (steam_id, user_code),
            )
        self.send_steam_return_html(
            HTTPStatus.OK,
            "Steam verified",
            "Your TCW profile is connected. Returning you to the website profile page now.",
            "verified",
            user_code,
        )

    def start_roster_discord_login(self, parsed: urllib.parse.ParseResult) -> None:
        query = urllib.parse.parse_qs(parsed.query)
        return_to = normalise_roster_return_to(query.get("return_to", [""])[0])
        location = stats_proxy_redirect_url(
            "/auth/discord/start",
            {"mode": "jwt", "return_to": return_to},
        )
        if not location:
            log_backend_event("discord_roster_start_failed", path="/v1/roster/discord/start", reason="stats_proxy_not_configured")
            self.send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": "stats_proxy_not_configured"})
            return
        self.send_response(HTTPStatus.FOUND)
        self.send_header("Location", location)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def exchange_roster_discord_token(self) -> None:
        payload = self.read_json()
        handoff_code = str(payload.get("handoff_code", "")).strip()
        if not handoff_code:
            raise ValueError("handoff_code is required")
        status, result = stats_proxy_request(
            "/auth/jwt/exchange",
            method="POST",
            body={"handoff_code": handoff_code},
        )
        if status >= 400:
            log_backend_event(
                "discord_roster_exchange_failed",
                path="/auth/jwt/exchange",
                status_code=status,
                reason=result.get("error"),
            )
        if status < 400 and result.get("access_token"):
            expected_steam_id = ""
            with connect_db() as db:
                expected_steam_id = self.bearer_steam_id(db) or ""
            sync_status, sync_payload = fetch_external_roster_profile(str(result.get("access_token", "")), expected_steam_id)
            if sync_status < 400:
                result["profile"] = sync_payload.get("profile")
                result["profile_sync"] = sync_payload.get("external", {})
            else:
                log_backend_event(
                    "discord_roster_exchange_failed",
                    path="/v1/me",
                    status_code=sync_status,
                    reason=sync_payload.get("error"),
                )
                result["profile_sync_error"] = sync_payload
        self.send_json(status, result)

    def refresh_roster_discord_token(self) -> None:
        payload = self.read_json()
        refresh_token = str(payload.get("refresh_token", "")).strip()
        if not refresh_token:
            raise ValueError("refresh_token is required")
        status, result = stats_proxy_request(
            "/auth/jwt/refresh",
            method="POST",
            body={"refresh_token": refresh_token},
        )
        if status >= 400:
            log_backend_event(
                "discord_roster_refresh_failed",
                path="/auth/jwt/refresh",
                status_code=status,
                reason=result.get("error"),
            )
        self.send_json(status, result)

    def logout_roster_discord(self) -> None:
        payload = self.read_json() if int(self.headers.get("Content-Length", "0") or "0") > 0 else {}
        refresh_token = str(payload.get("refresh_token", "")).strip()
        if refresh_token:
            status, result = stats_proxy_request(
                "/auth/jwt/logout",
                method="POST",
                body={"refresh_token": refresh_token},
            )
        else:
            status, result = HTTPStatus.OK, {"ok": True}
        self.send_json(status, result)

    def sync_roster_from_access_token(self) -> None:
        payload = self.read_json()
        access_token = str(payload.get("access_token", "")).strip()
        status, result = fetch_external_roster_profile(access_token)
        if status >= 400:
            log_backend_event(
                "discord_roster_sync_failed",
                path="/v1/roster/me",
                status_code=status,
                reason=result.get("error"),
            )
        self.send_json(status, result)

    @staticmethod
    def verify_steam_openid(openid: dict[str, str]) -> bool:
        payload = dict(openid)
        payload["openid.mode"] = "check_authentication"
        request = urllib.request.Request(
            STEAM_OPENID,
            data=urllib.parse.urlencode(payload).encode("utf-8"),
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                result = response.read().decode("utf-8", "replace")
        except (urllib.error.URLError, TimeoutError) as exc:
            log_backend_event("steam_openid_check_failed", reason=type(exc).__name__)
            return False
        verified = "is_valid:true" in result
        if not verified:
            log_backend_event("steam_openid_check_failed", reason="invalid_response")
        return verified

    def exchange_device_token(self) -> None:
        payload = self.read_json()
        device_code = str(payload.get("device_code", ""))
        if not device_code:
            raise ValueError("device_code is required")
        with connect_db() as db:
            status, result = exchange_device_code_for_session(db, device_code)
        if status >= 400:
            log_backend_event(
                "steam_device_token_failed",
                path="/v1/auth/device/token",
                status_code=status,
                reason=result.get("error"),
            )
        self.send_json(status, result)

    def logout(self) -> None:
        authorization = self.headers.get("Authorization", "")
        if authorization.startswith("Bearer "):
            with connect_db() as db:
                db.execute("DELETE FROM sessions WHERE token_hash = ?", (token_hash(authorization[7:].strip()),))
        self.send_json(HTTPStatus.OK, {"status": "signed_out"})

    def create_discord_bot_link_code(self) -> None:
        body = self.read_body()
        bot_id, error = self.verify_discord_bot_request(body)
        if error is not None:
            self.send_json(error[0], error[1])
            return
        payload = self.read_json(body)
        with connect_db() as db:
            result = create_discord_bot_link_code(db, payload, bot_id)
        self.send_json(HTTPStatus.OK, result)

    def sync_discord_bot_members(self) -> None:
        body = self.read_body()
        bot_id, error = self.verify_discord_bot_request(body)
        if error is not None:
            self.send_json(error[0], error[1])
            return
        payload = self.read_json(body)
        with connect_db() as db:
            result = sync_discord_members(db, payload, bot_id)
        self.send_json(HTTPStatus.OK, result)

    def ingest_discord_bot_notifications(self) -> None:
        body = self.read_body()
        bot_id, error = self.verify_discord_bot_request(body)
        if error is not None:
            self.send_json(error[0], error[1])
            return
        payload = self.read_json(body)
        with connect_db() as db:
            result = record_discord_notification_events(db, payload, bot_id)
        self.send_json(HTTPStatus.OK, result)

    def claim_discord_link_code(self) -> None:
        payload = self.read_json()
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            status, result = claim_discord_bot_link_code(db, steam_id, payload.get("code"))
        self.send_json(status, result)

    def update_community_reaction(self) -> None:
        payload = self.read_json()
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            status, result = update_community_reaction(db, steam_id, payload)
        self.send_json(status, result)

    def update_profile(self) -> None:
        payload = self.read_json()
        bio = clean_profile_bio(payload.get("bio", ""))
        profile_public = bool(payload.get("profile_public", True))
        avatar_id = None
        if "avatar_id" in payload:
            avatar_id = clean_avatar_id(payload.get("avatar_id", DEFAULT_AVATAR_ID))
            if not avatar_id_is_available(avatar_id):
                raise ValueError("avatar_id is not available")
        timestamp = now()
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            if avatar_id is None:
                db.execute(
                    "UPDATE users SET bio = ?, profile_public = ?, updated_at = ? WHERE steam_id = ?",
                    (bio, 1 if profile_public else 0, timestamp, steam_id),
                )
            else:
                db.execute(
                    "UPDATE users SET bio = ?, profile_public = ?, avatar_id = ?, updated_at = ? WHERE steam_id = ?",
                    (bio, 1 if profile_public else 0, avatar_id, timestamp, steam_id),
                )
            profile = profile_for(db, steam_id)
            safe_write_player_profile_snapshot(db, steam_id)
        self.send_json(HTTPStatus.OK, {"status": "saved", "profile": profile, "max_bio_chars": MAX_PROFILE_BIO_CHARS})

    def acknowledge_achievements(self) -> None:
        payload = self.read_json()
        achievement_ids = payload.get("achievement_ids", [])
        if achievement_ids is None:
            achievement_ids = []
        if not isinstance(achievement_ids, list):
            raise ValueError("achievement_ids must be a list")
        clean_ids = [str(achievement_id) for achievement_id in achievement_ids if str(achievement_id) in ACHIEVEMENTS]
        timestamp = now()
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            if clean_ids:
                placeholders = ",".join("?" for _ in clean_ids)
                db.execute(
                    f"UPDATE achievements SET acknowledged_at = ? WHERE steam_id = ? AND achievement_id IN ({placeholders})",
                    [timestamp, steam_id, *clean_ids],
                )
            else:
                db.execute(
                    "UPDATE achievements SET acknowledged_at = ? WHERE steam_id = ? AND acknowledged_at IS NULL",
                    (timestamp, steam_id),
                )
            profile = profile_for(db, steam_id)
            safe_write_player_profile_snapshot(db, steam_id)
        self.send_json(HTTPStatus.OK, {"status": "acknowledged", "profile": profile})

    def link_roster_profile(self) -> None:
        payload: dict[str, Any] = {}
        if int(self.headers.get("Content-Length", "0") or "0") > 0:
            payload = self.read_json()
        roster_access_token = str(payload.get("roster_access_token", "")).strip()
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
        if roster_access_token:
            status, result = fetch_external_roster_profile(roster_access_token, steam_id)
            self.send_json(status, result)
            return

        # Roster linking still supports the older squad XML path, but the
        # preferred TCWA3 roster/stat source is now the Discord-backed stats proxy.
        root_storm_result: dict[str, Any] = {}
        with connect_db() as db:
            root_storm_status, root_storm_result = try_link_root_storm_roster_from_discord(db, steam_id)
            if root_storm_status == HTTPStatus.OK and root_storm_result.get("profile"):
                profile = root_storm_result["profile"]
                safe_write_player_profile_snapshot(db, steam_id)
                self.send_json(
                    HTTPStatus.OK,
                    {
                        "status": "checked",
                        "profile": profile,
                        "rostered": True,
                        "root_storm": root_storm_result,
                        "message": root_storm_result.get("message", "Root Storm roster linked through the Discord bot bridge."),
                    },
                )
                return

        try:
            sync_roster()
        except Exception as exc:
            log_backend_event("discord_roster_squad_sync_failed", path="/v1/me/roster-link", reason=type(exc).__name__)
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            profile = profile_for(db, steam_id)
            if profile:
                safe_write_player_profile_snapshot(db, steam_id)
        api_base = PUBLIC_BASE_URL or "https://api.tcwa3.co.uk"
        return_to = normalise_roster_return_to(f"{WEB_BASE_URL}/profile.html?roster_return=1")
        login_url = f"{api_base}/v1/roster/discord/start?{urllib.parse.urlencode({'return_to': return_to})}"
        self.send_json(
            HTTPStatus.OK,
            {
                "status": "checked",
                "profile": profile,
                "rostered": bool(profile and profile.get("rostered")),
                "roster_login_url": login_url,
                "roster_request_url": "/v1/roster-link-requests",
                "root_storm": root_storm_result,
                "message": "Discord bot roster lookup did not complete. Galaxy Map sign-in is available, and staff review can be used if Discord blocks the handoff.",
            },
        )

    def create_roster_link_request(self) -> None:
        payload = self.read_json()
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            request = create_roster_link_request(db, steam_id, payload)
        self.send_json(
            HTTPStatus.OK,
            {
                "status": "queued",
                "request": request,
                "message": "Roster-link request queued for staff review.",
            },
        )

    def review_roster_link_request(self) -> None:
        if not self.has_owner_admin_access("POST", "/v1/admin/roster-link-requests"):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_owner_admin_token"})
            return
        with connect_db() as db:
            status, result = decide_roster_link_request(db, self.read_json(), self.admin_role() or "owner_admin")
        self.send_json(status, result)

    def update_player_support(self) -> None:
        if not self.has_owner_admin_access("POST", "/v1/admin/player-support"):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_owner_admin_token"})
            return
        with connect_db() as db:
            status, result = apply_player_support_action(db, self.read_json(), self.admin_role() or "owner_admin")
        self.send_json(status, result)

    def purchase_marketplace_item(self) -> None:
        payload = self.read_json()
        item_id = str(payload.get("item_id", "")).strip()
        if not item_id:
            raise ValueError("item_id is required")
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            status, result = purchase_marketplace_item(db, steam_id, item_id)
        self.send_json(status, result)

    def get_comlink_status(self, parsed: urllib.parse.ParseResult) -> None:
        query = urllib.parse.parse_qs(parsed.query)
        server_id = str(query.get("server_id", [""])[0])
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            self.send_json(HTTPStatus.OK, comlink_status_payload(db, steam_id, server_id))

    def get_comlink_channels(self, parsed: urllib.parse.ParseResult) -> None:
        query = urllib.parse.parse_qs(parsed.query)
        server_id = clean_comlink_id(query.get("server_id", [""])[0], "unassigned")
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            profile = profile_for(db, steam_id)
            self.send_json(
                HTTPStatus.OK,
                {
                    "feature": "project_bly_comlink",
                    "server_id": server_id,
                    "channels": comlink_channels_for_profile(profile),
                    "ready": comlink_ready(),
                    "transport": COMLINK_TRANSPORT,
                    "updated_at": now(),
                },
            )

    def create_comlink_token(self) -> None:
        payload = self.read_json()
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            status, result = issue_comlink_token(db, steam_id, payload)
        self.send_json(status, result)

    def leave_comlink(self) -> None:
        payload = self.read_json() if int(self.headers.get("Content-Length", "0") or "0") > 0 else {}
        with connect_db() as db:
            steam_id = self.bearer_steam_id(db)
            if steam_id is None:
                self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_session"})
                return
            result = leave_comlink_session(db, steam_id, payload)
        self.send_json(HTTPStatus.OK, result)

    def switch_comlink(self) -> None:
        with connect_db() as db:
            status, result = switch_comlink_channel(db, self.read_json())
        self.send_json(status, result)

    def report_comlink_client_event(self) -> None:
        with connect_db() as db:
            status, result = record_comlink_client_event(db, self.read_json())
        self.send_json(status, result)

    def get_admin_comlink_sessions(self, parsed: urllib.parse.ParseResult) -> None:
        if not self.has_owner_admin_access("GET", parsed.path):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_owner_admin_token"})
            return
        query = urllib.parse.parse_qs(parsed.query)
        try:
            limit = int(query.get("limit", ["100"])[0])
        except (TypeError, ValueError):
            limit = 100
        with connect_db() as db:
            self.send_json(HTTPStatus.OK, {"items": list_comlink_sessions(db, limit), "updated_at": now()})

    def get_admin_comlink_audit(self, parsed: urllib.parse.ParseResult) -> None:
        if not self.has_owner_admin_access("GET", parsed.path):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_owner_admin_token"})
            return
        query = urllib.parse.parse_qs(parsed.query)
        try:
            limit = int(query.get("limit", ["100"])[0])
        except (TypeError, ValueError):
            limit = 100
        with connect_db() as db:
            self.send_json(
                HTTPStatus.OK,
                {
                    "items": list_comlink_audit(
                        db,
                        limit,
                        action=str(query.get("action", [""])[0]),
                        steam_id=str(query.get("steam_id", [""])[0]),
                        server_id=str(query.get("server_id", [""])[0]),
                        channel_id=str(query.get("channel_id", [""])[0]),
                    ),
                    "updated_at": now(),
                },
            )

    def revoke_comlink(self) -> None:
        if not self.has_owner_admin_access("POST", "/v1/admin/comlink/revoke"):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_owner_admin_token"})
            return
        with connect_db() as db:
            status, result = revoke_comlink_sessions(db, self.read_json(), self.admin_role() or "owner_admin")
        self.send_json(status, result)

    def check_marketplace_ownership(self) -> None:
        body = self.read_body()
        server_id, error = self.verify_official_server_request(body)
        if error is not None:
            self.send_json(error[0], error[1])
            return
        payload = self.read_json(body)
        steam_id = str(payload.get("steam_id", "")).strip()
        item_ids = clean_marketplace_check_item_ids(payload.get("item_ids", []))
        with connect_db() as db:
            status, result = marketplace_ownership_check(db, steam_id, item_ids)
        if status == HTTPStatus.OK:
            result["official_server"] = server_id
        self.send_json(status, result)

    def get_server_profile_snapshots(self) -> None:
        body = self.read_body()
        server_id, error = self.verify_official_server_request(body)
        if error is not None:
            self.send_json(error[0], error[1])
            return
        payload = self.read_json(body)
        steam_ids_raw = payload.get("steam_ids", payload.get("steam_id", []))
        if isinstance(steam_ids_raw, str):
            steam_ids = [steam_ids_raw]
        elif isinstance(steam_ids_raw, list):
            steam_ids = [str(value) for value in steam_ids_raw]
        else:
            raise ValueError("steam_ids must be a SteamID64 string or a list of SteamID64 strings")
        if not steam_ids or len(steam_ids) > 100:
            raise ValueError("steam_ids must contain between 1 and 100 entries")
        invalid = [steam_id for steam_id in steam_ids if not STEAM_ID_PATTERN.fullmatch(str(steam_id).strip())]
        if invalid:
            raise ValueError("steam_ids contains an invalid SteamID64")
        with connect_db() as db:
            profiles = tcw_tools_profile_snapshots_for(db, steam_ids)
        self.send_json(
            HTTPStatus.OK,
            {
                "official_server": server_id,
                "profile_schema": "tcwa3_profile_v1",
                "profiles": profiles,
                "missing_steam_ids": [
                    steam_id
                    for steam_id in dict.fromkeys(steam_ids)
                    if steam_id not in {profile["steam_id"] for profile in profiles}
                ],
                "updated_at": now(),
            },
        )

    def update_news(self) -> None:
        if not (self.has_admin_token() or self.has_owner_admin_access("POST", "/v1/admin/news")):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_admin_token"})
            return
        payload = save_news_payload(self.read_json())
        with connect_db() as db:
            record_admin_audit(db, self.admin_role() or "owner_admin", "news_update", "news", {"items": len(payload["items"])})
        self.send_json(HTTPStatus.OK, {"status": "saved", "items": payload["items"], "updated_at": now()})

    def update_events(self) -> None:
        if not self.has_community_manager_access("POST", "/v1/admin/events"):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
            return
        payload = save_events_payload(self.read_json())
        with connect_db() as db:
            record_admin_audit(db, self.admin_role() or "community_manager", "event_banners_update", "events", {"events": len(payload["events"])})
        self.send_json(
            HTTPStatus.OK,
            {
                "status": "saved",
                "events": payload["events"],
                "manifest": load_event_manifest(),
                "updated_at": now(),
            },
        )

    def update_server_controls(self) -> None:
        if not self.has_community_manager_access("POST", "/v1/admin/server-controls"):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
            return
        payload = save_server_controls_payload(self.read_json())
        with connect_db() as db:
            record_admin_audit(db, self.admin_role() or "community_manager", "server_controls_update", "server_controls", {"servers": len(payload.get("servers", []))})
        self.send_json(
            HTTPStatus.OK,
            {
                "status": "saved",
                "server_controls": payload,
                "inventory": load_community_asset_inventory(self.admin_role() or "community_manager"),
                "updated_at": now(),
            },
        )

    def update_servers(self) -> None:
        if not self.has_community_manager_access("POST", "/v1/admin/servers"):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
            return
        before = load_server_catalog(include_hidden=True)
        payload = save_server_catalog_payload(self.read_json())
        before_ids = {str(item.get("id", "")) for item in before.get("servers", [])}
        after_ids = {str(item.get("id", "")) for item in payload.get("servers", [])}
        changed = {
            "servers": len(payload.get("servers", [])),
            "categories": len(payload.get("categories", [])),
            "added": sorted(after_ids - before_ids),
            "removed": sorted(before_ids - after_ids),
            "visible": len([item for item in payload.get("servers", []) if bool(item.get("visible", True))]),
            "maintenance": len([item for item in payload.get("servers", []) if bool(item.get("maintenance"))]),
        }
        with connect_db() as db:
            record_admin_audit(db, self.admin_role() or "community_manager", "server_catalog_update", "servers", changed)
        self.send_json(
            HTTPStatus.OK,
            {
                "status": "saved",
                "server_catalog": payload,
                "inventory": load_community_asset_inventory(self.admin_role() or "community_manager"),
                "updated_at": now(),
            },
        )

    def upload_community_asset(self) -> None:
        if not self.has_community_manager_access("POST", "/v1/admin/assets/upload"):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
            return
        payload = self.read_json(max_bytes=max(MAX_BODY_BYTES, COMMUNITY_MANAGER_MAX_FILE_BYTES * 2))
        target = str(payload.get("target", "")).strip().lower()
        if target == "theme_manifest":
            theme = save_theme_metadata(payload)
            self.send_json(
                HTTPStatus.OK,
                {"status": "saved", "theme": theme, "inventory": load_community_asset_inventory(self.admin_role() or "community_manager")},
            )
            return
        file_payload = payload.get("file")
        if not isinstance(file_payload, dict):
            if target == "theme" and (payload.get("theme_id") or payload.get("id")):
                theme = save_theme_metadata(
                    {
                        "theme_id": payload.get("theme_id") or payload.get("id"),
                        "theme_name": payload.get("theme_name") or payload.get("name"),
                        "description": payload.get("description", ""),
                        "accent_color": payload.get("accent_color", ""),
                        "panel_color": payload.get("panel_color", ""),
                        "text_color": payload.get("text_color", ""),
                        "active": payload.get("active", True),
                    }
                )
                self.send_json(
                    HTTPStatus.OK,
                    {"status": "saved", "theme": theme, "inventory": load_community_asset_inventory(self.admin_role() or "community_manager")},
                )
                return
            raise ValueError("file is required")
        filename = file_payload.get("name")
        data = decode_asset_upload(file_payload.get("data_base64") or file_payload.get("data"))
        if target == "audio":
            asset = save_audio_upload(payload.get("category"), filename, data)
            self.send_json(
                HTTPStatus.OK,
                {"status": "saved", "asset": asset, "inventory": load_community_asset_inventory(self.admin_role() or "community_manager")},
            )
            return
        if target == "theme":
            theme = save_theme_upload(
                payload.get("theme_id"),
                payload.get("theme_name"),
                payload.get("asset_type"),
                filename,
                data,
                file_payload.get("relative_path") or file_payload.get("path") or file_payload.get("webkitRelativePath") or filename,
            )
            self.send_json(
                HTTPStatus.OK,
                {"status": "saved", "theme": theme, "inventory": load_community_asset_inventory(self.admin_role() or "community_manager")},
            )
            return
        if target == "avatar":
            avatar = save_avatar_upload(filename, data)
            self.send_json(
                HTTPStatus.OK,
                {"status": "saved", "avatar": avatar, "inventory": load_community_asset_inventory(self.admin_role() or "community_manager")},
            )
            return
        raise ValueError("target must be audio, theme, theme_manifest, or avatar")

    def delete_community_asset(self) -> None:
        if not self.has_community_manager_access("POST", "/v1/admin/assets/delete"):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid_community_manager_token"})
            return
        payload = self.read_json()
        kind = str(payload.get("kind", "")).strip().lower()
        binned: dict[str, Any] | None
        if kind == "audio":
            binned = delete_audio_asset(payload.get("category"), payload.get("filename"))
        elif kind == "theme":
            binned = delete_theme_asset(payload.get("theme_id"), payload.get("path"))
        elif kind == "avatar":
            binned = delete_avatar_asset(payload.get("avatar_id"), payload.get("path"))
        else:
            raise ValueError("kind must be audio, theme, or avatar")
        with connect_db() as db:
            record_admin_audit(db, self.admin_role() or "community_manager", "asset_deleted", kind, {"bin_item": binned or {}})
        self.send_json(HTTPStatus.OK, {"status": "binned", "bin_item": binned, "inventory": load_community_asset_inventory(self.admin_role() or "community_manager")})

    def ingest_events(self) -> None:
        body = self.read_body()
        server_id, error = self.verify_official_server_request(body)
        if error is not None:
            self.send_json(error[0], error[1])
            return
        payload = self.read_json(body)
        events = payload.get("events", [])
        if not isinstance(events, list) or not events or len(events) > 500:
            raise ValueError("events must contain between 1 and 500 items")
        canonical_events: list[tuple[dict[str, Any], str]] = []
        canonical_server_ids: set[str] = set()
        for event in events:
            if not isinstance(event, dict):
                raise ValueError("each event must be an object")
            event_id = str(event.get("event_id", ""))[:128]
            steam_id = str(event.get("steam_id", ""))
            if not event_id or not STEAM_ID_PATTERN.fullmatch(steam_id):
                raise ValueError("event_id and a valid SteamID64 are required")
            event_server_id = official_event_server_id(server_id, event)
            if not event_server_id:
                log_backend_event(
                    "official_server_event_untrusted_source",
                    path="/v1/server/events",
                    auth_server_id=server_id,
                    event_id=event_id,
                    steam_id=steam_id,
                    declared_server=declared_event_server_identity(event) or "missing",
                )
                self.send_json(
                    HTTPStatus.FORBIDDEN,
                    {
                        "error": "untrusted_event_server",
                        "message": "Progression events must identify an official TCW server.",
                    },
                )
                return
            normalized_event = dict(event)
            normalized_event["server_id"] = event_server_id
            canonical_events.append((normalized_event, event_server_id))
            canonical_server_ids.add(event_server_id)
        accepted = 0
        duplicates = 0
        quests_updated = 0
        unlocked: dict[str, list[str]] = {}
        active_xp_event_ids: set[str] = set()
        affected_steam_ids: list[str] = []
        profile_snapshots: list[dict[str, Any]] = []
        include_profile_snapshots = bool(payload.get("include_profiles") or payload.get("include_profile_snapshots"))
        with connect_db() as db:
            for event, event_server_id in canonical_events:
                event_id = str(event.get("event_id", ""))[:128]
                steam_id = str(event.get("steam_id", ""))
                timestamp = now()
                cursor = db.execute(
                    "INSERT OR IGNORE INTO server_events (event_id, official_server, steam_id, payload_json, received_at) VALUES (?, ?, ?, ?, ?)",
                    (event_id, event_server_id, steam_id, json.dumps(event, ensure_ascii=False), timestamp),
                )
                if not cursor.rowcount:
                    # event_id is the idempotency key. Server retries are safe
                    # because duplicates are counted but do not affect stats.
                    duplicates += 1
                    continue
                display_name = clean_profile_name(event.get("profile_name"))
                has_real_arma_name = not is_generic_display_name(display_name)
                db.execute(
                    """
                    INSERT INTO users (steam_id, display_name, arma_profile_name, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(steam_id) DO UPDATE SET
                        display_name = CASE
                            WHEN excluded.arma_profile_name != ''
                             AND excluded.arma_profile_name NOT IN ('Unknown', 'Unknown Steam', 'Unknown Trooper', 'Clone trooper')
                            THEN excluded.display_name ELSE users.display_name END,
                        arma_profile_name = CASE
                            WHEN excluded.arma_profile_name != ''
                             AND excluded.arma_profile_name NOT IN ('Unknown', 'Unknown Steam', 'Unknown Trooper', 'Clone trooper')
                            THEN excluded.arma_profile_name ELSE users.arma_profile_name END,
                        updated_at = excluded.updated_at
                    """,
                    (steam_id, display_name, display_name if has_real_arma_name else "", timestamp, timestamp),
                )
                db.execute("INSERT OR IGNORE INTO stats (steam_id) VALUES (?)", (steam_id,))
                raw_deltas = event.get("stats", {})
                if not isinstance(raw_deltas, dict):
                    raise ValueError("stats must be an object")
                values: dict[str, int] = {}
                for stat, limit in EVENT_STAT_LIMITS.items():
                    value = int(raw_deltas.get(stat, 0))
                    minimum = EVENT_STAT_MINIMUMS.get(stat, 0)
                    if value < minimum or value > limit:
                        raise ValueError(f"invalid {stat} delta")
                    values[stat] = value
                apply_official_event_rewards(event, values, raw_deltas)
                xp_bonus_percent, xp_event_ids = active_event_xp_bonus(timestamp)
                active_xp_event_ids.update(xp_event_ids)
                values["xp"] = apply_xp_bonus(values["xp"], xp_bonus_percent)
                clamp_event_stat_values(values)
                deployment_id = deployment_id_for_event(event, steam_id, event_id)
                deployment_outcome = event_deployment_outcome(event, values)
                existing_deployment = find_deployment_row(db, deployment_id) if deployment_outcome else None
                active_deployment = find_active_deployment(db, steam_id, event_server_id, deployment_id) if deployment_outcome == "failed" else None
                if deployment_outcome == "started" and existing_deployment is None:
                    add_event_delta(values, "deployment_attempts", 1)
                elif deployment_outcome in {"completed", "failed"}:
                    if existing_deployment is None:
                        add_event_delta(values, "deployment_attempts", 1)
                    if deployment_outcome == "failed" and not event_has_raw_delta(raw_deltas, "deployments_failed"):
                        add_event_delta(values, "deployments_failed", 1)
                positive_xp_for_deployment = max(0, int(values.get("xp", 0)))
                deployment_xp_penalty = 0
                if deployment_outcome == "failed":
                    active_xp = int(active_deployment["xp_earned"] or 0) if active_deployment is not None else 0
                    deployment_xp_penalty = max(0, (active_xp + positive_xp_for_deployment) // 2)
                    if deployment_xp_penalty:
                        add_event_delta(values, "xp", -deployment_xp_penalty)
                        add_event_delta(values, "deployment_xp_adjustments", -deployment_xp_penalty)
                clamp_event_stat_values(values)
                contextual_ids, mission_progress = achievement_context_for_event(event, values, timestamp)
                droid_kills_delta = values["droid_kills"] or values["enemy_kills"] or values["kills"]
                db.execute(
                    """
                    UPDATE stats SET kills = kills + ?, deaths = deaths + ?, credits = MAX(0, credits + ?),
                                     xp = MAX(0, xp + ?), missions = missions + ?, playtime_seconds = playtime_seconds + ?,
                                     droid_kills = droid_kills + ?, vehicle_kills = vehicle_kills + ?,
                                     aircraft_kills = aircraft_kills + ?, friendly_kills = friendly_kills + ?,
                                     support_score = support_score + ?, revives = revives + ?, heals = heals + ?,
                                     repairs = repairs + ?, resupplies = resupplies + ?,
                                     transport_assists = transport_assists + ?, objective_support = objective_support + ?,
                                     kamino_visits = kamino_visits + ?, geonosis_missions = geonosis_missions + ?,
                                     friendly_fire_missions = friendly_fire_missions + ?,
                                     high_death_missions = high_death_missions + ?, perfect_missions = perfect_missions + ?,
                                     deployment_attempts = deployment_attempts + ?,
                                     deployments_completed = deployments_completed + ?,
                                     deployments_failed = deployments_failed + ?,
                                     deployment_xp_adjustments = deployment_xp_adjustments + ?
                    WHERE steam_id = ?
                    """,
                    (
                        values["kills"], values["deaths"], values["credits"], values["xp"],
                        values["missions"], values["playtime_seconds"], droid_kills_delta,
                        values["vehicle_kills"], values["aircraft_kills"],
                        values["friendly_kills"], values["support_score"], values["revives"],
                        values["heals"], values["repairs"], values["resupplies"],
                        values["transport_assists"], values["objective_support"],
                        mission_progress["kamino_visits"],
                        mission_progress["geonosis_missions"], mission_progress["friendly_fire_missions"],
                        mission_progress["high_death_missions"], mission_progress["perfect_missions"],
                        values["deployment_attempts"], values["deployments_completed"],
                        values["deployments_failed"], values["deployment_xp_adjustments"], steam_id,
                    ),
                )
                new_achievements = unlock_achievements(db, steam_id, contextual_ids)
                if deployment_outcome:
                    record_campaign_deployment(
                        db,
                        steam_id,
                        deployment_id,
                        event_server_id,
                        event,
                        new_achievements,
                        timestamp,
                        deployment_outcome,
                        positive_xp_for_deployment,
                        deployment_xp_penalty,
                    )
                else:
                    add_xp_to_active_deployment(db, steam_id, event_server_id, deployment_id, positive_xp_for_deployment)
                if record_quest_progress(db, steam_id, event_id, event_server_id, event, timestamp):
                    quests_updated += 1
                if new_achievements:
                    unlocked[steam_id] = new_achievements
                safe_write_player_profile_snapshot(db, steam_id)
                if steam_id not in affected_steam_ids:
                    affected_steam_ids.append(steam_id)
                accepted += 1
            if include_profile_snapshots and affected_steam_ids:
                profile_snapshots = tcw_tools_profile_snapshots_for(db, affected_steam_ids)
        response: dict[str, Any] = {
            "accepted": accepted,
            "duplicates": duplicates,
            "quests_updated": quests_updated,
            "achievements_unlocked": unlocked,
            "official_event_servers": sorted(canonical_server_ids),
        }
        if active_xp_event_ids:
            response["active_xp_events"] = sorted(active_xp_event_ids)
        if include_profile_snapshots:
            response["profile_schema"] = "tcwa3_profile_v1"
            response["profiles"] = profile_snapshots
        self.send_json(HTTPStatus.OK, response)


def main() -> None:
    initialize_database()
    try:
        with connect_db() as db:
            print(f"Republic wage cycle: {grant_weekly_republic_wages(db)}")
    except Exception as exc:
        log_backend_event("republic_wage_cycle_failed", reason=type(exc).__name__)
    try:
        print(f"Initial roster sync: {sync_roster()}")
    except Exception as exc:
        log_backend_event("discord_roster_squad_sync_failed", reason=type(exc).__name__)
    threading.Thread(target=roster_sync_loop, name="roster-sync", daemon=True).start()
    threading.Thread(target=republic_wage_loop, name="republic-wage", daemon=True).start()
    server = ThreadingHTTPServer((BIND_HOST, PORT), ApiHandler)
    print(f"TCW profile API listening on {BIND_HOST}:{PORT}")
    server.serve_forever()


if __name__ == "__main__":
    main()
