import hashlib
import hmac
import base64
import contextlib
import io
import json
import os
import shutil
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

TEST_TEMP_OWNER = getattr(os, "getuid", lambda: os.getpid())()
TEST_TEMP_PREFIX = f"tcw-profile-test-{TEST_TEMP_OWNER}"
os.environ["TCW_DATABASE_PATH"] = str(Path(tempfile.gettempdir()) / f"{TEST_TEMP_PREFIX}.sqlite3")
os.environ["TCW_PLAYER_DATA_ROOT"] = str(Path(tempfile.gettempdir()) / f"{TEST_TEMP_PREFIX}-players")
os.environ["TCW_EVENTS_PATH"] = str(Path(tempfile.gettempdir()) / f"{TEST_TEMP_PREFIX}-events.json")
os.environ["TCW_AVATAR_ROOT"] = str(Path(tempfile.gettempdir()) / f"{TEST_TEMP_PREFIX}-avatars")
os.environ["TCW_MARKETPLACE_PATH"] = str(Path(tempfile.gettempdir()) / f"{TEST_TEMP_PREFIX}-marketplace.json")
os.environ["TCW_SERVER_CONTROLS_PATH"] = str(Path(tempfile.gettempdir()) / f"{TEST_TEMP_PREFIX}-server-controls.json")

import server  # noqa: E402


class ProgressionTests(unittest.TestCase):
    def setUp(self):
        if server.DATABASE_PATH.exists():
            server.DATABASE_PATH.unlink()
        if server.PLAYER_DATA_ROOT.exists():
            shutil.rmtree(server.PLAYER_DATA_ROOT)
        if server.EVENTS_PATH.exists():
            server.EVENTS_PATH.unlink()
        if server.MARKETPLACE_PATH.exists():
            server.MARKETPLACE_PATH.unlink()
        if server.SERVER_CONTROLS_PATH.exists():
            server.SERVER_CONTROLS_PATH.unlink()
        if server.AVATAR_ROOT.exists():
            shutil.rmtree(server.AVATAR_ROOT)
        server.initialize_database()

    def post_signed_server_request(
        self,
        path,
        payload,
        *,
        server_id="geonosis",
        keys=None,
        signature_secret=None,
        timestamp=None,
        include_signature=True,
    ):
        original_keys = server.SERVER_KEYS
        server.SERVER_KEYS = dict(keys if keys is not None else {server_id: "test-secret"})
        body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        timestamp_text = str(timestamp if timestamp is not None else server.now())
        secret = signature_secret if signature_secret is not None else server.SERVER_KEYS.get(server_id, "")
        headers = {
            "Content-Type": "application/json",
            "X-TCW-Server": server_id,
            "X-TCW-Timestamp": timestamp_text,
        }
        if include_signature:
            headers["X-TCW-Signature"] = hmac.new(
                secret.encode("utf-8"),
                timestamp_text.encode("ascii") + b"." + body,
                hashlib.sha256,
            ).hexdigest()
        class QuietApiHandler(server.ApiHandler):
            def log_message(self, _format, *args):
                return

        httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), QuietApiHandler)
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{httpd.server_address[1]}{path}"
            request = urllib.request.Request(url, data=body, headers=headers, method="POST")
            try:
                with urllib.request.urlopen(request, timeout=5) as response:
                    return response.status, json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                return exc.code, json.loads(exc.read().decode("utf-8"))
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)
            server.SERVER_KEYS = original_keys

    def post_official_events(self, payload, **kwargs):
        return self.post_signed_server_request("/v1/server/events", payload, **kwargs)

    def post_json_request(self, path, payload, headers=None):
        body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        request_headers = {"Content-Type": "application/json"}
        request_headers.update(headers or {})

        class QuietApiHandler(server.ApiHandler):
            def log_message(self, _format, *args):
                return

        httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), QuietApiHandler)
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{httpd.server_address[1]}{path}"
            request = urllib.request.Request(url, data=body, headers=request_headers, method="POST")
            try:
                with urllib.request.urlopen(request, timeout=5) as response:
                    return response.status, json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                return exc.code, json.loads(exc.read().decode("utf-8"))
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)

    def get_json_request(self, path, headers=None):
        class QuietApiHandler(server.ApiHandler):
            def log_message(self, _format, *args):
                return

        httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), QuietApiHandler)
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{httpd.server_address[1]}{path}"
            request = urllib.request.Request(url, headers=headers or {}, method="GET")
            try:
                with urllib.request.urlopen(request, timeout=5) as response:
                    return response.status, json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                return exc.code, json.loads(exc.read().decode("utf-8"))
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)

    def captured_json_logs(self, callback):
        stream = io.StringIO()
        with contextlib.redirect_stdout(stream):
            result = callback()
        logs = []
        for line in stream.getvalue().splitlines():
            if line.startswith("{"):
                logs.append(json.loads(line))
        return result, logs

    def options_request(self, path, origin):
        class QuietApiHandler(server.ApiHandler):
            def log_message(self, _format, *args):
                return

        httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), QuietApiHandler)
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{httpd.server_address[1]}{path}"
            request = urllib.request.Request(
                url,
                headers={
                    "Origin": origin,
                    "Access-Control-Request-Method": "POST",
                    "Access-Control-Request-Headers": "content-type",
                },
                method="OPTIONS",
            )
            try:
                with urllib.request.urlopen(request, timeout=5) as response:
                    return response.status, dict(response.headers.items())
            except urllib.error.HTTPError as exc:
                return exc.code, dict(exc.headers.items())
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2)

    def test_level_curve(self):
        self.assertEqual(server.level_for_xp(0), 1)
        self.assertEqual(server.level_for_xp(499), 1)
        self.assertEqual(server.level_for_xp(500), 2)
        self.assertEqual(server.level_for_xp(1099), 2)
        self.assertEqual(server.level_for_xp(1100), 3)
        self.assertEqual(server.level_for_xp(2000), 4)
        self.assertEqual(server.next_level_xp(1), 500)
        self.assertEqual(server.current_level_xp(3), 1100)
        self.assertEqual(server.next_level_xp(3), 1820)

    def test_structured_logs_redact_sensitive_fields(self):
        _, logs = self.captured_json_logs(
            lambda: server.log_backend_event(
                "security_probe",
                access_token="secret-access-token",
                refresh_token="secret-refresh-token",
                signature="secret-signature",
                body='{"secret":true}',
                status_code=403,
                reason="line one\nline two",
            )
        )

        self.assertEqual(len(logs), 1)
        self.assertEqual(logs[0]["event"], "security_probe")
        self.assertEqual(logs[0]["status_code"], 403)
        self.assertEqual(logs[0]["reason"], "line one line two")
        self.assertNotIn("access_token", logs[0])
        self.assertNotIn("refresh_token", logs[0])
        self.assertNotIn("signature", logs[0])
        self.assertNotIn("body", logs[0])

    def test_official_event_rewards_derive_tcw_rules(self):
        values = {stat: 0 for stat in server.EVENT_STAT_LIMITS}
        server.apply_official_event_rewards({"event_type": "enemy_infantry_kill", "target_type": "infantry"}, values, {})
        self.assertEqual(values["xp"], 20)
        self.assertEqual(values["credits"], 20)
        self.assertEqual(values["kills"], 1)
        self.assertEqual(values["enemy_kills"], 1)
        self.assertEqual(values["droid_kills"], 1)

        values = {stat: 0 for stat in server.EVENT_STAT_LIMITS}
        server.apply_official_event_rewards({"event_type": "vehicle_destroyed", "vehicle_type": "tank"}, values, {})
        self.assertEqual(values["xp"], 100)
        self.assertEqual(values["credits"], 50)

        values = {stat: 0 for stat in server.EVENT_STAT_LIMITS}
        server.apply_official_event_rewards({"event_type": "player_death"}, values, {})
        self.assertEqual(values["xp"], -20)
        self.assertEqual(values["deaths"], 1)

        values = {stat: 0 for stat in server.EVENT_STAT_LIMITS}
        server.apply_official_event_rewards({"event_type": "teamkill", "target_side": "friendly"}, values, {})
        self.assertEqual(values["xp"], -100)
        self.assertEqual(values["friendly_kills"], 1)

        values = {stat: 0 for stat in server.EVENT_STAT_LIMITS}
        server.apply_official_event_rewards({"event_type": "mission_end", "difficulty": 4}, values, {})
        self.assertEqual(values["xp"], 500)
        self.assertEqual(values["missions"], 1)

    def test_signed_official_event_awards_progression_and_replay_is_idempotent(self):
        steam_id = "76561198000000000"
        event = {
            "event_id": "geonosis-mission-001",
            "steam_id": steam_id,
            "profile_name": "CT-2130 Hacket",
            "event_type": "mission_end",
            "map": "Geonosis",
            "mission_name": "First Battle of Geonosis",
            "stats": {
                "kills": 10,
                "enemy_kills": 10,
                "droid_kills": 10,
                "friendly_kills": 0,
                "deaths": 1,
                "credits": 250,
                "xp": 500,
                "missions": 1,
                "playtime_seconds": 5400,
            },
            "mission_stats": {
                "deaths": 1,
                "enemy_kills": 10,
                "friendly_kills": 0,
            },
        }

        status, result = self.post_official_events({"events": [event]})
        duplicate_status, duplicate = self.post_official_events({"events": [event]})

        with server.connect_db() as db:
            profile = server.profile_for(db, steam_id)
            stored_payload = db.execute("SELECT payload_json FROM server_events").fetchone()["payload_json"]
            event_count = db.execute("SELECT COUNT(*) AS count FROM server_events").fetchone()["count"]
            campaign_count = db.execute("SELECT COUNT(*) AS count FROM campaign_deployments").fetchone()["count"]
        profile_payload = json.dumps(profile, sort_keys=True)

        self.assertEqual(status, server.HTTPStatus.OK)
        self.assertEqual(result["accepted"], 1)
        self.assertEqual(result["duplicates"], 0)
        self.assertEqual(duplicate_status, server.HTTPStatus.OK)
        self.assertEqual(duplicate["accepted"], 0)
        self.assertEqual(duplicate["duplicates"], 1)
        self.assertEqual(event_count, 1)
        self.assertEqual(campaign_count, 1)
        self.assertEqual(profile["kills"], 10)
        self.assertEqual(profile["credits"], 250)
        self.assertEqual(profile["xp"], 500)
        self.assertEqual(profile["level"], 2)
        self.assertEqual(profile["missions"], 1)
        self.assertEqual(profile["campaigns"][0]["id"], "battle_of_geonosis")
        self.assertIn("mission_stats", stored_payload)
        self.assertNotIn("payload_json", profile_payload)
        self.assertNotIn("mission_stats", profile_payload)
        self.assertNotIn("event_type", profile_payload)
        achievement_ids = {achievement["id"] for achievement in profile["achievements"]}
        self.assertIn("first_blood", achievement_ids)
        self.assertIn("first_deployment", achievement_ids)

    def test_signed_tcw_tools_progression_event_awards_kill_reward(self):
        steam_id = "76561198000000034"
        event = {
            "event_id": "tcw-tools-prog-session-kill-001",
            "steam_id": steam_id,
            "profile_name": "CT-3434 HUD",
            "event_type": "enemy_infantry_kill",
            "source": "tcw_tools",
            "mission": "HUD Reward Smoke",
            "world": "VR",
            "target_type": "infantry",
            "victim_type": "infantry",
            "victim_class": "O_Soldier_F",
            "victim_name": "B1 Battle Droid",
            "stats": {
                "xp": 20,
                "credits": 20,
                "kills": 1,
                "enemy_kills": 1,
                "droid_kills": 1,
                "friendly_kills": 0,
            },
        }

        status, result = self.post_official_events({"events": [event]})
        duplicate_status, duplicate = self.post_official_events({"events": [event]})

        with server.connect_db() as db:
            profile = server.profile_for(db, steam_id)
            stored_payload = json.loads(db.execute("SELECT payload_json FROM server_events").fetchone()["payload_json"])

        self.assertEqual(status, server.HTTPStatus.OK)
        self.assertEqual(result["accepted"], 1)
        self.assertEqual(duplicate_status, server.HTTPStatus.OK)
        self.assertEqual(duplicate["accepted"], 0)
        self.assertEqual(duplicate["duplicates"], 1)
        self.assertEqual(profile["display_name"], "CT-3434 HUD")
        self.assertEqual(profile["xp"], 20)
        self.assertEqual(profile["credits"], 20)
        self.assertEqual(profile["kills"], 1)
        self.assertEqual(profile["droid_kills"], 1)
        self.assertEqual(stored_payload["source"], "tcw_tools")

    def test_signed_quest_event_records_profile_lore_and_history(self):
        steam_id = "76561198000000033"
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                (steam_id, "CT-3333 Lorekeeper"),
            )
            db.execute("INSERT INTO stats (steam_id) VALUES (?)", (steam_id,))
        event = {
            "event_id": "quest-arc-001-stage-002",
            "steam_id": steam_id,
            "profile_name": "CT-3333 Lorekeeper",
            "event_type": "quest_update",
            "quest": {
                "id": "quest_rescue_pilot",
                "title": "Rescue the Pilot",
                "category": "Main",
                "state": "SUCCEEDED",
                "stage_index": 2,
                "stage_title": "Extraction complete",
                "stage_description": "The pilot was extracted and debriefed at the forward base.",
                "lore": "The recovered pilot confirmed a hidden Separatist listening post beyond the ridge.",
            },
        }

        status, result = self.post_official_events({"events": [event]})
        duplicate_status, duplicate = self.post_official_events({"events": [event]})

        with server.connect_db() as db:
            profile = server.profile_for(db, steam_id)
            public_profile = server.public_profile_detail(db, steam_id)
            quest_rows = db.execute("SELECT COUNT(*) AS count FROM quest_progress WHERE steam_id = ?", (steam_id,)).fetchone()["count"]

        self.assertEqual(status, server.HTTPStatus.OK)
        self.assertEqual(result["accepted"], 1)
        self.assertEqual(result["quests_updated"], 1)
        self.assertEqual(duplicate_status, server.HTTPStatus.OK)
        self.assertEqual(duplicate["accepted"], 0)
        self.assertEqual(duplicate["duplicates"], 1)
        self.assertEqual(duplicate["quests_updated"], 0)
        self.assertEqual(quest_rows, 1)
        self.assertIsNotNone(profile)
        self.assertEqual(profile["quests"][0]["id"], "quest_rescue_pilot")
        self.assertEqual(profile["quests"][0]["state"], "SUCCEEDED")
        self.assertEqual(profile["quests"][0]["lore"][0]["text"], event["quest"]["lore"])
        self.assertEqual(profile["quests"][0]["history"][0]["event_id"], event["event_id"])
        self.assertIsNotNone(public_profile)
        self.assertEqual(public_profile["quest_count"], 1)
        self.assertEqual(public_profile["completed_quest_count"], 1)
        self.assertEqual(public_profile["quests"][0]["title"], "Rescue the Pilot")

    def test_unsigned_and_unknown_server_events_change_nothing(self):
        steam_id = "76561198000000001"
        payload = {
            "events": [
                {
                    "event_id": "unsigned-event",
                    "steam_id": steam_id,
                    "event_type": "enemy_infantry_kill",
                    "target_type": "infantry",
                }
            ]
        }

        (unsigned_status, unsigned, unknown_status, unknown), _logs = self.captured_json_logs(
            lambda: (
                *self.post_official_events(payload, include_signature=False),
                *self.post_official_events(
                    payload,
                    server_id="unknown-server",
                    keys={"geonosis": "test-secret"},
                    signature_secret="test-secret",
                ),
            )
        )

        with server.connect_db() as db:
            user_count = db.execute("SELECT COUNT(*) AS count FROM users WHERE steam_id = ?", (steam_id,)).fetchone()["count"]
            stats_count = db.execute("SELECT COUNT(*) AS count FROM stats WHERE steam_id = ?", (steam_id,)).fetchone()["count"]
            event_count = db.execute("SELECT COUNT(*) AS count FROM server_events").fetchone()["count"]
            campaign_count = db.execute("SELECT COUNT(*) AS count FROM campaign_deployments").fetchone()["count"]

        self.assertEqual(unsigned_status, server.HTTPStatus.UNAUTHORIZED)
        self.assertEqual(unsigned["error"], "invalid_server_signature")
        self.assertEqual(unknown_status, server.HTTPStatus.UNAUTHORIZED)
        self.assertEqual(unknown["error"], "invalid_server_auth")
        self.assertEqual(user_count, 0)
        self.assertEqual(stats_count, 0)
        self.assertEqual(event_count, 0)
        self.assertEqual(campaign_count, 0)

    def test_official_server_failures_emit_filterable_logs(self):
        steam_id = "76561198000000018"
        payload = {
            "events": [
                {
                    "event_id": "logged-official-failure",
                    "steam_id": steam_id,
                    "event_type": "enemy_infantry_kill",
                    "target_type": "infantry",
                }
            ]
        }

        def post_failures():
            unsigned_status, _unsigned = self.post_official_events(payload, include_signature=False)
            unknown_status, _unknown = self.post_official_events(
                payload,
                server_id="unknown-server",
                keys={"geonosis": "test-secret"},
                signature_secret="test-secret",
            )
            bad_payload_status, _bad_payload = self.post_official_events({"events": []})
            return unsigned_status, unknown_status, bad_payload_status

        (unsigned_status, unknown_status, bad_payload_status), logs = self.captured_json_logs(post_failures)
        events = {entry["event"] for entry in logs}

        self.assertEqual(unsigned_status, server.HTTPStatus.UNAUTHORIZED)
        self.assertEqual(unknown_status, server.HTTPStatus.UNAUTHORIZED)
        self.assertEqual(bad_payload_status, server.HTTPStatus.BAD_REQUEST)
        self.assertIn("official_server_signature_failed", events)
        self.assertIn("official_server_auth_failed", events)
        self.assertIn("official_server_events_bad_payload", events)
        for entry in logs:
            self.assertNotIn("signature", entry)
            self.assertNotIn("body", entry)
            self.assertNotIn("secret", entry)

    def test_auth_device_token_options_allows_tcw_web_origins(self):
        for origin in ["https://tcwa3.co.uk", "https://www.tcwa3.co.uk"]:
            with self.subTest(origin=origin):
                status, headers = self.options_request("/v1/auth/device/token", origin)

                self.assertEqual(status, server.HTTPStatus.NO_CONTENT)
                self.assertEqual(headers.get("Access-Control-Allow-Origin"), origin)
                self.assertIn("POST", headers.get("Access-Control-Allow-Methods", ""))
                self.assertIn("Content-Type", headers.get("Access-Control-Allow-Headers", ""))

        status, headers = self.options_request("/v1/auth/device/token", "https://example.com")

        self.assertEqual(status, server.HTTPStatus.FORBIDDEN)
        self.assertNotIn("Access-Control-Allow-Origin", headers)

    def test_profile_and_achievements(self):
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                ("76561198000000000", 'CT-2130 "Hacket"'),
            )
            db.execute(
                "INSERT INTO stats (steam_id, kills, credits, xp, missions) VALUES (?, 10, 1000, 8000, 10)",
                ("76561198000000000",),
            )
            unlocked = server.unlock_achievements(db, "76561198000000000")
            profile = server.profile_for(db, "76561198000000000")
        self.assertIn("first_blood", unlocked)
        self.assertIn("seasoned_10", unlocked)
        self.assertEqual(profile["display_name"], 'CT-2130 "Hacket"')
        self.assertGreaterEqual(profile["level"], 5)
        self.assertEqual(profile["avatar_id"], server.DEFAULT_AVATAR_ID)
        self.assertEqual(profile["inventory"], [])

    def test_achievement_acknowledgement_clears_unacknowledged_awards(self):
        steam_id = "76561198000000019"
        access_token = "tcwa3-award-ack-token"
        timestamp = server.now()
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (steam_id, "CT Awarded", timestamp, timestamp, timestamp),
            )
            db.execute("INSERT INTO stats (steam_id, kills, missions) VALUES (?, 1, 1)", (steam_id,))
            db.execute(
                "INSERT INTO sessions (token_hash, steam_id, created_at, expires_at, last_used_at) VALUES (?, ?, ?, ?, ?)",
                (server.token_hash(access_token), steam_id, timestamp, timestamp + 3600, timestamp),
            )
            server.unlock_achievements(db, steam_id)
            before = server.profile_for(db, steam_id)

        before_ids = {item["id"] for item in before["unacknowledged_achievements"]}
        first_status, first_result = self.post_json_request(
            "/v1/me/achievements/acknowledge",
            {"achievement_ids": ["first_blood"]},
            {"Authorization": f"Bearer {access_token}"},
        )
        second_status, second_result = self.post_json_request(
            "/v1/me/achievements/acknowledge",
            {"achievement_ids": []},
            {"Authorization": f"Bearer {access_token}"},
        )

        first_ids = {item["id"] for item in first_result["profile"]["unacknowledged_achievements"]}
        second_ids = {item["id"] for item in second_result["profile"]["unacknowledged_achievements"]}
        acknowledged = {
            item["id"]: item
            for item in second_result["profile"]["achievements"]
            if item["id"] in before_ids
        }

        self.assertEqual(first_status, server.HTTPStatus.OK)
        self.assertEqual(second_status, server.HTTPStatus.OK)
        self.assertIn("first_blood", before_ids)
        self.assertNotIn("first_blood", first_ids)
        self.assertGreater(len(first_ids), 0)
        self.assertEqual(second_ids, set())
        self.assertTrue(all(item.get("acknowledged_at") for item in acknowledged.values()))

    def test_avatar_catalog_and_profile_selection(self):
        steam_id = "76561198000000005"
        server.AVATAR_ROOT.mkdir(parents=True, exist_ok=True)
        (server.AVATAR_ROOT / "104th-wolfpack.png").write_bytes(b"png")
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, avatar_id, verified_at, created_at, updated_at) VALUES (?, ?, ?, 1, 1, 1)",
                (steam_id, "CT Wolfpack", "104th-wolfpack"),
            )
            db.execute("INSERT INTO stats (steam_id) VALUES (?)", (steam_id,))
            profile = server.profile_for(db, steam_id)
        catalog_ids = [avatar["id"] for avatar in server.avatar_catalog()]

        self.assertIn(server.DEFAULT_AVATAR_ID, catalog_ids)
        self.assertIn("104th-wolfpack", catalog_ids)
        self.assertEqual(profile["avatar_id"], "104th-wolfpack")
        self.assertTrue(profile["avatar_url"].endswith("/104th-wolfpack.png"))

    def test_external_roster_profile_extraction(self):
        profile = server.extract_external_roster_profile(
            {
                "user": {"discord_username": "CPL JT"},
                "steam_linked": {"steam_id64": "76561198000000011"},
            },
            {
                "linked_player": {"display_name": "CPL-5585 JT", "rank": "CPL"},
                "scoreboard_totals": {
                    "enemy_kills": 12,
                    "deaths": 3,
                    "xp": 1250,
                    "credits": 800,
                },
                "battalion_memberships": [{"unit_name": "502nd", "rank_name": "CPL"}],
            },
            {"operations": [{"mission_name": "Assault on Droid Factory"}]},
        )

        self.assertEqual(profile["steam_id"], "76561198000000011")
        self.assertEqual(profile["display_name"], "CPL-5585 JT")
        self.assertEqual(profile["unit"], "502nd")
        self.assertEqual(profile["rank"], "CPL")
        self.assertTrue(profile["steam_linked"])
        self.assertEqual(profile["stats"]["kills"], 12)
        self.assertEqual(profile["stats"]["droid_kills"], 12)
        self.assertEqual(len(profile["operations"]), 1)

    def test_external_roster_merge_preserves_backend_totals(self):
        steam_id = "76561198000000012"
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                (steam_id, "CT Existing"),
            )
            db.execute(
                "INSERT INTO stats (steam_id, kills, deaths, credits, xp, missions) VALUES (?, 30, 1, 900, 5000, 4)",
                (steam_id,),
            )
            profile = server.merge_external_roster_profile(
                db,
                {
                    "steam_id": steam_id,
                    "display_name": "CPL Existing",
                    "unit": "502nd",
                    "rank": "CPL",
                    "stats": {"kills": 10, "deaths": 4, "credits": 600, "xp": 2000, "missions": 8},
                },
            )

        self.assertEqual(profile["display_name"], "CPL Existing")
        self.assertEqual(profile["unit"], "502nd")
        self.assertEqual(profile["rank"], "CPL")
        self.assertTrue(profile["rostered"])
        self.assertEqual(profile["kills"], 30)
        self.assertEqual(profile["deaths"], 4)
        self.assertEqual(profile["credits"], 900)
        self.assertEqual(profile["xp"], 5000)
        self.assertEqual(profile["missions"], 8)

    def test_device_code_can_only_issue_one_session(self):
        steam_id = "76561198000000006"
        device_code = "tcwa3-test-device-code"
        timestamp = 1000
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (steam_id, "CT Device", timestamp, timestamp, timestamp),
            )
            db.execute("INSERT INTO stats (steam_id) VALUES (?)", (steam_id,))
            db.execute(
                """
                INSERT INTO device_codes (device_hash, user_code, steam_id, status, created_at, expires_at)
                VALUES (?, ?, ?, 'approved', ?, ?)
                """,
                (server.token_hash(device_code), "ABC12345", steam_id, timestamp, timestamp + 600),
            )
            first_status, first_payload = server.exchange_device_code_for_session(db, device_code, timestamp + 1)
            second_status, second_payload = server.exchange_device_code_for_session(db, device_code, timestamp + 2)
            session_count = db.execute(
                "SELECT COUNT(*) AS total FROM sessions WHERE steam_id = ?",
                (steam_id,),
            ).fetchone()["total"]

        self.assertEqual(first_status, server.HTTPStatus.OK)
        self.assertIn("access_token", first_payload)
        self.assertEqual(first_payload["expires_in"], server.SESSION_DAYS * 86400)
        self.assertEqual(first_payload["expires_at"], timestamp + 1 + server.SESSION_DAYS * 86400)
        self.assertEqual(second_status, server.HTTPStatus.CONFLICT)
        self.assertEqual(second_payload["error"], "already_consumed")
        self.assertEqual(session_count, 1)

    def test_me_response_includes_renewed_session_expiry_metadata(self):
        steam_id = "76561198000000026"
        access_token = "tcwa3-persistent-session-token"
        created_at = server.now()
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (steam_id, "CT Persistent", created_at, created_at, created_at),
            )
            db.execute("INSERT INTO stats (steam_id) VALUES (?)", (steam_id,))
            db.execute(
                "INSERT INTO sessions (token_hash, steam_id, created_at, expires_at, last_used_at) VALUES (?, ?, ?, ?, ?)",
                (server.token_hash(access_token), steam_id, created_at, created_at + 60, created_at),
            )

        status, payload = self.get_json_request("/v1/me", {"Authorization": f"Bearer {access_token}"})

        self.assertEqual(status, server.HTTPStatus.OK)
        self.assertEqual(payload["profile"]["steam_id"], steam_id)
        self.assertGreater(payload["session_expires_at"], created_at + 60)
        self.assertGreater(payload["session_expires_in"], 0)

    def test_contextual_geonosis_awards_and_snapshot(self):
        steam_id = "76561198000000000"
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                (steam_id, "CT Geonosis"),
            )
            db.execute("INSERT INTO stats (steam_id) VALUES (?)", (steam_id,))
            values = {stat: 0 for stat in server.EVENT_STAT_LIMITS}
            values.update({"missions": 1, "kills": 2, "enemy_kills": 2, "friendly_kills": 3, "deaths": 20})
            event = {
                "event_id": "geo-1",
                "steam_id": steam_id,
                "map": "Geonosis",
                "event_type": "mission_end",
                "mission_stats": {"deaths": 20, "enemy_kills": 2, "friendly_kills": 3},
            }
            contextual, progress = server.achievement_context_for_event(
                event,
                values,
                server.GEONOSIS_LAUNCH_WEEK_START + 60,
            )
            db.execute(
                """
                UPDATE stats
                   SET kills = ?, deaths = ?, missions = ?, droid_kills = ?,
                       friendly_kills = ?, geonosis_missions = ?,
                       friendly_fire_missions = ?, high_death_missions = ?
                 WHERE steam_id = ?
                """,
                (
                    values["kills"], values["deaths"], values["missions"], values["enemy_kills"],
                    values["friendly_kills"], progress["geonosis_missions"],
                    progress["friendly_fire_missions"], progress["high_death_missions"], steam_id,
                ),
            )
            unlocked = server.unlock_achievements(db, steam_id, contextual)
            repeated = server.unlock_achievements(db, steam_id, contextual)
            server.safe_write_player_profile_snapshot(db, steam_id)

        self.assertIn("geonosis_not_shiny_for_long", unlocked)
        self.assertIn("droid_bait", unlocked)
        self.assertIn("same_team", unlocked)
        self.assertIn("welcome_to_the_front", unlocked)
        self.assertEqual(repeated, [])
        snapshot = server.PLAYER_DATA_ROOT / steam_id / "achievements.json"
        self.assertTrue(snapshot.exists())
        snapshot_payload = json.loads(snapshot.read_text(encoding="utf-8"))
        self.assertEqual(snapshot_payload["steam_id"], steam_id)
        self.assertEqual(len([item for item in snapshot_payload["achievements"] if item["id"] == "droid_bait"]), 1)
        self.assertTrue((server.PLAYER_DATA_ROOT / steam_id / "inventory.json").exists())

    def test_marketplace_purchase_is_backend_authoritative(self):
        steam_id = "76561198000000002"
        server.MARKETPLACE_PATH.write_text(
            json.dumps(
                {
                    "items": [
                        {
                            "id": "orange-pauldrons",
                            "category": "custom_armour",
                            "name": "Orange Pauldrons",
                            "description": "Approved armour cosmetic.",
                            "cost": 250,
                            "class_name": "TCW_Armor_OrangePauldron",
                        }
                    ]
                }
            ),
            encoding="utf-8",
        )
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                (steam_id, "CT Store"),
            )
            db.execute("INSERT INTO stats (steam_id, credits) VALUES (?, 300)", (steam_id,))
            status, result = server.purchase_marketplace_item(db, steam_id, "orange-pauldrons")
            repeated_status, repeated = server.purchase_marketplace_item(db, steam_id, "orange-pauldrons")
            profile = server.profile_for(db, steam_id)

        self.assertEqual(status, server.HTTPStatus.OK)
        self.assertEqual(result["purchase"]["class_name"], "TCW_Armor_OrangePauldron")
        self.assertEqual(profile["credits"], 50)
        self.assertEqual(profile["inventory"][0]["item_id"], "orange-pauldrons")
        self.assertEqual(repeated_status, server.HTTPStatus.CONFLICT)
        self.assertEqual(repeated["error"], "already_owned")

    def test_marketplace_purchase_accepts_backend_requirements(self):
        steam_id = "76561198000000013"
        server.MARKETPLACE_PATH.write_text(
            json.dumps(
                {
                    "items": [
                        {
                            "id": "geonosis-veteran-kit",
                            "category": "unique_items",
                            "name": "Geonosis Veteran Kit",
                            "cost": 300,
                            "class_name": "TCW_Kit_GeonosisVeteran",
                            "requirements": {
                                "min_level": 5,
                                "achievements": ["first_blood"],
                                "rank": ["CPL", "SGT"],
                                "unit": "212th",
                                "campaign": "battle_of_geonosis",
                            },
                        }
                    ]
                }
            ),
            encoding="utf-8",
        )
        with server.connect_db() as db:
            db.execute(
                """
                INSERT INTO users
                    (steam_id, display_name, unit, rank, rostered, verified_at, created_at, updated_at)
                VALUES (?, ?, '212th', 'CPL', 1, 1, 1, 1)
                """,
                (steam_id, "CPL Eligible"),
            )
            db.execute(
                "INSERT INTO stats (steam_id, credits, xp, kills) VALUES (?, 500, ?, 1)",
                (steam_id, server.total_xp_for_level(5)),
            )
            db.execute(
                "INSERT INTO achievements (steam_id, achievement_id, unlocked_at) VALUES (?, 'first_blood', 1)",
                (steam_id,),
            )
            db.execute(
                """
                INSERT INTO campaign_deployments
                    (deployment_id, steam_id, campaign_id, campaign_name, mission_name, planet,
                     official_server, completed_at, awards_json)
                VALUES ('dep-geonosis-eligible', ?, 'battle_of_geonosis', 'Battle of Geonosis',
                        'Factory Push', 'Geonosis', 'main', 1, '[]')
                """,
                (steam_id,),
            )
            catalog = server.marketplace_catalog_for_player(db, steam_id)
            status, result = server.purchase_marketplace_item(db, steam_id, "geonosis-veteran-kit")
            profile = server.profile_for(db, steam_id)

        catalog_item = catalog["items"][0]
        self.assertTrue(catalog_item["eligible"])
        self.assertEqual(catalog_item["requirement_status"]["missing"], [])
        self.assertEqual(status, server.HTTPStatus.OK)
        self.assertEqual(result["purchase"]["item_id"], "geonosis-veteran-kit")
        self.assertEqual(profile["credits"], 200)
        self.assertEqual(profile["inventory"][0]["class_name"], "TCW_Kit_GeonosisVeteran")

    def test_marketplace_purchase_rejects_missing_requirements_without_spending(self):
        steam_id = "76561198000000014"
        server.MARKETPLACE_PATH.write_text(
            json.dumps(
                {
                    "items": [
                        {
                            "id": "arc-veteran-kit",
                            "category": "unique_items",
                            "name": "ARC Veteran Kit",
                            "cost": 300,
                            "class_name": "TCW_Kit_ARCVeteran",
                            "requirements": {
                                "level": 5,
                                "achievement": "first_blood",
                                "ranks": ["CPL", "SGT"],
                                "units": ["212th"],
                                "campaigns": ["battle_of_geonosis"],
                            },
                        }
                    ]
                }
            ),
            encoding="utf-8",
        )
        with server.connect_db() as db:
            db.execute(
                """
                INSERT INTO users
                    (steam_id, display_name, unit, rank, rostered, verified_at, created_at, updated_at)
                VALUES (?, ?, '501st', 'PVT', 1, 1, 1, 1)
                """,
                (steam_id, "PVT Locked"),
            )
            db.execute("INSERT INTO stats (steam_id, credits, xp) VALUES (?, 1000, 0)", (steam_id,))
            catalog = server.marketplace_catalog_for_player(db, steam_id)
            status, result = server.purchase_marketplace_item(db, steam_id, "arc-veteran-kit")
            profile = server.profile_for(db, steam_id)
            purchase_count = db.execute(
                "SELECT COUNT(*) AS count FROM marketplace_purchases WHERE steam_id = ?",
                (steam_id,),
            ).fetchone()["count"]

        catalog_item = catalog["items"][0]
        self.assertFalse(catalog_item["eligible"])
        self.assertEqual(status, server.HTTPStatus.FORBIDDEN)
        self.assertEqual(result["error"], "requirements_not_met")
        self.assertEqual(profile["credits"], 1000)
        self.assertEqual(purchase_count, 0)
        missing_types = {entry["type"] for entry in result["requirements"]["missing"]}
        self.assertEqual(missing_types, {"level", "achievement", "rank", "unit", "campaign"})

    def test_official_server_ownership_check_verifies_purchases(self):
        steam_id = "76561198000000015"
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                (steam_id, "CT Entitled"),
            )
            db.execute("INSERT INTO stats (steam_id, credits) VALUES (?, 0)", (steam_id,))
            db.execute(
                """
                INSERT INTO marketplace_purchases
                    (steam_id, item_id, category, class_name, cost, purchased_at)
                VALUES (?, 'arc-veteran-kit', 'unique_items', 'TCW_Kit_ARCVeteran', 300, 1)
                """,
                (steam_id,),
            )

        status, result = self.post_signed_server_request(
            "/v1/server/ownership/check",
            {"steam_id": steam_id, "item_ids": ["arc-veteran-kit", "missing-kit"]},
        )

        self.assertEqual(status, server.HTTPStatus.OK)
        self.assertTrue(result["verified"])
        self.assertEqual(result["official_server"], "geonosis")
        self.assertEqual(result["owned_item_ids"], ["arc-veteran-kit"])
        self.assertEqual(result["missing_item_ids"], ["missing-kit"])
        grants = {item["item_id"]: item for item in result["items"]}
        self.assertTrue(grants["arc-veteran-kit"]["owned"])
        self.assertEqual(grants["arc-veteran-kit"]["class_name"], "TCW_Kit_ARCVeteran")
        self.assertFalse(grants["missing-kit"]["owned"])

    def test_official_server_ownership_check_rejects_bad_auth(self):
        steam_id = "76561198000000016"
        payload = {"steam_id": steam_id, "item_ids": ["arc-veteran-kit"]}

        (unsigned_status, unsigned, unknown_status, unknown), _logs = self.captured_json_logs(
            lambda: (
                *self.post_signed_server_request(
                    "/v1/server/ownership/check",
                    payload,
                    include_signature=False,
                ),
                *self.post_signed_server_request(
                    "/v1/server/ownership/check",
                    payload,
                    server_id="unknown",
                    keys={"geonosis": "test-secret"},
                ),
            )
        )

        self.assertEqual(unsigned_status, server.HTTPStatus.UNAUTHORIZED)
        self.assertEqual(unsigned["error"], "invalid_server_signature")
        self.assertEqual(unknown_status, server.HTTPStatus.UNAUTHORIZED)
        self.assertEqual(unknown["error"], "invalid_server_auth")

    def test_official_server_ownership_check_fails_closed_for_missing_profile(self):
        status, result = self.post_signed_server_request(
            "/v1/server/ownership/check",
            {"steam_id": "76561198000000017", "item_ids": ["arc-veteran-kit"]},
        )

        self.assertEqual(status, server.HTTPStatus.NOT_FOUND)
        self.assertEqual(result["error"], "profile_not_found")

    def test_marketplace_catalog_marks_empty_store_as_coming_soon(self):
        catalog = server.marketplace_catalog_for_player()

        self.assertEqual(catalog["active_item_count"], 0)
        self.assertFalse(catalog["marketplace_open"])
        self.assertEqual(catalog["policy"]["currency"], "in_game_credits")
        self.assertFalse(catalog["policy"]["real_money_purchases"])
        self.assertIn("No real money", catalog["policy"]["message"])

    def test_marketplace_open_requires_enabled_visible_items(self):
        server.MARKETPLACE_PATH.write_text(
            json.dumps(
                {
                    "items": [
                        {
                            "id": "disabled-display-item",
                            "category": "customisations",
                            "name": "Disabled Display Item",
                            "cost": 100,
                            "enabled": False,
                        },
                        {
                            "id": "hidden-live-item",
                            "category": "customisations",
                            "name": "Hidden Live Item",
                            "cost": 100,
                            "visible": False,
                        },
                    ]
                }
            ),
            encoding="utf-8",
        )

        catalog = server.marketplace_catalog_for_player()

        self.assertEqual(catalog["active_item_count"], 0)
        self.assertFalse(catalog["marketplace_open"])
        self.assertEqual([item["id"] for item in catalog["items"]], ["disabled-display-item"])

    def test_kamino_and_master_scrapper_awards_are_one_time(self):
        steam_id = "76561198000000001"
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                (steam_id, "CT Kamino"),
            )
            db.execute("INSERT INTO stats (steam_id, droid_kills, kamino_visits) VALUES (?, 1000, 1)", (steam_id,))
            unlocked = server.unlock_achievements(db, steam_id)
            repeated = server.unlock_achievements(db, steam_id)

        self.assertIn("kamino_shiny", unlocked)
        self.assertIn("master_scrapper", unlocked)
        self.assertEqual(repeated, [])

    def test_official_event_rewards_read_nested_targets(self):
        values = {stat: 0 for stat in server.EVENT_STAT_LIMITS}
        server.apply_official_event_rewards(
            {
                "event_type": "kill",
                "target": {"type": "tank", "side": "cis"},
                "mission": {"difficulty": 5, "map": "Geonosis"},
            },
            values,
            {},
        )

        self.assertEqual(values["xp"], 100)
        self.assertEqual(values["credits"], 50)
        self.assertEqual(values["kills"], 1)
        self.assertEqual(values["enemy_kills"], 1)
        self.assertEqual(values["droid_kills"], 1)

    def test_public_profiles_bio_and_recent_squadmates(self):
        first = "76561198000000010"
        second = "76561198000000011"
        hidden = "76561198000000012"
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, unit, rank, bio, profile_public, verified_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, 1, 1, 10)",
                (first, "CT First", "104th", "Trooper", "Frontline lore"),
            )
            db.execute(
                "INSERT INTO users (steam_id, display_name, unit, rank, bio, profile_public, verified_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, 1, 1, 20)",
                (second, "CT Second", "501st", "Sergeant", "Squadmate lore"),
            )
            db.execute(
                "INSERT INTO users (steam_id, display_name, unit, rank, bio, profile_public, verified_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 0, 1, 1, 30)",
                (hidden, "CT Hidden", "104th", "Trooper", "Hidden lore"),
            )
            db.execute("INSERT INTO stats (steam_id, xp, missions) VALUES (?, 500, 1)", (first,))
            db.execute("INSERT INTO stats (steam_id, xp, missions) VALUES (?, 1800, 2)", (second,))
            db.execute("INSERT INTO stats (steam_id, xp, missions) VALUES (?, 500, 1)", (hidden,))
            db.execute(
                "INSERT INTO achievements (steam_id, achievement_id, unlocked_at) VALUES (?, 'first_blood', 100)",
                (second,),
            )
            db.execute(
                """
                INSERT INTO campaign_deployments
                    (deployment_id, steam_id, campaign_id, campaign_name, mission_name, planet,
                     official_server, completed_at, awards_json)
                VALUES ('public-profile-geonosis', ?, 'battle_of_geonosis', 'Battle of Geonosis',
                        'Factory Push', 'Geonosis', 'geonosis', 120, '[]')
                """,
                (second,),
            )
            db.execute(
                "INSERT INTO server_events (event_id, official_server, steam_id, payload_json, received_at) VALUES (?, ?, ?, '{}', ?)",
                ("recent-a", "geonosis", first, 1000),
            )
            db.execute(
                "INSERT INTO server_events (event_id, official_server, steam_id, payload_json, received_at) VALUES (?, ?, ?, '{}', ?)",
                ("recent-b", "geonosis", second, 1100),
            )
            db.execute(
                "INSERT INTO server_events (event_id, official_server, steam_id, payload_json, received_at) VALUES (?, ?, ?, '{}', ?)",
                ("recent-hidden", "geonosis", hidden, 1100),
            )

            public_profiles = server.list_public_profiles(db, "", "active", "", 1, 24)
            unit_profiles = server.list_public_profiles(db, "104th", "legion", "", 1, 24)
            search_profiles = server.list_public_profiles(db, "", "active", "second", 1, 24)
            level_profiles = server.list_public_profiles(db, "", "level", "", 1, 24)
            wildcard_profiles = server.list_public_profiles(db, "", "active", "%", 1, 24)
            small_page = server.list_public_profiles(db, "", "active", "", 1, 1)
            detail = server.public_profile_detail(db, second)
            hidden_detail = server.public_profile_detail(db, hidden)
            recent = server.recently_played_with(db, first)

        self.assertEqual([profile["steam_id"] for profile in public_profiles["profiles"]], [second, first])
        self.assertEqual(public_profiles["pagination"]["total"], 2)
        self.assertEqual([profile["steam_id"] for profile in unit_profiles["profiles"]], [first])
        self.assertEqual([profile["steam_id"] for profile in search_profiles["profiles"]], [second])
        self.assertEqual([profile["steam_id"] for profile in level_profiles["profiles"]], [second, first])
        self.assertEqual(wildcard_profiles["profiles"], [])
        self.assertTrue(small_page["pagination"]["has_more"])
        self.assertEqual(detail["steam_id"], second)
        self.assertEqual(detail["bio"], "Squadmate lore")
        self.assertEqual(detail["rank"], "Sergeant")
        self.assertEqual(detail["unit"], "501st")
        self.assertEqual(detail["achievements"][0]["id"], "first_blood")
        self.assertEqual(detail["campaigns"][0]["id"], "battle_of_geonosis")
        self.assertEqual(detail["campaigns"][0]["deployments"][0]["mission_name"], "Factory Push")
        self.assertIsNone(hidden_detail)
        self.assertEqual([profile["steam_id"] for profile in recent], [second])
        self.assertEqual(server.clean_profile_bio("x" * 700), "x" * server.MAX_PROFILE_BIO_CHARS)

    def test_release_manifest_sha256_cleanup(self):
        digest = "a" * 64
        manifest = server.clean_release_manifest(
            {
                "sha256": digest.lower(),
                "downloads": {
                    "windows": {
                        "url": "https://tcwa3.co.uk/downloads/TCW-Launcher-Windows.zip",
                        "installer_url": "https://tcwa3.co.uk/downloads/TCW-Launcher-Windows.zip",
                        "sha256": "not-a-real-digest",
                    }
                },
            }
        )
        self.assertEqual(manifest["sha256"], digest.upper())
        self.assertEqual(manifest["downloads"]["windows"]["sha256"], "")

    def test_news_payload_cleanup(self):
        payload = server.clean_news_payload(
            {
                "items": [
                    {
                        "title": "Long title " * 20,
                        "body": "Mission update",
                        "date": "2026-06-19",
                        "priority": "3",
                    },
                    {"title": "Higher Priority", "body": "First in launcher", "priority": 10},
                ]
            }
        )
        self.assertEqual(payload["items"][0]["title"], "Higher Priority")
        self.assertLessEqual(len(payload["items"][1]["title"]), 80)

    def test_news_payload_requires_items(self):
        with self.assertRaises(ValueError):
            server.clean_news_payload({"items": []})

    def test_event_payload_cleanup_and_active_manifest(self):
        payload = server.save_events_payload(
            {
                "events": [
                    {
                        "title": "+20% XP Weekend",
                        "description": "Bonus XP for launch weekend.",
                        "active": True,
                        "priority": 10,
                        "accent_color": "#d9b36c",
                        "background_color": "#070b12",
                        "effect": "pulse",
                        "popup_style": "center",
                        "font_family": "mono",
                        "duration_seconds": 999,
                        "sound_url": "https://tcwa3.co.uk/audio/event_sounds/alert.mp3",
                        "xp_bonus_percent": 20,
                    },
                    {
                        "title": "Inactive old event",
                        "active": False,
                        "xp_bonus_percent": 500,
                    },
                ]
            }
        )
        manifest = server.load_event_manifest()
        bonus, event_ids = server.active_event_xp_bonus(server.now())

        self.assertEqual(payload["events"][0]["id"], "20-xp-weekend")
        self.assertEqual(payload["events"][0]["popup_style"], "center")
        self.assertEqual(payload["events"][0]["font_family"], "mono")
        self.assertEqual(payload["events"][0]["duration_seconds"], 120)
        self.assertEqual(payload["events"][0]["sound_url"], "https://tcwa3.co.uk/audio/event_sounds/alert.mp3")
        self.assertEqual(len(manifest["events"]), 1)
        self.assertEqual(manifest["modifiers"]["xp_bonus_percent"], 20)
        self.assertEqual(bonus, 20)
        self.assertEqual(event_ids, ["20-xp-weekend"])
        self.assertEqual(server.apply_xp_bonus(100, bonus), 120)

    def test_event_dates_filter_future_and_ended_banners(self):
        current_time = 1_800_000_000
        server.save_events_payload(
            {
                "events": [
                    {"title": "Live", "start_at": "2026-01-01T00:00:00Z", "end_at": "2030-01-01T00:00:00Z"},
                    {"title": "Future", "start_at": "2035-01-01T00:00:00Z"},
                    {"title": "Ended", "end_at": "2020-01-01T00:00:00Z"},
                ]
            }
        )
        active = server.load_event_banners(timestamp=current_time)

        self.assertEqual([event["title"] for event in active], ["Live"])

    def test_server_controls_mark_status_as_maintenance(self):
        payload = server.save_server_controls_payload(
            {
                "servers": [
                    {
                        "name": "TCW Roleplay Server 1",
                        "ip": "144.48.104.82",
                        "port": 2311,
                        "maintenance": True,
                        "reason": "Patch window",
                    },
                    {
                        "name": "TCW Action Server 1",
                        "ip": "144.48.104.82",
                        "port": 2326,
                        "maintenance": False,
                    },
                ]
            }
        )

        maintenance = server.apply_server_control(
            {"status": "online", "players": 12, "max_players": 40, "mission": "Kamino"},
            "144.48.104.82",
            2311,
        )
        available = server.apply_server_control(
            {"status": "online", "players": 4, "max_players": 40, "mission": "Geonosis"},
            "144.48.104.82",
            2326,
        )

        self.assertEqual(payload["servers"][0]["key"], "144.48.104.82:2326")
        self.assertEqual(payload["servers"][1]["key"], "144.48.104.82:2311")
        self.assertEqual(maintenance["status"], "maintenance")
        self.assertTrue(maintenance["maintenance"])
        self.assertEqual(maintenance["message"], "Patch window")
        self.assertEqual(maintenance["mission"], "Patch window")
        self.assertEqual(available["status"], "online")
        self.assertNotIn("maintenance", available)

    def test_server_controls_admin_route_requires_manager_token_and_persists_state(self):
        original_token = server.COMMUNITY_MANAGER_TOKEN
        server.COMMUNITY_MANAGER_TOKEN = "manager-secret"
        try:
            body = {
                "servers": [
                    {
                        "name": "TCW Roleplay Server 1",
                        "ip": "144.48.104.82",
                        "port": 2311,
                        "maintenance": True,
                        "reason": "Operation patch window",
                    }
                ]
            }

            status, error_payload = self.post_json_request("/v1/admin/server-controls", body)
            self.assertEqual(status, 401)
            self.assertEqual(error_payload["error"], "invalid_community_manager_token")

            status, payload = self.post_json_request(
                "/v1/admin/server-controls",
                body,
                headers={"Authorization": "Bearer manager-secret"},
            )

            self.assertEqual(status, 200)
            self.assertEqual(payload["status"], "saved")
            saved = payload["server_controls"]["servers"][0]
            self.assertEqual(saved["key"], "144.48.104.82:2311")
            self.assertTrue(saved["maintenance"])
            self.assertEqual(saved["reason"], "Operation patch window")
            self.assertEqual(server.load_server_controls()["servers"][0]["reason"], "Operation patch window")
        finally:
            server.COMMUNITY_MANAGER_TOKEN = original_token

    def test_audio_manifest_scans_named_categories(self):
        with tempfile.TemporaryDirectory() as temp_root:
            original_root = server.AUDIO_ROOT
            original_base = server.AUDIO_BASE_URL
            try:
                server.AUDIO_ROOT = Path(temp_root)
                server.AUDIO_BASE_URL = "https://tcwa3.co.uk/audio"
                music_dir = server.AUDIO_ROOT / "menu_music"
                sounds_dir = server.AUDIO_ROOT / "menu_sounds"
                event_sounds_dir = server.AUDIO_ROOT / "event_sounds"
                radio_dir = server.AUDIO_ROOT / "holonet_radio"
                music_dir.mkdir(parents=True)
                sounds_dir.mkdir(parents=True)
                event_sounds_dir.mkdir(parents=True)
                radio_dir.mkdir(parents=True)
                (music_dir / "republic march.mp3").write_bytes(b"mp3")
                (sounds_dir / "button click.mp3").write_bytes(b"mp3")
                (event_sounds_dir / "operation alert.mp3").write_bytes(b"mp3")
                (radio_dir / "holonet bulletin.mp3").write_bytes(b"mp3")
                (radio_dir / "ignore.txt").write_text("not audio", encoding="utf-8")

                manifest = server.load_audio_manifest()
            finally:
                server.AUDIO_ROOT = original_root
                server.AUDIO_BASE_URL = original_base

        self.assertEqual(manifest["categories"]["menu_music"]["tracks"][0]["title"], "Republic March")
        self.assertEqual(manifest["categories"]["menu_sounds"]["tracks"][0]["category"], "menu_sounds")
        self.assertEqual(manifest["categories"]["event_sounds"]["tracks"][0]["title"], "Operation Alert")
        self.assertEqual(len(manifest["categories"]["holonet_radio"]["tracks"]), 1)
        self.assertTrue(manifest["categories"]["holonet_radio"]["tracks"][0]["url"].endswith("holonet_radio/holonet%20bulletin.mp3"))

    def test_theme_manifest_loads_custom_theme_assets(self):
        with tempfile.TemporaryDirectory() as temp_root:
            original_root = server.THEME_ROOT
            original_base = server.THEME_BASE_URL
            try:
                server.THEME_ROOT = Path(temp_root)
                server.THEME_BASE_URL = "https://tcwa3.co.uk/themes"
                theme_dir = server.THEME_ROOT / "104th"
                (theme_dir / "backgrounds").mkdir(parents=True)
                (theme_dir / "logo.png").write_bytes(b"png")
                (theme_dir / "backgrounds" / "wolfpack.png").write_bytes(b"png")
                (theme_dir / "theme.json").write_text(
                    json.dumps(
                        {
                            "id": "104th",
                            "name": "104th Wolfpack",
                            "description": "Wolfpack legion theme.",
                            "accent_color": "#9aa4ad",
                            "logo": "logo.png",
                            "backgrounds": ["backgrounds/wolfpack.png", "../secret.png"],
                        }
                    ),
                    encoding="utf-8",
                )

                manifest = server.load_theme_manifest()
            finally:
                server.THEME_ROOT = original_root
                server.THEME_BASE_URL = original_base

        custom = [theme for theme in manifest["themes"] if theme["id"] == "104th"][0]
        self.assertEqual(custom["name"], "104th Wolfpack")
        self.assertEqual(len(custom["backgrounds"]), 1)
        self.assertTrue(custom["logo_url"].endswith("/104th/logo.png"))

    def test_community_manager_audio_upload_and_delete(self):
        with tempfile.TemporaryDirectory() as temp_root, tempfile.TemporaryDirectory() as temp_bin:
            original_root = server.AUDIO_ROOT
            original_base = server.AUDIO_BASE_URL
            original_bin = server.ASSET_BIN_ROOT
            try:
                server.AUDIO_ROOT = Path(temp_root)
                server.AUDIO_BASE_URL = "https://tcwa3.co.uk/audio"
                server.ASSET_BIN_ROOT = Path(temp_bin)
                track = server.save_audio_upload("event_sounds", "briefing report.mp3", b"mp3")
                inventory = server.load_community_asset_inventory()
                binned = server.delete_audio_asset("event_sounds", "briefing report.mp3")
                bin_inventory = server.load_community_asset_inventory()["bin"]
                binned_file_exists = binned is not None and (Path(temp_bin) / binned["bin_path"]).exists()
            finally:
                server.AUDIO_ROOT = original_root
                server.AUDIO_BASE_URL = original_base
                server.ASSET_BIN_ROOT = original_bin

        self.assertEqual(track["title"], "Briefing Report")
        self.assertEqual(track["category"], "event_sounds")
        self.assertEqual(len(inventory["audio"]["event_sounds"]["tracks"]), 1)
        self.assertFalse((Path(temp_root) / "event_sounds" / "briefing report.mp3").exists())
        self.assertIsNotNone(binned)
        self.assertEqual(binned["kind"], "audio")
        self.assertTrue(binned_file_exists)
        self.assertIn("backend_asset_archive/community_assets/audio/event_sounds", binned["github_archive_path"])
        self.assertEqual(len(bin_inventory["items"]), 1)

    def test_audio_upload_rejects_invalid_category_file_type_and_oversized_payload(self):
        with self.assertRaisesRegex(ValueError, "Unknown audio category"):
            server.save_audio_upload("bad_category", "briefing.mp3", b"mp3")
        with self.assertRaisesRegex(ValueError, "Unsupported file type"):
            server.save_audio_upload("event_sounds", "briefing.wav", b"wav")

        original_max = server.COMMUNITY_MANAGER_MAX_FILE_BYTES
        server.COMMUNITY_MANAGER_MAX_FILE_BYTES = 3
        try:
            too_large = base64.b64encode(b"1234").decode("ascii")
            with self.assertRaisesRegex(ValueError, "Uploaded file is too large"):
                server.decode_asset_upload(too_large)
        finally:
            server.COMMUNITY_MANAGER_MAX_FILE_BYTES = original_max

    def test_community_manager_theme_upload_and_delete(self):
        with tempfile.TemporaryDirectory() as temp_root, tempfile.TemporaryDirectory() as temp_bin:
            original_root = server.THEME_ROOT
            original_base = server.THEME_BASE_URL
            original_bin = server.ASSET_BIN_ROOT
            try:
                server.THEME_ROOT = Path(temp_root)
                server.THEME_BASE_URL = "https://tcwa3.co.uk/themes"
                server.ASSET_BIN_ROOT = Path(temp_bin)
                theme = server.save_theme_upload("104th", "104th Wolfpack", "background", "wolfpack.png", b"png")
                inventory = server.load_community_asset_inventory()
                binned = server.delete_theme_asset("104th", "backgrounds/wolfpack.png")
                manifest = json.loads((server.THEME_ROOT / "104th" / "theme.json").read_text(encoding="utf-8"))
                binned_file_exists = binned is not None and (Path(temp_bin) / binned["bin_path"]).exists()
            finally:
                server.THEME_ROOT = original_root
                server.THEME_BASE_URL = original_base
                server.ASSET_BIN_ROOT = original_bin

        self.assertEqual(theme["id"], "104th")
        self.assertEqual(theme["name"], "104th Wolfpack")
        self.assertEqual(len(theme["backgrounds"]), 1)
        self.assertEqual(len(inventory["themes"][0]["background_assets"]), 1)
        self.assertEqual(manifest["backgrounds"], [])
        self.assertIsNotNone(binned)
        self.assertEqual(binned["kind"], "images")
        self.assertTrue(binned_file_exists)
        self.assertIn("backend_asset_archive/community_assets/images/104th", binned["github_archive_path"])

    def test_community_manager_theme_logo_delete_clears_manifest_references(self):
        with tempfile.TemporaryDirectory() as temp_root, tempfile.TemporaryDirectory() as temp_bin:
            original_root = server.THEME_ROOT
            original_base = server.THEME_BASE_URL
            original_bin = server.ASSET_BIN_ROOT
            try:
                server.THEME_ROOT = Path(temp_root)
                server.THEME_BASE_URL = "https://tcwa3.co.uk/themes"
                server.ASSET_BIN_ROOT = Path(temp_bin)
                theme = server.save_theme_upload("104th", "104th Wolfpack", "logo", "wolfpack.png", b"png")
                manifest_path = server.THEME_ROOT / "104th" / "theme.json"
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                manifest["logo_url"] = theme["logo_url"]
                manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

                binned = server.delete_theme_asset("104th", "logos/wolfpack.png")
                saved = json.loads(manifest_path.read_text(encoding="utf-8"))
                binned_file_exists = binned is not None and (Path(temp_bin) / binned["bin_path"]).exists()
            finally:
                server.THEME_ROOT = original_root
                server.THEME_BASE_URL = original_base
                server.ASSET_BIN_ROOT = original_bin

        self.assertEqual(saved["logo"], "")
        self.assertEqual(saved["logo_url"], "")
        self.assertIsNotNone(binned)
        self.assertTrue(binned_file_exists)

    def test_community_manager_theme_folder_upload_preserves_asset_folders(self):
        with tempfile.TemporaryDirectory() as temp_root:
            original_root = server.THEME_ROOT
            original_base = server.THEME_BASE_URL
            try:
                server.THEME_ROOT = Path(temp_root)
                server.THEME_BASE_URL = "https://tcwa3.co.uk/themes"
                background_theme = server.save_theme_upload(
                    "razor-squadron",
                    "Razor Squadron",
                    "background",
                    "briefing.png",
                    b"png",
                    "Razor squadron theme/backgrounds/briefing.png",
                )
                logo_theme = server.save_theme_upload(
                    "razor-squadron",
                    "Razor Squadron",
                    "logo",
                    "razor-logo.png",
                    b"png",
                    "Razor squadron theme/logos/razor-logo.png",
                )
                manifest = json.loads(
                    (server.THEME_ROOT / "razor-squadron" / "theme.json").read_text(encoding="utf-8")
                )
                background_file_exists = (server.THEME_ROOT / "razor-squadron" / "backgrounds" / "briefing.png").exists()
                logo_file_exists = (server.THEME_ROOT / "razor-squadron" / "logos" / "razor-logo.png").exists()
            finally:
                server.THEME_ROOT = original_root
                server.THEME_BASE_URL = original_base

        self.assertEqual(background_theme["id"], "razor-squadron")
        self.assertIn("https://tcwa3.co.uk/themes/razor-squadron/backgrounds/briefing.png", background_theme["backgrounds"])
        self.assertEqual(manifest["backgrounds"], ["backgrounds/briefing.png"])
        self.assertEqual(manifest["logo"], "logos/razor-logo.png")
        self.assertEqual(logo_theme["logo_url"], "https://tcwa3.co.uk/themes/razor-squadron/logos/razor-logo.png")
        self.assertTrue(background_file_exists)
        self.assertTrue(logo_file_exists)

    def test_theme_upload_detects_logo_mark_and_icon_names_without_explicit_asset_type(self):
        with tempfile.TemporaryDirectory() as temp_root:
            original_root = server.THEME_ROOT
            original_base = server.THEME_BASE_URL
            try:
                server.THEME_ROOT = Path(temp_root)
                server.THEME_BASE_URL = "https://tcwa3.co.uk/themes"
                logo_theme = server.save_theme_upload("logo-test", "Logo Test", "", "104th-logo.png", b"png")
                mark_theme = server.save_theme_upload("mark-test", "Mark Test", "", "company mark.webp", b"webp")
                icon_theme = server.save_theme_upload("icon-test", "Icon Test", "", "unit_icon.jpg", b"jpg")
                background_theme = server.save_theme_upload("background-test", "Background Test", "", "briefing.png", b"png")
            finally:
                server.THEME_ROOT = original_root
                server.THEME_BASE_URL = original_base

        self.assertTrue(logo_theme["logo_url"].endswith("/logo-test/logos/104th-logo.png"))
        self.assertTrue(mark_theme["logo_url"].endswith("/mark-test/logos/company%20mark.webp"))
        self.assertTrue(icon_theme["logo_url"].endswith("/icon-test/logos/unit_icon.jpg"))
        self.assertEqual(background_theme["logo_url"], "")
        self.assertEqual(background_theme["backgrounds"], ["https://tcwa3.co.uk/themes/background-test/backgrounds/briefing.png"])

    def test_community_manager_theme_metadata_save(self):
        with tempfile.TemporaryDirectory() as temp_root:
            original_root = server.THEME_ROOT
            original_base = server.THEME_BASE_URL
            try:
                server.THEME_ROOT = Path(temp_root)
                server.THEME_BASE_URL = "https://tcwa3.co.uk/themes"
                theme = server.save_theme_metadata(
                    {
                        "theme_id": "104th",
                        "theme_name": "104th Wolfpack",
                        "description": "Wolfpack legion theme.",
                        "accent_color": "#9aa4ad",
                        "panel_color": "#05090f",
                        "text_color": "#f8fafc",
                    }
                )
                saved = json.loads((server.THEME_ROOT / "104th" / "theme.json").read_text(encoding="utf-8"))
            finally:
                server.THEME_ROOT = original_root
                server.THEME_BASE_URL = original_base

        self.assertEqual(theme["id"], "104th")
        self.assertEqual(theme["name"], "104th Wolfpack")
        self.assertEqual(theme["accent_color"], "#9AA4AD")
        self.assertEqual(theme["panel_color"], "#05090F")
        self.assertEqual(theme["text_color"], "#F8FAFC")
        self.assertEqual(saved["description"], "Wolfpack legion theme.")

    def test_community_manager_rejects_unsafe_asset_paths(self):
        with tempfile.TemporaryDirectory() as temp_root:
            with self.assertRaises(ValueError):
                server.resolve_public_child(Path(temp_root), "../secret.png")
            with self.assertRaises(ValueError):
                server.safe_asset_filename("payload.exe", server.AUDIO_EXTENSIONS)

    def test_community_manager_scope_excludes_protected_actions(self):
        scope = server.community_manager_authority_scope()
        allowed = {
            f"{method} {path}"
            for method, paths in scope["allowed_routes"].items()
            for path in paths
        }
        protected = {
            route
            for area in scope["protected_areas"]
            for route in area["routes"]
        }

        self.assertIn("GET /v1/admin/assets", allowed)
        self.assertIn("POST /v1/admin/assets/upload", allowed)
        self.assertFalse(server.community_manager_route_allowed("POST", "/v1/server/events"))
        self.assertFalse(server.community_manager_route_allowed("POST", "/v1/marketplace/purchase"))
        self.assertFalse(server.community_manager_route_allowed("POST", "/v1/server/ownership/check"))
        self.assertFalse(server.community_manager_route_allowed("POST", "/v1/admin/news"))
        self.assertNotIn("POST /v1/server/events", allowed)
        self.assertNotIn("POST /v1/marketplace/purchase", allowed)
        self.assertNotIn("POST /v1/server/ownership/check", allowed)
        self.assertIn("POST /v1/server/events", protected)
        self.assertIn("POST /v1/marketplace/purchase", protected)
        self.assertIn("POST /v1/server/ownership/check", protected)

    def test_community_manager_inventory_includes_authority_scope(self):
        inventory = server.load_community_asset_inventory()
        authority = inventory["authority"]

        self.assertEqual(authority["role"], "community_manager")
        self.assertIn("/v1/admin/assets", authority["allowed_routes"]["GET"])
        self.assertNotIn("/v1/marketplace/purchase", authority["allowed_routes"].get("POST", []))
        self.assertTrue(any(area["area"] == "Secrets and raw database rows" for area in authority["protected_areas"]))

    def test_expanded_api_preflight_allows_profile_community_quest_and_admin_paths(self):
        paths = [
            "/v1/me",
            "/v1/me/quests",
            "/v1/roster-link-requests",
            "/v1/community/leaderboards",
            "/v1/quests",
            "/v1/admin/roster-link-requests",
            "/v1/admin/player-support",
        ]
        for path in paths:
            with self.subTest(path=path):
                status, headers = self.options_request(path, "https://tcwa3.co.uk")

                self.assertEqual(status, server.HTTPStatus.NO_CONTENT)
                self.assertEqual(headers.get("Access-Control-Allow-Origin"), "https://tcwa3.co.uk")
                self.assertIn("GET", headers.get("Access-Control-Allow-Methods", ""))
                self.assertIn("POST", headers.get("Access-Control-Allow-Methods", ""))
                self.assertIn("Authorization", headers.get("Access-Control-Allow-Headers", ""))

    def test_community_leaderboards_and_quests_routes_respect_public_profiles(self):
        public_steam = "76561198000000040"
        hidden_steam = "76561198000000041"
        access_token = "tcwa3-quest-session"
        timestamp = server.now()
        with server.connect_db() as db:
            db.execute(
                "INSERT INTO users (steam_id, display_name, profile_public, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1, 20)",
                (public_steam, "CT Public"),
            )
            db.execute(
                "INSERT INTO users (steam_id, display_name, profile_public, verified_at, created_at, updated_at) VALUES (?, ?, 0, 1, 1, 30)",
                (hidden_steam, "CT Hidden"),
            )
            db.execute("INSERT INTO stats (steam_id, xp, credits, kills, missions) VALUES (?, 1800, 500, 12, 3)", (public_steam,))
            db.execute("INSERT INTO stats (steam_id, xp, credits, kills, missions) VALUES (?, 9000, 900, 99, 9)", (hidden_steam,))
            db.execute(
                "INSERT INTO achievements (steam_id, achievement_id, unlocked_at) VALUES (?, 'first_blood', 1)",
                (public_steam,),
            )
            db.execute(
                """
                INSERT INTO quest_progress
                    (steam_id, quest_id, title, category, state, stage_index, stage_title,
                     stage_description, lore_json, history_json, started_at, updated_at)
                VALUES (?, 'quest_rescue_pilot', 'Rescue the Pilot', 'Main', 'SUCCEEDED', 2,
                        'Extraction complete', 'Pilot extracted.', '[]', '[]', ?, ?)
                """,
                (public_steam, timestamp, timestamp),
            )
            db.execute(
                "INSERT INTO sessions (token_hash, steam_id, created_at, expires_at, last_used_at) VALUES (?, ?, ?, ?, ?)",
                (server.token_hash(access_token), public_steam, timestamp, timestamp + 3600, timestamp),
            )

        leaderboard_status, leaderboards = self.get_json_request("/v1/community/leaderboards?limit=5")
        quests_status, quests = self.get_json_request("/v1/quests")
        my_status, mine = self.get_json_request("/v1/me/quests", {"Authorization": f"Bearer {access_token}"})

        self.assertEqual(leaderboard_status, server.HTTPStatus.OK)
        self.assertEqual(leaderboards["summary"]["public_profiles"], 1)
        self.assertEqual(leaderboards["summary"]["xp"], 1800)
        level_board = next(board for board in leaderboards["leaderboards"] if board["id"] == "level")
        self.assertEqual(level_board["profiles"][0]["steam_id"], public_steam)
        self.assertNotEqual(level_board["profiles"][0]["steam_id"], hidden_steam)
        self.assertEqual(quests_status, server.HTTPStatus.OK)
        self.assertTrue(any(item["id"] == "quest_rescue_pilot" for item in quests["quests"]))
        self.assertEqual(quests["recent_progress"][0]["steam_id"], public_steam)
        self.assertEqual(my_status, server.HTTPStatus.OK)
        self.assertEqual(mine["profile_quests"][0]["id"], "quest_rescue_pilot")

    def test_roster_link_request_queue_requires_owner_admin_for_decision_and_audits(self):
        steam_id = "76561198000000042"
        access_token = "tcwa3-roster-fallback-session"
        original_owner_token = server.OWNER_ADMIN_TOKEN
        original_manager_token = server.COMMUNITY_MANAGER_TOKEN
        server.OWNER_ADMIN_TOKEN = "owner-secret"
        server.COMMUNITY_MANAGER_TOKEN = "manager-secret"
        timestamp = server.now()
        try:
            with server.connect_db() as db:
                db.execute(
                    "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                    (steam_id, "CT Fallback"),
                )
                db.execute("INSERT INTO stats (steam_id) VALUES (?)", (steam_id,))
                db.execute(
                    "INSERT INTO sessions (token_hash, steam_id, created_at, expires_at, last_used_at) VALUES (?, ?, ?, ?, ?)",
                    (server.token_hash(access_token), steam_id, timestamp, timestamp + 3600, timestamp),
                )

            status, payload = self.post_json_request(
                "/v1/roster-link-requests",
                {"message": "Discord rejected the handoff.", "unit": "104th", "rank": "CPL"},
                {"Authorization": f"Bearer {access_token}"},
            )
            denied_status, denied = self.get_json_request(
                "/v1/admin/roster-link-requests?status=pending",
                {"Authorization": "Bearer manager-secret"},
            )
            owner_status, owner_payload = self.get_json_request(
                "/v1/admin/roster-link-requests?status=pending",
                {"Authorization": "Bearer owner-secret"},
            )
            request_id = payload["request"]["request_id"]
            approve_status, approved = self.post_json_request(
                "/v1/admin/roster-link-requests",
                {"request_id": request_id, "action": "approve", "note": "Verified by staff."},
                {"Authorization": "Bearer owner-secret"},
            )

            with server.connect_db() as db:
                profile = server.profile_for(db, steam_id)
                audit = server.list_admin_audit(db, 10)

            self.assertEqual(status, server.HTTPStatus.OK)
            self.assertEqual(payload["status"], "queued")
            self.assertEqual(denied_status, server.HTTPStatus.UNAUTHORIZED)
            self.assertEqual(denied["error"], "invalid_owner_admin_token")
            self.assertEqual(owner_status, server.HTTPStatus.OK)
            self.assertEqual(owner_payload["requests"][0]["request_id"], request_id)
            self.assertEqual(approve_status, server.HTTPStatus.OK)
            self.assertEqual(approved["status"], "approved")
            self.assertTrue(profile["rostered"])
            self.assertEqual(profile["unit"], "104th")
            self.assertTrue(any(item["action"] == "roster_link_approved" for item in audit))
        finally:
            server.OWNER_ADMIN_TOKEN = original_owner_token
            server.COMMUNITY_MANAGER_TOKEN = original_manager_token

    def test_owner_admin_player_support_adjustment_requires_owner_and_writes_audit(self):
        steam_id = "76561198000000043"
        original_owner_token = server.OWNER_ADMIN_TOKEN
        original_manager_token = server.COMMUNITY_MANAGER_TOKEN
        server.OWNER_ADMIN_TOKEN = "owner-secret"
        server.COMMUNITY_MANAGER_TOKEN = "manager-secret"
        try:
            with server.connect_db() as db:
                db.execute(
                    "INSERT INTO users (steam_id, display_name, verified_at, created_at, updated_at) VALUES (?, ?, 1, 1, 1)",
                    (steam_id, "CT Support"),
                )
                db.execute("INSERT INTO stats (steam_id, xp, credits) VALUES (?, 100, 50)", (steam_id,))

            body = {"action": "adjust_progress", "steam_id": steam_id, "xp_delta": 250, "credits_delta": -10, "reason": "Corrected event import."}
            denied_status, denied = self.post_json_request(
                "/v1/admin/player-support",
                body,
                {"Authorization": "Bearer manager-secret"},
            )
            status, payload = self.post_json_request(
                "/v1/admin/player-support",
                body,
                {"Authorization": "Bearer owner-secret"},
            )

            self.assertEqual(denied_status, server.HTTPStatus.UNAUTHORIZED)
            self.assertEqual(denied["error"], "invalid_owner_admin_token")
            self.assertEqual(status, server.HTTPStatus.OK)
            self.assertEqual(payload["profile"]["xp"], 350)
            self.assertEqual(payload["profile"]["credits"], 40)
            self.assertEqual(payload["audit"]["action"], "player_support_adjust_progress")
            self.assertEqual(payload["audit"]["actor_role"], "owner_admin")
        finally:
            server.OWNER_ADMIN_TOKEN = original_owner_token
            server.COMMUNITY_MANAGER_TOKEN = original_manager_token

    def test_youtube_feed_parser(self):
        feed = b"""<?xml version="1.0" encoding="UTF-8"?>
        <feed xmlns="http://www.w3.org/2005/Atom"
              xmlns:yt="http://www.youtube.com/xml/schemas/2015"
              xmlns:media="http://search.yahoo.com/mrss/">
          <entry>
            <yt:videoId>Ct7sYna3wU0</yt:videoId>
            <title>The Clone Wars | Arma-3 - The First Battle of Geonosis Trailer</title>
            <published>2026-06-14T13:00:13+00:00</published>
            <link rel="alternate" href="https://www.youtube.com/watch?v=Ct7sYna3wU0" />
            <media:group>
              <media:thumbnail url="https://i.ytimg.com/vi/Ct7sYna3wU0/hqdefault.jpg" />
            </media:group>
          </entry>
        </feed>"""
        video = server.parse_youtube_feed(feed)
        self.assertTrue(video["available"])
        self.assertEqual(video["video_id"], "Ct7sYna3wU0")
        self.assertIn("mute=1", video["embed_url"])
        self.assertEqual(video["thumbnail_url"], "https://i.ytimg.com/vi/Ct7sYna3wU0/hqdefault.jpg")


if __name__ == "__main__":
    unittest.main()
