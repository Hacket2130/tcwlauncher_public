(function () {
  const apiBaseUrl = "https://api.tcwa3.co.uk";
  const tokenStorageKey = "tcwa3_profile_access_token";
  const pendingAuthStorageKey = "tcwa3_profile_pending_steam_auth";
  const authCard = document.getElementById("profileAuthCard");
  const authTitle = document.getElementById("profileAuthTitle");
  const introText = document.getElementById("profileIntroText");
  const authCopy = document.getElementById("profileAuthCopy");
  const loginButton = document.getElementById("profileLoginButton");
  const refreshButton = document.getElementById("profileRefreshButton");
  const logoutButton = document.getElementById("profileLogoutButton");
  const statusText = document.getElementById("profileStatus");
  const profileContent = document.getElementById("profileContent");
  const rosterButton = document.getElementById("profileRosterButton");
  const bioInput = document.getElementById("profileBioInput");
  const bioCount = document.getElementById("profileBioCount");
  const bioSaveButton = document.getElementById("profileBioSaveButton");
  const bioStatus = document.getElementById("profileBioStatus");
  const profilePublicToggle = document.getElementById("profilePublicToggle");
  const profileAvatarImage = document.getElementById("profileAvatarImage");
  const profileAvatarSelect = document.getElementById("profileAvatarSelect");
  const communitySortSelect = document.getElementById("communitySortSelect");
  const communityUnitSelect = document.getElementById("communityUnitSelect");
  const communityProfileList = document.getElementById("communityProfileList");
  const recentPlayersCard = document.getElementById("recentPlayersCard");
  const recentProfileList = document.getElementById("recentProfileList");
  const maxBioChars = 600;
  const defaultAvatarUrl = "/assets/default-profile-avatar.png";
  let activePollTimer = 0;
  let activePollDeviceCode = "";
  let avatarCatalog = [];
  let currentAvatarId = "tcw-standard";

  function setStatus(text, state) {
    statusText.textContent = text;
    statusText.dataset.state = state || "";
  }

  function storedToken() {
    return localStorage.getItem(tokenStorageKey) || "";
  }

  function setStoredToken(token) {
    if (token) {
      localStorage.setItem(tokenStorageKey, token);
    } else {
      localStorage.removeItem(tokenStorageKey);
    }
  }

  function storedPendingAuth() {
    try {
      const pending = JSON.parse(localStorage.getItem(pendingAuthStorageKey) || "{}");
      if (!pending.device_code || !pending.expires_at || Number(pending.expires_at) <= Date.now()) {
        localStorage.removeItem(pendingAuthStorageKey);
        return null;
      }
      return pending;
    } catch (_error) {
      localStorage.removeItem(pendingAuthStorageKey);
      return null;
    }
  }

  function setStoredPendingAuth(auth) {
    localStorage.setItem(pendingAuthStorageKey, JSON.stringify({
      device_code: auth.device_code,
      user_code: auth.user_code || "",
      verification_uri: auth.verification_uri || "",
      interval: Number(auth.interval || 3),
      expires_at: Date.now() + Math.max(30, Number(auth.expires_in || 600)) * 1000,
    }));
  }

  function clearStoredPendingAuth() {
    localStorage.removeItem(pendingAuthStorageKey);
  }

  async function apiRequest(path, options) {
    const response = await fetch(new URL(path, apiBaseUrl), {
      cache: "no-store",
      ...options,
      headers: {
        ...(options && options.headers ? options.headers : {}),
      },
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.message || data.error || `HTTP ${response.status}`);
      error.code = data.error || "";
      error.status = response.status;
      throw error;
    }
    return data;
  }

  async function authRequest(path, token, options) {
    return apiRequest(path, {
      ...options,
      headers: {
        "Authorization": `Bearer ${token}`,
        ...(options && options.headers ? options.headers : {}),
      },
    });
  }

  async function loadAvatarCatalog() {
    try {
      const data = await apiRequest("/v1/avatars", { method: "GET" });
      avatarCatalog = Array.isArray(data.avatars) ? data.avatars : [];
    } catch (_error) {
      avatarCatalog = [];
    }
    if (!avatarCatalog.length) {
      avatarCatalog = [{ id: "tcw-standard", name: "TCW Standard", url: defaultAvatarUrl }];
    }
    renderAvatarOptions(currentAvatarId);
  }

  async function startSteamLogin() {
    clearPollTimer();
    clearStoredPendingAuth();
    activePollDeviceCode = "";
    loginButton.disabled = true;
    setStatus("Opening Steam sign-in...", "");
    const steamWindow = window.open("", "_blank");
    try {
      const auth = await apiRequest("/v1/auth/device/start", { method: "POST" });
      if (!auth.device_code || !auth.verification_uri) {
        throw new Error("Steam sign-in did not return a valid code.");
      }
      setStoredPendingAuth(auth);
      if (steamWindow) {
        steamWindow.opener = null;
        steamWindow.location.href = auth.verification_uri;
      } else {
        window.location.href = auth.verification_uri;
        return;
      }
      setStatus("Steam opened in a new tab. Finish sign-in there, then this page will update automatically.", "");
      pollForToken(auth.device_code, Number(auth.interval || 3), Date.now() + Math.max(30, Number(auth.expires_in || 600)) * 1000);
    } catch (error) {
      if (steamWindow) {
        steamWindow.close();
      }
      loginButton.disabled = false;
      setStatus(`Could not start Steam sign-in: ${error.message}`, "error");
    }
  }

  function pollForToken(deviceCode, intervalSeconds, expiresAt) {
    clearPollTimer();
    activePollDeviceCode = deviceCode;
    const intervalMs = Math.max(1500, intervalSeconds * 1000);
    let networkRetries = 0;
    async function poll() {
      if (activePollDeviceCode !== deviceCode) {
        return;
      }
      if (Date.now() > expiresAt) {
        clearStoredPendingAuth();
        loginButton.disabled = false;
        setStatus("Steam sign-in expired. Press Login With Steam to try again.", "error");
        return;
      }
      try {
        const data = await apiRequest("/v1/auth/device/token", {
          method: "POST",
          // Keep this as a simple CORS request so Cloudflare does not need an
          // OPTIONS preflight before the player has a signed-in session.
          body: JSON.stringify({ device_code: deviceCode }),
        });
        if (data.access_token) {
          clearStoredPendingAuth();
          setStoredToken(data.access_token);
          setStatus("Steam connected. Loading your TCWA3 profile...", "ok");
          loginButton.disabled = false;
          renderSignedInControls(true);
          await loadProfile();
          return;
        }
      } catch (error) {
        if (String(error.message || "").includes("pending") || String(error.message || "").includes("HTTP 202")) {
          activePollTimer = window.setTimeout(poll, intervalMs);
          return;
        }
        if (error.code === "already_consumed" || String(error.message || "").includes("already_consumed")) {
          clearStoredPendingAuth();
          activePollDeviceCode = "";
          loginButton.disabled = false;
          setStatus("That Steam sign-in link was already used. Press Login With Steam to start a fresh sign-in.", "error");
          return;
        }
        if (isTransientFetchError(error) && networkRetries < 8) {
          networkRetries += 1;
          setStatus("Waiting for Steam confirmation. Reconnecting to the TCWA3 backend...", "");
          activePollTimer = window.setTimeout(poll, Math.min(10000, intervalMs + networkRetries * 1000));
          return;
        }
        loginButton.disabled = false;
        setStatus(`Steam sign-in could not complete: ${error.message}`, "error");
        return;
      }
      activePollTimer = window.setTimeout(poll, intervalMs);
    }
    activePollTimer = window.setTimeout(poll, intervalMs);
  }

  function isTransientFetchError(error) {
    const message = String(error && error.message ? error.message : error).toLowerCase();
    return message.includes("failed to fetch") || message.includes("networkerror") || message.includes("load failed");
  }

  function resumePendingSteamLogin(fromSteamReturn) {
    const pending = storedPendingAuth();
    if (!pending || storedToken()) {
      return false;
    }
    loginButton.disabled = true;
    const remaining = Number(pending.expires_at) - Date.now();
    setStatus(
      fromSteamReturn ? "Steam verified. Finalising your TCWA3 profile sign-in..." : "Waiting for Steam sign-in to finish...",
      fromSteamReturn ? "ok" : ""
    );
    pollForToken(pending.device_code, Number(pending.interval || 3), Date.now() + Math.max(3000, remaining));
    return true;
  }

  function handleSteamReturnFromQuery() {
    const params = new URLSearchParams(window.location.search);
    const result = params.get("steam");
    if (!result) {
      return "";
    }
    params.delete("steam");
    params.delete("user_code");
    const replacement = `${window.location.pathname}${params.toString() ? `?${params.toString()}` : ""}${window.location.hash || ""}`;
    window.history.replaceState({}, "", replacement);
    if (result === "verified") {
      return "verified";
    }
    clearStoredPendingAuth();
    setStatus("Steam sign-in failed. Please try again.", "error");
    return "failed";
  }

  function clearPollTimer() {
    if (activePollTimer) {
      window.clearTimeout(activePollTimer);
      activePollTimer = 0;
    }
  }

  async function loadProfile() {
    const token = storedToken();
    if (!token) {
      clearPollTimer();
      renderSignedInControls(false);
      profileContent.hidden = true;
      setStatus("Not signed in.", "");
      return;
    }
    refreshButton.disabled = true;
    try {
      const data = await authRequest("/v1/me", token, { method: "GET" });
      if (!data.profile) {
        throw new Error("Profile was not found.");
      }
      renderProfile(data.profile);
      renderSignedInControls(true);
      setStatus("Profile loaded from the TCWA3 backend.", "ok");
      loadRecentProfiles();
    } catch (error) {
      setStoredToken("");
      profileContent.hidden = true;
      renderSignedInControls(false);
      setStatus("Your session expired. Sign in with Steam again to view your profile.", "error");
    } finally {
      refreshButton.disabled = false;
    }
  }

  async function signOut() {
    clearPollTimer();
    clearStoredPendingAuth();
    const token = storedToken();
    setStoredToken("");
    if (token) {
      authRequest("/v1/auth/logout", token, { method: "POST" }).catch(() => {});
    }
    profileContent.hidden = true;
    renderSignedInControls(false);
    setStatus("Signed out on this device.", "");
  }

  function renderSignedInControls(isSignedIn) {
    authTitle.textContent = isSignedIn ? "Connected to Steam" : "Connect Steam";
    if (introText) {
      introText.textContent = isSignedIn
        ? "Signed in with Steam to view the same backend profile used by your launcher: level, credits, deployments, combat stats, and achievements."
        : "Sign in with Steam to view the same backend profile used by your launcher: level, credits, deployments, combat stats, and achievements.";
    }
    if (authCopy) {
      authCopy.textContent = isSignedIn
        ? "Steam has verified your SteamID64. Your TCWA3 stats are stored on the TCW backend and follow you between PCs."
        : "We use Steam only to verify your SteamID64. Your TCWA3 stats stay on the TCW backend and follow you between PCs.";
    }
    loginButton.hidden = isSignedIn;
    loginButton.disabled = false;
    refreshButton.hidden = !isSignedIn;
    logoutButton.hidden = !isSignedIn;
    authCard.classList.toggle("profile-auth-card-signed-in", isSignedIn);
  }

  function renderProfile(profile) {
    profileContent.hidden = false;
    currentAvatarId = profile.avatar_id || "tcw-standard";
    renderAvatarOptions(currentAvatarId);
    if (profileAvatarImage) {
      profileAvatarImage.src = profile.avatar_url || defaultAvatarUrl;
      profileAvatarImage.alt = `${profile.display_name || "Clone trooper"} profile portrait`;
    }
    setText("profileName", profile.display_name || "Clone trooper");
    setText("profileSteamId", profile.steam_id || "-");
    setText("profileRank", profile.rank || "Unassigned");
    setText("profileUnit", profile.unit || "Unassigned");
    setText("profileVerified", profile.verified ? "Verified" : "Pending");
    setText("profileRosterState", profile.rostered ? "Linked to the TCW roster." : "Not yet linked to the TCW roster.");
    if (rosterButton) {
      rosterButton.textContent = profile.rostered ? "Refresh Roster Link" : "Check TCW Roster";
    }
    if (bioInput) {
      bioInput.value = profile.bio || "";
      updateBioCount();
    }
    if (profilePublicToggle) {
      profilePublicToggle.checked = profile.profile_public !== false;
    }
    setText("profileLevel", `Level ${number(profile.level)}`);
    setText("profileCredits", `${number(profile.credits)} Credits`);
    setText("profileKills", number(profile.kills));
    setText("profileDroidKills", number(profile.droid_kills));
    setText("profileDeaths", number(profile.deaths));
    setText("profileMissions", number(profile.missions));
    setText("profilePlaytime", playtime(profile.playtime_seconds));
    setText("profileGeonosis", number(profile.geonosis_missions));

    const levelStart = Number(profile.current_level_xp || 0);
    const levelEnd = Number(profile.next_level_xp || 500);
    const xp = Number(profile.xp || 0);
    const span = Math.max(1, levelEnd - levelStart);
    const inLevel = Math.max(0, xp - levelStart);
    const percent = Math.max(0, Math.min(100, (inLevel / span) * 100));
    document.getElementById("profileXpBar").style.width = `${percent}%`;
    setText("profileXpText", `${number(inLevel)} / ${number(span)} XP (${number(xp)} total)`);

    renderAchievements(Array.isArray(profile.achievements) ? profile.achievements : []);
    renderCampaigns(Array.isArray(profile.campaigns) ? profile.campaigns : []);
  }

  async function saveProfileBio() {
    const token = storedToken();
    if (!token) {
      setBioStatus("Sign in with Steam before saving your bio.", "error");
      return;
    }
    bioSaveButton.disabled = true;
    try {
      const data = await authRequest("/v1/me", token, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        bio: bioInput.value,
        profile_public: profilePublicToggle.checked,
        avatar_id: profileAvatarSelect ? profileAvatarSelect.value : currentAvatarId,
      }),
      });
      renderProfile(data.profile);
      setBioStatus("Bio saved to your TCWA3 profile.", "ok");
      loadCommunityProfiles();
    } catch (error) {
      setBioStatus(`Could not save bio: ${error.message}`, "error");
    } finally {
      bioSaveButton.disabled = false;
    }
  }

  async function checkRosterLink() {
    const token = storedToken();
    if (!token) {
      setStatus("Sign in with Steam before checking the TCW roster.", "error");
      return;
    }
    rosterButton.disabled = true;
    setStatus("Checking the TCW roster for your SteamID64...", "");
    try {
      const data = await authRequest("/v1/me/roster-link", token, { method: "POST" });
      renderProfile(data.profile);
      setStatus(data.profile && data.profile.rostered ? "TCW roster link found." : "No TCW roster entry found for this SteamID64 yet.", data.profile && data.profile.rostered ? "ok" : "");
      loadCommunityProfiles();
    } catch (error) {
      setStatus(`Could not check roster: ${error.message}`, "error");
    } finally {
      rosterButton.disabled = false;
    }
  }

  async function loadCommunityProfiles() {
    if (!communityProfileList) {
      return;
    }
    communityProfileList.replaceChildren(emptyMessage("Loading community profiles..."));
    const params = new URLSearchParams();
    params.set("sort", communitySortSelect.value || "active");
    if (communityUnitSelect.value) {
      params.set("unit", communityUnitSelect.value);
    }
    try {
      const data = await apiRequest(`/v1/profiles?${params.toString()}`, { method: "GET" });
      renderUnitOptions(Array.isArray(data.units) ? data.units : []);
      renderProfileCards(communityProfileList, Array.isArray(data.profiles) ? data.profiles : [], "No public trooper profiles are available yet.");
    } catch (error) {
      communityProfileList.replaceChildren(emptyMessage(`Could not load profiles: ${error.message}`));
    }
  }

  async function loadRecentProfiles() {
    const token = storedToken();
    if (!recentPlayersCard || !recentProfileList || !token) {
      if (recentPlayersCard) {
        recentPlayersCard.hidden = true;
      }
      return;
    }
    recentPlayersCard.hidden = false;
    recentProfileList.replaceChildren(emptyMessage("Checking recent squadmates..."));
    try {
      const data = await authRequest("/v1/me/recent", token, { method: "GET" });
      renderProfileCards(recentProfileList, Array.isArray(data.profiles) ? data.profiles : [], "Recent squadmates will appear after official server sessions are reported.");
    } catch (_error) {
      recentPlayersCard.hidden = true;
    }
  }

  function renderUnitOptions(units) {
    const selected = communityUnitSelect.value;
    const currentOptions = new Set(Array.from(communityUnitSelect.options).map((option) => option.value));
    units.forEach((unit) => {
      if (unit && !currentOptions.has(unit)) {
        const option = document.createElement("option");
        option.value = unit;
        option.textContent = unit;
        communityUnitSelect.appendChild(option);
      }
    });
    communityUnitSelect.value = selected;
  }

  function renderProfileCards(parent, profiles, emptyText) {
    parent.replaceChildren();
    if (!profiles.length) {
      parent.appendChild(emptyMessage(emptyText));
      return;
    }
    profiles.forEach((profile) => {
      const card = document.createElement("article");
      card.className = "community-profile-card";

      const avatar = document.createElement("img");
      avatar.className = "community-profile-avatar";
      avatar.src = profile.avatar_url || defaultAvatarUrl;
      avatar.alt = `${profile.display_name || "Clone trooper"} profile portrait`;

      const content = document.createElement("div");
      content.className = "community-profile-card-body";

      const heading = document.createElement("div");
      heading.className = "community-profile-heading";
      const title = document.createElement("h3");
      title.textContent = profile.display_name || "Clone trooper";
      const unit = document.createElement("span");
      unit.textContent = profile.unit || "Unassigned";
      heading.append(title, unit);

      const meta = document.createElement("div");
      meta.className = "community-profile-meta";

      addProfileTag(meta, profile.rank || "Unassigned");
      addProfileTag(meta, `Level ${number(profile.level)}`);
      addProfileTag(meta, `${number(profile.achievement_count)} awards`);
      if (profile.latest_campaign) {
        addProfileTag(meta, profile.latest_campaign);
      }

      const bio = document.createElement("p");
      bio.className = "community-profile-bio";
      bio.textContent = profile.bio || "No character bio yet.";

      const stats = document.createElement("dl");
      stats.className = "community-profile-stats";
      addMiniStat(stats, "Deployments", number(profile.missions));
      addMiniStat(stats, "Droids", number(profile.droid_kills || profile.kills));
      addMiniStat(stats, "Playtime", playtime(profile.playtime_seconds));

      content.append(heading, meta, bio, stats);
      card.append(avatar, content);
      parent.appendChild(card);
    });
  }

  function renderAvatarOptions(selectedId) {
    if (!profileAvatarSelect) {
      return;
    }
    const selected = selectedId || profileAvatarSelect.value || "tcw-standard";
    currentAvatarId = selected;
    profileAvatarSelect.replaceChildren();
    avatarCatalog.forEach((avatar) => {
      const option = document.createElement("option");
      option.value = avatar.id || "tcw-standard";
      option.textContent = avatar.name || "TCW Portrait";
      profileAvatarSelect.appendChild(option);
    });
    profileAvatarSelect.value = selected;
    if (!profileAvatarSelect.value && profileAvatarSelect.options.length) {
      profileAvatarSelect.selectedIndex = 0;
    }
  }

  function addMiniStat(parent, label, value) {
    const item = document.createElement("div");
    const dt = document.createElement("dt");
    dt.textContent = label;
    const dd = document.createElement("dd");
    dd.textContent = value;
    item.append(dt, dd);
    parent.appendChild(item);
  }

  function addProfileTag(parent, value) {
    const tag = document.createElement("span");
    tag.textContent = value;
    parent.appendChild(tag);
  }

  function emptyMessage(text) {
    const empty = document.createElement("p");
    empty.className = "asset-empty";
    empty.textContent = text;
    return empty;
  }

  function updateBioCount() {
    if (bioCount && bioInput) {
      bioCount.textContent = `${bioInput.value.length} / ${maxBioChars}`;
    }
  }

  function setBioStatus(text, state) {
    bioStatus.textContent = text;
    bioStatus.dataset.state = state || "";
  }

  function renderAchievements(achievements) {
    const list = document.getElementById("profileAchievements");
    list.replaceChildren();
    setText("profileAchievementCount", `${achievements.length} unlocked`);
    if (!achievements.length) {
      const empty = document.createElement("p");
      empty.className = "asset-empty";
      empty.textContent = "No achievements unlocked yet. Join official operations to start building your record.";
      list.appendChild(empty);
      return;
    }
    achievements.forEach((achievement) => {
      const card = document.createElement("article");
      card.className = "web-profile-achievement";
      const title = document.createElement("h3");
      title.textContent = achievement.name || achievement.id || "Achievement";
      const body = document.createElement("p");
      body.textContent = achievement.description || "";
      const date = document.createElement("span");
      date.textContent = achievement.unlocked_at ? `Unlocked ${formatDate(achievement.unlocked_at)}` : "Unlocked";
      card.append(title, body, date);
      list.appendChild(card);
    });
  }

  function renderCampaigns(campaigns) {
    const list = document.getElementById("profileCampaigns");
    if (!list) {
      return;
    }
    list.replaceChildren();
    setText("profileCampaignCount", `${campaigns.length} campaign${campaigns.length === 1 ? "" : "s"}`);
    if (!campaigns.length) {
      const empty = document.createElement("p");
      empty.className = "asset-empty";
      empty.textContent = "No completed campaign deployments have been reported yet.";
      list.appendChild(empty);
      return;
    }
    campaigns.slice(0, 6).forEach((campaign) => {
      const card = document.createElement("article");
      card.className = "web-profile-campaign";

      const header = document.createElement("div");
      header.className = "web-profile-campaign-header";
      const title = document.createElement("h3");
      title.textContent = campaign.name || "TCWA3 Campaign";
      const meta = document.createElement("span");
      const deploymentCount = Number(campaign.deployment_count || (Array.isArray(campaign.deployments) ? campaign.deployments.length : 0));
      const planet = campaign.planet ? `${campaign.planet} · ` : "";
      meta.textContent = `${planet}${deploymentCount} deployment${deploymentCount === 1 ? "" : "s"}`;
      header.append(title, meta);

      const deployments = document.createElement("ul");
      deployments.className = "web-profile-deployments";
      const rows = Array.isArray(campaign.deployments) ? campaign.deployments : [];
      rows.slice(0, 5).forEach((deployment) => {
        const item = document.createElement("li");
        const mission = document.createElement("strong");
        mission.textContent = deployment.mission_name || "Official deployment";
        const details = document.createElement("span");
        const awards = Array.isArray(deployment.awards) && deployment.awards.length
          ? `Awards: ${deployment.awards.map((award) => award.name || award.id || "Award").join(", ")}`
          : "No new awards";
        details.textContent = `${formatDate(deployment.completed_at)} · ${awards}`;
        item.append(mission, details);
        deployments.appendChild(item);
      });
      if (!rows.length) {
        const item = document.createElement("li");
        const empty = document.createElement("span");
        empty.textContent = "Deployments will appear here after official servers report completed missions.";
        item.appendChild(empty);
        deployments.appendChild(item);
      }
      card.append(header, deployments);
      list.appendChild(card);
    });
  }

  function setText(id, value) {
    const element = document.getElementById(id);
    if (element) {
      element.textContent = String(value);
    }
  }

  function number(value) {
    return new Intl.NumberFormat("en-GB").format(Number(value || 0));
  }

  function playtime(seconds) {
    const hours = Math.floor(Number(seconds || 0) / 3600);
    if (hours >= 1) {
      return `${number(hours)}h`;
    }
    const minutes = Math.floor(Number(seconds || 0) / 60);
    return `${number(minutes)}m`;
  }

  function formatDate(timestamp) {
    const numeric = Number(timestamp || 0);
    const date = new Date(numeric > 10_000_000_000 ? numeric : numeric * 1000);
    if (!Number.isFinite(date.getTime())) {
      return "";
    }
    return date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  }

  loginButton.addEventListener("click", startSteamLogin);
  refreshButton.addEventListener("click", () => loadProfile());
  logoutButton.addEventListener("click", signOut);
  rosterButton.addEventListener("click", checkRosterLink);
  bioInput.addEventListener("input", updateBioCount);
  bioSaveButton.addEventListener("click", saveProfileBio);
  profilePublicToggle.addEventListener("change", saveProfileBio);
  if (profileAvatarSelect) {
    profileAvatarSelect.addEventListener("change", () => {
      const avatar = avatarCatalog.find((item) => item.id === profileAvatarSelect.value);
      currentAvatarId = profileAvatarSelect.value || "tcw-standard";
      if (profileAvatarImage && avatar) {
        profileAvatarImage.src = avatar.url || defaultAvatarUrl;
      }
    });
  }
  communitySortSelect.addEventListener("change", loadCommunityProfiles);
  communityUnitSelect.addEventListener("change", loadCommunityProfiles);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      if (storedToken()) {
        loadProfile();
      } else {
        resumePendingSteamLogin(false);
      }
    }
  });
  window.addEventListener("focus", () => {
    if (storedToken()) {
      loadProfile();
    } else {
      resumePendingSteamLogin(false);
    }
  });
  window.addEventListener("storage", (event) => {
    if (event.key === tokenStorageKey && event.newValue) {
      loadProfile();
    }
  });
  updateBioCount();
  loadAvatarCatalog();
  loadCommunityProfiles();
  const returnedFromSteam = handleSteamReturnFromQuery();
  if (storedToken()) {
    clearStoredPendingAuth();
    loadProfile();
  } else if (returnedFromSteam === "failed") {
    renderSignedInControls(false);
    profileContent.hidden = true;
  } else if (!resumePendingSteamLogin(returnedFromSteam === "verified")) {
    loadProfile();
  }
})();
