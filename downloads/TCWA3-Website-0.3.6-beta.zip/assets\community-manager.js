(function () {
  const apiBaseUrl = "https://api.tcwa3.co.uk";
  const storageKey = "tcwa3_community_manager_key";
  const unlockForm = document.getElementById("managerUnlockForm");
  const unlockInput = document.getElementById("managerUnlockToken");
  const unlockMessage = document.getElementById("managerUnlockMessage");
  const loginVeil = document.getElementById("managerLoginVeil");
  const tokenInput = document.getElementById("managerToken");
  const rememberKey = document.getElementById("rememberManagerKey");
  const lockButton = document.getElementById("lockManager");
  const loadButton = document.getElementById("loadInventory");
  const audioForm = document.getElementById("audioUploadForm");
  const themeForm = document.getElementById("themeUploadForm");
  const saveThemeMetadataButton = document.getElementById("saveThemeMetadata");
  const themeDropZone = document.getElementById("themeDropZone");
  const themeFolderInput = document.getElementById("themeFolderInput");
  const audioInventory = document.getElementById("audioInventory");
  const themeInventory = document.getElementById("themeInventory");
  const audioBinInventory = document.getElementById("audioBinInventory");
  const themeBinInventory = document.getElementById("themeBinInventory");
  const eventForm = document.getElementById("eventForm");
  const eventInventory = document.getElementById("eventInventory");
  const newEventButton = document.getElementById("newEventButton");
  const cancelEventEdit = document.getElementById("cancelEventEdit");
  const message = document.getElementById("assetMessage");
  let maxFileBytes = 50 * 1024 * 1024;
  let currentEvents = [];
  let managerUnlocked = false;

  function setMessage(text, state) {
    message.textContent = text;
    message.dataset.state = state || "";
  }

  function setUnlockMessage(text, state) {
    if (!unlockMessage) {
      return;
    }
    unlockMessage.textContent = text;
    unlockMessage.dataset.state = state || "";
  }

  function lockManager(clearSaved) {
    managerUnlocked = false;
    tokenInput.value = "";
    document.body.classList.add("manager-locked");
    document.body.classList.remove("manager-unlocked");
    if (loginVeil) {
      loginVeil.hidden = false;
    }
    if (clearSaved) {
      localStorage.removeItem(storageKey);
      if (rememberKey) {
        rememberKey.checked = false;
      }
    }
  }

  async function unlockManager(token, remember, quiet) {
    const cleaned = String(token || "").trim();
    if (!cleaned) {
      throw new Error("Enter the Community Manager key first.");
    }
    tokenInput.value = cleaned;
    if (rememberKey) {
      rememberKey.checked = Boolean(remember);
    }
    localStorage.removeItem(storageKey);
    setUnlockMessage(quiet ? "Checking saved manager key..." : "Checking manager key...", "");
    const data = await apiRequest("/v1/admin/assets", { method: "GET" }, { skipRelock: true });
    if (remember) {
      localStorage.setItem(storageKey, cleaned);
    }
    managerUnlocked = true;
    document.body.classList.remove("manager-locked");
    document.body.classList.add("manager-unlocked");
    if (loginVeil) {
      loginVeil.hidden = true;
    }
    applyInventory(data);
    setUnlockMessage("");
    setMessage("Community Manager unlocked.", "ok");
  }

  function managerToken() {
    const token = tokenInput.value.trim();
    if (!token) {
      throw new Error("Enter the Community Manager key first.");
    }
    if (rememberKey.checked) {
      localStorage.setItem(storageKey, token);
    } else {
      localStorage.removeItem(storageKey);
    }
    return token;
  }

  async function apiRequest(path, options, meta) {
    const token = managerToken();
    const response = await fetch(new URL(path, apiBaseUrl), {
      cache: "no-store",
      ...options,
      headers: {
        "Authorization": `Bearer ${token}`,
        ...(options && options.headers ? options.headers : {}),
      },
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      if ((response.status === 401 || response.status === 403) && !(meta && meta.skipRelock)) {
        lockManager(true);
        setUnlockMessage("That manager key was not accepted. Please enter the current key.", "error");
      }
      throw new Error(data.message || data.error || `HTTP ${response.status}`);
    }
    return data;
  }

  function fileToPayload(file) {
    if (!file) {
      return Promise.reject(new Error("Choose a file first."));
    }
    if (file.size > maxFileBytes) {
      return Promise.reject(new Error(`File is too large. Maximum size is ${formatBytes(maxFileBytes)}.`));
    }
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.addEventListener("load", () => {
        resolve({
          name: file.name,
          size: file.size,
          type: file.type,
          data_base64: reader.result,
        });
      });
      reader.addEventListener("error", () => reject(new Error("Could not read the selected file.")));
      reader.readAsDataURL(file);
    });
  }

  async function loadInventory() {
    setMessage("Loading current audio, theme, and event assets...", "");
    const data = await apiRequest("/v1/admin/assets", { method: "GET" });
    applyInventory(data);
    setMessage("Current assets and events loaded.", "ok");
  }

  async function uploadAudio(event) {
    event.preventDefault();
    setMessage("Uploading audio asset...", "");
    const file = document.getElementById("audioFile").files[0];
    const filePayload = await fileToPayload(file);
    const data = await apiRequest("/v1/admin/assets/upload", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        target: "audio",
        category: document.getElementById("audioCategory").value,
        file: filePayload,
      }),
    });
    applyInventory(data.inventory);
    audioForm.reset();
    setMessage("Audio uploaded. Launchers will see it on the next manifest refresh.", "ok");
  }

  async function uploadTheme(event) {
    event.preventDefault();
    setMessage("Uploading theme artwork...", "");
    const file = document.getElementById("themeFile").files[0];
    const filePayload = await fileToPayload(file);
    await saveThemeMetadata({ silent: true });
    const data = await apiRequest("/v1/admin/assets/upload", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        target: "theme",
        theme_id: document.getElementById("themeId").value,
        theme_name: document.getElementById("themeName").value,
        asset_type: document.getElementById("themeAssetType").value,
        file: filePayload,
      }),
    });
    applyInventory(data.inventory);
    document.getElementById("themeFile").value = "";
    setMessage("Theme artwork uploaded. Launchers will see it on the next manifest refresh.", "ok");
  }

  function themeMetadataPayload() {
    return {
      target: "theme_manifest",
      theme_id: document.getElementById("themeId").value,
      theme_name: document.getElementById("themeName").value,
      description: document.getElementById("themeDescription").value,
      accent_color: document.getElementById("themeAccentColor").value,
      panel_color: document.getElementById("themePanelColor").value,
      text_color: document.getElementById("themeTextColor").value,
    };
  }

  async function saveThemeMetadata(options) {
    const payload = themeMetadataPayload();
    if (!payload.theme_id.trim()) {
      throw new Error("Give the theme a stable id first.");
    }
    const data = await apiRequest("/v1/admin/assets/upload", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    applyInventory(data.inventory);
    if (!(options && options.silent)) {
      setMessage("Theme details saved. Launchers will see the updated theme manifest on refresh.", "ok");
    }
    return data;
  }

  function fileToText(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.addEventListener("load", () => resolve(String(reader.result || "")));
      reader.addEventListener("error", () => reject(new Error("Could not read theme.json.")));
      reader.readAsText(file);
    });
  }

  function localThemeSlug(value) {
    return String(value || "theme")
      .toLowerCase()
      .replace(/[^a-z0-9_-]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 64) || `theme-${Date.now()}`;
  }

  function themeRootName(files) {
    const first = files.find((file) => file.webkitRelativePath);
    if (first) {
      return first.webkitRelativePath.split("/")[0];
    }
    return "";
  }

  function isThemeImage(file) {
    return /\.(png|jpe?g|webp)$/i.test(file.name || "");
  }

  function themeAssetTypeFromFile(file) {
    const path = `${file.webkitRelativePath || ""}/${file.name || ""}`.toLowerCase();
    return path.includes("logo") || path.includes("mark") || path.includes("icon") ? "logo" : "background";
  }

  async function uploadThemeFolder(fileList) {
    const files = Array.from(fileList || []);
    const imageFiles = files.filter(isThemeImage);
    if (!imageFiles.length) {
      throw new Error("Drop or choose a folder with PNG, JPG, JPEG, or WEBP files.");
    }
    const root = themeRootName(files);
    const manifestFile = files.find((file) => /(^|\/)theme\.json$/i.test(file.webkitRelativePath || file.name));
    let manifest = {};
    if (manifestFile) {
      try {
        const parsed = JSON.parse(await fileToText(manifestFile));
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          manifest = parsed;
        }
      } catch (error) {
        throw new Error(`theme.json could not be read: ${error.message}`);
      }
    }
    const themeId = localThemeSlug(document.getElementById("themeId").value || manifest.id || root);
    document.getElementById("themeId").value = themeId;
    document.getElementById("themeName").value = document.getElementById("themeName").value || manifest.name || root.replace(/[-_]+/g, " ");
    document.getElementById("themeDescription").value = document.getElementById("themeDescription").value || manifest.description || "";
    document.getElementById("themeAccentColor").value = document.getElementById("themeAccentColor").value || manifest.accent_color || "";
    document.getElementById("themePanelColor").value = document.getElementById("themePanelColor").value || manifest.panel_color || "";
    document.getElementById("themeTextColor").value = document.getElementById("themeTextColor").value || manifest.text_color || "";

    setMessage(`Uploading ${imageFiles.length} theme image${imageFiles.length === 1 ? "" : "s"}...`, "");
    await saveThemeMetadata({ silent: true });
    let uploaded = 0;
    for (const file of imageFiles) {
      const filePayload = await fileToPayload(file);
      const data = await apiRequest("/v1/admin/assets/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          target: "theme",
          theme_id: themeId,
          theme_name: document.getElementById("themeName").value,
          asset_type: themeAssetTypeFromFile(file),
          file: filePayload,
        }),
      });
      uploaded += 1;
      applyInventory(data.inventory);
      setMessage(`Uploaded ${uploaded} of ${imageFiles.length} theme images...`, "");
    }
    setMessage(`Theme folder imported. ${uploaded} image${uploaded === 1 ? "" : "s"} are now available to the launcher.`, "ok");
  }

  async function deleteAsset(payload, label) {
    if (!confirm(`Move ${label} to the private bin? It will stop being hosted immediately.`)) {
      return;
    }
    setMessage("Moving asset to private bin...", "");
    const data = await apiRequest("/v1/admin/assets/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    applyInventory(data.inventory);
    setMessage("Asset moved to the private bin and removed from public hosting.", "ok");
  }

  function applyInventory(data) {
    maxFileBytes = Number(data && data.limits && data.limits.max_file_bytes) || maxFileBytes;
    renderAudio(data && data.audio ? data.audio : {});
    renderThemes(Array.isArray(data && data.themes) ? data.themes : []);
    renderBin(data && data.bin ? data.bin : {});
    currentEvents = Array.isArray(data && data.events) ? data.events : currentEvents;
    renderEvents(currentEvents);
  }

  function slugFromTitle(value) {
    const slug = String(value || "event")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 72);
    return slug || `event-${Date.now()}`;
  }

  function formatLocalDate(value) {
    if (!value) {
      return "";
    }
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) {
      return "";
    }
    const pad = (number) => String(number).padStart(2, "0");
    return [
      date.getFullYear(),
      pad(date.getMonth() + 1),
      pad(date.getDate()),
    ].join("-") + `T${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }

  function isoFromLocalInput(value) {
    if (!value) {
      return "";
    }
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) {
      return "";
    }
    return date.toISOString();
  }

  function eventStatus(event) {
    if (!event.active) {
      return "Inactive";
    }
    const nowTime = Date.now();
    const start = event.start_at ? new Date(event.start_at).getTime() : 0;
    const end = event.end_at ? new Date(event.end_at).getTime() : 0;
    if (Number.isFinite(start) && start > nowTime) {
      return "Scheduled";
    }
    if (Number.isFinite(end) && end > 0 && end <= nowTime) {
      return "Ended";
    }
    return "Live";
  }

  function resetEventForm() {
    if (!eventForm) {
      return;
    }
    eventForm.reset();
    document.getElementById("eventId").value = "";
    document.getElementById("eventPriority").value = "0";
    document.getElementById("eventXpBonus").value = "0";
    document.getElementById("eventEffect").value = "glow";
    document.getElementById("eventAccentColor").value = "#d9b36c";
    document.getElementById("eventBackgroundColor").value = "#070b12";
    document.getElementById("eventActive").checked = true;
  }

  function readEventForm() {
    const title = document.getElementById("eventTitle").value.trim();
    if (!title) {
      throw new Error("Give the event a title first.");
    }
    const id = document.getElementById("eventId").value || slugFromTitle(title);
    return {
      id,
      title,
      description: document.getElementById("eventDescription").value.trim(),
      active: document.getElementById("eventActive").checked,
      start_at: isoFromLocalInput(document.getElementById("eventStartAt").value),
      end_at: isoFromLocalInput(document.getElementById("eventEndAt").value),
      priority: Number(document.getElementById("eventPriority").value || 0),
      accent_color: document.getElementById("eventAccentColor").value,
      background_color: document.getElementById("eventBackgroundColor").value,
      effect: document.getElementById("eventEffect").value,
      xp_bonus_percent: Number(document.getElementById("eventXpBonus").value || 0),
    };
  }

  async function saveEventList(events) {
    const data = await apiRequest("/v1/admin/events", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ events }),
    });
    currentEvents = Array.isArray(data.events) ? data.events : [];
    renderEvents(currentEvents);
    return data;
  }

  async function saveEventForm(event) {
    event.preventDefault();
    setMessage("Saving event banner...", "");
    const eventPayload = readEventForm();
    const nextEvents = currentEvents.filter((item) => item.id !== eventPayload.id);
    nextEvents.push(eventPayload);
    await saveEventList(nextEvents);
    resetEventForm();
    setMessage("Event banner saved. The website and launcher will see it on their next refresh.", "ok");
  }

  async function deleteEvent(eventId, label) {
    if (!confirm(`Delete ${label || "this event"} from the live event list?`)) {
      return;
    }
    setMessage("Deleting event banner...", "");
    await saveEventList(currentEvents.filter((event) => event.id !== eventId));
    resetEventForm();
    setMessage("Event banner deleted.", "ok");
  }

  function editEvent(event) {
    document.getElementById("eventId").value = event.id || "";
    document.getElementById("eventTitle").value = event.title || "";
    document.getElementById("eventDescription").value = event.description || "";
    document.getElementById("eventActive").checked = event.active !== false;
    document.getElementById("eventStartAt").value = formatLocalDate(event.start_at);
    document.getElementById("eventEndAt").value = formatLocalDate(event.end_at);
    document.getElementById("eventPriority").value = String(event.priority || 0);
    document.getElementById("eventXpBonus").value = String(event.xp_bonus_percent || 0);
    document.getElementById("eventEffect").value = event.effect || "glow";
    document.getElementById("eventAccentColor").value = /^#[0-9a-f]{6}$/i.test(event.accent_color || "")
      ? event.accent_color
      : "#d9b36c";
    document.getElementById("eventBackgroundColor").value = /^#[0-9a-f]{6}$/i.test(event.background_color || "")
      ? event.background_color
      : "#070b12";
    eventForm.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function renderEvents(events) {
    if (!eventInventory) {
      return;
    }
    eventInventory.replaceChildren();
    if (!Array.isArray(events) || !events.length) {
      eventInventory.appendChild(emptyRow("No event banners have been created yet."));
      return;
    }
    events.forEach((event) => {
      const row = document.createElement("article");
      row.className = "event-row";
      row.style.setProperty("--event-accent", /^#[0-9a-f]{6}$/i.test(event.accent_color || "") ? event.accent_color : "#d9b36c");
      row.style.setProperty("--event-bg", /^#[0-9a-f]{6}$/i.test(event.background_color || "") ? event.background_color : "#070b12");
      const xp = Number(event.xp_bonus_percent || 0);
      row.innerHTML = `
        <div>
          <span class="event-state">${escapeHtml(eventStatus(event))}</span>
          <h3>${escapeHtml(event.title || "Community Event")}</h3>
          <p>${escapeHtml(event.description || "No description set.")}</p>
          <small>${escapeHtml(event.id || "")}${xp > 0 ? ` - +${xp}% XP` : ""}</small>
        </div>
        <button type="button" data-action="edit">Edit</button>
        <button type="button" data-action="delete">Delete</button>
      `;
      row.querySelector('[data-action="edit"]').addEventListener("click", () => editEvent(event));
      row.querySelector('[data-action="delete"]').addEventListener("click", () => deleteEvent(event.id, event.title));
      eventInventory.appendChild(row);
    });
  }

  function renderAudio(categories) {
    audioInventory.replaceChildren();
    const entries = Object.entries(categories);
    if (entries.length === 0) {
      audioInventory.appendChild(emptyRow("No audio assets found."));
      return;
    }
    entries.forEach(([category, detail]) => {
      const group = document.createElement("section");
      group.className = "asset-group";
      group.innerHTML = `<h3>${escapeHtml(categoryTitle(category, detail))}</h3>`;
      const tracks = Array.isArray(detail.tracks) ? detail.tracks : [];
      if (tracks.length === 0) {
        group.appendChild(emptyRow("No MP3s in this folder yet."));
      } else {
        tracks.forEach((track) => {
          const row = document.createElement("div");
          row.className = "asset-row";
          row.innerHTML = `
            <div>
              <strong>${escapeHtml(track.title || track.filename)}</strong>
              <span>${escapeHtml(track.filename || "")}</span>
            </div>
            <button type="button">Delete</button>
          `;
          row.querySelector("button").addEventListener("click", () => {
            deleteAsset({ kind: "audio", category, filename: track.filename }, track.filename);
          });
          group.appendChild(row);
        });
      }
      audioInventory.appendChild(group);
    });
  }

  function renderThemes(themes) {
    themeInventory.replaceChildren();
    if (themes.length === 0) {
      themeInventory.appendChild(emptyRow("No custom theme artwork found."));
      return;
    }
    themes.forEach((theme) => {
      const group = document.createElement("section");
      group.className = "asset-group";
      group.innerHTML = `
        <h3>${escapeHtml(theme.name || theme.id)}</h3>
        <p class="asset-subtle">${escapeHtml(theme.id || "")}</p>
      `;
      if (theme.logo && theme.logo.path) {
        group.appendChild(themeAssetRow(theme, theme.logo, "Logo"));
      } else {
        group.appendChild(emptyRow("No logo uploaded."));
      }
      const backgrounds = Array.isArray(theme.background_assets) ? theme.background_assets : [];
      if (backgrounds.length === 0) {
        group.appendChild(emptyRow("No backgrounds uploaded."));
      } else {
        backgrounds.forEach((asset, index) => {
          group.appendChild(themeAssetRow(theme, asset, `Background ${index + 1}`));
        });
      }
      themeInventory.appendChild(group);
    });
  }

  function themeAssetRow(theme, asset, label) {
    const row = document.createElement("div");
    row.className = "asset-row";
    row.innerHTML = `
      <div>
        <strong>${escapeHtml(label)}</strong>
        <span>${escapeHtml(asset.path || asset.filename || "")}</span>
      </div>
      <a href="${escapeAttribute(asset.url || "#")}" target="_blank" rel="noopener">View</a>
      <button type="button">Delete</button>
    `;
    row.querySelector("button").addEventListener("click", () => {
      deleteAsset({ kind: "theme", theme_id: theme.id, path: asset.path }, asset.path || asset.filename);
    });
    return row;
  }

  function renderBin(bin) {
    const items = Array.isArray(bin.items) ? bin.items : [];
    const audioItems = items.filter((item) => item.kind === "audio");
    const imageItems = items.filter((item) => item.kind === "images");
    renderBinList(audioBinInventory, audioItems, "No audio has been moved to the bin.");
    renderBinList(themeBinInventory, imageItems, "No theme images have been moved to the bin.");
  }

  function renderBinList(container, items, emptyText) {
    if (!container) {
      return;
    }
    container.replaceChildren();
    if (!items.length) {
      container.appendChild(emptyRow(emptyText));
      return;
    }
    items.forEach((item) => {
      const row = document.createElement("div");
      row.className = "asset-row asset-bin-row";
      const cleanup = Number(item.days_until_cleanup || 0);
      row.innerHTML = `
        <div>
          <strong>${escapeHtml(item.filename || "Binned asset")}</strong>
          <span>${escapeHtml(item.github_archive_path || item.bin_path || "")}</span>
          <span>${cleanup > 0 ? `${cleanup} day${cleanup === 1 ? "" : "s"} until backend cleanup` : "Ready for backend cleanup after GitHub archive"}</span>
        </div>
      `;
      container.appendChild(row);
    });
  }

  function emptyRow(text) {
    const row = document.createElement("p");
    row.className = "asset-empty";
    row.textContent = text;
    return row;
  }

  function categoryTitle(category, detail) {
    if (detail && detail.label) {
      return detail.label;
    }
    return String(category || "").replace(/_/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
  }

  function formatBytes(bytes) {
    if (bytes < 1024 * 1024) {
      return `${Math.round(bytes / 1024)} KB`;
    }
    return `${Math.round(bytes / (1024 * 1024))} MB`;
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function escapeAttribute(value) {
    return escapeHtml(value).replace(/"/g, "&quot;");
  }

  const savedToken = localStorage.getItem(storageKey);
  if (savedToken) {
    if (unlockInput) {
      unlockInput.value = savedToken;
    }
    if (rememberKey) {
      rememberKey.checked = true;
    }
    unlockManager(savedToken, true, true).catch((error) => {
      lockManager(true);
      setUnlockMessage(`Saved manager key failed: ${error.message}`, "error");
    });
  }

  if (unlockForm) {
    unlockForm.addEventListener("submit", (event) => {
      event.preventDefault();
      unlockManager(unlockInput.value, rememberKey && rememberKey.checked, false).catch((error) => {
        lockManager(false);
        setUnlockMessage(`Could not unlock: ${error.message}`, "error");
      });
    });
  }
  if (lockButton) {
    lockButton.addEventListener("click", () => {
      lockManager(true);
      setUnlockMessage("Community Manager locked on this device.", "");
    });
  }

  loadButton.addEventListener("click", () => {
    loadInventory().catch((error) => setMessage(`Could not load assets: ${error.message}`, "error"));
  });
  audioForm.addEventListener("submit", (event) => {
    uploadAudio(event).catch((error) => setMessage(`Audio upload failed: ${error.message}`, "error"));
  });
  themeForm.addEventListener("submit", (event) => {
    uploadTheme(event).catch((error) => setMessage(`Theme upload failed: ${error.message}`, "error"));
  });
  if (saveThemeMetadataButton) {
    saveThemeMetadataButton.addEventListener("click", () => {
      saveThemeMetadata().catch((error) => setMessage(`Theme details save failed: ${error.message}`, "error"));
    });
  }
  if (themeFolderInput) {
    themeFolderInput.addEventListener("change", () => {
      uploadThemeFolder(themeFolderInput.files).catch((error) => setMessage(`Theme folder upload failed: ${error.message}`, "error"));
    });
  }
  if (themeDropZone) {
    themeDropZone.addEventListener("click", () => themeFolderInput && themeFolderInput.click());
    themeDropZone.addEventListener("dragover", (event) => {
      event.preventDefault();
      themeDropZone.classList.add("is-drag-over");
    });
    themeDropZone.addEventListener("dragleave", () => {
      themeDropZone.classList.remove("is-drag-over");
    });
    themeDropZone.addEventListener("drop", (event) => {
      event.preventDefault();
      themeDropZone.classList.remove("is-drag-over");
      uploadThemeFolder(event.dataTransfer.files).catch((error) => setMessage(`Theme folder upload failed: ${error.message}`, "error"));
    });
  }
  if (eventForm) {
    eventForm.addEventListener("submit", (event) => {
      saveEventForm(event).catch((error) => setMessage(`Event save failed: ${error.message}`, "error"));
    });
  }
  if (newEventButton) {
    newEventButton.addEventListener("click", resetEventForm);
  }
  if (cancelEventEdit) {
    cancelEventEdit.addEventListener("click", resetEventForm);
  }
})();
