# TCWA3 Launcher Themes

Launcher themes are prepared as folders under this directory. Each custom theme
gets its own folder with a `theme.json` file and whatever art it needs.

Example:

```json
{
  "id": "104th",
  "name": "104th Wolfpack",
  "description": "104th legion launcher theme.",
  "accent_color": "#9aa4ad",
  "logo": "logo.png",
  "backgrounds": [
    "backgrounds/wolfpack-01.png",
    "backgrounds/wolfpack-02.png"
  ]
}
```

The backend exposes valid themes through `GET /v1/themes`. The built-in starter
themes are `tcw_standard`, `dark`, and `light`; legion folders can be added as
soon as the artwork is ready.
