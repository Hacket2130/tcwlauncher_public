(function () {
  const apiBaseUrl = "https://api.tcwa3.co.uk";
  const tokenStorageKey = "tcwa3_profile_access_token";
  const creditsText = document.getElementById("marketplaceCredits");
  const statusText = document.getElementById("marketplaceStatus");
  const refreshButton = document.getElementById("marketplaceRefresh");
  const categoryTabs = document.getElementById("marketplaceCategoryTabs");
  const grid = document.getElementById("marketplaceGrid");

  let marketplace = { categories: [], items: [] };
  let activeCategory = "all";

  function token() {
    return localStorage.getItem(tokenStorageKey) || "";
  }

  function headers() {
    const result = { "Content-Type": "application/json" };
    if (token()) {
      result.Authorization = `Bearer ${token()}`;
    }
    return result;
  }

  function setStatus(message, state) {
    statusText.textContent = message;
    statusText.dataset.state = state || "";
  }

  async function api(path, options) {
    const response = await fetch(new URL(path, apiBaseUrl), {
      cache: "no-store",
      ...options,
      headers: { ...headers(), ...(options && options.headers ? options.headers : {}) },
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const message = data.message || data.error || `Request failed (${response.status})`;
      const error = new Error(message);
      error.status = response.status;
      throw error;
    }
    return data;
  }

  async function loadMarketplace() {
    setStatus("Checking the TCWA3 marketplace...", "");
    grid.replaceChildren(emptyCard("Loading marketplace items..."));
    try {
      marketplace = await api("/v1/marketplace", { method: "GET" });
      render();
      if (token()) {
        creditsText.textContent = `${number(marketplace.credits)} Credits`;
        setStatus("Signed in. Purchases will be stored against your Steam-linked TCWA3 profile.", "ok");
      } else {
        creditsText.textContent = "Sign in to view credits";
        setStatus("Browse is public. Sign in through Profile before purchasing items.", "");
      }
    } catch (error) {
      creditsText.textContent = "Store offline";
      setStatus(`Could not load the marketplace: ${error.message}`, "error");
      grid.replaceChildren(emptyCard("Marketplace is temporarily unavailable."));
    }
  }

  function render() {
    renderCategories();
    renderItems();
  }

  function renderCategories() {
    const categories = Array.isArray(marketplace.categories) ? marketplace.categories : [];
    categoryTabs.replaceChildren();
    categoryTabs.appendChild(categoryButton("all", "All Items"));
    categories.forEach((category) => {
      categoryTabs.appendChild(categoryButton(category.id, category.name || category.id));
    });
  }

  function categoryButton(id, label) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = id === activeCategory ? "active" : "";
    button.textContent = label;
    button.addEventListener("click", () => {
      activeCategory = id;
      render();
    });
    return button;
  }

  function renderItems() {
    const items = Array.isArray(marketplace.items) ? marketplace.items : [];
    const visibleItems = activeCategory === "all" ? items : items.filter((item) => item.category === activeCategory);
    grid.replaceChildren();
    if (!visibleItems.length) {
      grid.appendChild(emptyCard("No items have been added to this category yet."));
      return;
    }
    visibleItems.forEach((item) => grid.appendChild(itemCard(item)));
  }

  function itemCard(item) {
    const card = document.createElement("article");
    card.className = "marketplace-item-card";

    const visual = document.createElement("div");
    visual.className = "marketplace-item-visual";
    if (item.image_url) {
      const image = document.createElement("img");
      image.src = item.image_url;
      image.alt = `${item.name || "Marketplace item"} preview`;
      visual.appendChild(image);
    } else {
      visual.textContent = "TCW";
    }

    const top = document.createElement("div");
    top.className = "marketplace-item-top";
    const title = document.createElement("h2");
    title.textContent = item.name || item.id;
    const price = document.createElement("strong");
    price.textContent = `${number(item.cost)} Credits`;
    top.append(title, price);

    const copy = document.createElement("p");
    copy.textContent = item.description || "Approved TCWA3 item awaiting kit-system details.";

    const meta = document.createElement("div");
    meta.className = "marketplace-item-meta";
    meta.appendChild(chip(categoryName(item.category)));
    if (item.class_name) {
      meta.appendChild(chip(item.class_name));
    }
    if (item.one_time) {
      meta.appendChild(chip("One-time"));
    }

    const button = document.createElement("button");
    button.type = "button";
    button.className = "marketplace-buy-button";
    if (!token()) {
      button.textContent = "Sign in to buy";
      button.disabled = true;
    } else if (item.owned) {
      button.textContent = "Owned";
      button.disabled = true;
    } else if (!item.enabled) {
      button.textContent = "Unavailable";
      button.disabled = true;
    } else {
      button.textContent = "Purchase";
      button.addEventListener("click", () => purchase(item.id, button));
    }

    card.append(visual, top, copy, meta, button);
    return card;
  }

  function categoryName(id) {
    const category = (marketplace.categories || []).find((item) => item.id === id);
    return category ? category.name : id;
  }

  function chip(value) {
    const span = document.createElement("span");
    span.textContent = value;
    return span;
  }

  function emptyCard(text) {
    const card = document.createElement("article");
    card.className = "marketplace-empty-card";
    card.textContent = text;
    return card;
  }

  async function purchase(itemId, button) {
    button.disabled = true;
    button.textContent = "Purchasing...";
    try {
      const data = await api("/v1/marketplace/purchase", {
        method: "POST",
        body: JSON.stringify({ item_id: itemId }),
      });
      marketplace = data.marketplace || marketplace;
      creditsText.textContent = `${number(marketplace.credits)} Credits`;
      setStatus("Purchase saved to your backend profile.", "ok");
      render();
    } catch (error) {
      setStatus(`Purchase failed: ${error.message}`, "error");
      button.disabled = false;
      button.textContent = "Purchase";
    }
  }

  function number(value) {
    const parsed = Number(value || 0);
    return Number.isFinite(parsed) ? parsed.toLocaleString("en-GB") : "0";
  }

  refreshButton.addEventListener("click", loadMarketplace);
  loadMarketplace();
})();
