(function () {
  const apiBaseUrl = "https://api.tcwa3.co.uk";
  const videoFrame = document.getElementById("latestVideoFrame");
  const videoTitle = document.getElementById("latestVideoTitle");
  const videoLink = document.getElementById("latestVideoLink");
  const newsList = document.getElementById("communityNewsList");
  const eventDock = document.getElementById("eventBannerDock");
  const radioTrackCount = document.getElementById("holonetTrackCount");
  const radioTrackTitle = document.getElementById("holonetTrackTitle");
  const radioPrevious = document.getElementById("holonetPrevious");
  const radioPlay = document.getElementById("holonetPlay");
  const radioNext = document.getElementById("holonetNext");
  const radioVolume = document.getElementById("holonetVolume");
  const radioPlayer = new Audio();
  const radioVolumeStorageKey = "tcwa3_holonet_radio_volume";
  let radioTracks = [];
  let activeRadioIndex = 0;
  let radioIsPlaying = false;
  let eventPopupShown = false;

  radioPlayer.preload = "metadata";
  const savedRadioVolume = Number(localStorage.getItem(radioVolumeStorageKey));
  if (radioVolume && Number.isFinite(savedRadioVolume) && savedRadioVolume >= 0 && savedRadioVolume <= 100) {
    radioVolume.value = String(savedRadioVolume);
  }
  radioPlayer.volume = Number(radioVolume ? radioVolume.value : 65) / 100;

  function setVideoFallback() {
    if (videoTitle) {
      videoTitle.textContent = "Latest TCWA3 video";
    }
    if (videoLink) {
      videoLink.href = "https://www.youtube.com/@TheCloneWarsArma-3";
      videoLink.textContent = "Open YouTube";
    }
    if (videoFrame) {
      videoFrame.hidden = true;
      videoFrame.removeAttribute("src");
    }
  }

  async function loadLatestVideo() {
    try {
      const response = await fetch(new URL("/v1/youtube/latest", apiBaseUrl), { cache: "no-store" });
      if (!response.ok) {
        throw new Error("video request failed");
      }
      const video = await response.json();
      if (!video.available || !video.embed_url) {
        setVideoFallback();
        return;
      }
      videoTitle.textContent = video.title || "Latest TCWA3 video";
      videoLink.href = video.url || video.channel_url || "https://www.youtube.com/@TheCloneWarsArma-3";
      videoLink.textContent = "Open on YouTube";
      videoFrame.src = video.embed_url;
      videoFrame.hidden = false;
    } catch (_error) {
      setVideoFallback();
    }
  }

  function renderNews(items) {
    newsList.replaceChildren();
    items.slice(0, 3).forEach((item) => {
      const entry = document.createElement("article");
      entry.className = "community-news-item";
      const title = document.createElement("h3");
      title.textContent = item.title || "Community update";
      const body = document.createElement("p");
      body.textContent = item.body || "";
      entry.append(title, body);
      if (item.link) {
        const link = document.createElement("a");
        link.href = item.link;
        link.textContent = "Read more";
        link.rel = "noopener noreferrer";
        entry.appendChild(link);
      }
      newsList.appendChild(entry);
    });
  }

  async function loadNews() {
    try {
      const response = await fetch(new URL("/v1/news", apiBaseUrl), { cache: "no-store" });
      if (!response.ok) {
        throw new Error("news request failed");
      }
      const payload = await response.json();
      const items = Array.isArray(payload.items) ? payload.items : [];
      renderNews(items.length ? items : [{ title: "Community Updates", body: "Latest TCWA3 news will appear here." }]);
    } catch (_error) {
      renderNews([{ title: "Community Updates", body: "Latest TCWA3 news will appear here." }]);
    }
  }

  function eventAccent(event) {
    return /^#[0-9a-f]{6}$/i.test(event.accent_color || "") ? event.accent_color : "#d9b36c";
  }

  function eventBackground(event) {
    return /^#[0-9a-f]{6}$/i.test(event.background_color || "") ? event.background_color : "#070b12";
  }

  function effectClass(event) {
    const effect = String(event.effect || "glow").toLowerCase();
    return ["none", "glow", "pulse", "scanline", "urgent"].includes(effect) ? `event-effect-${effect}` : "event-effect-glow";
  }

  function createEventCard(event, modifiers, compact) {
    const card = document.createElement("article");
    card.className = `event-banner-card ${effectClass(event)}${compact ? " event-banner-compact" : ""}`;
    card.style.setProperty("--event-accent", eventAccent(event));
    card.style.setProperty("--event-bg", eventBackground(event));

    const eyebrow = document.createElement("p");
    eyebrow.className = "event-banner-eyebrow";
    eyebrow.textContent = "Live Event";

    const title = document.createElement("h2");
    title.textContent = event.title || "Community Event";

    const description = document.createElement("p");
    description.className = "event-banner-description";
    description.textContent = event.description || "";

    const xpBonus = Number((modifiers && modifiers.xp_bonus_percent) || event.xp_bonus_percent || 0);
    card.append(eyebrow, title);
    if (xpBonus > 0) {
      const modifier = document.createElement("strong");
      modifier.className = "event-banner-modifier";
      modifier.textContent = `+${xpBonus}% XP active`;
      card.appendChild(modifier);
    }
    if (description.textContent) {
      card.appendChild(description);
    }
    return card;
  }

  function renderEvents(events, modifiers) {
    if (!eventDock) {
      return;
    }
    eventDock.replaceChildren();
    const activeEvents = Array.isArray(events) ? events : [];
    if (!activeEvents.length) {
      eventDock.hidden = true;
      return;
    }
    eventDock.hidden = false;
    eventDock.appendChild(createEventCard(activeEvents[0], modifiers, true));
    if (!eventPopupShown) {
      eventPopupShown = true;
      showEventPopup(activeEvents[0], modifiers);
    }
  }

  function showEventPopup(event, modifiers) {
    const popup = document.createElement("aside");
    popup.className = "event-banner-popup";
    popup.appendChild(createEventCard(event, modifiers, false));
    document.body.appendChild(popup);
    requestAnimationFrame(() => popup.classList.add("event-banner-popup-visible"));
    window.setTimeout(() => {
      popup.classList.remove("event-banner-popup-visible");
      popup.classList.add("event-banner-popup-dismissing");
      window.setTimeout(() => popup.remove(), 800);
    }, 5200);
  }

  async function loadEvents() {
    try {
      const response = await fetch(new URL("/v1/events", apiBaseUrl), { cache: "no-store" });
      if (!response.ok) {
        throw new Error("events request failed");
      }
      const payload = await response.json();
      renderEvents(payload.events || [], payload.modifiers || {});
    } catch (_error) {
      renderEvents([], {});
    }
  }

  function setRadioEnabled(enabled) {
    [radioPrevious, radioPlay, radioNext, radioVolume].forEach((control) => {
      if (control) {
        control.disabled = !enabled;
      }
    });
  }

  function setRadioTrack(index) {
    if (!radioTracks.length) {
      return;
    }
    activeRadioIndex = (index + radioTracks.length) % radioTracks.length;
    const track = radioTracks[activeRadioIndex];
    radioPlayer.src = track.url;
    if (radioTrackTitle) {
      radioTrackTitle.textContent = track.title || track.filename || "Holonet transmission";
    }
    if (radioTrackCount) {
      radioTrackCount.textContent = `${activeRadioIndex + 1} / ${radioTracks.length}`;
    }
  }

  async function playRadio() {
    if (!radioTracks.length) {
      return;
    }
    try {
      if (!radioPlayer.src) {
        setRadioTrack(activeRadioIndex);
      }
      await radioPlayer.play();
      radioIsPlaying = true;
      radioPlay.textContent = "Pause";
      radioPlay.setAttribute("aria-pressed", "true");
    } catch (_error) {
      radioIsPlaying = false;
      radioPlay.textContent = "Play";
      radioPlay.setAttribute("aria-pressed", "false");
      if (radioTrackTitle) {
        radioTrackTitle.textContent = "Press Play again to start the Holonet radio.";
      }
    }
  }

  function pauseRadio() {
    radioPlayer.pause();
    radioIsPlaying = false;
    if (radioPlay) {
      radioPlay.textContent = "Play";
      radioPlay.setAttribute("aria-pressed", "false");
    }
  }

  function moveRadio(offset) {
    if (!radioTracks.length) {
      return;
    }
    const shouldResume = radioIsPlaying;
    pauseRadio();
    setRadioTrack(activeRadioIndex + offset);
    if (shouldResume) {
      playRadio();
    }
  }

  async function loadHolonetRadio() {
    setRadioEnabled(false);
    try {
      const response = await fetch(new URL("/v1/audio", apiBaseUrl), { cache: "no-store" });
      if (!response.ok) {
        throw new Error("audio request failed");
      }
      const payload = await response.json();
      const category = payload.categories && payload.categories.holonet_radio ? payload.categories.holonet_radio : {};
      radioTracks = Array.isArray(category.tracks) ? category.tracks.filter((track) => track && track.url) : [];
      if (!radioTracks.length) {
        if (radioTrackCount) {
          radioTrackCount.textContent = "Offline";
        }
        if (radioTrackTitle) {
          radioTrackTitle.textContent = "No Holonet transmissions have been uploaded yet.";
        }
        return;
      }
      setRadioTrack(0);
      setRadioEnabled(true);
    } catch (_error) {
      if (radioTrackCount) {
        radioTrackCount.textContent = "Offline";
      }
      if (radioTrackTitle) {
        radioTrackTitle.textContent = "Holonet radio is unavailable right now.";
      }
    }
  }

  if (radioPlay) {
    radioPlay.addEventListener("click", () => {
      if (radioIsPlaying) {
        pauseRadio();
      } else {
        playRadio();
      }
    });
  }
  if (radioPrevious) {
    radioPrevious.addEventListener("click", () => moveRadio(-1));
  }
  if (radioNext) {
    radioNext.addEventListener("click", () => moveRadio(1));
  }
  if (radioVolume) {
    radioVolume.addEventListener("input", () => {
      radioPlayer.volume = Number(radioVolume.value || 0) / 100;
      localStorage.setItem(radioVolumeStorageKey, radioVolume.value);
    });
  }
  radioPlayer.addEventListener("ended", () => moveRadio(1));

  loadLatestVideo();
  loadNews();
  loadEvents();
  loadHolonetRadio();
})();
