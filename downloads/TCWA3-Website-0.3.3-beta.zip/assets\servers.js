(function () {
  const apiBaseUrl = "https://api.tcwa3.co.uk";
  const armaSteamAppId = "107410";
  const serverPassword = "TCW";

  const servers = {
    tcw_roleplay_1: { name: "TCW Roleplay Server 1", ip: "144.48.104.82", port: 2311 },
    tcw_germany_1: { name: "TCW Germany Server 1", ip: "46.4.103.189", port: 2306 },
    tcw_germany_2: { name: "TCW Germany Server 2", ip: "46.4.103.189", port: 2316 },
    tcw_germany_3: { name: "TCW Germany Server 3", ip: "46.4.103.189", port: 2326 },
    tcw_germany_4: { name: "TCW Germany Server 4", ip: "176.9.116.6", port: 2316 },
    tcw_germany_5: { name: "TCW Germany Server 5", ip: "46.4.103.189", port: 2346 },
    tcw_germany_6: { name: "TCW Germany Server 6", ip: "148.251.237.60", port: 2336 },
    tcw_germany_7: { name: "TCW Germany Server 7", ip: "148.251.237.60", port: 2341 },
    tcw_germany_8: { name: "TCW Germany Server 8", ip: "148.251.237.60", port: 2346 },
    tcw_england_1: { name: "TCW England Server 1", ip: "104.234.251.163", port: 2316 },
    tcw_england_2: { name: "TCW England Server 2", ip: "104.234.251.169", port: 2316 },
    tcw_england_3: { name: "TCW England Server 3", ip: "104.234.251.169", port: 2321 },
    tcw_australia_2: { name: "TCW Australia Server 2", ip: "103.1.214.18", port: 2321 },
    tcw_australia_3: { name: "TCW Australia Server 3", ip: "103.1.214.18", port: 2326 },
    tcw_singapore_1: { name: "TCW Singapore Server 1", ip: "23.106.54.134", port: 2306 },
    tcw_singapore_2: { name: "TCW Singapore Server 2", ip: "14.1.30.100", port: 2346 },
    tcw_singapore_4: { name: "TCW Singapore Server 4", ip: "14.1.30.100", port: 2351 },
    tcw_us_east_1: { name: "TCW US East Server 1", ip: "115.42.46.220", port: 2311 },
    tcw_us_east_2: { name: "TCW US East Server 2", ip: "115.42.46.220", port: 2316 },
    tcw_us_east_3: { name: "TCW US East Server 3", ip: "115.42.46.220", port: 2321 },
    tcw_us_east_4: { name: "TCW US East Server 4", ip: "115.42.46.130", port: 2316 },
    tcw_us_east_8: { name: "TCW US East Server 8", ip: "136.175.187.97", port: 2306 },
    tcw_us_east_9: { name: "TCW US East Server 9", ip: "136.175.187.97", port: 2336 },
    tcw_us_east_10: { name: "TCW US East Server 10", ip: "136.175.187.97", port: 2341 },
    tcw_us_east_11: { name: "TCW US East Server 11", ip: "136.175.187.68", port: 2321 },
    tcw_us_east_12: { name: "TCW US East Server 12", ip: "136.175.187.68", port: 2326 },
    tcw_us_east_14: { name: "TCW US East Server 14", ip: "198.73.57.174", port: 2306 },
    tcw_us_east_15: { name: "TCW US East Server 15", ip: "198.73.57.172", port: 2306 },
    tcw_us_east_16: { name: "TCW US East Server 16", ip: "198.73.57.179", port: 2316 },
    tcw_us_west_1: { name: "TCW US West Server 1", ip: "199.60.101.91", port: 2311 },
    tcw_us_west_2: { name: "TCW US West Server 2", ip: "104.192.227.2", port: 2306 },
    tcw_us_west_4: { name: "TCW US West Server 4", ip: "104.192.227.30", port: 2326 },
    tcw_us_central_2: { name: "TCW US Central Server 2", ip: "144.48.106.189", port: 2306 },
    tcw_us_central_3: { name: "TCW US Central Server 3", ip: "66.151.242.114", port: 2326 },
    tcw_us_central_6: { name: "TCW US Central Server 6", ip: "216.105.171.156", port: 2306 },
    tcw_us_central_8: { name: "TCW US Central Server 8", ip: "198.73.57.178", port: 2306 },
    tcw_us_central_9: { name: "TCW US Central Server 9", ip: "216.105.171.146", port: 2306 },
    tcw_us_central_10: { name: "TCW US Central Server 10", ip: "144.48.104.82", port: 2326 },
    tcw_us_central_11: { name: "TCW US Central Server 11", ip: "216.245.176.212", port: 2361 },
    tcw_us_central_12: { name: "TCW US Central Server 12", ip: "216.245.176.212", port: 2356 },
    tcw_us_central_13: { name: "TCW US Central Server 13", ip: "216.245.176.212", port: 2351 },
    tcw_us_central_14: { name: "TCW US Central Server 14", ip: "216.245.176.212", port: 2346 },
    tcw_us_central_15: { name: "TCW US Central Server 15", ip: "216.245.176.212", port: 2336 },
    tcw_us_central_16: { name: "TCW US Central Server 16", ip: "216.245.176.212", port: 2331 },
    tcw_us_central_17: { name: "TCW US Central Server 17", ip: "216.245.176.212", port: 2326 },
    tcw_us_central_18: { name: "TCW US Central Server 18", ip: "216.105.171.156", port: 2316 },
    tcw_us_central_19: { name: "TCW US Central Server 19", ip: "216.105.171.156", port: 2321 },
    tcw_us_central_20: { name: "TCW US Central Server 20", ip: "144.48.104.90", port: 2331 },
    tcw_us_central_22: { name: "TCW US Central Server 22", ip: "216.245.176.148", port: 2316 },
    tcw_us_central_23: { name: "TCW US Central Server 23", ip: "216.245.177.37", port: 2336 },
    tcw_us_central_24: { name: "TCW Central Server 24", ip: "216.245.177.32", port: 2311 },
    tcw_us_central_26: { name: "TCW US Central Server 26", ip: "144.48.104.130", port: 2306 },
  };

  const categories = [
    { id: "all", name: "All Servers", servers: Object.keys(servers) },
    { id: "roleplay_global", name: "Global Roleplay", servers: ["tcw_roleplay_1"] },
    {
      id: "roleplay_us_central",
      name: "US Central Roleplay",
      servers: [
        "tcw_us_central_2",
        "tcw_us_central_3",
        "tcw_us_central_6",
        "tcw_us_central_8",
        "tcw_us_central_9",
        "tcw_us_central_10",
        "tcw_us_central_11",
        "tcw_us_central_12",
        "tcw_us_central_13",
        "tcw_us_central_14",
        "tcw_us_central_15",
        "tcw_us_central_16",
        "tcw_us_central_17",
        "tcw_us_central_18",
        "tcw_us_central_19",
        "tcw_us_central_20",
        "tcw_us_central_22",
        "tcw_us_central_23",
        "tcw_us_central_24",
        "tcw_us_central_26",
      ],
    },
    {
      id: "roleplay_us_east",
      name: "US East Roleplay",
      servers: [
        "tcw_us_east_1",
        "tcw_us_east_2",
        "tcw_us_east_3",
        "tcw_us_east_4",
        "tcw_us_east_8",
        "tcw_us_east_9",
        "tcw_us_east_10",
        "tcw_us_east_11",
        "tcw_us_east_12",
        "tcw_us_east_14",
        "tcw_us_east_15",
        "tcw_us_east_16",
      ],
    },
    { id: "roleplay_us_west", name: "US West Roleplay", servers: ["tcw_us_west_1", "tcw_us_west_2", "tcw_us_west_4"] },
    {
      id: "roleplay_germany",
      name: "Germany Roleplay",
      servers: [
        "tcw_germany_1",
        "tcw_germany_2",
        "tcw_germany_3",
        "tcw_germany_4",
        "tcw_germany_5",
        "tcw_germany_6",
        "tcw_germany_7",
        "tcw_germany_8",
      ],
    },
    { id: "roleplay_england", name: "England Roleplay", servers: ["tcw_england_1", "tcw_england_2", "tcw_england_3"] },
    { id: "roleplay_singapore", name: "Singapore Roleplay", servers: ["tcw_singapore_1", "tcw_singapore_2", "tcw_singapore_4"] },
    { id: "roleplay_australia", name: "Australia Roleplay", servers: ["tcw_australia_2", "tcw_australia_3"] },
  ];

  const filters = document.getElementById("serverFilters");
  const grid = document.getElementById("serverGrid");
  const statusCopy = document.getElementById("serverStatus");
  let activeCategory = "all";

  function getServerKeys() {
    return categories.find((category) => category.id === activeCategory).servers;
  }

  function armaLaunchUrl(server) {
    const args = [`-connect=${server.ip}`, `-port=${server.port}`];
    if (serverPassword) {
      args.push(`-password=${serverPassword}`);
    }
    return `steam://run/${armaSteamAppId}//${encodeURIComponent(args.join(" "))}/`;
  }

  function steamServerInfoUrl(server) {
    return `steam://connect/${server.ip}:${server.port}/${encodeURIComponent(serverPassword)}`;
  }

  function directConnectText(server) {
    return `Arma 3 launch options: -connect=${server.ip} -port=${server.port} -password=${serverPassword}`;
  }

  function renderFilters() {
    filters.replaceChildren();
    for (const category of categories) {
      const button = document.createElement("button");
      button.className = `filter-button${category.id === activeCategory ? " active" : ""}`;
      button.type = "button";
      button.textContent = category.name;
      button.addEventListener("click", () => {
        activeCategory = category.id;
        renderFilters();
        renderServers();
      });
      filters.appendChild(button);
    }
  }

  function renderServers() {
    const keys = getServerKeys();
    grid.replaceChildren();
    statusCopy.textContent = `${keys.length} official server${keys.length === 1 ? "" : "s"} listed`;

    for (const key of keys) {
      const server = servers[key];
      const card = document.createElement("article");
      card.className = "server-card";
      card.dataset.serverKey = key;
      card.innerHTML = `
        <div class="server-card-top">
          <span class="status-pill status-checking">Checking</span>
          <span class="server-region">${regionName(server.name)}</span>
        </div>
        <h2>${escapeHtml(server.name)}</h2>
        <p class="server-address">${server.ip}:${server.port}</p>
        <dl class="server-meta">
          <div><dt>Players</dt><dd data-field="players">?/ ?</dd></div>
          <div><dt>Mission</dt><dd data-field="mission">Loading...</dd></div>
        </dl>
        <div class="server-actions">
          <a class="join-server join-server-disabled" href="#" data-join-url="${armaLaunchUrl(server)}" data-server-info-url="${steamServerInfoUrl(server)}" aria-disabled="true" tabindex="-1">Checking...</a>
          <button class="copy-server" type="button">Copy Details</button>
        </div>
      `;
      card.querySelector(".join-server").addEventListener("click", (event) => {
        const link = event.currentTarget;
        if (link.getAttribute("aria-disabled") === "true") {
          event.preventDefault();
          return;
        }
        link.textContent = "Launching Arma 3...";
        window.setTimeout(() => {
          if (link.getAttribute("aria-disabled") !== "true") {
            link.textContent = "Join Server";
          }
        }, 2400);
      });
      card.querySelector(".copy-server").addEventListener("click", async (event) => {
        await copyServerDetails(server, event.currentTarget);
      });
      grid.appendChild(card);
    }

    refreshStatuses(keys);
  }

  async function refreshStatuses(keys) {
    for (const key of keys) {
      await updateServerStatus(key);
    }
  }

  async function updateServerStatus(key) {
    const server = servers[key];
    const card = grid.querySelector(`[data-server-key="${key}"]`);
    if (!server || !card) {
      return;
    }

    const url = new URL("/v1/server-status", apiBaseUrl);
    url.searchParams.set("ip", server.ip);
    url.searchParams.set("port", String(server.port));
    url.searchParams.set("name", server.name);

    try {
      const response = await fetch(url, { cache: "no-store" });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const data = await response.json();
      setServerStatus(card, data);
    } catch (_error) {
      setServerStatus(card, { status: "unknown", players: 0, max_players: 0, mission: "Unavailable" });
    }
  }

  function setServerStatus(card, data) {
    const status = String(data.status || "unknown").toLowerCase();
    const pill = card.querySelector(".status-pill");
    const players = card.querySelector('[data-field="players"]');
    const mission = card.querySelector('[data-field="mission"]');
    const join = card.querySelector(".join-server");
    const maxPlayers = Number(data.max_players || 0);
    const playerCount = Number(data.players || 0);
    const online = status === "online";

    pill.className = `status-pill status-${status}`;
    pill.textContent = status === "online" ? "Online" : status === "offline" ? "Offline" : "Unknown";
    players.textContent = maxPlayers > 0 ? `${playerCount}/${maxPlayers}` : "?/?";
    mission.textContent = data.mission || "Unavailable";
    mission.title = data.mission || "Unavailable";
    join.classList.toggle("join-server-disabled", !online);
    join.setAttribute("aria-disabled", online ? "false" : "true");
    join.tabIndex = online ? 0 : -1;
    join.href = online ? join.dataset.joinUrl : "#";
    join.textContent = online ? "Join Server" : status === "offline" ? "Server Offline" : "Unavailable";
  }

  async function copyServerDetails(server, button) {
    const text = directConnectText(server);
    try {
      await navigator.clipboard.writeText(text);
      button.textContent = "Copied";
      setTimeout(() => {
        button.textContent = "Copy Details";
      }, 1400);
    } catch (_error) {
      window.prompt("Copy server details", text);
    }
  }

  function regionName(name) {
    if (name.includes("Germany")) return "Germany";
    if (name.includes("England")) return "England";
    if (name.includes("Australia")) return "Australia";
    if (name.includes("Singapore")) return "Singapore";
    if (name.includes("US East")) return "US East";
    if (name.includes("US West")) return "US West";
    if (name.includes("US Central") || name.includes("Central")) return "US Central";
    return "Global";
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  renderFilters();
  renderServers();
})();
