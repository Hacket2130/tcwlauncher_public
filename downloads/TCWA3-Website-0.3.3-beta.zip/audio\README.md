# TCWA3 Launcher Audio

Drop public launcher audio files into these folders on the server:

- `menu_music/`: MP3 background music for the launcher main menu.
- `menu_sounds/`: short MP3 button/UI sounds.
- `holonet_radio/`: longer MP3 tracks for the Holonet radio controls.

The backend exposes these files through `GET /v1/audio`. The launcher downloads
and caches tracks locally, so new files can be added without rebuilding the app.

Keep file names readable because the launcher turns names like
`republic-march.mp3` into player-facing titles such as `Republic March`.
