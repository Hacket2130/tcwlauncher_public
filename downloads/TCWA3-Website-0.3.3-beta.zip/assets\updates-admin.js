(function () {
  const apiBaseUrl = "https://api.tcwa3.co.uk";
  const storageKey = "tcwa3_updates_admin_key";
  const form = document.getElementById("updatesForm");
  const list = document.getElementById("updatesList");
  const tokenInput = document.getElementById("adminToken");
  const rememberKey = document.getElementById("rememberKey");
  const loadButton = document.getElementById("loadCurrent");
  const addButton = document.getElementById("addUpdate");
  const message = document.getElementById("editorMessage");
  let items = [];

  function blankItem() {
    return {
      title: "Operation Update",
      body: "Add the update text here.",
      date: new Date().toISOString().slice(0, 10),
      priority: 10,
      link: "",
    };
  }

  function setMessage(text, state) {
    message.textContent = text;
    message.dataset.state = state || "";
  }

  function render() {
    list.replaceChildren();
    items.forEach((item, index) => {
      const card = document.createElement("article");
      card.className = "update-edit-card";
      card.innerHTML = `
        <div class="update-edit-header">
          <h2>Update ${index + 1}</h2>
          <button type="button" class="remove-update">Remove</button>
        </div>
        <label>
          <span>Title</span>
          <input data-field="title" value="${escapeAttribute(item.title)}" maxlength="80">
        </label>
        <label>
          <span>Body</span>
          <textarea data-field="body" maxlength="500" rows="4">${escapeHtml(item.body)}</textarea>
        </label>
        <div class="two-column-fields">
          <label>
            <span>Date</span>
            <input data-field="date" value="${escapeAttribute(item.date)}" placeholder="2026-06-19" maxlength="32">
          </label>
          <label>
            <span>Priority</span>
            <input data-field="priority" type="number" value="${Number(item.priority || 0)}" min="0" max="100">
          </label>
        </div>
        <label>
          <span>Optional link</span>
          <input data-field="link" value="${escapeAttribute(item.link || "")}" placeholder="https://..." maxlength="300">
        </label>
        <section class="update-preview" aria-label="Launcher preview">
          <strong>Launcher preview</strong>
          <p>${escapeHtml(previewText(item))}</p>
        </section>
      `;
      card.querySelector(".remove-update").addEventListener("click", () => {
        items.splice(index, 1);
        if (items.length === 0) {
          items.push(blankItem());
        }
        render();
      });
      card.querySelectorAll("[data-field]").forEach((field) => {
        field.addEventListener("input", () => {
          const key = field.dataset.field;
          items[index][key] = key === "priority" ? Number(field.value || 0) : field.value;
          const preview = card.querySelector(".update-preview p");
          preview.textContent = previewText(items[index]);
        });
      });
      list.appendChild(card);
    });
  }

  function previewText(item) {
    const title = String(item.title || "Update").trim();
    const body = String(item.body || "").trim();
    return `• ${title}${body ? ` — ${body}` : ""}`;
  }

  async function loadCurrent() {
    setMessage("Loading current launcher updates...", "");
    try {
      const response = await fetch(new URL("/v1/news", apiBaseUrl), { cache: "no-store" });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const data = await response.json();
      items = Array.isArray(data.items) && data.items.length ? data.items : [blankItem()];
      render();
      setMessage("Current launcher updates loaded.", "ok");
    } catch (_error) {
      setMessage("Could not load the live updates. You can still create a new set and save it.", "error");
      items = [blankItem()];
      render();
    }
  }

  async function saveUpdates(event) {
    event.preventDefault();
    const token = tokenInput.value.trim();
    if (!token) {
      setMessage("Enter the private update key before saving.", "error");
      return;
    }
    if (rememberKey.checked) {
      localStorage.setItem(storageKey, token);
    } else {
      localStorage.removeItem(storageKey);
    }
    setMessage("Saving updates to the launcher feed...", "");
    try {
      const response = await fetch(new URL("/v1/admin/news", apiBaseUrl), {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ items }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data.message || data.error || `HTTP ${response.status}`);
      }
      items = Array.isArray(data.items) && data.items.length ? data.items : items;
      render();
      setMessage("Saved. Players will see this in the launcher on the next update refresh.", "ok");
    } catch (error) {
      setMessage(`Save failed: ${error.message}`, "error");
    }
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function escapeAttribute(value) {
    return escapeHtml(value).replace(/"/g, "&quot;");
  }

  const savedToken = localStorage.getItem(storageKey);
  if (savedToken) {
    tokenInput.value = savedToken;
    rememberKey.checked = true;
  }

  addButton.addEventListener("click", () => {
    items.unshift(blankItem());
    render();
    setMessage("New update added at the top.", "");
  });
  loadButton.addEventListener("click", loadCurrent);
  form.addEventListener("submit", saveUpdates);
  loadCurrent();
})();
